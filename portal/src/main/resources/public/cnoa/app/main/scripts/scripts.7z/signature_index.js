var CNOA_main_signature, CNOA_main_signatureClass;

//主面板
CNOA_main_signatureClass = CNOA.Class.create();
CNOA_main_signatureClass.prototype = {
	init : function(){
		_this = this;

		this.graphPanel = new CNOA_main_signature_graphClass();
		
		this.centerPanel = new Ext.ux.VerticalTabPanel({
			region: 'center',
			border: false,
			tabWidth: 100,
			activeItem: 0,
			tabPosition: 'left',
			deferredRender: false,
			items: [
				this.graphPanel.mainPanel
			]
			
		});
		
		this.mainPanel = new Ext.Panel({
			border: false,
			layout: 'border',
			items: [this.centerPanel]
		});
	}
}