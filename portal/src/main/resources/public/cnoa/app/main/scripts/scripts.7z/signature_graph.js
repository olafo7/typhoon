var CNOA_main_signature_graphClass;

CNOA_main_signature_graphClass = CNOA.Class.create();
CNOA_main_signature_graphClass.prototype = {
	init : function(){
		var _this = this;
		
		this.baseUrl = "index.php?app=main&func=signature&action=index&model=graph";
		this.circleUrl = "index.php?app=main&func=signature&action=index&model=circle";
		
		this.graphFields = [
			{name: 'sid'},
			{name: 'username'},
			{name: 'signature'},
			{name: 'url'}
		];
		
		this.graphStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({url: this.baseUrl + '&task=getJsonDatas'}),
			reader: new Ext.data.JsonReader({totalProperty: 'total', root: 'data', fields: this.graphFields})
		});
		
		this.graphStore.load();
		
		this.graphSm = new Ext.grid.CheckboxSelectionModel({singleSelect: false});
		
		this.graphModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.graphSm,
			{header: 'sid', dataIndex: 'sid', hidden: true},
			{header: '用户名', dataIndex: 'username', width: 120},
			{header: '印章名', dataIndex: 'signature', width: 130},
			{header: '印章', dataIndex: 'url', id: 'signature', renderer: this.makePic.createDelegate(this)}
		]);
		
		this.graphGrid = new Ext.grid.PageGridPanel({
			cm: this.graphModel,
			sm: this.graphSm,
			store: this.graphStore,
			border: false,
			waitMsgTarget: true,
			autoExpandColumn: 'signature',
			tbar: new Ext.Toolbar({
				items: [
					{
						text: lang('refresh'),
						iconCls: 'icon-system-refresh',
						tooltip: lang('refresh'),
						handler: function(){
							_this.graphStore.reload();
						}
					},'-',
					{
						text: '制章',
						iconCls: 'icon-form-signature',
						tooltip: '制章',
						handler: function(){
							_this.makeSeal();
						}
					},
					{
						text: lang('add'),
						iconCls: 'icon-utils-s-add',
						tooltip: lang('add'),
						handler: function(){
							_this.addEditWindow('add', '');
						}
					},'-',
					{
						text: lang('modify'),
						iconCls: 'icon-utils-s-edit',
						tooltip: lang('modify'),
						handler: function(btn, e){
							var rows = _this.graphGrid.getSelectionModel().getSelections();
							if(rows.length == 0){
								var position = btn.getEl().getBox();
								position = [position['x']+12, position['y']+26];
								CNOA.miniMsg.alert(lang('mustSelectOneRow'), position);
							}else if(rows.length > 1){
								var position = btn.getEl().getBox();
								position = [position['x']+12, position['y']+26];
								CNOA.miniMsg.alert('修改时，只能选一条信息进行修改', position);
							}else{
								var id = rows[rows.length-1].id;
								_this.addEditWindow('edit', id);
								_this.loadForm(id);
							}
						}
						
					},'-',
					{
						text: lang('del'),
						iconCls: 'icon-utils-s-delete',
						tooltip: lang('del'),
						handler: function(btn, e){
							var rows = _this.graphGrid.getSelectionModel().getSelections();
							if(rows.length == 0){
								var position = btn.getEl().getBox();
								position = [position['x']+12, position['y']+26];
								CNOA.miniMsg.alert(lang('mustSelectOneRow'), position);
							}else{
								CNOA.msg.cf("确定要删除改签章吗？", function(btntext){
									if(btntext == 'yes'){
										if(rows){
											var ids = new Array();
											for(var i=0; i<rows.length; i++){
												ids[i] = rows[i].id;
											}
											_this.delSignature(ids.join(','));
										}
									}
								})
							}
						}
					}
				]
			})
		});
		
		this.mainPanel = new Ext.Panel({
			title: '图形签章',
			border: false,
			waitMsgTarget: true,
			autoScroll: true,
			layout: 'fit',
			labelWidth: 130,
			items: [this.graphGrid]
		});
	},
	
	makePic : function(value, cellmeta, record, rowIndex, columnIndex, color_store){
		return "<img src='"+value+"' onload='resizeImage(this, 90, 70)' />";
	},
		
	addEditWindow : function(ac, id){
		var _this = this;

		var title = ac=='edit' ? '修改签章' : '添加签章';
		
		this.form = new Ext.form.FormPanel({
			labelAlign: 'right',
			labelWidth: 70,
			border: false,
			fileUpload: true,
			autoHeight: true,
			bodyStyle: 'padding: 10px;',
			defaults: {style: 'margin-bottom: 10px;'},
			items: [
				{
					xtype: 'compositefield',
					items: [
						{
							xtype: 'textfield',
							fieldLabel: '用户名',
							name: 'name',
							allowBlank: false
						},
						{
							xtype: 'hidden',
							name: 'uid'
						},
						{
							xtype: 'btnForPoepleSelectorSingle',
							dataUrl: this.baseUrl + "&task=getAllUserListsInPermitDeptTree",
							text: '选择',
							listeners: {
								'selected' : function(th, data){
									_this.form.getForm().findField('name').setValue(data[0].uname);
									_this.form.getForm().findField('uid').setValue(data[0].uid);
								},
								'onrender' : function(th){
									th.setSelectedUids(_this.form.getForm().findField('uid').getValue().split(","));
								}
							}
						}
					]
					
				},
				{
					xtype: 'textfield',
					fieldLabel: '签章名',
					allowBlank: false,
					name: 'signature',
					style: 'margin-bottom: 5px;'
				},
				{
					xtype: 'fileuploadfield',
					name: 'image',
					fieldLabel: '签章',
					width: 220,
					buttonCfg: {
						text: '上传图片'
					}
				}
			]
		});
		
		this.win = new Ext.Window({
			title: title,
			modal: true,
			layout: 'fit',
			width: 350,
			//height: 250,
			resizable: false,
			items: [this.form],
			buttons: [
				{
					text: lang('save'),
					iconCls: 'icon-order-s-accept',
					handler: function(){
						submit();
					}
				},
				{
					text: lang('close'),
					iconCls: 'icon-dialog-cancel',
					handler: function(){
						_this.win.close();
					}
				}
			]
		}).show();
		
		var submit = function(){
			var f = _this.form.getForm();
			if(f.isValid()){
				f.submit({
					url: _this.baseUrl + "&task=addEditSignature",
					waitTitle: lang('notice'),
					method: 'POST',
					params: {id: id},
					waitMsg: lang('waiting'),
					success: function(form, action){
						_this.win.close();
						_this.graphStore.reload();
					},
					failure: function(form, action){
						CNOA.msg.alert(action.result.msg);
					}
				});
			}
		}
	},
	
	//制章
	makeSeal : function(){
		var _this = this;
		
		var makeSealPanel = new Ext.Panel({
			width: 400,
			height: 500,
			region: 'west',
			border: false,
			html: '<img id="sealImg" src="' + this.circleUrl + '&task=sealImg" style="margin: 100px;" />',
			listeners: {
				'afterlayout' : function(){
					var img = $("img:#sealImg");
					var parent = img.parent();
					var width = (parent.width()-42*3.78)/2;
					var height = (parent.height() - 42*3.78)/2;
					img.css({"margin-left": width, "margin-top": height});
				}
			}
		});
		
		//加载字体
		var fontStore =new Ext.data.JsonStore({  
		    url: this.circleUrl + "&task=loadFont",  
		    root: 'data',  
		    fields:[{name:'font'}, {name: 'url'}],
			listeners: {
				'load': function(th){
					var data = th.getRange()[0].data;
					var font = data.font;
					var url = data.url;
					Ext.getCmp('upCombo').setValue(font);
					Ext.getCmp('upFont').setValue(url);
					Ext.getCmp('croCombo').setValue(font);
					Ext.getCmp('croFont').setValue(url);
				}
			}
		});  
		fontStore.load();
		
		//加载内图
		var imgStore = new Ext.data.JsonStore({
			url: this.circleUrl + "&task=loadImg",
			root: 'data',
			fields: [{name: 'url'}, {name: 'name'}],
			listeners: {
				'load' : function(th){
					var data = th.getRange()[0].data;
					var url = data.url;
					var name = data.name;
					Ext.getCmp('inImg').setValue(name+'.png'); 
				}
			}
		});
		imgStore.load();
		
		var tpl = new Ext.XTemplate(
			'<tpl for=".">',
	            '<div class="thumb-wrap" id="{name}">',
			    '<div class="thumb"><img src="{url}" title="{name}"></div>',
			    '<span class="x-editable">{shortName}</span></div>',
	        '</tpl>',
	        '<div class="x-clear"></div>'
		);
		
		var sealTab = new Ext.TabPanel({
			activeTab: 0,
			height: 180,
			padding: 20,
//			deferredRender: false,
			defaults: {layout: 'form', defaultType: 'textfield', labelAlign: 'right', labelWidth: 60},
			items: [
				{
					title: '上炫文',
					defaults: {width: 230},
					items: [
						{
							fieldLabel: '文字内容',
							name: 'upText',
							value: '印章测试字符串',
							listeners: {
								'change' : function(){
									preView();
								}
							}
						},
						{
							xtype: 'combo',
							id: 'upCombo',
							editable: false,
							fieldLabel: '字体名称',
							mode: 'local',
							triggerAction: 'all',
							store: fontStore,
							displayField: 'font',
							valueField: 'url',
							listeners: {
								'select' : function(th){
									Ext.getCmp('upFont').setValue(th.getValue());
									preView();
								}
							}
						},
						{
							xtype: 'hidden',
							id: 'upFont',
							name: 'upFont'
						},
						{
							xtype: 'panel',
							layout: 'table',
							columns: 5,
							fieldLabel: '字体大小',
							items: [
								{
									xtype: 'spinnerfield',
									name:　'upFontHeight',
									width: 65,
									minValue: 0,
									allowDecimals: true,
									decimalPrecision: 2,
									incrementValue: 0.1,
									value: '4.2'
								},
								{
									xtype: 'displayfield',
									value: '毫米',
									style: 'margin-left: 5px; margin-right: 10px;'
								},
								{
									xtype: 'displayfield',
									value: '内移:'
								},
								{
									xtype: 'spinnerfield',
									name: 'inMove',
									width: 65,
									minValue: 0,
									allowDecimals: true,
									decimalPrecision: 2,
									incrementValue: 0.1,
									value: '1'
								},
								{
									xtype: 'displayfield',
									value: '毫米',
									style: 'margin-left: 5px;'
								}
							]
						},
						{
							xtype: 'panel',
							layout: 'table',
							columns: 2,
							fieldLabel: '占用角度',
							items: [
								{
									xtype: 'spinnerfield',
									name:　'uAngle',
									width: 65,
									minValue: 0,
									allowDecimals: true,
									decimalPrecision: 2,
									incrementValue: 1,
									value: '210'
								},
								{
									xtype: 'displayfield',
									value: '度',
									style: 'margin-left: 5px; margin-right: 10px;'
								}
							]
						}
					]
				},
				{
					title: '横向文',
					defaults: {width: 230},
					items: [
						{
							fieldLabel: '文字内容',
							name: 'croText',
							value: '演示章',
							listeners: {
								'change' : function(){
									preView();
								}
							}
						},
						{
							xtype: 'combo',
							id: 'croCombo',
							editable: false,
							fieldLabel: '字体名称',
							mode: 'local',
							triggerAction: 'all',
							store: fontStore,
							displayField: 'font',
							valueField: 'url',
							listeners: {
								'select' : function(th){
									Ext.getCmp('croFont').setValue(th.getValue());
									preView();
								}
							}
						},
						{
							xtype: 'hidden',
							id: 'croFont',
							name: 'croFont'
						},
						{
							xtype: 'panel',
							layout: 'table',
							columns: 5,
							fieldLabel: '字体大小',
							items: [
								{
									xtype: 'spinnerfield',
									name: 'croFontHeight',
									width: 65,
									minValue: 0,
									allowDecimals: true,
									decimalPrecision: 2,
									incrementValue: 0.1,
									value: '4.2'
								},
								{
									xtype: 'displayfield',
									value: '毫米',
									style: 'margin-left: 5px; margin-right: 10px;'
								},
								{
									xtype: 'displayfield',
									value: '下移:'
								},
								{
									xtype: 'spinnerfield',
									name: 'downMove',
									width: 65,
									minValue: 0,
									allowDecimals: true,
									decimalPrecision: 2,
									incrementValue: 0.1,
									value: '3'
								},
								{
									xtype: 'displayfield',
									value: '毫米',
									style: 'margin-left: 5px;'
								}
							]
							
						},
						{
							xtype: 'panel',
							layout: 'table',
							columns: 5,
							fieldLabel: '字符间隔',
							items: [
								{
									xtype: 'spinnerfield',
									name: 'spacing',
									width: 65,
									minValue: 0,
									allowDecimals: true,
									decimalPrecision: 2,
									incrementValue: 0.1,
									value: '1'
								},
								{
									xtype: 'displayfield',
									value: '毫米',
									style: 'margin-left: 5px; margin-right: 10px;'
								}
							]
						}
					]
				},
				{
					title: '内刊图 ',
					cls: 'img-chooser-view',
					items: [
						new Ext.DataView({
							singleSelect: true,
							overClass:'x-view-over',
							itemSelector:'div.thumb-wrap',
							emptyText: '没有可用的内图',
							store: imgStore,
							tpl: tpl,
							autoScroll: true,
							height: 80,
							listeners: {
								'click' : function(th, index, node, obj){
									Ext.getCmp('inImg').setValue($(node).attr('id')+'.png');
									preView();
								}
							}
						}),
						{
							xtype: 'hidden',
							id: 'inImg',
							name: 'inImg'
						},
						{
							xtype: 'panel',
							layout: 'table',
							columns: 5,
							fieldLabel: '内图宽度',
							style: 'margin-top: 8px;',
							items:[
								{
									xtype: 'spinnerfield',
									name: 'inImgWidth',
									width: 65,
									minValue: 0,
									allowDecimals: true,
									decimalPrecision: 2,
									incrementValue: 0.1,
									value: '14'
								},
								{
									xtype: 'displayfield',
									value: '毫米',
									style: 'margin-left: 5px; margin-right: 10px;'
								},
								{
									xtype: 'displayfield',
									value: '下移:'
								},
								{
									xtype: 'spinnerfield',
									name: 'inImgDown',
									width: 65,
									allowDecimals: true,
									decimalPrecision: 2,
									incrementValue: 0.1,
									value: '0'
								},
								{
									xtype: 'displayfield',
									value: '毫米',
									style: 'margin-left: 5px;'
								}
							]
						}
					]
				}
			],
			listeners: {
				'afterrender' : function(th){
					th.setActiveTab(1);
					th.setActiveTab(2);
					th.setActiveTab(0);
				}
			}
		});
		
		var makeSealForm = new Ext.form.FormPanel({
			height: 550,
			region: 'center',
			padding: 10,
			frame: true,
			border: false,
			items: [
				{
					xtype: 'fieldset',
					title: '印章规格',
					defaults: {hideLabel: true},
					items: [
						{
							xtype: 'combo',
							style: {marginLeft: '25px'},
							width: 300,
							editable: false,
							typeAhead: true,
							triggerAction: 'all',
							mode: 'local',
							value: 1,
							store: new Ext.data.ArrayStore({
								fields: ['rid', 'rule'],
								data: [[1, '42毫米 × 42毫米'], [2, '45毫米 × 45毫米'],[3, '自定义印章规格']]
							}),
							displayField: 'rule',
							valueField: 'rid',
							listeners: {
								'change' : function(th, nVal, oVal){
									if (nVal == 3) {
										th.nextSibling().setReadOnly(false);
									}else{
										th.nextSibling().setReadOnly(true);
									}
								},
								'select': function(th, record, index){
									var rid = record.json[0];
									if(rid == 1){
										Ext.getCmp('width').setValue(42);
										Ext.getCmp('height').setValue(42);
									}else if(rid == 2){
										Ext.getCmp('width').setValue(45);
										Ext.getCmp('height').setValue(45);
									}
									preView();
								}
							}
						},
						{
							xtype: 'compositefield',
							defaults: {width: 40, readOnly: true},
							style: {marginLeft: '25px'},
							items: [
								{
									xtype: 'displayfield',
									value: '宽度：'
								},
								{
									xtype: 'spinnerfield',
									name: 'width',
									id: 'width',
									width: 65,
									minValue: 1,
									allowDecimals: true,
									decimalPrecision: 2,
									incrementValue: 0.1,
									value: 42.0
								},
								{
									xtype: 'displayfield',
									value: '毫米'
								},
								{
									xtype: 'displayfield',
									value: '高度：'
								},
								{
									xtype: 'spinnerfield',
									name: 'height',
									id: 'height',
									width: 65,
									minValue: 1,
									allowDecimals: true,
									decimalPrecision: 2,
									incrementValue: 0.1,
									value: 42.0
								},
								{
									xtype: 'displayfield',
									value: '毫米'
								}
							]
						},
						{
							xtype: 'compositefield',
							style: {marginLeft: '5px'},
							items:[
								{
									xtype: 'displayfield',
									value: '边框厚度：',
									widht: 60
								},
								{
									xtype: 'spinnerfield',
									name: 'rim',
									width: 65,
									minValue: 0,
									allowDecimals: true,
									decimalPrecision: 2,
									incrementValue: 0.1,
									value: 1.4
								},
								{
									xtype: 'displayfield',
									value: '毫米'
								}
							]
						}
					]
				},
				sealTab,
				{
					xtype: 'fieldset',
					title: '印章信息',
					items: [
						{
							xtype: 'compositefield',
							items: [
								{
									xtype: 'textfield',
									fieldLabel: '用户名',
									name: 'userName',
									readOnly: true
								},
								{
									xtype: 'hidden',
									name: 'userId'
								},
								{
									xtype: 'btnForPoepleSelectorSingle',
									dataUrl: this.baseUrl + "&task=getAllUserListsInPermitDeptTree",
									text: '选择',
									listeners: {
										'selected' : function(th, data){
											makeSealForm.getForm().findField('userName').setValue(data[0].uname);
											makeSealForm.getForm().findField('userId').setValue(data[0].uid);
										},
										'onrender' : function(th){
											th.setSelectedUids(makeSealForm.getForm().findField('userId').getValue().split(","));
										}
									}
								}
							]
							
						},
						{
							xtype: 'textfield',
							fieldLabel: '签章名',
							name: 'sealName',
							style: 'margin-bottom: 5px;'
						}
					]
				}
			],
			 buttons: [
			 	{
					text: '预览',
					handler: function(){
						preView();
					}
				}
			 ]
		});
		
		var makeSealWin = new Ext.Window({
			title: '制作印章',
			width: 800,
			height: makeWindowHeight(520),
			modal: true,
			resizable: false,
			layout: 'border',
			plain: true,
			items: [makeSealPanel, makeSealForm],
			buttons:[
				{
					text: lang('save'),
					iconCls: 'icon-order-s-accept',
					handler: function(){
						var f = makeSealForm.getForm();
						if(f.isValid()){
							f.submit({
								url: _this.circleUrl + "&task=saveCircle",
								waitTitle: lang('notice'),
								method: 'POST',
								waitMsg: lang('waiting'),
								success: function(form, action){
									makeSealWin.close();
									_this.graphStore.reload();
								},
								failure: function(form, action){
									CNOA.msg.alert(action.result.msg);
								}
							});
						}
					}
				},
				{
					text: lang('close'),
					iconCls: 'icon-dialog-cancel',
					handler: function(){
						makeSealWin.close();
					}
				}
			]
		}).show();
		
		//预览印章
		var preView = function(){
			var f = makeSealForm.getForm();
			if(f.isValid()){
				f.submit({
					url: _this.circleUrl + '&task=preView',
					method: 'POST',
					success: function(form, action){
						var img = $("img:#sealImg");
						var data = action.result.msg;
						img.attr('src', _this.circleUrl + '&task=sealImg&data=' + data);
						setInterval(function(){
							posiImg();
						});
					},
					failure: function(form, action){
						
					}
				});
			}
		};
		
		//图片定位
		var posiImg = function(){
			var img = $("img:#sealImg");
			var parent = img.parent();
			var width = (parent.width()-img.width())/2;
			var height = (parent.height() - img.height())/2;
			img.css({"margin-left": width, "margin-top": height});
		};
	},
	
	loadForm : function(id){
		var _this = this;
		
		this.form.getForm().load({
			url: _this.baseUrl + '&task=editLoadFormDataInfo',
			method: 'POST',
			params: {id: id},
			waitMsg: lang('waiting')
		});
	},
	
	delSignature : function(ids){
		var _this = this;

		Ext.Ajax.request({
			url: this.baseUrl + '&task=delSignature',
			method: 'POST',
			params: {ids: ids},
			success: function(r){
				var result = Ext.decode(r.responseText);
				if (result.success === true) {
					CNOA.msg.alert(result.msg);
					_this.graphStore.reload();
				}else{
					CNOA.msg.alert(result.msg);
				}
			}
		})
	}
}
