/**
 * 全局变量
 */

var CNOA_odoc_files_borrow, CNOA_odoc_files_borrowClass;
CNOA_odoc_files_borrowClass = CNOA.Class.create();
CNOA_odoc_files_borrowClass.prototype = {
	init : function(){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NUMBER	= Ext.id();
		var ID_SEARCH_SORT		= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_HURRY		= Ext.id();
		var ID_SEARCH_STIME		= Ext.id();
		var ID_SEARCH_ETIME		= Ext.id();		
		
		this.from				= CNOA.odoc.files.from;
		
		this.baseUrl = "index.php?app=odoc&func=files&action=borrow";
		
		this.typeListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getTypeList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.typeListStore.load();
		
		this.levelListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getLevelList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.levelListStore.load();
		
		this.flowListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getFlowList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "flowid", mapping: 'id'},
					{name : "flowname"}
				]
			})
		});
		
		this.storeBar = {
			storeType : "all",
			title : "",
			number : "",
			sort : "",
			type : "",
			level : ""
		};
		
		this.fields = [
			{name : "id"},
			{name : "title"},
			{name : "number"},
			{name : "type"},
			{name : "from"},
			{name : "level"},
			{name : "stime"},
			{name : "etime"},
			{name : "stepname"},
			{name : "senddate"},
			{name : "status"},
			{name:"uFlowId"}
		];
		
		this.store = new Ext.data.Store({
			autoLoad : true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		if(this.from == "pass"){
			this.storeBar.storeType = "pass";
			this.store.load({params : this.storeBar});
		}else if(this.from == "unpass"){
			this.storeBar.storeType = "unpass";
			this.store.load({params : this.storeBar});
		}else{
			this.store.load();
		}
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: false
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "id", dataIndex: 'id', hidden: true},
			{header: '操作', dataIndex: 'id', width: 100, sortable: true, menuDisabled :true,renderer:function(v,c,record){
				var l = '';
				var rd = record.data;
				if(rd.status == 2 || rd.status == 3){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_borrow.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}else if(rd.status == 0){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_borrow.operate('+v+')">发起审批</a>';
				}
				return l;
			}},
			{header: '文件类型', dataIndex: 'from', width: 100, sortable: true, menuDisabled :true},
			{header: '文件标题', dataIndex: 'title', width: 150, sortable: true, menuDisabled :true},
			{header: '文件字号', dataIndex: 'number', width: 100, sortable: true, menuDisabled :true},
			{header: '成文日期', dataIndex: 'senddate', width: 100, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows:true,
			region:"center",
			border:false,
			store:this.store,
			loadMask:{msg: lang('loading')},
			cm:this.colModel,
			sm:this.sm,
			hideBorders:true,
			listeners:{
				"rowdblclick":function(button, event){
					
				}
			},
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					text:"借阅申请",
					iconCls:'icon-utils-s-add',
					handler:function(btn, evt){
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(btn, "请选择一个文件，进行申请");
						} else {
							_this.newBorrow(rows[0].get("id"));
						}
					}
				},"-",
				{
					handler:function(button, event) {
						_this.storeBar.storeType = "all";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					pressed:_this.from == "unpass" ? true : false,
					iconCls:'icon-roduction',
					enableToggle:true,
					pressed:true,
					allowDepress:false,
					toggleGroup:"meeting_room_check",
					tooltip:"显示所有公文列表",
					text:'所有公文列表'
				},"-",
				{
					handler:function(button, event) {
						_this.storeBar.storeType = "waiting";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls:'icon-roduction',
					enableToggle:true,
					allowDepress:false,
					toggleGroup:"meeting_room_check",
					tooltip:"显示待审借阅的公文列表",
					text:'待审借阅'
				},"-",
				{
					handler:function(button, event) {
						_this.storeBar.storeType = "pass";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls:'icon-roduction',
					enableToggle:true,
					allowDepress:false,
					toggleGroup:"meeting_room_check",
					tooltip:"显示审批通过的公文列表",
					text:'审批通过'
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "unpass";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示审批不通过的公文列表",
					text : '审批不通过'
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "return";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示已归还借阅的公文列表",
					text : '已归还借阅'
				},
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid],
			tbar : [
				"标题: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TITLE
				},
				"文号: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_NUMBER
				},
				"类型: ",
				new Ext.form.ComboBox({
					name: 'sort',
					store: new Ext.data.SimpleStore({
						fields: ['value', 'title'],
						data: [['1', "发文"], ['2', "收文"], ['3', "其他"]]
					}),
					width: 60,
					hiddenName: 'sort',
					id : ID_SEARCH_SORT,
					valueField: 'value',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false,
					listeners : {
					
					}
				}),
				"类别: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.typeListStore,
					width: 100,
					id : ID_SEARCH_TYPE,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"密级: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.levelListStore,
					width: 100,
					id : ID_SEARCH_LEVEL,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"起始日期",
				{
					xtype : "datefield",
					format : "Y-m-d",
					id : ID_SEARCH_STIME,
					width : 100
				},
				"终止日期",
				{
					xtype : "datefield",
					format : "Y-m-d",
					id : ID_SEARCH_ETIME,
					width : 100
				},
				{
					xtype: "button",
					text: "查询",
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.number 		= Ext.getCmp(ID_SEARCH_NUMBER).getValue();
						_this.storeBar.sort 		= Ext.getCmp(ID_SEARCH_SORT).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						_this.storeBar.level 		= Ext.getCmp(ID_SEARCH_LEVEL).getValue();
						_this.storeBar.stime 		= Ext.getCmp(ID_SEARCH_STIME).getRawValue();
						_this.storeBar.etime 		= Ext.getCmp(ID_SEARCH_ETIME).getRawValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:"清空",
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NUMBER).setValue("");
						Ext.getCmp(ID_SEARCH_SORT).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
						Ext.getCmp(ID_SEARCH_STIME).setValue("");
						Ext.getCmp(ID_SEARCH_ETIME).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.number 		= "";
						_this.storeBar.sort 		= "";
						_this.storeBar.type 		= "";
						_this.storeBar.level 		= "";
						_this.storeBar.stime 		= "";
						_this.storeBar.etime 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]
		});
	},
	
	newBorrow : function(id){
		var _this = this;
		
		_this.flowListStore.load();
				
		var submit = function(id){			
			if (form.getForm().isValid()) {
				form.getForm().submit({
					url: _this.baseUrl + "&task=nextStep",
					waitTitle: lang('waiting'),
					method: 'POST',
					params : {id : id},
					waitMsg: lang('loading'),
					success: function(form, action) {
						if(action.result.success === true){
							CNOA.msg.notice(action.result.msg, "公文管理");
							win.close();
						}else{
							CNOA.msg.alert(action.result.msg);
						}
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg, function(){

						});
					}.createDelegate(this)
				});
			}
		};
		
		var fields = [
			{name : "id"},
			{name: "stepName"},
			{name: "uname"}
		];
		
		var store = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({url: _this.baseUrl+"&task=getFlowDetails", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		var colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			{header: "id", dataIndex: 'id', hidden: true},
			{header: '步骤名称', dataIndex: 'stepName', width: 250, sortable: true, menuDisabled :true},
			{header: '经办人', dataIndex: 'uname', width: 200, sortable: true, menuDisabled :true},
			//{header: '操作', dataIndex: 'id', width: 60, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		var grid = new Ext.grid.GridPanel({
			stripeRows : true,
			layout : "fit",
			width : 584,
			height : 155,
			autoScroll : true,
			border : true,
			store : store,
			loadMask : {msg: lang('loading')},
			cm : colModel,
			hideBorders: true
		});
		
		var baseField = [
			{
				xtype: "fieldset",
				title: "借阅设置",
				autoHeight: true,
				defaults : {
					border : false,
					style : "margin-bottom : 5px"
				},
				items: [
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype : "panel",
								layout : "form",
								items : [
									{
										xtype : "textfield",
										fieldLabel : "借阅人",
										width : 144,
										readOnly : true,
										value : CNOA_USER_TRUENAME
									}
								]
							},
							{
								xtype : "panel",
								layout : "table",
								column : 2,
								defaults : {
									border : false
									//style : "margin-bottom : 5px"
								},
								items : [
									{
										xtype : "panel",
										layout : "form",
										items : [
											{
												xtype : "datefield",
												name : "stime",
												width : 123,
												fieldLabel : "借阅时间",
												allowBlank : false,
												format : "Y-m-d"
											}
										]
									},
									{
										xtype : "panel",
										layout : "form",
										items : [
											{
												xtype : "datefield",
												name : "etime",
												width : 123,
												fieldLabel : "归还时间",
												allowBlank : false,
												format : "Y-m-d"
											}
										]
									}
								]
							}
						]
					},
					{
						xtype : 'panel',
						layout : "form",
						items : [	
							{
								xtype : "textfield",
								width : 520,
								fieldLabel : "借阅部门",
								value : CNOA_USER_DEPTMENT,
								readOnly : true
							}
						]
					},
					{
						xtype : "textarea",
						width : 520,
						height : 60,
						name : "reason",
						fieldLabel : "原由"
					},
					new Ext.form.ComboBox({
						allowBlank : false,
						fieldLabel : "选择流程",
						name: 'flowid',
						store: this.flowListStore,
						width: 520,
						hiddenName: 'flowid',
						valueField: 'flowid',
						displayField: 'flowname',
						blankText: "请选择要流转流程",
						mode: 'local',
						triggerAction: 'all',
						forceSelection: true,
						editable: false,
						listeners: {
							change : function(th, newValue, oldValue){
								//alert(newValue);
							},
							select : function(combo, record, index){
								store.load({params : {id : record.id }});
							}
						}
					})
				]
			},
			{
				xtype: "fieldset",
				title: "借阅档案",
				autoHeight: true,
				items : [grid]
			}
		];
		
		var form = new Ext.form.FormPanel({
			border: false,
			labelWidth: 60,
			labelAlign: 'right',
			region : "center",
			layout : "fit",
			waitMsgTarget: true,
			items:[
				{
					xtype: "panel",
					border: false,
					bodyStyle: "padding:10px",
					items: baseField
				}
			]
		});
		
		var win = new Ext.Window({
			title : "借阅窗口",
			layout : "border",
			width : 650,
			height : makeWindowHeight(500),
			resizable : false,
			modal : true,
			items : [form],
			buttons : [
				{
					text : "转下一步",
					iconCls: 'icon-flow-goto-nextstep',
					handler : function(){
						submit(id);
					}
				},
				{
					text : "取消",
					handler : function(){
						win.close();
					}
				}
			]
		}).show();
	},
		
	viewFlow:function(uFlowId){
		mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
		mainPanel.loadClass(this.baseUrl+"&task=loadpage&from=viewflow&uFlowId="+uFlowId, "CNOA_MENU_WF_USE_OPENFLOW", "查看工作流程", "icon-flow");
	},
	
	operate:function(v){
		var _this = this;
		CNOA.msg.cf('输入您要发起的流程的名称', function(btn){
			if(btn == 'yes'){
				//flowId, nameRuleId, tplSort, flowType, childId
				Ext.Ajax.request({
					url: _this.baseUrl + "&task=getFaqiFlow",
					method: 'POST',
					params:{id:v},
					success: function(r) {
						var result = Ext.decode(r.responseText);
						if(result.success === true){
							var flowType = result.flowType;
							var flowId = result.flowId;
							var nameRuleId = result.nameRuleId;
							var tplSort = result.tplSort;
							var childId = 0;
							var otherApp = result.otherApp;
							
							if(flowType == 0){
								mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
								mainPanel.loadClass("index.php?app=wf&func=flow&action=use&modul=new&task=loadPage&from=newflow&flowId="+flowId+"&nameRuleId="+nameRuleId+"&flowType="+flowType+"&tplSort="+tplSort+"&childId="+childId+"&otherApp="+otherApp, "CNOA_MENU_WF_USE_OPENFLOW", "发起新的固定流程", "icon-flow-new");
							}else{
								mainPanel.closeTab("CNOA_USE_FLOW_NEWFREE_FLOWDESIGN");
								mainPanel.loadClass("index.php?app=wf&func=flow&action=use&modul=newfree&task=loadPage&from=flowdesign&flowId="+flowId+"&flowType="+flowType+"&tplSort="+tplSort+"&childId="+childId+"&otherApp="+otherApp, "CNOA_USE_FLOW_NEWFREE_FLOWDESIGN", "设计流程", "icon-flow-new");
							}
						}else{
							CNOA.msg.alert(result.msg, function(){});
						}
					}
				});
			}
		});
	}
}

