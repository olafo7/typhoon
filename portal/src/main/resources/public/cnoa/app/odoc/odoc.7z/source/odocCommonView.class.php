<?php 
class odocCommonView{
	private $t_send_list			= "odoc_send_list";
	private $t_receive_list			= "odoc_receive_list";
	private $t_tpl_list				= "odoc_setting_template_list";
	private $t_setting_word_level	= "odoc_setting_word_level";//"odoc_setting_send_level"; 
	private $t_setting_word_hurry	= "odoc_setting_word_hurry";
	private $t_flow					= "odoc_setting_flow";
	private $t_flow_step			= "odoc_setting_flow_step";
	private $t_step					= "odoc_step";
	private $t_step_temp			= "odoc_step_temp";
	
	private $fromType				= "send";
	private $table_list				= "";
									
	/**
	 * 构造函数
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * 析构函数
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function run($fromType = "send"){
		$this->fromType		= $fromType;
		$this->table_list	= $this->fromType == "send" ? $this->t_send_list : $this->t_receive_list;
		
		$act = getPar($_GET, "act", "");
		
		switch ($act) {
			#查看发文，载入模板文件
			case "getHtml" :
				$this->_getHtml();
				break;
			#查看发文，载入JS文件
			case "getZhengWen" :
				$this->_getZhengWen();
				break;
			#查看发文，载入正文文件
			case "getFormHtml" :
				$this->_getFormHtml();
				break;
			#查看发文，载入附件列表
			case "getAttachList" :
				$this->_getAttachList();
				break;
			#查看发文，载入审批步骤列表
			case "getStepList" :
				$this->_getStepListt();
				break;
		}
	}
	
	public function _getHtml(){
		global $CNOA_DB, $CNOA_CONTROLLER, $CNOA_SESSION;
		$id = getPar($_GET, "id", "");
		
		$GLOBALS['id']				= $id;
		$GLOBALS['func']			= $CNOA_CONTROLLER->func;
		$GLOBALS['action']			= $CNOA_CONTROLLER->action;
		$GLOBALS['fromType']		= $this->fromType;
		$GLOBALS['CNOA_SYSTEM_NAME']= $this->fromType == "send" ? "查看发文" : "查看收文";
		$GLOBALS['CNOA_USERNAME']	= $CNOA_SESSION->get("TRUENAME");
		$CNOA_CONTROLLER->loadViewCustom($CNOA_CONTROLLER->appPath . "/tpl/default/viewOdoc.htm", true, true);
		exit;
	}

	public function _getFormHtml(){
		global $CNOA_DB, $CNOA_SESSION;

		$id			= intval(getPar($_POST, "id", ""));
		$fromTypeI	= $this->fromType == "send" ? 1 : 2;
		
		//$info = $CNOA_DB->db_getone("*", $this->table_list, "WHERE `id`='{$id}'");

		#找出当前最后一个已办理的步骤
		$maxid = $CNOA_DB->db_getmax("id", $this->t_step, "WHERE `fromType`='{$fromTypeI}' AND `fromId`='{$id}' AND `stepType`=1 AND `status`=2");
		if(empty($maxid)){
			$where	= "WHERE `fromType`='{$fromTypeI}' AND `fromId`='{$id}' AND `status`=1";
			$maxid	= $CNOA_DB->db_getmax("id", $this->t_step, $where);
		}
		
		$formPath = CNOA_PATH_FILE. "/common/odoc/".$this->fromType."/{$id}/form.history.{$maxid}.php";
		
		if (file_exists($formPath)){
			$form = include $formPath;
		}else{
			$form = "无发文单";
		}
		
		//去掉双引号及换行符号
		$form = str_replace(
			array("\r\n", "\n", "\""),
			array("&#13;", "&#13;", "'"),
			$form
		);
		
		echo $form;exit;
	}

	public function _getAttachList(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$id = getPar($_POST, "id", 0);
		
		$info = $CNOA_DB->db_getone("*", $this->table_list, "WHERE `id`='{$id}'");
		
		//附件
		$fs = new fs();
		$info['attach']		 	= json_decode($info['attach'], true);
		$info['attachCount']	= !$info['attach'] ? 0 : count($info['attach']);
		$info['attach']			= $fs->getDownLoadItems4normal($info['attach'], true);
		//$info['attach']   = $fs->getXXXXDownLoadFileListByIds(json_decode($info['attach']));
		//$info['attachCount'] = !$info['attach'] ? 0 : count($info['attach']);

		$dataStore  = new dataStore();
		$dataStore->data = array("attach"=>$info['attach']);
		
		echo $dataStore->makeJsonData();
		exit;
	}

	public function _getStepListt(){
		global $CNOA_DB, $CNOA_SESSION, $CNOA_CONTROLLER;
		
		$func = $CNOA_CONTROLLER->func;
		$action = $CNOA_CONTROLLER->action;
		
		if($func == "send"){
			app::loadApp("odoc", "sendCheck")->api_getStepList();
		}else if($func == "receive"){
			app::loadApp("odoc", "receiveCheck")->api_getStepList();
		}else{
			if($action == "send"){
				app::loadApp("odoc", "sendCheck")->api_getStepList();
			}else if($action == "receive"){
				app::loadApp("odoc", "receiveCheck")->api_getStepList();
			}
		}
		exit;
	}
	

	public function _getZhengWen(){
		global $CNOA_DB, $CNOA_CONTROLLER, $CNOA_SESSION;
		
		$id = getPar($_GET, "id", "");
		
		$fromTypeI	= $this->fromType == "send" ? 1 : 2;

		#找出当前最后一个已办理的步骤
		$maxid = $CNOA_DB->db_getmax("id", $this->t_step, "WHERE `fromType`='{$fromTypeI}' AND `fromId`='{$id}' AND `stepType`=1 AND `status`=2");
		if(empty($maxid)){
			$where	= "WHERE `fromType`='{$fromTypeI}' AND `fromId`='{$id}' AND `status`=1";
			$maxid	= $CNOA_DB->db_getmax("id", $this->t_step, $where);
		}
		
		$filePath = CNOA_PATH_FILE . "/common/odoc/".$this->fromType."/{$id}/doc.history.{$maxid}.php";

		if(file_exists($filePath)){
			$file = @file_get_contents($filePath);
		}else{
			$file = " ";
		}
		echo $file;
		exit;
	}
}
