<?php 
class odocFilesBorrow extends model{
	private $t_files_dangan			= "odoc_files_dangan";
	private $t_files_borrow_list	= "odoc_files_borrow_list";
	private $t_flow_step			= "odoc_setting_flow_step";
	private $t_flow_step_list		= "odoc_step";
	
	private $f_from			= array(3=>"其他", 1=>"发文", 2=>"收文");
	
	private $rows			= 15;
	
	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getTypeList" :
				app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "settingWord")->api_getLevelList();
				break;
			case "getAllUserListsInPermitDeptTree" :
				$GLOBALS['user']['permitArea']['area'] = "all";
				$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
				echo json_encode($userList);
				exit;
			case "getStructTree" :
				$GLOBALS['user']['permitArea']['area'] = "all";
				echo app::loadApp("main", "struct")->api_getStructTree();
				exit;
			case "getStepJsonData" :
				$this->_getStepJsonData();
				break;
			case "getFlowList" :
				app::loadApp("odoc", "settingFlow")->api_getFlowList("borrow");
				break;
			case "getFlowDetails" :
				app::loadApp("odoc", "settingFlow")->api_getFlowDetails();
				break;
			case "nextStep" :
				$this->_nextStep();
				break;
		}
	}
	
	private function _loadpage(){
		global $CNOA_CONTROLLER;
		$from = getPar($_GET, "from", "");
		$GLOBALS['files']['from'] = $from;
		$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/files/borrow.htm';
		$CNOA_CONTROLLER->loadExtraTpl($tplPath);
		exit;
	}
	
	private function _getJsonData(){
		global $CNOA_DB;
		$start = getPar($_POST, "start", 0);
		$storeType = getPar($_POST, "storeType", "all");
		$WHERE = "WHERE 1 ";
		if($storeType == "all"){
			$this->__getJsonDataByALl();
		}elseif ($storeType == "waiting"){
			$WHERE .= "AND `status` = '0' ";
		}elseif ($storeType == "pass"){
			$WHERE .= "AND `status` = '1' ";
		}elseif ($storeType == "unpass"){
			$WHERE .= "AND `status` = '2' ";
		}elseif ($storeType == "return"){
			$WHERE .= "AND `status` = '3' ";
		}
		
		$s_sort		= getPar($_POST, "sort", 0);
		$s_title	= getPar($_POST, "title", "");
		$s_number	= getPar($_POST, "number", "");
		$s_type		= getPar($_POST, "type", 0);	
		$s_level	= getPar($_POST, "level", 0);
		$s_stime	= getPar($_POST, "stime", 0);
		$s_etime	= getPar($_POST, "etime", 0);
		
		$WHERE2 = "";
		if(!empty($s_sort)){
			$WHERE2 .= "AND `from` = '{$s_sort}' ";
		}
		if(!empty($s_title)){
			$WHERE2 .= "AND `title` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_number)){
			$WHERE2 .= "AND `number` LIKE '%{$s_number}%' ";
		}
		if(!empty($s_type)){
			$WHERE2 .= "AND `type` = '{$s_type}' ";
		}
		if(!empty($s_level)){
			$WHERE2 .= "AND `level` = '{$s_level}' ";
		}
		if(!empty($s_stime)){
			$s_stime = strtotime($s_stime);
			$WHERE2 .= "AND `collectdate` > '{$s_stime}' ";
		}
		if(!empty($s_etime)){
			$s_etime = strtotime($s_etime);
			$WHERE2 .= "AND `collectdate` < '{$s_etime}' ";
		}
		if(!empty($WHERE2)){
			$fileDB = $CNOA_DB->db_select(array("id"), $this->t_files_dangan, "WHERE 1 " . $WHERE2 . "AND `anjuanstatus` = '0' ");
			!is_array($fileDB) && $fileDB = arrat();
			$fileArr = array(0);
			foreach ($fileDB as $k=>$v) {
				$fileArr[] = $v['id'];
			}
			$WHERE = "AND `fileid` IN (" . implode(",", $fileArr) . ") ";
		}
		
		$dblist = $CNOA_DB->db_select(array("fileid"), $this->t_files_borrow_list, $WHERE . "ORDER BY `id` DESC LIMIT {$start}, {$this->rows}");

		!is_array($dblist) && $dblist = array();
		$idArr = array(0);
		foreach ($dblist as $k=>$v) {
			$idArr[] = $v['fileid'];
		}
		$danganArr = app::loadApp("odoc", "filesDananmgr")->api_getAllDanganJsonData($idArr);
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['from']		= $this->f_from[$v['from']];
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		$dataStore->total = $CNOA_DB->db_getcount($this->t_files_borrow_list, $WHERE);
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function __getJsonDataByALl(){
		global $CNOA_DB;
		$WHERE = "WHERE 1 ";
		$start	= getPar($_POST, "start", 0);
		
		$s_sort		= getPar($_POST, "sort", 0);
		$s_title	= getPar($_POST, "title", "");
		$s_number	= getPar($_POST, "number", "");
		$s_type		= getPar($_POST, "type", 0);	
		$s_level	= getPar($_POST, "level", 0);
		$s_stime	= getPar($_POST, "stime", 0);
		$s_etime	= getPar($_POST, "etime", 0);
		
		if(!empty($s_sort)){
			$WHERE .= "AND `from` = '{$s_sort}' ";
		}
		if(!empty($s_title)){
			$WHERE .= "AND `title` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_number)){
			$WHERE .= "AND `number` LIKE '%{$s_number}%' ";
		}
		if(!empty($s_type)){
			$WHERE .= "AND `type` = '{$s_type}' ";
		}
		if(!empty($s_level)){
			$WHERE .= "AND `level` = '{$s_level}' ";
		}
		if(!empty($s_stime)){
			$s_stime = strtotime($s_stime);
			$WHERE .= "AND `collectdate` > '{$s_stime}' ";
		}
		if(!empty($s_etime)){
			$s_etime = strtotime($s_etime);
			$WHERE .= "AND `collectdate` < '{$s_etime}' ";
		}
		
		$dblist = $CNOA_DB->db_select("*", $this->t_files_dangan, $WHERE . "AND `anjuanstatus` = '0' ORDER BY `id` DESC LIMIT {$start}, {$this->rows}");
	
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['from']		= $this->f_from[$v['from']];
			$dblist[$k]['senddate']	= formatDate($v['senddate']);
		}	//debug::xprint($dblist);
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		$dataStore->total = $CNOA_DB->db_getcount($this->t_files_dangan, "WHERE 1");
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _nextStep(){
		global $CNOA_DB, $CNOA_SESSION;
		$data['fileid'] = getPar($_POST, "id", 0);
		$data['stime']	= strtotime(getPar($_POST, "stime", "") . " 00:00");
		$data['etime']	= strtotime(getPar($_POST, "etime", "") . " 23:59");
		$data['reason']	= getPar($_POST, "reason", "");
		$data['fid']	= getPar($_POST, "flowid", 0);
		$data['postuid']	= $CNOA_SESSION->get("UID");
		$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['status']	= 0;
		$id = $CNOA_DB->db_insert($data, $this->t_files_borrow_list);
		$this->_addFlowStep("借阅开始", $id, 3, $data['fid'], getPar($_POST, "id", 0));
		msg::callBack(true, "操作成功");
	}	
	
	private function _addFlowStep($firstStep, $id, $fromType, $fid, $danganId){
		global $CNOA_DB, $CNOA_SESSION;
		$uid				= $CNOA_SESSION->get("UID");
		$deptInfo = app::loadApp("main", "struct")->api_getDeptByUid($uid);
		$first['fromId']	= $id;
		$first['fromType']	= $fromType;
		$first['stepid']	= 1;
		$first['stepname']	= $firstStep;
		$first['stepType']	= 1;
		$first['status']	= 2;
		$first['detpId']	= $deptInfo['id'];
		$first['deptName']	= $deptInfo['name'];
		$first['uid']		= $uid;
		$first['uname']		= $CNOA_SESSION->get("TRUENAME");
		$first['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
		$first['etime']		= $GLOBALS['CNOA_TIMESTAMP'];
		$CNOA_DB->db_insert($first, $this->t_flow_step_list);
		
		$dblist = $CNOA_DB->db_select("*", $this->t_flow_step, "WHERE `fid` = '{$fid}' ORDER BY `id` ASC");
		!is_array($dblist) && $dblist = array();
		$i = 1;
		foreach ($dblist as $k=>$v) {
			$data['fromId']		= $id;
			$data['fromType']	= $fromType;
			$data['stepid']		= $i+1;
			$data['stepType']	= 1;
			if($i == 1){
				$data['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
				$data['status']		= 1;
				$info = $CNOA_DB->db_getone(array("title", "number"), $this->t_files_dangan, "WHERE `id` = '{$danganId}' ");
				$noticeT = "公文借阅管理";
				$noticeC = "文号:" . $info['number'] . "标题[" . $info['title'] . "]需要您审批";
				$noticeH	= "index.php?app=odoc&func=files&action=brwchk";
				$data['noticeid_c'] = notice::add($v['uid'], $noticeT, $noticeC, $noticeH, 0, 17, $CNOA_SESSION->get('UID'));
				/*
				$notice['touid']	= $v['uid'];
				$notice['from']		= 17;
				$notice['fromid']	= 0;
				$notice['href']		= $noticeH;
				$notice['title']	= $noticeC;
				$notice['content']	= "";
				$notice['funname']	= "公文借阅管理";
				$notice['move']		= "审批";
				$data['todoid_c']	= notice::add2($notice);
				*/
			}else{
				$data['status']		= 0;
			}
			$data['stepname']	= $v['stepName'];
			$data['uid']		= $v['uid'];
			$data['uname']		= $v['uname'];
			$deptInfo = app::loadApp("main", "struct")->api_getDeptByUid($data['uid']);
			$data['detpId']	= $deptInfo['id'];
			$data['deptName']	= $deptInfo['name'];
			$CNOA_DB->db_insert($data, $this->t_flow_step_list);
			$i++;
		}
	}
}
?>