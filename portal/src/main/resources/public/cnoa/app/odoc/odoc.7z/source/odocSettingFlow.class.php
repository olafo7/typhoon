<?php 
class odocSettingFlow extends model{
	private $t_odoc_view_fieldset="odoc_view_fieldset";
	private $t_odoc_view_field	="odoc_view_field";
	private $t_odoc_data		="odoc_data";
	private $t_odoc_view_field_list ="odoc_view_field_list";
	private $t_odoc_bind_flow_kj	= "odoc_bind_flow_kj";
	private $t_odoc_bind_flow	= "odoc_bind_flow";
	
	private $f_which	= array(1=>"发文", 2=>"收文");
	private $rows		= 15;
									
	/**
	 * 构造函数
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * 析构函数
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case 'submitBindFlow':
				$this->_submitBindFlow();
				break;
			case 'submitAddWinLayout':
				$this->_submitAddWinLayout();
				break;
			case 'loadFormData':
				$this->_loadFormData();
				break;
			case 'getFieldList':
				$this->_getFieldList();
				break;
			case 'submitList':
				$this->_submitList();
				break;
			case 'loadColumn':
				app::loadApp('user', 'customersAgent')->api_loadColumn();
				break;
			case 'getFlowList':
				$this->_getFlowList();
				break;
			case 'getBindFieldList':
				$this->_getBindFieldList();
				break;
			case 'getFlowJsonData':
				//include_once CNOA_PATH.'/app/wf/inc/wfCommon.class.php';
				//app::loadApp('wf', 'flowSetFlow')->api_getJsonData();
				$this->_getFlowJsonData();
				break;
			case 'getFlowSortTree':
				include_once CNOA_PATH.'/app/wf/inc/wfCommon.class.php';
				app::loadApp("wf", "flowSetSort")->api_getSortTree("all");
				break;
			case 'addBindFlowId':
				$this->_addBindFlowId();
				break;
			case 'getFlowFieldList':
				$this->_getFlowFieldList();
				break;
			case 'submitBindFlowField':
				$this->_submitBindFlowField();
				break;
			case 'submitDept':
				$this->_submitDept();
				break;
			case 'list':
				$this->_getJsonList();
				break;
			case 'deleteData':
				$this->_deleteData();
				break;
			case 'getAllUserListsInPermitDeptTree':
				$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
				echo json_encode($userList);
				exit;
			case 'removeAgent':
				$this->_removeAgent();
				break;
			/*
			case 'removebindflow':
				$this->_removebindflow();
				break;
			*/
			case 'getWordList':
				$this->_getWordList();
				break;
			case 'loadPermitFormData':
				$this->_loadPermitFormData();
				break;
			case 'editLoadBindFlowData':
				$this->_editLoadBindFlowData();
				break;
			case 'deleteFlow':
				$this->_deleteFlow();
				break;
			case 'setStatus':
				$this->_setStatus();
				break;
		}
	}
	
	private function _loadpage(){
		
	}
	
	private function _getJsonList(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$dblist = $CNOA_DB->db_select("*", $this->t_odoc_data, "WHERE 1 ORDER BY `id` DESC ");
	
		!is_array($dblist) && $dblist = array();$uidArr = array(0);
		foreach ($dblist as $k=>$v){
			foreach ($v as $key=>$val){
				if(!empty($val)){
					if($fieldArr[$key] == 'type'){
						$typeArr[] = $val;
					}
					if($fieldArr[$key] == 'sort'){
						$sortArr[] = $val;
					}
				}
			}
			$uidArr[] = $v['uid'];
		}
	
		$trueNameDB = app::loadApp('main', 'user')->api_getUserNamesByUids($uidArr);
		
		foreach ($dblist as $k=>$v){
			$dblist[$k]['posttime'] = date("Y-m-d", $v['posttime']);
			$dblist[$k]['postname'] = $trueNameDB[$v['uid']]['truename'];
		}
	
		$ds = new dataStore();
		$ds->data = $dblist;
		echo $ds->makeJsonData();exit();
	}
	
	/**
	 * 提交设计的添加界面的布局
	 * @author 高超
	 * @date 2012-12-20
	 */
	
	private function _submitBindFlow(){
		global $CNOA_DB, $CNOA_SESSION;
	
		$from		= getPar($_POST, 'from', '');
		$bindFlow	= getPar($_POST, 'bindFlow', 0);
		$name		= getPar($_POST, 'name', '');
		$tp			= getPar($_POST, 'tp', '');
		$id			= getPar($_POST, 'id', '0');
	
		if($bindFlow == 0){
			msg::callBack(false, '请绑定一条工作流程');
		}
		if(empty($from)){
			msg::callBack(false, '发生错误');
		}
		
		$data = array();
		if($tp == 'edit'){
			$data['name'] = $name;
			$data['flowId'] = $bindFlow;
				
			$CNOA_DB->db_update($data, $this->t_odoc_bind_flow, "WHERE `id`='{$id}'");
			
			$CNOA_DB->db_update(array('flowId'=>$bindFlow), $this->t_odoc_bind_flow_kj, "WHERE `id`='{$id}'");
		}else{
			$data['name'] = $name;
			$data['flowId'] = $bindFlow;
			$data['from']	= $from;
			$data['status']	= 0;
			
			$CNOA_DB->db_insert($data, $this->t_odoc_bind_flow);
		}
	
		msg::callBack(true, lang('successopt'));
	}
	
	private function _submitAddWinLayout(){
		global $CNOA_DB, $CNOA_SESSION;

		$tempStoreData = $_POST['tempStoreData'];
		$tempStoreData = json_decode($tempStoreData, true);
		$from = getPar($_POST, 'from', 'send');
		$CNOA_DB->db_delete($this->t_odoc_view_fieldset, "WHERE `from` = '{$from}' ");
		$CNOA_DB->db_delete($this->t_odoc_view_field, "WHERE `from` = '{$from}' ");
		foreach($tempStoreData as $k=>$v){
			$CNOA_DB->db_insert(array('name'=>$v['name'], 'fieldset'=>$v['value'], 'from'=>$from), $this->t_odoc_view_fieldset);
		}
		//$i = 1;
		foreach ($_POST as $k=>$v){
			if(ereg('field', $k)){
				$data = array();
				$arr = explode('_', $k);
				$data['from']		= $from;
				$data['fieldset']	= $arr[2];
				$data['field']		= 0;
				$data['type']		= $arr[3];
				$data['display']	= $arr[4] == 'hide'?'hide':'show';
				$data['name'] = preg_replace('/\{\[.*\]\}/i', '', $v);
				if(empty($data['name'])){
					$data['name'] = ' ';
				}
				$id = $CNOA_DB->db_insert($data, $this->t_odoc_view_field);
				$CNOA_DB->db_update(array('field'=>$id), $this->t_odoc_view_field, "WHERE `id`='{$id}'");
				if($data['display'] == 'show'){
					if($data['type'] == 'textarea'){
						$CNOA_DB->query("ALTER TABLE  `cnoa_odoc_data` ADD  `field_".$id."` TEXT NOT NULL COMMENT  '".$data['name']."'");
					}else{
						$CNOA_DB->query("ALTER TABLE  `cnoa_odoc_data` ADD  `field_".$id."` VARCHAR( 100 ) NOT NULL COMMENT  '".$data['name']."'");
					}
				}
				//$i++;
			}
		}
		msg::callBack(true, lang('successopt'));
	}
	
	private function _loadFormData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$from = getPar($_POST, 'from', 'send');
		
		$dbFieldSetDB	= $CNOA_DB->db_select("*", $this->t_odoc_view_fieldset, "WHERE `from` = '{$from}' ORDER BY `id` ASC");
		$dbFieldDB		= $CNOA_DB->db_select("*", $this->t_odoc_view_field, "WHERE `from` = '{$from}' ORDER BY `id` ASC");
	
		!is_array($dbFieldSetDB) && $dbFieldSetDB = array();
	
		!is_array($dbFieldDB) && $dbFieldDB = array();
		$dbFieldArr = array();
		$temp = array();
		foreach ($dbFieldDB as $k=>$v){
			if($v['field']%2 == 0){
				$temp['secname'] = $v['name'];
				$temp['secfield']= $v['field'];
				$dbFieldArr[] = $temp;
				$temp = array();
			}else{
				$temp['fstname'] = $v['name'];
				$temp['type']	 = $v['type'];
				$temp['fstfield']= $v['field'];
				$temp['fieldset']= $v['fieldset'];
			}
		}
		
		$result = array(
			'success'=>true,
			'fieldset'=>$dbFieldSetDB,
			'field'=>$dbFieldArr
		);
	
		echo json_encode($result);exit();
	}
	
	private function _getFieldList(){
		global $CNOA_DB;
		$from = getPar($_POST, 'from', 'send');
		$dblist = $CNOA_DB->db_select("*", $this->t_odoc_view_field, "WHERE `display` = 'show' AND `from` = '{$from}' ");
		$column = $CNOA_DB->db_select("*", $this->t_odoc_view_field_list, "WHERE `from` = '{$from}' ");
		!is_array($column) && $column = array();
		$columnArr = array();
		foreach ($column as $k=>$v){
			$columnArr[] = $v['field'];
		}
		!is_array($dblist) && $dblist = array();
		$data = array();
		foreach ($dblist as $k=>$v){
			if(!in_array($v['field'], $columnArr)){
				$data[] = $v;
			}
		}
		$ds = new dataStore();
		$ds->data = $data;
		echo $ds->makeJsonData();
		exit();
	}
	
	private function _submitList(){
		global $CNOA_DB;
		$data = $_POST['data'];
		$from = getPar($_POST, 'from', 'send');
		$dataArr = json_decode($data, true);
		$CNOA_DB->db_delete($this->t_odoc_view_field_list, "WHERE `from` = '{$from}' ");
		foreach ($dataArr as $k=>$v){
			if(empty($v['title'])){
				$v['title'] = $v['name'];
			}
			if(empty($v['width'])){
				$v['width'] = 100;
			}
			$v['from'] = $from;
			$CNOA_DB->db_insert($v, $this->t_odoc_view_field_list);
		}
		msg::callBack(true, lang('successopt'));
	}
	
	private function _getFlowList(){
		global $CNOA_DB;
		
		$dblist = $CNOA_DB->db_select(array('flowId', 'name', 'sortId'), 'wf_s_flow', "WHERE `status` = 1 ORDER BY `sortId` ASC, `name` ASC");
		!is_array($dblist) && $dblist = array();
		$data = array(array('flowId'=>'0', 'name'=>'未绑定流程'));
		
		//获取流程分类
		include_once CNOA_PATH.'/app/wf/inc/wfCommon.class.php';
		$sortList = app::loadApp("wf", "flowSetSort")->api_getSortList();
		
		foreach ($dblist as $k=>$v) {
			$v['name'] = '[' . $sortList[$v['sortId']]['name'] . '] ' . $v['name'];
			$data[] = $v;
		}
		
		
		$ds = new dataStore();
		$ds->data = $data;
		echo $ds->makeJsonData();
		exit();
	}
	
	private function _getBindFieldList(){
		global $CNOA_DB;
		
		$from	= getPar($_POST, 'from', 'send');
		$id		= getPar($_POST, 'id', '0');
		
		$dblist = $CNOA_DB->db_select("*", $this->t_odoc_bind_flow_kj, "WHERE `from` = '{$from}' AND `id`='{$id}'");
		!is_array($dblist) && $dblist = array();$data = array();
		foreach ($dblist as $k=>$v){
			unset($v['id']);
			$data[] = $v;
		}
		$ds = new dataStore();
		$ds->data = $data;
		echo $ds->makeJsonData();exit();
	}
	
	private function _getFlowJsonData(){
		global $CNOA_DB;
		$from = getPar($_GET, 'from', 'send');
		
		/*
		switch ($from){
			case 'send':
				$from = 1;
				break;
			case 'receive':
				$from = 2;
				break;
			case 'borrow':
				$from = 3;
				break;
		}
		*/
		
		$dblist = $CNOA_DB->db_select("*", $this->t_odoc_bind_flow, "WHERE `from` = '{$from}' ");
		!is_array($dblist) && $dblist = array();
		$flowIds = array(0);
		foreach ($dblist as $k=>$v){
			$flowIds[] = $v['flowId'];
		}
		
		include_once CNOA_PATH.'/app/wf/inc/wfCommon.class.php';
		$flowList = app::loadApp("wf", "flowSetFlow")->api_getFlowData(array("flowIdArr"=>$flowIds, "field"=>array('flowId', 'name')));
		
		foreach ($dblist as $k=>$v){
			$dblist[$k]['flowName'] = $flowList[$v['flowId']]['name'];
		}
		
		$ds = new dataStore();
		$ds->data = $dblist;
		echo $ds->makeJsonData();
		exit();
	}
	
	private function _addBindFlowId(){
		global $CNOA_DB;
		$flowId = getPar($_POST, 'flowId', 0);
		$from = getPar($_POST, 'from', 'send');
		
		$data['flowId']		= $flowId;
		$data['from']		= $from;
		if($from == 'borrow'){
			$data['field']		= 'title';
			$data['type']		= 'title';
			$data['name']		= '文件标题';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
			$data['field']		= 'number';
			$data['type']		= 'number';
			$data['name']		= '文件字号';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
			$data['field']		= 'agree';
			$data['type']		= 'agree';
			$data['name']		= '是否同意';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
			$data['field']		= 'optinion';
			$data['type']		= 'optinion';
			$data['name']		= '意见';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
			$data['field']		= 'stime';
			$data['type']		= 'stime';
			$data['name']		= '借阅时间';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
			$data['field']		= 'etime';
			$data['type']		= 'etime';
			$data['name']		= '归还时间';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
			$data['field']		= 'postuid';
			$data['type']		= 'postuid';
			$data['name']		= '借阅人';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
			$data['field']		= 'dept';
			$data['type']		= 'dept';
			$data['name']		= '借阅部门';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
			$data['field']		= 'reason';
			$data['type']		= 'reason';
			$data['name']		= '原由';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
			msg::callBack(true, lang('successopt'));
		}
		
		$dblist = $CNOA_DB->db_select("*", $this->t_odoc_view_field, "WHERE `display` = 'show' AND `from` = '{$from}' ");
		!is_array($dblist) && $dblist = array();
		if($from == 'receive'){
			$data['field']		= 'deptment';
			$data['type']		= 'deptment';
			$data['name']		= '来文单位';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
			$data['field']		= 'title';
			$data['type']		= 'title';
			$data['name']		= '来文标题';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
			$data['field']		= 'number';
			$data['type']		= 'number';
			$data['name']		= '来文编号';
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
		}
		foreach ($dblist as $k=>$v){
			$data['field']		= $v['field'];
			$data['type']		= $v['type'];
			$data['name']		= $v['name'];
			$CNOA_DB->db_insert($data,$this->t_odoc_bind_flow_kj);
		}
		msg::callBack(true, lang('successopt'));
	}
	
	private function _getFlowFieldList(){
		global $CNOA_DB;
		$from = getPar($_POST, 'from', 'send');
		$id = getPar($_POST, 'id', '0');
		
		$dataA = $CNOA_DB->db_getone('*', $this->t_odoc_bind_flow, "WHERE `from` = '{$from}' AND `id`='{$id}'");
		$flowId = $dataA['flowId'];
		if(empty($flowId)){
			$ds = new dataStore();
			$ds->data = array();
			echo $ds->makeJsonData();exit();
		}
		
		//$fieldList1 = $CNOA_DB->db_select("*", $this->t_odoc_view_field, "WHERE `from`='{$from}'");
		//$fieldList2 = $CNOA_DB->db_select("*", $this->t_odoc_bind_flow_kj, "WHERE `id`='{$id}' AND `from`='{$from}'");
		
		
		//判断是否增加新的控件
		$dblistA = $CNOA_DB->db_select('*', $this->t_odoc_view_field, "WHERE `from` = '{$from}' ");
		$dblistB = $CNOA_DB->db_select("*", $this->t_odoc_bind_flow_kj, "WHERE `from` = '{$from}' AND `id`='{$id}'");

		!is_array($dblistA) && $dblistA = array();!is_array($dblistB) && $dblistB = array();
		$fieldArr = array();$bindFieldArr = array();
	
		foreach ($dblistB as $k=>$v){
			$bindFieldArr[] = $v['field'];
		}
		foreach ($dblistA as $k=>$v){
			
			if(!in_array($v['field'], $bindFieldArr)){
				$data = array();
				$data['id']			= $dataA['id'];
				$data['from']		= $dataA['from'];
				$data['flowId']		= $dataA['flowId'];
				$data['field']		= $v['field'];
				$data['name']		= $v['name'];
				$data['type']		= $v['type'];
				$data['kongjian']	='';
				$CNOA_DB->db_insert($data, $this->t_odoc_bind_flow_kj);
			}
		}
		unset($data);
		
		$dblist = $CNOA_DB->db_select("*", 'wf_s_field', "WHERE `flowId` = {$flowId} ");
		!is_array($dblist) && $dblist = array();
		$data = array(array('id'=>'0', 'name'=>'未选择控件'));
		foreach ($dblist as $k=>$v) {
			if($v['otype'] == 'textfield' || $v['otype'] == 'textarea' || ($v['otype'] = 'radio' && $v['type'] == 'text')){
				$data[] = $v;
			}
		}
		$ds = new dataStore();
		$ds->data = $data;
		echo $ds->makeJsonData();exit();
		/**/
	}
	
	private function _submitBindFlowField(){
		global $CNOA_DB;
		$data = $_POST['data'];
		$data = json_decode($data, true);
		$from = getPar($_POST, 'from', 'send');
		foreach ($data as $k=>$v){
			$CNOA_DB->db_update(array('kongjian'=>$v['kongjian']), $this->t_odoc_bind_flow_kj, "WHERE `from` = '{$from}' AND `field` = '{$v['field']}' ");
		}
	
		msg::callBack(true, lang('successopt'));
	}
	
	private function _submitDept(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid = $CNOA_SESSION->get("UID");
		if($uid != 1){
			msg::callBack(false,'对不起，该权限只能由超级管理员设置');
		}
		$dept = getPar($_POST, 'dept', 0);
		if(!file_exists(CNOA_PATH_FILE.'/config/customerAgent.php')){
			touch(CNOA_PATH_FILE.'/config/customerAgent.php');
		}
		$handle = fopen(CNOA_PATH_FILE.'/config/customerAgent.php', 'w+');
	
		$content = "<?php return array('stationid'=>".$_POST['stationid'].", 'deptId'=>".$_POST['deptId'].", 'jobId'=>".$_POST['jobId'].", 'usemessager'=>".$_POST['usemessager'].", 'usesend'=>".$_POST['usesend'].", 'usereceive'=>".$_POST['usereceive']."); ?>";
		fwrite($handle, $content);
		fclose($handle);
		msg::callBack(true,lang('successopt'));
	}
	
	private function _deleteData(){
		global $CNOA_DB;
		$ids = getPar($_POST, 'ids', 0);
		$ids = substr($ids, 0, -1);
		$CNOA_DB->db_delete($this->t_agent_data, "WHERE `id` IN (".$ids.") ");
		msg::callBack(true, lang('successopt'));
	}
	
	private function _removeAgent(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid = $CNOA_SESSION->get("UID");
		$removeToUid = getPar($_POST, 'removeToUid', 0);
		$ids = getPar($_POST, 'ids', 0);
	
		$CNOA_DB->db_update(array('uid' => $removeToUid), $this->t_agent_data, "WHERE `id` IN (".substr($ids, 0, -1).") ");
		msg::callBack(true, lang('successopt'));
	}
	
	/*
	private function _removebindflow(){
		global $CNOA_DB, $CNOA_SESSION;
		$from = getPar($_POST, 'from', 'send');
		$CNOA_DB->db_delete($this->t_odoc_bind_flow_kj, "WHERE `from` = '{$from}' ");
		msg::callBack(true,lang('successopt'));
	}
	*/
	
	private function _getWordList(){
		global $CNOA_DB;
		$from = getPar($_POST, 'from', 'send');
		
		$fieldDB = $CNOA_DB->db_select("*", $this->t_odoc_view_field, "WHERE `from` = '{$from}' ");
		!is_array($fieldDB) && $fieldDB = array();$fieldName = array();
		foreach ($fieldDB as $k=>$v){
			$field[] = $v['field'];
			$fieldName[$v['field']] = $v['name'];
		}
		$data = $CNOA_DB->db_select("*", $this->t_odoc_view_field_list, "WHERE `from` = '{$from}' ");
		!is_array($data) && $data = array();$dblist = array();
		foreach ($data as $k=>$v){
			if(!in_array($v['field'], $field)){
				$CNOA_DB->db_delete($this->t_odoc_view_field_list, "WHERE `from` = '{$from}' AND `field` = {$v['field']}");
			}else{
				$v['name'] = $fieldName[$v['field']];
				$dblist[] = $v;
			}
		}
		$ds = new dataStore();
		$ds->data = $dblist;
		echo $ds->makeJsonData();
		exit();
	}
	
	private function _loadPermitFormData(){
		global $CNOA_DB;
		$file = include CNOA_PATH_FILE.'/config/customerAgent.php';
		//$file['deptName'] = $file[''];
		$file['deptName'] = app::loadApp('main', 'struct')->api_getNameById($file['deptId']);
		//$file['deptName'] = app::loadApp("main", "job")->api_getNameById($file['jobId']);
		$ds = new dataStore();
		$ds->data = $file;
		echo $ds->makeJsonData();
		exit();
	}
	
	private function _editLoadBindFlowData(){
		global $CNOA_DB;
		
		$id = getPar($_POST, 'id', 0);
		
		$data = array();
		$info = $CNOA_DB->db_getone("*", $this->t_odoc_bind_flow, "WHERE `id`='{$id}'");
		
		$data['name']		= $info['name'];
		$data['bindFlow']	= $info['flowId'];
		
		$ds = new dataStore();
		$ds->data = $data;
		echo $ds->makeJsonData();
		exit();
	}
	
	private function _setStatus(){
		global $CNOA_DB;
		
		$id = getPar($_POST, 'id', 0);
		
		$info = $CNOA_DB->db_getone("*", $this->t_odoc_bind_flow, "WHERE `id`='{$id}'");
		
		$data = array();
		$data['status'] = $info['status'] == 1 ? 0 : 1;
		
		$CNOA_DB->db_update($data, $this->t_odoc_bind_flow, "WHERE `id`='{$id}'");
		
		msg::callBack(true, lang('successopt'));
	}
	
	private function _deleteFlow(){
		global $CNOA_DB;
		
		$id = getPar($_POST, 'id', 0);
		
		$CNOA_DB->db_delete($this->t_odoc_bind_flow, "WHERE `id`='{$id}'");
		$CNOA_DB->db_delete($this->t_odoc_bind_flow_kj, "WHERE `id`='{$id}'");
		
		msg::callBack(true, lang('successopt'));
	}
	
	public function api_loadFormData(){
		$this->_loadFormData();
	}
}
?>