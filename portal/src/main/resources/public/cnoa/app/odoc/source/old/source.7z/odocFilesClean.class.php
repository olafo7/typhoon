<?php 
class odocFilesClean extends model{
	private $t_step			= "odoc_step";
	private $t_send_list	= "odoc_send_list";
	private $t_receive_list	= "odoc_receive_list";
	private $t_files_dangan	= "odoc_files_dangan";
	private $rows = 15;
	
	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getTypeList" :
				app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "settingWord")->api_getLevelList();
				break;
			case "getRoomList" :
				app::loadApp("odoc", "filesSetting")->api_getRoomList();
				break;
			case "getAnjuanList" :
				app::loadApp("odoc", "filesAnjuanmgr")->api_anjuanList();
				break;
			case "getWenzhongList" :
				app::loadApp("odoc", "filesSetting")->api_getWenzhongList();
				break;
			case "loadFormData" :
				$this->_loadFormData();
				break;
			case 'add' :
				$this->_add();
				break;
			case 'collect' :
				$this->_collect();
				break;
			#查看
			case 'view':
				$fromType = getPar($_GET, "fromType");
				app::loadApp("odoc", "commonView")->run($fromType);
				break;
				
			case 'delete':		//删除
				$this->_delete();
				break;
		}
	}
	
	
	/**
	 * 删除档案
	 * Enter description here ...
	 */
	private function _delete(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$ids	= getPar($_POST, 'ids');
		$ids	= substr($ids, 0, -1);
		$from	= getPar($_POST, 'fromType');
		
		//debug::xprint($_POST); debug::xprint($ids);
		
		//到cnoa_odoc_receive_list删除ids的数据，再到step删除，删除步骤文件
		/*
		private $t_step			= "odoc_step";
		private $t_send_list	= "odoc_send_list";
		private $t_receive_list	= "odoc_receive_list";
		*/
		
		//默认是发文的
		$table		= $this->t_send_list;
		$fromType	= 1;
		$folder		= 'send';
		
		
		//如果是收文的
		if($from == 'receive'){
			$table		= $this->t_receive_list;
			$fromType	= 2;
			$folder		= 'receive';
		}
		
		
		
		//删除
		$where	= "WHERE 1";
		$where	.= " AND `id` IN ({$ids})";
		$CNOA_DB->db_delete($table, $where);
		
		
		//删除步骤文件
		$argId = explode(',', $ids);
		foreach ($argId as $fid){
			$where	= "WHERE `fromId`={$fid} AND `fromType`={$fromType}";
			$dblist	= $CNOA_DB->db_select('*', $this->t_step, $where);
			!is_array($dblist) && $dblist = array();
			
			foreach ($dblist as $dbinfo){
				$step_id = $dbinfo['id'];
				$path = CNOA_PATH_FILE. "/common/odoc/{$folder}/". $fid ."/";
				@unlink($path . 'form.history.'.$step_id.'.php');
				@unlink($path . 'doc.history.'.$step_id.'.php');
			}
		}
				
		//删除步骤
		$where	= "WHERE 1";
		$where	.= " AND `fromId` IN ({$fid}) AND `fromType`={$fromType}";
		$CNOA_DB->db_delete($this->t_step, $where);
		
		
		msg::callBack(true, "删除操作成功.");
	}
	
	
	
	
	private function _loadpage(){
		
	}
	
	private function _getJsonData(){
		global $CNOA_DB;
		$storeType = getPar($_POST, "storeType", "send");
		
		$WHERE = "WHERE 1 ";
		if($storeType == "send"){
			$table = $this->t_send_list;
		}elseif($storeType == "receive"){
			$table = $this->t_receive_list;
		}
		
		$s_title	= getPar($_POST, "title", "");
		$s_number	= getPar($_POST, "number", "");
		$s_type		= getPar($_POST, "type", 0);
		$s_level	= getPar($_POST, "level", 0);
		$s_stime	= getPar($_POST, "stime", 0);
		$e_etime	= getPar($_POST, "etime", 0);
		
		if(!empty($s_title)){
			$WHERE .= "AND `title` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_number)){
			$WHERE .= "AND `number` LIKE '%{$s_number}%' ";
		}
		if(!empty($s_type)){
			$WHERE .= "AND `type` = '{$s_type}' ";
		}
		if(!empty($s_level)){
			$WHERE .= "AND `level` = '{$s_level}' ";
		}
		if(!empty($s_stime)){
			$s_stime = strtotime($s_stime);
			$WHERE .= "AND `createtime` > '{$s_stime}' ";
		}
		if(!empty($s_etime)){
			$s_etime = strtotime($s_etime);
			$WHERE .= "AND `createtime` < '{$s_etime}' ";
		}
		
		$start = getPar($_POST, 'start', 0);
		
		
		$WHERE .= " AND `status` = '2' AND `collect` = '0' ";
		
		$dblist = $CNOA_DB->db_select("*", $table, $WHERE . " ORDER BY `id` DESC LIMIT {$start},{$this->rows} ");
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['senddate'] = formatDate($v['senddate']);
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		$dataStore->total	= $CNOA_DB->db_getcount($table, $WHERE);
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _loadFormData(){
		global $CNOA_DB;
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		$num = count($idArr);
		$storeType = getPar($_POST, "storeType", "send");
		switch ($storeType){
			case "send" :
				$table = $this->t_send_list;
				break;
			case "receive" :
				$table = $this->t_receive_list;
				break;
		}
		if($num == 1){
			$this->__getLoadFormDataSingle($table, $idArr);
		}else{
			$this->__getLoadFormDataMult($table, $idArr);
		}
	}
	
	private function __getLoadFormDataSingle($table, $idArr){
		global $CNOA_DB;
		$data		= $CNOA_DB->db_getone("*", $table, "WHERE `id` = '{$idArr[0]}'");
		$typeArr	= app::loadApp("odoc", "settingWord")->api_getTypeAllArr();
		$data['type']			= $typeArr[$data['type']]['title'];
		$data['guidangdate']	= formatDate($GLOBALS['CNOA_TIMESTAMP']);
		$data['senddate']		= formatDate($data['createtime']);
		$dataStore = new dataStore();
		$dataStore->data = $data;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function __getLoadFormDataMult($table, $idArr){
		global $CNOA_DB;
		$dblist['guidangdate'] = formatDate($GLOBALS['CNOA_TIMESTAMP']);
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _add(){
		global $CNOA_DB;
		$data['title']			= getPar($_POST, "title", "");
		$data['level']			= getPar($_POST, "level", 0);
		$data['filesnum']		= getPar($_POST, "filesnum", "");
		$data['number']			= getPar($_POST, "number", "");
		$data['senddate']		= strtotime(getPar($_POST, "senddate", ""));
		$data['respon']			= getPar($_POST, "respon", "");
		$data['page']			= getPar($_POST, "page", "");
		$data['collectdate']	= strtotime(getPar($_POST, "collectdate", ""));
		$data['wenzhong']		= getPar($_POST, "wenzhong", "");
		$data['anjuan']			= getPar($_POST, "anjuan", "");
		$data['note']			= getPar($_POST, "note", "");
		$data['danganshi']		= getPar($_POST, "room", "");
		$data['from']			= 3;
		
		 //获取上传文档的ID
		$fs = new fs();
		$filesUpload = getPar($_POST, "filesUpload", array());
		$attch = $fs->add($filesUpload, 17);
		$data['attach'] = json_encode($attch);
		$CNOA_DB->db_insert($data, $this->t_files_dangan);
		
		msg::callBack(true, "操作成功");
	}
	
	private function _collect(){
		global $CNOA_DB;
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		$storeType = getPar($_POST, "storeType", "send");
		
		$respon		= getPar($_POST, "respon", "");
		$filesnum	= getPar($_POST, "filesnum", "");
		$wenzhong	= getPar($_POST, "wenzhong", 0);
		$anjuan		= getPar($_POST, "anjuan", 0);
		$danganshi	= getPar($_POST, "room", 0);
		switch ($storeType) {
			case "send" :
				$table = $this->t_send_list;
				$from = 1;
				break;
			case "receive" :
				$table = $this->t_receive_list;
				$from = 2;
				break;
		}
		foreach ($idArr as $v) {
			$data = $CNOA_DB->db_getone(array("title","page","level","number","senddate","attach", "type"), $table, "WHERE `id` = '{$v}' ");
			
			$data['from']		= $from;
			$data['fromid']		= $v;
			$data['respon']		= $respon;
			$data['filesnum']	= $filesnum;
			$data['wenzhong']	= $wenzhong;
			$data['anjuan']		= $anjuan;
			$data['danganshi']	= $danganshi;
			$data['collectdate']= $GLOBALS['CNOA_TIMESTAMP'];
			$data['senddate']	= $data['senddate'];
			unset($data['createtime']);
			$data['page']		= getPar($_POST, "page", "");
			$CNOA_DB->db_insert($data, $this->t_files_dangan);
			
			$CNOA_DB->db_update(array("collect"=>1), $table, "WHERE `id` = '{$v}' ");
		}
		msg::callBack(true, "操作成功");
	}
}
?>