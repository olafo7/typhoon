<?php 
class odocSettingFlow extends model{
	private $t_flow				= "odoc_setting_flow";
	private $t_flow_step		= "odoc_setting_flow_step";
	private $t_flow_step_list	= "odoc_step";
	
	private $f_which	= array(1=>"发文", 2=>"收文");
	private $rows		= 15;
	
	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getStepJsonData" :
				$this->_getStepJsonData();
				break;
			case "getTypeList" :
					app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getAllUserListsInPermitDeptTree" :
				$GLOBALS['user']['permitArea']['area'] = "all";
				$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
				echo json_encode($userList);
				exit;
			case "submit" :
				$from = getPar($_POST, "from", "");
				if($from == "add"){
					$this->_add();
				}elseif($from == "edit"){
					$this->_edit();
				}
			case "loadFormData" :
				$this->_loadFormData();
				break;
			case "active" :
				$this->_active();
				break;
			case "delete" :
				$this->_delete();
				break;
		}
	}
	
	private function _loadpage(){
		
	}
	
	private function _getJsonData(){
		global $CNOA_DB;
		$WHERE = "WHERE 1 ";
		
		$storeType	= getPar($_POST, "storeType", "send");
		$status		= getPar($_POST, "status", "active");
		if($storeType == "send"){
			$WHERE .= "AND `which` = '1' ";
		}elseif($storeType == "receive"){
			$WHERE .= "AND `which` = '2' ";
		}elseif($storeType == "borrow"){
			$WHERE .= "AND `which` = '3' ";
		}

		$typeArr		= app::loadApp("odoc", "settingWord")->api_getTypeAllArr();
		if($status == "active"){
			$WHERE .= "AND `active` = '1' ";
		}elseif($status == "forbid"){
			$WHERE .= "AND `active` = '2' ";
		}
		
		$s_title	= getPar($_POST, "title", "");
		$s_type		= getPar($_POST, "type", "");
		if(!empty($s_title)){
			$WHERE .= "AND `flowname` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_type)){
			$WHERE .= "AND `type` = '{$s_type}' ";
		}
		
		$dblist = $CNOA_DB->db_select("*", $this->t_flow, $WHERE . "ORDER BY `id` DESC");
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v) {
			$uidArr[]	= $v['postuid'];
		}
		$truenameArr	= app::loadApp("main", "user")->api_getUserNamesByUids($uidArr);
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['posttime'] = formatDate($v['posttime'], "Y-m-d H:i");
			$dblist[$k]['postname'] = $truenameArr[$v['postuid']]['truename'];
			$dblist[$k]['type']		= $typeArr[$v['type']]['title'];
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _getStepJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$fid = getPar($_POST, "id", 0);
		
		$dblist = $CNOA_DB->db_select("*", $this->t_flow_step, "WHERE `fid` = '{$fid}' ORDER BY `id` ASC");
		!is_array($dblist) && $dblist = array();
		//$uidArr = array();
		//foreach ($dblist as $k=>$v) {
		//	$uidArr[] = $v['uid'];
		//}
		//$truenameArr = app::loadApp("main", "user")->api_getUserNamesByUids($uidArr);
		//foreach ($dblist as $k=>$v) {
		//	$dblist[$k]['uname'] = $truenameArr[$v['uid']]['truename'];
		//}

		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
		
	}
	
	private function _add(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$data['flowname']	= getPar($_POST, "flowname", "");
		$data['which']		= getPar($_POST, "which", 0);
		$data['type']		= getPar($_POST, "type", 0);
		$data['active']		= 2;
		$num = $CNOA_DB->db_getcount($this->t_flow, "WHERE `flowname` = '{$data['flowname']}' AND `which` = '{$data['which']}' AND `type` = '{$data['type']}' ");
		if($num > 0){
			msg::callBack(false, "已存在该流程名称");
		}
		
		$data['postuid']	= $CNOA_SESSION->get("UID");
		$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
		
		$flow['fid'] = $CNOA_DB->db_insert($data, $this->t_flow);
		
		$step	= $_POST["data"];
		$step	= json_decode($step, true);
		!is_array($step) && $step = array();
		foreach ($step as $k=>$v) {
			$flow['stepName']	= $v['stepName'];
			$flow['uid']		= $v['uid'];
			$flow['uname']		= $v['uname'];
			//$flow['stepType']	= $v['stepType'];
			$CNOA_DB->db_insert($flow, $this->t_flow_step);
		}
		
		msg::callBack(true, "操作成功");
	}
	
	private function _edit(){
		global $CNOA_DB, $CNOA_SESSION;
		$id = getPar($_POST, "id", 0);
		
		$data['flowname']	= getPar($_POST, "flowname", "");
		$data['which']		= getPar($_POST, "which", 0);
		$data['type']		= getPar($_POST, "type", 0);
		$num = $CNOA_DB->db_getcount($this->t_flow, "WHERE `id` != '{$id}' AND `flowname` = '{$data['flowname']}' AND `which` = '{$data['which']}' AND `type` = '{$data['type']}' ");
		if($num > 0){
			msg::callBack(false, "已存在该流程名称");
		}

		$CNOA_DB->db_update($data, $this->t_flow, "WHERE `id`='{$id}'");
		
		$step	= $_POST["data"];
		$step	= json_decode($step, true);
		!is_array($step) && $step = array();
		$CNOA_DB->db_delete($this->t_flow_step, "WHERE `fid` = '{$id}'");
		$flow			= array();
		$flow['fid']	= $id;
		foreach ($step as $k=>$v) {
			$flow['stepName']	= $v['stepName'];
			$flow['uid']		= $v['uid'];
			$flow['uname']		= $v['uname'];
			//$flow['stepType']	= $v['stepType'];
			$CNOA_DB->db_insert($flow, $this->t_flow_step);
		}
		
		msg::callBack(true, "操作成功");
	}
	
	private function _loadFormData(){
		global $CNOA_DB, $CNOA_SESSION;
		$id = getPar($_POST, "id", 0);
		$dblist = $CNOA_DB->db_getone(array("flowname", "type", "which"), $this->t_flow, "WHERE `id`='{$id}'");
		
		!is_array($dblist) && $dblist=array();
		
		foreach ($dblist AS $k=>$v){
			
		}
		
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _active(){
		global $CNOA_DB;
		$active = getPar($_POST, "type", "active");
		$id		= getPar($_POST, "id", 0);
		if($active == "active"){
			$data['active'] = 1;
		}elseif($active == "forbid"){
			$data['active'] = 2;
		}
		$CNOA_DB->db_update($data, $this->t_flow, "WHERE `id` = '{$id}'");
		msg::callBack(true, "操作成功");
	}
	
	private function _delete(){
		global $CNOA_DB;
		$id = getPar($_POST, "id", 0);
		$CNOA_DB->db_delete($this->t_flow, "WHERE `id` = '{$id}' ");
		$CNOA_DB->db_delete($this->t_flow_step, "WHERE `fid` = '{$id}' ");
		msg::callBack(true, "删除成功");
	}
	
	public function api_getFlowList($type = "send"){
		global $CNOA_DB;
		$WHERE = "WHERE 1 ";
		if($type == "send"){
			$WHERE .= "AND `which` = '1' ";
		}elseif($type == "receive"){
			$WHERE .= "AND `which` = '2' ";
		}elseif($type == "borrow"){
			$WHERE .= "AND `which` = '3' ";
		}
		$dblist = $CNOA_DB->db_select(array("id", "flowname"), $this->t_flow, $WHERE . "AND `active` = '1' ORDER BY `id` ASC");
		!is_array($dblist) && $dblist = array();
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_getFlowDetails(){
		global $CNOA_DB;
		$fid = getPar($_POST, "id", 0);
		$dblist = $CNOA_DB->db_select(array("id", "stepName", "uname"),$this->t_flow_step, "WHERE `fid` = '{$fid}' ");
		!is_array($dblist) && $dblist = array();
		
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
}
?>