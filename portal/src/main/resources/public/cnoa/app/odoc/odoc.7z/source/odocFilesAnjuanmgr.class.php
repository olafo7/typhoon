<?php 
class odocFilesAnjuanmgr extends model{
	private $t_anjuan_list	= "odoc_files_anjuan_list";
	private $t_dangan_list	= "odoc_files_dangan";
	private $t_dangan_room	= "odoc_files_dangan_room";
	private $t_dangan_type	= "odoc_files_dangan_type";
	
	private $rows			= 15;
									
	/**
	 * 构造函数
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * 析构函数
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			//case "getSecretList" :
			//	app::loadApp("odoc", "settingWord")->api_getSecretList();
			//	break;
			case "getSavetimeList" :
				app::loadApp("odoc", "filesSetting")->api_getSavetimeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "filesSetting")->api_getLevellist();
				break;
			case "getRoomList" :
				app::loadApp("odoc", "filesSetting")->api_getRoomList();
				break;
			case "getTypeList" :
				app::loadApp("odoc", "filesSetting")->api_getTypeList();
				break;
			case "add" :
				$from = getPar($_POST, "from", "add");
				if($from == "add"){
					$this->_add();
				}elseif ($from == "edit"){
					$this->_edit();
				}
				break;
			case "loadFormData" :
				$this->_loadFormData();
				break;
			case "delete" :
				$this->_delete();
				break;
			case "lock" :
				$this->_lock();
				break;
			case "getRoom" :
				$this->_getRoom();
				break;
		}
	}
	
	private function _loadpage(){
		
	}
	
	private function _getJsonData(){
		global $CNOA_DB;
		
		$id = getPar($_POST, "id", 0);
		$start = getPar($_POST, "start", 0);
		$WHERE = "WHERE `danganshi` = '{$id}' ";
		
		$s_type	= getPar($_POST, "type", 0);
		if(!empty($s_type)){
			$typeDB = $CNOA_DB->db_select(array("id"), $this->t_dangan_type, "WHERE `title` LIKE '%{$s_type}%' ");
			!is_array($typeDB) && $typeDB = array();
			$typeArr = array(0);
			foreach ($typeDB as $k=>$v) {
				$typeArr[] = $v['id'];
			}
			$WHERE .= "AND `type` IN (" . implode(",", $typeArr) . ") ";
		}
		
		$dblist		= $CNOA_DB->db_select("*", $this->t_anjuan_list, $WHERE . "ORDER BY `id` ASC LIMIT {$start}, {$this->rows}");
		$typeArr	= app::loadApp("odoc", "filesSetting")->api_getTypeData();
		$secretArr	= app::loadApp("odoc", "settingWord")->api_getSecretAllArr();
		$roomArr	= app::loadApp("odoc", "filesSetting")->api_getRoomData();
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['type']		= $typeArr[$v['type']]['title'];
			$dblist[$k]['secret']	= $secretArr[$v['secret']]['title'];
			$dblist[$k]['room']		= $roomArr[$v['danganshi']]['title'];
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _add(){
		global $CNOA_DB, $CNOA_SESSION;
		$data['title']				= getPar($_POST, "title", "");
		$data['hehao']				= getPar($_POST, "hehao", "");
		$data['level']				= getPar($_POST, "level", 0);
		$data['anjuandate']			= getPar($_POST, "anjuandate", "");
		$data['quanzonghao']		= getPar($_POST, "quanzonghao", "");
		$data['secret']				= getPar($_POST, "secret", "");
		$data['danganshidaihao']	= getPar($_POST, "danganshidaihao", "");
		$data['danganshi']			= getPar($_POST, "danganshi", "");
		$data['type']				= getPar($_POST, "type", "");
		$data['page']				= getPar($_POST, "page", "");
		$data['respon']				= getPar($_POST, "respon", "");
		$data['secret']				= getPar($_POST, "secret", "");
		$data['stime']				= strtotime(getPar($_POST, "stime", ""));
		$data['etime']				= strtotime(getPar($_POST, "etime", ""));
		$data['note']				= getPar($_POST, "note", "");
		$data['postuid']			= $CNOA_SESSION->get("UID");
		
		$CNOA_DB->db_insert($data, $this->t_anjuan_list);
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('add', 3205, $data['title'], '案卷');
		msg::callBack(true, "操作成功");
	}
	
	private function _edit(){
		global $CNOA_DB;
		$id = getPar($_POST, "id", 0);
		$data['title']				= getPar($_POST, "title", "");
		$data['hehao']				= getPar($_POST, "hehao", "");
		$data['level']				= getPar($_POST, "level", 0);
		$data['anjuandate']			= getPar($_POST, "anjuandate", "");
		$data['quanzonghao']		= getPar($_POST, "quanzonghao", "");
		$data['secret']				= getPar($_POST, "secret", 0);
		$data['danganshidaihao']	= getPar($_POST, "danganshidaihao", "");
		$data['danganshi']			= getPar($_POST, "danganshi", "");
		$data['type']				= getPar($_POST, "type", 0);
		$data['page']				= getPar($_POST, "page", "");
		$data['respon']				= getPar($_POST, "respon", "");
		$data['secret']				= getPar($_POST, "secret", "");
		$data['stime']				= strtotime(getPar($_POST, "stime", ""));
		$data['etime']				= strtotime(getPar($_POST, "etime", ""));
		$data['note']				= getPar($_POST, "note", "");
		$CNOA_DB->db_update($data, $this->t_anjuan_list, "WHERE `id` = '{$id}'");
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('update', 3205, $data['title'], '案卷');
		msg::callBack(true, "操作成功");
	}
	
	private function _loadFormData(){
		global $CNOA_DB;
		$id = getPar($_POST, "id", 0);
		$dblist = $CNOA_DB->db_getone("*", $this->t_anjuan_list, "WHERE `id` = '{$id}'");
		!is_array($dblist) && $dblist = array();
		$dblist['stime'] = formatDate($dblist['stime']);
		$dblist['etime'] = formatDate($dblist['etime']);
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _delete(){
		global $CNOA_DB;
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		//系统操作日志
		$DB = $CNOA_DB->db_select(array('id', 'title'), $this->t_anjuan_list, "WHERE `id` IN ({$ids})");
		foreach ($DB as $v){
		    $title[$v['id']] = $v['title'];
		}
		
		foreach ($idArr as $k=>$v) {
			$CNOA_DB->db_delete($this->t_anjuan_list, "WHERE `id` = '{$v}'");
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('del', 3205, $title[$v], '案卷');
		}
		msg::callBack(true, "操作成功");
	}
	
	private function _lock(){
		global $CNOA_DB;
		$from = getPar($_POST, "from", "lock");
		$data = array();
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		if($from == "lock") {
			$data['status'] = 1;
		}elseif($from == "unlock"){
			$data['status'] = 0;
		}
		
		//系统操作日志
		$DB = $CNOA_DB->db_select(array('id', 'title'), $this->t_anjuan_list, "WHERE `id` IN ({$ids})");
		foreach ($DB as $v){
		    $title[$v['id']] = $v['title'];
		}
		
		foreach ($idArr as $v) {
			$CNOA_DB->db_update($data, $this->t_anjuan_list, "WHERE `id` = '{$v}' ");
			if($from == "lock") {
				$CNOA_DB->db_update(array("anjuanstatus"=>1), $this->t_dangan_list, "WHERE `anjuan` = '{$v}'");
				//系统操作日志
				app::loadApp('main', 'systemLogs')->api_addLogs('', 3205, $title[$v], '封卷');
			}elseif($from == "unlock"){
				$CNOA_DB->db_update(array("anjuanstatus"=>0), $this->t_dangan_list, "WHERE `anjuan` = '{$v}'");
				//系统操作日志
				app::loadApp('main', 'systemLogs')->api_addLogs('', 3205, $title[$v], '折卷');
			}
		}
		msg::callBack(true, "操作成功");
	}
	
	private function _getRoom(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select("*", $this->t_dangan_room);
		$jsonList = array();
		foreach ($dblist AS $k=>$v){
			$jsonList[] = array(
				"id"=>$v['id'],
				"text"=>$v['title'],
				"iconCls"=>"icon-folder--plus",
				"leaf"=>true
			);
		}
		echo json_encode($jsonList);
		exit;
	}
	
	public function api_anjuanList(){
		global $CNOA_DB;
		$room = getPar($_POST, "room", 0);
		$year = getPar($_POST, "year", 0);
		$WHERE = "WHERE 1 ";
		if(!empty($room)){
			$WHERE .= "AND `danganshi` = '{$room}' ";
		}
		if(!empty($year)){
			$WHERE .= "AND `anjuandate` = '{$year}' ";
		}
		$dblist = $CNOA_DB->db_select(array("id", "title"), $this->t_anjuan_list, $WHERE . "AND `status` = '0' ");
		!is_array($dblist) && $dblist = array();
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_anjuanArr(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("id", "title"), $this->t_anjuan_list);
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v) {
			$data[$v['id']] = $v;
		}
		return $data;
	}
}
?>