var CNOA_odoc_viewFiles, CNOA_odoc_viewFilesClass;


CNOA_odoc_viewFilesClass = CNOA.Class.create();
CNOA_odoc_viewFilesClass.prototype = {
	init : function(id, baseUrl){
		var _this = this;

		this.id				= id;
		this.baseUrl		= baseUrl;
		//this.func			= CNOA.odoc.func;
		//this.action		= CNOA.odoc.action;
		//this.fromType		= CNOA.odoc.fromType;
		this.ID_attachCt	= Ext.id();
		this.ID_printArea	= Ext.id();
		this.ID_baseInfo	= Ext.id();

		var _this = this;
		
		var ID_fieldSet_Base = Ext.id();
		var ID_fieldSet_Word = Ext.id();
		var ID_fieldSet_Attach = Ext.id();
		var ID_fieldSet_Form = Ext.id();
		
		this.mainPanel = new Ext.Window({
			title:'查看档案内容',
			width:800,
			height:makeWindowHeight(Ext.getBody().getBox().height-40),
			modal:true,
			bodyStyle: 'background-color:#FFF;padding:10px;',
			autoScroll: true,
			maximizable: true,
			border:false,
			items: [
				{
					xtype: 'fieldset',
					title: '档案信息',
					hidden: true,
					id: ID_fieldSet_Base
				},
				{
					xtype: 'fieldset',
					title: '公文表单',
					hidden: true,
					id: ID_fieldSet_Form
				},
				{
					xtype: 'fieldset',
					title: '公文正文',
					hidden: true,
					id: ID_fieldSet_Word
				},
				{
					xtype: 'fieldset',
					title: '附件',
					hidden: true,
					id: ID_fieldSet_Attach
				}
			],
			listeners: {
				afterrender : function(){
					_this.loadInfo();
				}
			},
			buttons:[
				{
					text:lang('close'),
					handler:function(btn){
						_this.mainPanel.close();
					}
				}
			]
		}).show();
	},

	loadInfo : function(){
		var _this = this;

		Ext.Ajax.request({
			url: _this.baseUrl + "&task=loadInfo",
			method: 'POST',
			params:{id: this.id},
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					if(result.data.word){
						//Ext.getCmp(ID_fieldSet_Word).show();
						//Ext.getCmp(ID_fieldSet_Word).body.update(result.data.word);
					}
					if(result.data.attach){
						//Ext.getCmp(ID_fieldSet_Attach).show();
						//Ext.getCmp(ID_fieldSet_Attach).body.update(result.data.attach);
					}
					if(result.data.form){
						//Ext.getCmp(ID_fieldSet_Form).show();
						//Ext.getCmp(ID_fieldSet_Form).body.update(result.data.form);
					}
				}else{
					//CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	}
};

/**
 * 全局变量
 */

var CNOA_odoc_files_anjuanmgr, CNOA_odoc_files_anjuanmgrClass;
CNOA_odoc_files_anjuanmgrClass = CNOA.Class.create();
CNOA_odoc_files_anjuanmgrClass.prototype = {	
	init : function(){
		var _this = this;
		
		var ID_SEARCH_STATUS	= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=files&action=anjuanmgr";
		
		this.typeListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getTypeList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.typeListStore.load();
		
		this.levelListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getLevelList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.levelListStore.load();
		
		this.savetimeListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getSavetimeList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.savetimeListStore.load();
		
		this.roomListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getRoomList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.roomListStore.load();
		
		this.storeBar = {
			id : 0,
			storeType : "waiting",
			status : "",
			type : ""
		};
		
		this.fields = [
			{name : "id"},
			{name : "title"},
			{name : "room"},
			{name : "hehao"},
			{name : "type"},
			{name : "title"},
			{name : "anjuandate"},
			{name : "page"},
			{name : "secret"},
			{name : "note"},
			{name : "status"}
		];
		
		this.store = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: false
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "id", dataIndex: 'id', hidden: true},
			{header: '属性', dataIndex: 'status', width: 40, sortable: true, menuDisabled :true, renderer : this.status.createDelegate(this)},
			{header: '所属内目', dataIndex: 'type', width: 100, sortable: true, menuDisabled :true},
			{header: '盒号', dataIndex: 'hehao', width: 100, sortable: true, menuDisabled :true},
			{header: '案卷提名', dataIndex: 'title', width: 80, sortable: true, menuDisabled :true},
			{header: '年度', dataIndex: 'anjuandate', width: 80, sortable: true, menuDisabled :true},
			{header: '页数', dataIndex: 'page', width: 80, sortable: true, menuDisabled :true},
			{header: '保管期限', dataIndex: 'secret', width: 80, sortable: true, menuDisabled :true},
			{header: '备注', dataIndex: 'note', width: 80, sortable: true, menuDisabled :true},
			//{header: '操作', dataIndex: 'operate', width: 120, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			bodyStyle: 'border-left-width:1px;',
			store:this.store,
			loadMask : {msg: lang('loading')},
			cm: this.colModel,
			sm: this.sm,
			hideBorders: true,
			listeners:{
				"rowdblclick":function(button, event){
					
				}
			},
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.add("add", 0);
					}.createDelegate(this),
					iconCls: 'icon-utils-s-add',
					text : '添加案卷'
				},"-",
				{
					text:"修改",
					iconCls: 'icon-utils-s-edit',
					handler : function(){
						var rows = _this.grid.getSelectionModel().getSelections();
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, lang('mustSelectOneRow'));
						} else {
							_this.add("edit", rows[0].get("id"));
						}
					}
				},"-",
				{
					text:"删除",
					iconCls: 'icon-utils-s-delete',
					handler : function(button){
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, lang('mustSelectOneRow'));
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要删该记录吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.deleteData(ids);
								}
							});
						}
					}
				},"-",
				{
					text:"封卷",
					iconCls: 'icon-folder-lock',
					handler : function(button){
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, "您还没有选择要封卷的案卷");
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要封卷该案卷吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.lock(ids, "lock");
								}
							});
						}
					}
				},"-",
				{
					text:"拆卷",
					iconCls: 'icon-folder-lock-unlock',
					handler : function(button){
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, "您还没有选择要封卷的案卷");
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要拆卷该案卷吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.lock(ids, "unlock");
								}
							});
						}
					}
				},
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.treeRoot = new Ext.tree.AsyncTreeNode({
			text: "档案室",
			expanded: true
		});

		this.treeLoader = new Ext.tree.TreeLoader({
			dataUrl: this.baseUrl + "&task=getRoom",
			preloadChildren: true,
			clearOnLoad: false,
			listeners:{
				"load":function(node){
					
				}.createDelegate(this)
			}
		});
		
		this.dirTree = new Ext.tree.TreePanel({
			hideBorders: true,
			border: false,
			rootVisible: true,
			lines: true,
			animCollapse: false,
			animate: false,
			loader: this.treeLoader,
			root: this.treeRoot,
			autoScroll: true,
			listeners:{
				"click":function(node){
					_this.storeBar.id = node.attributes.id;
					_this.store.load({params :  _this.storeBar});
				}.createDelegate(this),
				"render" : function(){
					//Ext.state.Manager.set("CNOA_main_user_index_treeState", "");
				}
			}
		});
		
		this.left = new Ext.Panel({
			region : "west",
			width : 200,
			layout:'fit',
			split: true,
			minWidth: 80,
			maxWidth: 380,
			bodyStyle: 'border-right-width:1px;',
			items: [this.dirTree],
			tbar : [
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.treeRoot.reload();
					}
				},"->",
				"档案室"
			]
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.left,this.grid],
			tbar : [
				"内目名称: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TYPE
				},
				/*
				"类型: ",
				new Ext.form.ComboBox({
					store: new Ext.data.SimpleStore({
						fields: ['value', 'title'],
						data: [['1', "发文"], ['2', "收文"], ['3', "其他"]]
					}),
					width: 60,
					id : ID_SEARCH_STATUS,
					valueField: 'value',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false,
					listeners : {
					
					}
				}),*/
				{
					xtype: "button",
					text: "查询",
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						//_this.storeBar.status 		= Ext.getCmp(ID_SEARCH_STATUS).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:"清空",
					handler:function(){
						//Ext.getCmp(ID_SEARCH_STATUS).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						
						//_this.storeBar.status 		= "";
						_this.storeBar.type 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]
		});
	},
	
	lock : function(ids, from){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + '&task=lock',
			params: {ids : ids, from : from},
			method: "POST",
			success: function(r, opts) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.store.reload();
				}else{
					CNOA.msg.alert(result.msg, function(){
						_this.store.reload();
					});
				}
			},
			failure: function(response, opts) {
				CNOA.msg.alert(result.msg, function(){
					_this.store.reload();
				});
			}
		});
	},
	
	status : function(value, c, rd){
		if(value == 0) {
			return '<img src="' + CNOA_EXTJS_PATH + '/resources/images/default/tree/lock-unlock.png" align="absmiddle">';
		}else if(value == 1) {
			return '<img src="' + CNOA_EXTJS_PATH + '/resources/images/default/tree/lock.png" align="absmiddle">';
		}
	},
	
	add : function(from, id){
		var _this = this;
		
		var loadFormData = function(id){		
			form.getForm().load({
				url: _this.baseUrl + "&task=loadFormData",
				params : {id : id},
				method:'POST',
				waitTitle: lang('waiting'),
				success: function(form, action){
	
				},
				failure: function(form, action) {
					CNOA.msg.alert(action.result.msg, function(){
						
					});
				}
			})
		};
		
		var submit = function(from, id){
			if (form.getForm().isValid()) {
				form.getForm().submit({
					url: _this.baseUrl + "&task=add",
					waitTitle: lang('waiting'),
					params : {from : from, id : id},
					method: 'POST',
					waitMsg: lang('loading'),
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						win.close();
						_this.store.reload();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg, function(){
							//this.mainPanel.enable();
						});
					}.createDelegate(this)
				});
			}
		};
		
		var baseField = [
			{
				xtype: "fieldset",
				title: "添加案卷",
				autoHeight: true,
				defaults : {
					border : false,
					style : "margin-bottom : 5px"
				},
				items: [
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "案卷题名",
										width: 150,
										name : "title",
										allowBlank : false
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype : "textfield",
										fieldLabel : "盒号",
										width : 150,
										name : "hehao",
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										fieldLabel: "年度",
										name: 'anjuandate',
										allowBlank : false,
										store: new Ext.data.SimpleStore({
											fields: ['value', 'anjuandate'],
											data: (function(){
												var Y = new Date().getFullYear()+1;
												var arr	= [];
												for(var i=0; i<20;i++){
													arr[i]	= [Y, Y];
													Y--;
												}
												return arr;
											})()
										}),
										width: 150,
										hiddenName: 'anjuandate',
										valueField: 'value',
										displayField: 'anjuandate',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "全宗号",
										name : "quanzonghao",
										width: 150,
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'savetime',
										store: _this.savetimeListStore,
										allowBlank : false,
										width: 150,
										fieldLabel : "保管期限",
										hiddenName: 'savetime',
										valueField: 'tid',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype : "textfield",
										fieldLabel : "档案室代号",
										allowBlank : false,
										name : "danganshidaihao",
										width : 150
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'danganshi',
										store: _this.roomListStore,
										width: 150,
										fieldLabel : "档案室",
										allowBlank : false,
										hiddenName: 'danganshi',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "责任者",
										width: 150,
										name : "respon",
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'type',
										store: _this.typeListStore,
										allowBlank : false,
										width: 150,
										fieldLabel : "内目",
										hiddenName: 'type',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "页数",
										width: 150,
										name : "page",
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'level',
										store: _this.levelListStore,
										width: 150,
										allowBlank : false,
										fieldLabel : "密级",
										hiddenName: 'level',
										valueField: 'tid',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							}
						]
					},{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "datefield",
										fieldLabel: "卷类文件起始时间",
										name : "stime",
										format : "Y-m-d",
										width: 150,
										allowBlank : false
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "datefield",
										fieldLabel: "卷类文件终止时间",
										name : "etime",
										format : "Y-m-d",
										width: 150,
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "textarea",
						fieldLabel : "备注",
						name : "note",
						width : 425,
						height : 50
					}
				]
			}
		];
		
		var form = new Ext.form.FormPanel({
			border: false,
			labelWidth: 120,
			labelAlign: 'right',
			region : "center",
			layout : "fit",
			waitMsgTarget: true,
			items:[
				{
					xtype: "panel",
					border: false,
					bodyStyle: "padding:10px",
					layout: "form",
					region: "center",
					autoScroll: true,
					items: baseField
				}
			]
		});
		
		var win = new Ext.Window({
			title : "添加案卷窗口",
			layout : "border",
			width : 620,
			height : makeWindowHeight(420),
			resizable : false,
			modal : true,
			items : [form],
			buttons : [
				{
					text : "提交",
					handler : function(){
						submit(from, id);
					}
				},
				{
					text : "取消",
					handler : function(){
						win.close();
					}
				}
			]
		}).show();
		
		if(from == "edit"){
			loadFormData(id);
		}	
	},
	
	deleteData : function(ids){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + '&task=delete',
			params: {ids : ids},
			method: "POST",
			success: function(r, opts) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.store.reload();
				}else{
					CNOA.msg.alert(result.msg, function(){
						_this.store.reload();
					});
				}
			},
			failure: function(response, opts) {
				CNOA.msg.alert(result.msg, function(){
					_this.store.reload();
				});
			}
		});
	}
}


/**
 * 全局变量
 */

var CNOA_odoc_files_borrow, CNOA_odoc_files_borrowClass;
CNOA_odoc_files_borrowClass = CNOA.Class.create();
CNOA_odoc_files_borrowClass.prototype = {
	init : function(){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NUMBER	= Ext.id();
		var ID_SEARCH_SORT		= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_HURRY		= Ext.id();
		var ID_SEARCH_STIME		= Ext.id();
		var ID_SEARCH_ETIME		= Ext.id();		
		
		this.from				= CNOA.odoc.files.from;
		
		this.baseUrl = "index.php?app=odoc&func=files&action=borrow";
		
		this.typeListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getTypeList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.typeListStore.load();
		
		this.levelListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getLevelList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.levelListStore.load();
		
		this.flowListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getFlowList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "flowid", mapping: 'id'},
					{name : "flowname"}
				]
			})
		});
		
		this.storeBar = {
			storeType : "all",
			title : "",
			number : "",
			sort : "",
			type : "",
			level : ""
		};
		
		this.fields = [
			{name : "id"},
			{name : "title"},
			{name : "number"},
			{name : "type"},
			{name : "from"},
			{name : "level"},
			{name : "stime"},
			{name : "etime"},
			{name : "stepname"},
			{name : "senddate"},
			{name : "status"},
			{name:"uFlowId"}
		];
		
		this.store = new Ext.data.Store({
			autoLoad : true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		if(this.from == "pass"){
			this.storeBar.storeType = "pass";
			this.store.load({params : this.storeBar});
		}else if(this.from == "unpass"){
			this.storeBar.storeType = "unpass";
			this.store.load({params : this.storeBar});
		}else{
			this.store.load();
		}
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: false
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "id", dataIndex: 'id', hidden: true},
			{header: '操作', dataIndex: 'id', width: 100, sortable: true, menuDisabled :true,renderer:function(v,c,record){
				var l = '';
				var rd = record.data;
				if(rd.status == 2 || rd.status == 3){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_borrow.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}else if(rd.status == 0){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_borrow.operate('+v+')">发起审批</a>';
				}
				return l;
			}},
			{header: '文件类型', dataIndex: 'from', width: 100, sortable: true, menuDisabled :true},
			{header: '文件标题', dataIndex: 'title', width: 150, sortable: true, menuDisabled :true},
			{header: '文件字号', dataIndex: 'number', width: 100, sortable: true, menuDisabled :true},
			{header: '成文日期', dataIndex: 'senddate', width: 100, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows:true,
			region:"center",
			border:false,
			store:this.store,
			loadMask:{msg: lang('loading')},
			cm:this.colModel,
			sm:this.sm,
			hideBorders:true,
			listeners:{
				"rowdblclick":function(button, event){
					
				}
			},
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					text:"借阅申请",
					iconCls:'icon-utils-s-add',
					handler:function(btn, evt){
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(btn, "请选择一个文件，进行申请");
						} else {
							_this.newBorrow(rows[0].get("id"));
						}
					}
				},"-",
				{
					handler:function(button, event) {
						_this.storeBar.storeType = "all";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					pressed:_this.from == "unpass" ? true : false,
					iconCls:'icon-roduction',
					enableToggle:true,
					pressed:true,
					allowDepress:false,
					toggleGroup:"meeting_room_check",
					tooltip:"显示所有公文列表",
					text:'所有公文列表'
				},"-",
				{
					handler:function(button, event) {
						_this.storeBar.storeType = "waiting";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls:'icon-roduction',
					enableToggle:true,
					allowDepress:false,
					toggleGroup:"meeting_room_check",
					tooltip:"显示待审借阅的公文列表",
					text:'待审借阅'
				},"-",
				{
					handler:function(button, event) {
						_this.storeBar.storeType = "pass";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls:'icon-roduction',
					enableToggle:true,
					allowDepress:false,
					toggleGroup:"meeting_room_check",
					tooltip:"显示审批通过的公文列表",
					text:'审批通过'
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "unpass";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示审批不通过的公文列表",
					text : '审批不通过'
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "return";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示已归还借阅的公文列表",
					text : '已归还借阅'
				},
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid],
			tbar : [
				"标题: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TITLE
				},
				"文号: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_NUMBER
				},
				"类型: ",
				new Ext.form.ComboBox({
					name: 'sort',
					store: new Ext.data.SimpleStore({
						fields: ['value', 'title'],
						data: [['1', "发文"], ['2', "收文"], ['3', "其他"]]
					}),
					width: 60,
					hiddenName: 'sort',
					id : ID_SEARCH_SORT,
					valueField: 'value',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false,
					listeners : {
					
					}
				}),
				"类别: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.typeListStore,
					width: 100,
					id : ID_SEARCH_TYPE,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"密级: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.levelListStore,
					width: 100,
					id : ID_SEARCH_LEVEL,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"起始日期",
				{
					xtype : "datefield",
					format : "Y-m-d",
					id : ID_SEARCH_STIME,
					width : 100
				},
				"终止日期",
				{
					xtype : "datefield",
					format : "Y-m-d",
					id : ID_SEARCH_ETIME,
					width : 100
				},
				{
					xtype: "button",
					text: "查询",
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.number 		= Ext.getCmp(ID_SEARCH_NUMBER).getValue();
						_this.storeBar.sort 		= Ext.getCmp(ID_SEARCH_SORT).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						_this.storeBar.level 		= Ext.getCmp(ID_SEARCH_LEVEL).getValue();
						_this.storeBar.stime 		= Ext.getCmp(ID_SEARCH_STIME).getRawValue();
						_this.storeBar.etime 		= Ext.getCmp(ID_SEARCH_ETIME).getRawValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:"清空",
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NUMBER).setValue("");
						Ext.getCmp(ID_SEARCH_SORT).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
						Ext.getCmp(ID_SEARCH_STIME).setValue("");
						Ext.getCmp(ID_SEARCH_ETIME).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.number 		= "";
						_this.storeBar.sort 		= "";
						_this.storeBar.type 		= "";
						_this.storeBar.level 		= "";
						_this.storeBar.stime 		= "";
						_this.storeBar.etime 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]
		});
	},
	
	newBorrow : function(id){
		var _this = this;
		
		_this.flowListStore.load();
				
		var submit = function(id){			
			if (form.getForm().isValid()) {
				form.getForm().submit({
					url: _this.baseUrl + "&task=nextStep",
					waitTitle: lang('waiting'),
					method: 'POST',
					params : {id : id},
					waitMsg: lang('loading'),
					success: function(form, action) {
						if(action.result.success === true){
							CNOA.msg.notice(action.result.msg, "公文管理");
							win.close();
						}else{
							CNOA.msg.alert(action.result.msg);
						}
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg, function(){

						});
					}.createDelegate(this)
				});
			}
		};
		
		var fields = [
			{name : "id"},
			{name: "stepName"},
			{name: "uname"}
		];
		
		var store = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({url: _this.baseUrl+"&task=getFlowDetails", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		var colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			{header: "id", dataIndex: 'id', hidden: true},
			{header: '步骤名称', dataIndex: 'stepName', width: 250, sortable: true, menuDisabled :true},
			{header: '经办人', dataIndex: 'uname', width: 200, sortable: true, menuDisabled :true},
			//{header: '操作', dataIndex: 'id', width: 60, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		var grid = new Ext.grid.GridPanel({
			stripeRows : true,
			layout : "fit",
			width : 584,
			height : 155,
			autoScroll : true,
			border : true,
			store : store,
			loadMask : {msg: lang('loading')},
			cm : colModel,
			hideBorders: true
		});
		
		var baseField = [
			{
				xtype: "fieldset",
				title: "借阅设置",
				autoHeight: true,
				defaults : {
					border : false,
					style : "margin-bottom : 5px"
				},
				items: [
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype : "panel",
								layout : "form",
								items : [
									{
										xtype : "textfield",
										fieldLabel : "借阅人",
										width : 144,
										readOnly : true,
										value : CNOA_USER_TRUENAME
									}
								]
							},
							{
								xtype : "panel",
								layout : "table",
								column : 2,
								defaults : {
									border : false
									//style : "margin-bottom : 5px"
								},
								items : [
									{
										xtype : "panel",
										layout : "form",
										items : [
											{
												xtype : "datefield",
												name : "stime",
												width : 123,
												fieldLabel : "借阅时间",
												allowBlank : false,
												format : "Y-m-d"
											}
										]
									},
									{
										xtype : "panel",
										layout : "form",
										items : [
											{
												xtype : "datefield",
												name : "etime",
												width : 123,
												fieldLabel : "归还时间",
												allowBlank : false,
												format : "Y-m-d"
											}
										]
									}
								]
							}
						]
					},
					{
						xtype : 'panel',
						layout : "form",
						items : [	
							{
								xtype : "textfield",
								width : 520,
								fieldLabel : "借阅部门",
								value : CNOA_USER_DEPTMENT,
								readOnly : true
							}
						]
					},
					{
						xtype : "textarea",
						width : 520,
						height : 60,
						name : "reason",
						fieldLabel : "原由"
					},
					new Ext.form.ComboBox({
						allowBlank : false,
						fieldLabel : "选择流程",
						name: 'flowid',
						store: this.flowListStore,
						width: 520,
						hiddenName: 'flowid',
						valueField: 'flowid',
						displayField: 'flowname',
						blankText: "请选择要流转流程",
						mode: 'local',
						triggerAction: 'all',
						forceSelection: true,
						editable: false,
						listeners: {
							change : function(th, newValue, oldValue){
								//alert(newValue);
							},
							select : function(combo, record, index){
								store.load({params : {id : record.id }});
							}
						}
					})
				]
			},
			{
				xtype: "fieldset",
				title: "借阅档案",
				autoHeight: true,
				items : [grid]
			}
		];
		
		var form = new Ext.form.FormPanel({
			border: false,
			labelWidth: 60,
			labelAlign: 'right',
			region : "center",
			layout : "fit",
			waitMsgTarget: true,
			items:[
				{
					xtype: "panel",
					border: false,
					bodyStyle: "padding:10px",
					items: baseField
				}
			]
		});
		
		var win = new Ext.Window({
			title : "借阅窗口",
			layout : "border",
			width : 650,
			height : makeWindowHeight(500),
			resizable : false,
			modal : true,
			items : [form],
			buttons : [
				{
					text : "转下一步",
					iconCls: 'icon-flow-goto-nextstep',
					handler : function(){
						submit(id);
					}
				},
				{
					text : "取消",
					handler : function(){
						win.close();
					}
				}
			]
		}).show();
	},
		
	viewFlow:function(uFlowId){
		mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
		mainPanel.loadClass(this.baseUrl+"&task=loadpage&from=viewflow&uFlowId="+uFlowId, "CNOA_MENU_WF_USE_OPENFLOW", "查看工作流程", "icon-flow");
	},
	
	operate:function(v){
		var _this = this;
		CNOA.msg.cf('输入您要发起的流程的名称', function(btn){
			if(btn == 'yes'){
				//flowId, nameRuleId, tplSort, flowType, childId
				Ext.Ajax.request({
					url: _this.baseUrl + "&task=getFaqiFlow",
					method: 'POST',
					params:{id:v},
					success: function(r) {
						var result = Ext.decode(r.responseText);
						if(result.success === true){
							var flowType = result.flowType;
							var flowId = result.flowId;
							var nameRuleId = result.nameRuleId;
							var tplSort = result.tplSort;
							var childId = 0;
							var otherApp = result.otherApp;
							
							if(flowType == 0){
								mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
								mainPanel.loadClass("index.php?app=wf&func=flow&action=use&modul=new&task=loadPage&from=newflow&flowId="+flowId+"&nameRuleId="+nameRuleId+"&flowType="+flowType+"&tplSort="+tplSort+"&childId="+childId+"&otherApp="+otherApp, "CNOA_MENU_WF_USE_OPENFLOW", "发起新的固定流程", "icon-flow-new");
							}else{
								mainPanel.closeTab("CNOA_USE_FLOW_NEWFREE_FLOWDESIGN");
								mainPanel.loadClass("index.php?app=wf&func=flow&action=use&modul=newfree&task=loadPage&from=flowdesign&flowId="+flowId+"&flowType="+flowType+"&tplSort="+tplSort+"&childId="+childId+"&otherApp="+otherApp, "CNOA_USE_FLOW_NEWFREE_FLOWDESIGN", "设计流程", "icon-flow-new");
							}
						}else{
							CNOA.msg.alert(result.msg, function(){});
						}
					}
				});
			}
		});
	}
}


/**
 * 全局变量
 */

var CNOA_odoc_files_brwchk, CNOA_odoc_files_brwchkClass;
CNOA_odoc_files_brwchkClass = CNOA.Class.create();
CNOA_odoc_files_brwchkClass.prototype = {
	init : function(){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NUMBER	= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_HURRY		= Ext.id();
		var ID_BTN_AGREE		= Ext.id();
		var ID_BTN_DISAGREE		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=files&action=brwchk";
		
		this.storeBar = {
			storeType : "waiting",
			title : "",
			number : "",
			type : "",
			level : "",
			hurry : ""
		};
		
		this.fields = [
			{name:"id"},
			{name:"fileid"},
			{name:"title"},
			{name:"status"},
			{name:"number"},
			{name:"type"},
			{name:"type1"},
			{name:"level"},
			{name:"wenzhong"},
			{name:"danganshi"},
			{name:"anjuan"},
			{name:"anjuandate"},
			{name:"filesnum"},
			{name:"page"},
			{name:"reader"},
			{name:"stime"},
			{name:"etime"},
			{name:"deptment"},
			{name:"posttime"},
			{name:'senddate'},
			{name:'reason'}
		];
		
		this.store = new Ext.data.Store({
			autoLoad : true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				}
			}
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: false
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "id", dataIndex: 'id', hidden: true},
			{header: '操作', dataIndex: 'fileid', width: 80, sortable: true, menuDisabled :true, renderer : this.operate.createDelegate(this)},
			//{header: '状态', dataIndex: 'status', width: 80, sortable: true, menuDisabled :true},
			{header: '类型', dataIndex: 'type', width: 80, sortable: true, menuDisabled :true},
			{header: '密级', dataIndex: 'level', width: 80, sortable: true, menuDisabled :true},
			{header: '文件提名', dataIndex: 'title', width: 120, sortable: true, menuDisabled :true},
			{header: '借阅人部门', dataIndex: 'deptment', width: 140, sortable: true, menuDisabled :true},
			{header: '借阅人', dataIndex: 'reader', width: 80, sortable: true, menuDisabled :true},
			{header: '提交时间', dataIndex: 'posttime', width: 100, sortable: true, menuDisabled :true},
			{header: '成文日期', dataIndex: 'senddate', width: 100, sortable: true, menuDisabled :true},
			{header: '借阅开始时间', dataIndex: 'stime', width: 100, sortable: true, menuDisabled :true},
			{header: '借阅结束时间', dataIndex: 'etime', width: 100, sortable: true, menuDisabled :true},
			{header: '档案室', dataIndex: 'danganshi', width: 100, sortable: true, menuDisabled :true},
			{header: '类目', dataIndex: 'type1', width: 100, sortable: true, menuDisabled :true},
			{header: '案卷', dataIndex: 'anjuan', width: 80, sortable: true, menuDisabled :true},
			{header: '文种', dataIndex: 'wenzhong', width: 80, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		/**
		 * 
			layout:"fit",
			border : false,
	        store: this.store,
	        trackMouseOver:false,
	        disableSelection:true,
	        loadMask: true,
			autoScroll : true,
		 */
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			layout:"fit",
			border:false,
			trackMouseOver:false,
	        disableSelection:true,
			autoScroll : true,
			store:this.store,
			loadMask : {msg: lang('loading')},
			cm: this.colModel,
			sm: this.sm,
			hideBorders: true,
	        viewConfig: {
	            forceFit:true,
	            enableRowBody:true,
	            showPreview:true,
	            getRowClass : function(record, rowIndex, p, store){
	                if(this.showPreview){
	                    p.body = '<div style="padding-left:45px;" class="cnoa_color_gray"><div style=" width:60px; float:left">借阅原因: </div><div style="width:700px; float:left;">'+record.data.reason+'</div></div>';
	                }
	            }
	        },
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "waiting";
						_this.store.load({params: _this.storeBar});
						Ext.getCmp(ID_BTN_AGREE).show();
						Ext.getCmp(ID_BTN_DISAGREE).show();
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					pressed: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示待审批的公文列表",
					text : '待审批'
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "pass";
						_this.store.load({params: _this.storeBar});
						Ext.getCmp(ID_BTN_AGREE).hide();
						Ext.getCmp(ID_BTN_DISAGREE).hide();
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示已审批的公文列表",
					text : '已审批'
				},"-",
				{
					handler : function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, "您还没有选择信息");
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要同意该借阅吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.submit(ids, "agree");
								}
							});
						}
					}.createDelegate(this),
					id : ID_BTN_AGREE,
					iconCls: 'icon-dialog-ok-apply',
					text : "同意"
				},"-",
				{
					handler : function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, "您还没有选择信息");
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要不同意该借阅吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.submit(ids, "disagree");
								}
							});
						}
					}.createDelegate(this),
					id : ID_BTN_DISAGREE,
					iconCls: 'icon-order-s-close',
					text : "不同意"
				},
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid]//,
			/*tbar : [
				"标题: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TITLE
				},
				"文号: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_NUMBER
				},"类型: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.typeListStore,
					width: 100,
					id : ID_SEARCH_TYPE,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"密级: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.levelListStore,
					width: 100,
					id : ID_SEARCH_LEVEL,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"缓急: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.hurryListStore,
					width: 100,
					id : ID_SEARCH_HURRY,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				{
					xtype: "button",
					text: "查询",
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.number 		= Ext.getCmp(ID_SEARCH_NUMBER).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						_this.storeBar.level 		= Ext.getCmp(ID_SEARCH_LEVEL).getValue();
						_this.storeBar.hurry 		= Ext.getCmp(ID_SEARCH_HURRY).getValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:"清空",
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NUMBER).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
						Ext.getCmp(ID_SEARCH_HURRY).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.number 		= "";
						_this.storeBar.type 		= "";
						_this.storeBar.level 		= "";
						_this.storeBar.hurry 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]*/
		});
	},
	
	submit : function(ids, type){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + '&task=submit',
			params: {ids : ids, from : type},
			method: "POST",
			success: function(r, opts) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.store.reload();
				}else{
					CNOA.msg.alert(result.msg, function(){
						_this.store.reload();
					});
				}
			},
			failure: function(response, opts) {
				CNOA.msg.alert(result.msg, function(){
					_this.store.reload();
				});
			}
		});
	},
	
	operate : function(value) {
		var _this	= this;
		var sUrl	= _this.baseUrl;
		
		var x = (screen.availWidth - 850);
		var y = (screen.availHeight - 600);
		var sWin	= 'window.open("' + sUrl + '&task=view&act=getHtml&id=' + value + '", "", "width=890,height=500,left=' + x +',top=' + y + ',scrollbars=yes,resizable=yes,status=no");';
		
		return "<a href='javascript:void(0)' onclick='" + sWin + "'>查看档案</a>";
	}
}

/**
 * 全局变量
 */

var CNOA_odoc_files_clean, CNOA_odoc_files_cleanClass;
CNOA_odoc_files_cleanClass = CNOA.Class.create();
CNOA_odoc_files_cleanClass.prototype = {
	init:function(){
		var _this = this;
		
		this.ID_anJuan			= Ext.id();
				
		this.baseUrl = "index.php?app=odoc&func=files&action=clean";
		
		Ext.Ajax.request({
			url:_this.baseUrl + "&task=loadColumn",
			method:'POST',
			success:function(r){
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.layoutPanel(result);
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	layoutPanel:function(result){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NUMBER	= Ext.id();
		var ID_SEARCH_SORT		= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_STIME		= Ext.id();
		var ID_SEARCH_ETIME		= Ext.id();
		
		this.select = {
			room : "",
			year : ""
		};
		
		this.storeBar = {
			storeType : "send",
			title : "",
			number : "",
			type : "",
			level : "",
			stime : "",
			etime : ""
		};
		
		this.smSend = new Ext.grid.CheckboxSelectionModel({
			singleSelect:false
		});
		
		this.cmSend = [new Ext.grid.RowNumberer(), this.smSend,
			{header:'操作',sortable:true,dataIndex:'id',width:140,menuDisabled:true,renderer:function(v, c, record){
				var rd = record.data;
				var l = '';
				if(rd.status == 2){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_clean.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}else if(rd.status == 0){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_clean.operate('+v+')">发起审批</a>';
				}else if(rd.status == 1){
					l += '审批中';
				}
				return l;
			}},
			{header:'添加时间',sortable:true,dataIndex:'posttime',width:100,menuDisabled:true}
		];

		this.fieldSend = [{name:'id'},{name:'posttime'},{name:'status'},{name:'uFlowId'}];
		Ext.each(result.column.send, function(v,i){
			_this.fieldSend.push({name:'field_'+v.field});
			_this.cmSend.push({
				header			:v.title,
				sortable		:true,
				dataIndex		:'field_'+v.field,
				width			:v.width,
				menuDisabled	:true
			});
		});
		
		this.typeListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getTypeList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.typeListStore.load();
		
		this.levelListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getLevelList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.levelListStore.load();
		
		this.roomListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getRoomList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.roomListStore.load();
		
		this.anJuanListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getAnjuanList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			}),
			listeners : {
				"load" : function(){
					//Ext.getCmp(_this.ID_anJuan).setValue(_this.anjuanid);
				}
			}
		});
		
		this.wenzhongListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getWenzhongList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.wenzhongListStore.load();
		
		this.storeSend = new Ext.data.Store({
			autoLoad:true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData&from=send", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:this.fieldSend}),
			listeners:{
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		this.storeSend.load({params:{from:'send'}});
				
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.storeSend,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.gridSend = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			border:false,
			store:this.storeSend,
			loadMask : {msg: lang('loading')},
			columns: this.cmSend,
			sm: this.smSend,
			hideBorders: true,
			listeners:{
				"rowdblclick" : function(button, event){}
			},
			bbar: this.pagingBar
		});
		
		
		this.smReceive = new Ext.grid.CheckboxSelectionModel({
			singleSelect:false
		});
		
		this.cmReceive = [new Ext.grid.RowNumberer(), this.smReceive,
			{header:'操作',sortable:true,dataIndex:'id',width:140,menuDisabled:true,renderer:function(v, c, record){
				var rd = record.data;
				var l = '';
				if(rd.status == 2){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_clean.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}else if(rd.status == 0){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_clean.operate('+v+')">发起审批</a>';
				}else if(rd.status == 1){
					l += '审批中';
				}
				return l;
			}},
			{header:'添加时间',sortable:true,dataIndex:'posttime',width:100,menuDisabled:true},
			{header:'来文机关',sortable:true,dataIndex:'deptment',width:100,menuDisabled:true},
			{header:'来文标题',sortable:true,dataIndex:'title',width:100,menuDisabled:true},
			{header:'来文编号',sortable:true,dataIndex:'number',width:100,menuDisabled:true}
		];

		this.fieldSend = [{name:'id'},{name:'posttime'},{name:'status'},{name:'uFlowId'},{name:'deptment'},{name:'title'},{name:'number'}];
		Ext.each(result.column.receive, function(v,i){
			_this.fieldSend.push({name:'field_'+v.field});
			_this.cmReceive.push({
				header			:v.title,
				sortable		:true,
				dataIndex		:'field_'+v.field,
				width			:v.width,
				menuDisabled	:true
			});
		});
		
		this.storeReceive = new Ext.data.Store({
			autoLoad:true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData&from=receive", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:this.fieldSend}),
			listeners:{
				"load" : function(th, rd, op){
				}
			}
		});
		
		this.storeReceive.load({params:{from:'receive'}});
		
		this.gridReceive = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			border:false,
			store:this.storeReceive,
			loadMask : {msg: lang('loading')},
			columns: this.cmReceive,
			sm: this.smReceive,
			hideBorders: true,
			listeners:{
				"rowdblclick" : function(button, event){}
			},
			bbar: this.pagingBar
		});
		
		this.secondPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			region:'center',
			layout:'card',
			autoScroll:false,
			activeItem:0,
			items:[this.gridSend, this.gridReceive],
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.storeReceive.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.add("add", 0);
					}.createDelegate(this),
					iconCls: 'icon-folder--pencil',
					text : '著录'
				},"-",
				{
					handler : function(button, event) {
						if(_this.storeBar.storeType == "receive"){
							var rows = _this.gridReceive.getSelectionModel().getSelections();
						}else{
							var rows = _this.gridSend.getSelectionModel().getSelections();
						}
						if(rows.length == 0){
							CNOA.miniMsg.alertShowAt(button, "您还没有选择要归档的信息");
						}else{
							var ids = "";
							for(var i = 0; i < rows.length; i++){
								ids += rows[i].get("id") + ",";
							}
							_this.collect(ids);
						}
					}.createDelegate(this),
					iconCls: 'icon-folder--plus',
					text : '归档'
				},"-",
				{
					handler : function(button, event) {
						_this.deleteList(button, _this.storeBar.storeType);
					}.createDelegate(this),
					iconCls: 'icon-utils-s-delete',
					text : '删除'
				},"-",
				{
					handler:function(button, event){
						_this.storeBar.storeType = "send";
						_this.secondPanel.layout.setActiveItem(0);
					}.createDelegate(this),
					iconCls:'icon-roduction',
					pressed:true,
					enableToggle:true,
					allowDepress:false,
					toggleGroup:"meeting_room_check",
					tooltip:"显示发文的公文列表",
					text:'发文列表'
				},"-",
				{
					handler:function(button, event){
						_this.storeBar.storeType = "receive";
						_this.secondPanel.layout.setActiveItem(1);
					}.createDelegate(this),
					iconCls:'icon-roduction',
					enableToggle:true,
					allowDepress:false,
					toggleGroup:"meeting_room_check",
					tooltip:"显示收文的公文列表",
					text:'收文列表'
				}
			]			
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			layout:'border',
			autoScroll:false,
			items:[this.secondPanel],
			tbar:[
				"标题:",
				{
					xtype:"textfield",
					width:100,
					id:ID_SEARCH_TITLE
				},
				"文号:",
				{
					xtype:"textfield",
					width:100,
					id:ID_SEARCH_NUMBER
				},
				"类别:",
				new Ext.form.ComboBox({
					name:'title',
					store:_this.typeListStore,
					width:100,
					id:ID_SEARCH_TYPE,
					hiddenName:'tid',
					valueField:'tid',
					displayField:'title',
					mode:'local',
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}),
				"密级: ",
				new Ext.form.ComboBox({
					name:'title',
					store:_this.levelListStore,
					width:100,
					id:ID_SEARCH_LEVEL,
					hiddenName:'tid',
					valueField:'tid',
					displayField:'title',
					mode:'local',
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}),
				"起始日期",
				{
					xtype:"datefield",
					format:"Y-m-d",
					id:ID_SEARCH_STIME,
					width:100
				},
				"终止日期",
				{
					xtype:"datefield",
					format:"Y-m-d",
					id:ID_SEARCH_ETIME,
					width:100
				},
				{
					xtype:"button",
					text:"查询",
					style:"margin-left:5px",
					cls:"x-btn-over",
					listeners:{
						"mouseout":function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.number 		= Ext.getCmp(ID_SEARCH_NUMBER).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						_this.storeBar.level 		= Ext.getCmp(ID_SEARCH_LEVEL).getValue();
						_this.storeBar.stime 		= Ext.getCmp(ID_SEARCH_STIME).getRawValue();
						_this.storeBar.etime 		= Ext.getCmp(ID_SEARCH_ETIME).getRawValue();

						_this.storeSend.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:"清空",
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NUMBER).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
						Ext.getCmp(ID_SEARCH_STIME).setValue("");
						Ext.getCmp(ID_SEARCH_ETIME).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.number 		= "";
						_this.storeBar.type 		= "";
						_this.storeBar.level 		= "";
						_this.storeBar.stime 		= "";
						_this.storeBar.etime 		= "";
						
						_this.storeSend.load({params:_this.storeBar});
					}
				}
			]
		});

		Ext.getCmp(CNOA.odoc.files.clean.parentID).add(this.mainPanel);
		Ext.getCmp(CNOA.odoc.files.clean.parentID).doLayout();
	},
	
	//整理要删除的ID列表	
	deleteList:function(button, fromType){
		var _this = this;				
		var rows = _this.gridSend.getSelectionModel().getSelections(); // 返回值为 Record 数组 
		if (rows.length == 0) {
			CNOA.miniMsg.alertShowAt(button, lang('mustSelectOneRow'));

		} else {
			CNOA.msg.cf("您确定要删除?", function(btn) {
				if (btn == 'yes') {
					if (rows) {
						var ids = "";
						var row = '';
						for (var i = 0; i < rows.length; i++) {
							var row		= rows[i];
							var id		= parseInt(row.get("id"));
							ids += id + ",";							
						}
						_this.deleteData(ids, fromType);
					}
				}
			});
		}
	},
	
	//发送删除信息
	deleteData:function(ids, fromType){
	    var	_this = this;
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=delete",
			method: 'POST',
			params: { ids: ids, fromType:fromType },
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					CNOA.msg.notice(result.msg, "公文管理");
					_this.storeSend.reload();
					_this.storeReceive.reload();
				}else{
					CNOA.msg.alert(result.msg);
				}
			}
		});
	},
	
	operate : function(value,c,record) {
		var _this	= this;
		var rd = record.data;
		return '<a href="javascript:void(0)" onclick="CNOA_odoc_files_clean.viewFlow('+rd.uFlowId+')">查看流程</a>';
	},
	
	viewFlow:function(uFlowId){
		mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
		mainPanel.loadClass(this.baseUrl+"&task=loadpage&from=viewflow&uFlowId="+uFlowId, "CNOA_MENU_WF_USE_OPENFLOW", "查看工作流程", "icon-flow");
	},
	
	add : function(type, id){
		var _this = this;
		
		var loadFileFormData = function(){
			form.getForm().load({
				url: _this.baseUrl + "&task=loadFileFormData",
				params : {id : id},
				method:'POST',
				waitTitle: lang('waiting'),
				success: function(form, action){
					_this.anjuanid = action.result.data.anjuan;
					_this.anJuanListStore.load({params : action.result.data.year});
					//Ext.getCmp(_this.ID_anJuan).setValue(_this.anjuanid);
				},
				failure: function(form, action) {
					CNOA.msg.alert(action.result.msg, function(){
						
					});
				}
			})
		};
		
		var submit = function(){
			if (form.getForm().isValid()) {
				form.getForm().submit({
					url: _this.baseUrl + "&task=add",
					waitTitle: lang('waiting'),
					method: 'POST',
					params : {storeType : _this.storeBar.storeType, id:id},
					waitMsg: lang('loading'),
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						win.close();
						_this.storeSend.reload();
						_this.storeReceive.reload();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg, function(){});
					}.createDelegate(this)
				});
			}
		};
		
		var baseField = [
			{
				xtype: "fieldset",
				title: "著录信息",
				autoHeight: true,
				defaults : {
					border : false,
					style : "margin-bottom : 5px"
				},
				items: [
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype:"textfield",
										fieldLabel:"文件标题",
										width:150,
										name:"title",
										allowBlank : false
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										fieldLabel : "密级",
										name: 'level',
										store: _this.levelListStore,
										width: 150,
										allowBlank : false,
										hiddenName: 'level',
										valueField: 'tid',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "件号",
										width: 150,
										name : "filesnum",
										allowBlank : false
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "文件字号",
										name : "number",
										width: 150,
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "datefield",
										fieldLabel: "成文日期",
										name : "senddate",
										format : "Y-m-d",
										width: 150,
										allowBlank : false
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "责任者",
										width: 150,
										name : "respon",
										value : CNOA_USER_TRUENAME
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "页号",
										name : "page",
										width: 150
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "datefield",
										fieldLabel: "归档日期",
										name : "collectdate",
										format : "Y-m-d",
										width: 150,
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'room',
										store: _this.roomListStore,
										width: 150,
										fieldLabel : "档案室",
										hiddenName: 'room',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false,
										listeners : {
											"select" : function(th, record, num){
												form.getForm().findField("anjuan").setValue("");
												_this.select.room = record.id;
												_this.anJuanListStore.load({params : _this.select.room});
											}
										}
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'wenzhong',
										store: _this.wenzhongListStore,
										width: 150,
										fieldLabel : "文种",
										hiddenName: 'wenzhong',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false
									})
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										fieldLabel: "年度",
										name: 'year',
										store: new Ext.data.SimpleStore({
											fields: ['value', 'year'],
											data: (function(){
												var Y = new Date().getFullYear()+1;
												var arr	= [];
												for(var i=0; i<20;i++){
													arr[i]	= [Y, Y];
													Y--;
												}
												return arr;
											})()
										}),
										width: 150,
										hiddenName: 'year',
										valueField: 'value',
										displayField: 'year',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										regex: /^\+?[1-9][0-9]*$/i,
										regexText: '必须设置为正整数',
										allowBlank : false,
										listeners : {
											"select" : function(th, record, num){
												form.getForm().findField("anjuan").setValue("");
												_this.select.year = record.data.value;
												_this.anJuanListStore.load({params : _this.select.year});
											}
										}
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										id: _this.ID_anJuan,
										name: 'anjuan',
										store: _this.anJuanListStore,
										width: 150,
										fieldLabel : "案卷",
										hiddenName: 'anjuan',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false
									})
								]
							}
						]
					},
					{
						xtype: "flashfile",
						fieldLabel: "添加附件",
						style: "margin-top:5px;",
						inputPre: "filesUpload",
						name : "attach"
					},
					{
						xtype : "textarea",
						fieldLabel : "备注",
						width : 385,
						height : 50,
						name: "note"
					}
				]
			}
		];
		
		var form = new Ext.form.FormPanel({
			border: false,
			labelWidth: 80,
			labelAlign: 'right',
			region : "center",
			layout : "fit",
			waitMsgTarget: true,
			items:[
				{
					xtype: "panel",
					border: false,
					bodyStyle: "padding:10px",
					layout: "form",
					region: "center",
					autoScroll: true,
					items: baseField
				}
			]
		});
		
		var win = new Ext.Window({
			title : "著录窗口",
			layout : "border",
			width : 550,
			height : makeWindowHeight(420),
			resizable : false,
			modal : true,
			items : [form],
			buttons : [
				{
					text : "提交",
					handler : function(){
						submit();
					}
				},
				{
					text : "取消",
					handler : function(){
						win.close();
					}
				}
			]
		}).show();
		if(type == "edit"){
			loadFileFormData();
		}
	},
	
	collect : function(ids){
		var _this = this;
		
		var submit = function(ids){
			if (form.getForm().isValid()) {
				form.getForm().submit({
					url: _this.baseUrl + "&task=collect",
					waitTitle: lang('waiting'),
					params : {ids : ids, storeType : _this.storeBar.storeType},
					method: 'POST',
					waitMsg: lang('loading'),
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						win.close();
						_this.storeSend.reload();
						_this.storeReceive.reload();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg, function(){

						});
					}.createDelegate(this)
				});
			}
		};
		
		var loadFormData = function(ids, type){
			form.getForm().load({
				url: _this.baseUrl + "&task=loadFormData",
				params : {ids : ids, storeType : type},
				method:'POST',
				waitTitle: lang('waiting'),
				success: function(form, action){
					
				},
				failure: function(form, action) {
					CNOA.msg.alert(action.result.msg, function(){
						
					});
				}
			})
		};
		
		var baseField = [
			{
				xtype: "fieldset",
				title: "归档信息",
				autoHeight: true,
				defaults : {
					border : false,
					style : "margin-bottom : 5px"
				},
				items: [
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "文件标题",
										width: 150,
										name : "title"
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										fieldLabel:"文件类型",
										store:new Ext.data.SimpleStore({
											fields:['value', 'text'],
											data:[['0', "其他"], ['1', "发文"], ['2', "收文"]]
										}),
										width:150,
										valueField:'value',
										displayField:'text',
										mode:'local',
										triggerAction:'all',
										forceSelection:true,
										editable:false,
										hiddenName:'type',
										name:'name',
										listeners:{
											select:function(th, record, index){
												var id = record.data.value;
												submit("gender", id);
											}
										}
									})
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "成文日期",
										name : "senddate",
										width: 150
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "文件字号",
										width: 150,
										name : "number"
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "归档日期",
										width: 150,
										name : "guidangdate"
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "责任者",
										width: 150,
										name : "respon",
										value : CNOA_USER_TRUENAME
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "页号",
										width: 150,
										name : "page"
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "件号",
										name : "filesnum",
										width: 150
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'room',
										store: _this.roomListStore,
										width: 150,
										fieldLabel : "档案室",
										hiddenName: 'room',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false,
										listeners : {
											"select" : function(th, record, num){
												form.getForm().findField("anjuan").setValue("");
												_this.select.room = record.id;
												_this.anJuanListStore.load({params : _this.select.room});
											}
										}
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'wenzhong',
										store: _this.wenzhongListStore,
										width: 150,
										fieldLabel : "文种",
										hiddenName: 'wenzhong',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false
									})
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										fieldLabel: "年度",
										name: 'anjuandate',
										store: new Ext.data.SimpleStore({
											fields: ['value', 'anjuandate'],
											data: (function(){
												var Y = new Date().getFullYear()+1;
												var arr	= [];
												for(var i=0; i<20;i++){
													arr[i]	= [Y, Y];
													Y--;
												}
												return arr;
											})()
										}),
										width: 150,
										hiddenName: 'anjuandate',
										valueField: 'value',
										displayField: 'anjuandate',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false,
										listeners : {
											"select" : function(th, record, num){
												form.getForm().findField("anjuan").setValue("");
												_this.select.year = record.data.value;
												_this.anJuanListStore.load({params : _this.select});
											}
										}
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'anjuan',
										store: _this.anJuanListStore,
										width: 150,
										fieldLabel : "案卷",
										hiddenName: 'anjuan',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false
									})
								]
							}
						]
					},
					new Ext.BoxComponent({
						autoEl: {
							tag: 'div',
							style: "margin-left:80px;margin-top:5px;margin-bottom:5px;color:#676767;",
							html: '注意:案卷管理是通过档案室和年度筛选出来的,选择了档案室和年度才会显示出相应的案卷'
						}
					})
				]
			}
		];
		
		var form = new Ext.form.FormPanel({
			border: false,
			labelWidth: 80,
			labelAlign: 'right',
			region : "center",
			layout : "fit",
			waitMsgTarget: true,
			items:[
				{
					xtype: "panel",
					border: false,
					bodyStyle: "padding:10px",
					layout: "form",
					region: "center",
					autoScroll: true,
					items: baseField
				}
			]
		});
		
		var win = new Ext.Window({
			title:"归档窗口",
			layout:"border",
			width:550,
			height:360,
			resizable:false,
			modal:true,
			items:form,
			buttons:[
				{
					text:"确认",
					handler:function(){
						submit(ids);
					}
				},
				{
					text:"取消",
					handler:function(){
						win.close();
					}
				}
			]
		}).show();
		
		loadFormData(ids, _this.storeBar.storeType);
	},
	
	viewFlow:function(uFlowId){
		mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
		mainPanel.loadClass(this.baseUrl+"&task=loadpage&from=viewflow&uFlowId="+uFlowId, "CNOA_MENU_WF_USE_OPENFLOW", "查看工作流程", "icon-flow");
	}
}


/**
 * 全局变量
 */

var CNOA_odoc_files_dananmgr, CNOA_odoc_files_dananmgrClass;

CNOA_odoc_files_dananmgrClass = CNOA.Class.create();
CNOA_odoc_files_dananmgrClass.prototype = {	
	init : function(){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NUMBER	= Ext.id();
		var ID_SEARCH_SORT		= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_STIME		= Ext.id();
		var ID_SEARCH_ETIME		= Ext.id();
		var ID_BTN_SPLIT		= Ext.id();
		this.ID_BTN_SAVE		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=files&action=dananmgr";
		
		this.storeBar = {
			storeType : "all",
			title : "",
			number : "",
			sort : "",
			type : "",
			level : "",
			stime : "",
			etime : ""
		};
		
		this.fields = [
			{name : "id"},
			{name : "title"},
			{name : "number"},
			{name : "type"},
			{name : "level"},
			{name : "hurry"},
			{name : "from"},
			{name : "senddate"},
			{name : "danganshi"},
			{name : "anjuan"},
			{name : "fileid"}
		];
		
		this.roomStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=roomList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.roomStore.load();
		
		this.anjuanStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=anjuanList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.store = new Ext.data.Store({
			autoLoad : true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: false
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "id", dataIndex: 'id', hidden: true},
			//{header: '档案编号', dataIndex: 'type', width: 100, sortable: true, menuDisabled :true},
			{header: '文件类型', dataIndex: 'from', width: 80, sortable: true, menuDisabled :true},
			//{header: '类别', dataIndex: 'type', width: 100, sortable: true, menuDisabled :true},
			{header: '标题', dataIndex: 'title', width: 150, sortable: true, menuDisabled :true},
			{header: '文件字号', dataIndex: 'number', width: 100, sortable: true, menuDisabled :true},
			{header: '成文日期', dataIndex: 'senddate', width: 80, sortable: true, menuDisabled :true},
			//{header: '文种', dataIndex: 'w', width: 80, sortable: true, menuDisabled :true},
			{header: '所在档案室', dataIndex: 'danganshi', width: 80, sortable: true, menuDisabled :true},
			{header: '所在案卷', dataIndex: 'anjuan', width: 80, sortable: true, menuDisabled :true},
			{header: '操作', dataIndex: 'fileid', width: 120, sortable: true, menuDisabled :true, renderer : this.operate.createDelegate(this)},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			border:false,
			store:this.store,
			loadMask : {msg: lang('loading')},
			cm: this.colModel,
			sm: this.sm,
			hideBorders: true,
			listeners:{
				"rowdblclick":function(button, event){
					/*
					var rows = _this.grid.getSelectionModel().getSelections();
					_this.type = "edit";
					_this.edit_id = rows[0].get("id");
					var CNOA_odoc_files_clean = new CNOA_odoc_files_cleanClass();
					CNOA_odoc_files_clean.add(_this.type, _this.edit_id);
					*/
				}
			},
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "all";
						_this.store.load({params: _this.storeBar});
						Ext.getCmp(ID_BTN_SPLIT).show();
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					pressed: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示所有档案列表",
					text : '所有档案'
				},'-',
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "history";
						_this.store.load({params: _this.storeBar});
						Ext.getCmp(ID_BTN_SPLIT).hide();
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示分发历史记录列表",
					text : '分发历史记录'
				},"-",
				{
					handler : function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections();

						if(rows.length <= 0){
							CNOA.msg.alert('您好，请至少选择一个档案进行操作.');
							return;
						}
						var slid = rows[0].json.id;
						
						_this.issueSend(slid);
					}.createDelegate(this),
					id : ID_BTN_SPLIT,
					iconCls: 'icon-applications-stack',
					tooltip: "分发文件",
					text : '分发'
				},"-","<span>双击可修改档案信息，按住ctrl或shift键可选择多个</span>",
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid],
			tbar : [
				"标题: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TITLE
				},
				"文号: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_NUMBER
				},"类型: ",
				new Ext.form.ComboBox({
					name: 'sort',
					store: new Ext.data.SimpleStore({
						fields: ['value', 'title'],
						data: [['1', "发文"], ['2', "收文"]]
					}),
					width: 60,
					hiddenName: 'sort',
					id : ID_SEARCH_SORT,
					valueField: 'value',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false,
					listeners : {

					}
				}),
				"档案室: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.roomStore,
					width: 100,
					id : ID_SEARCH_TYPE,
					hiddenName: 'id',
					valueField: 'id',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false,
					listeners : {
						select : function(th, record, index){
							Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
							//cdump(record);
							_this.anjuanStore.load({params : {id : record.id}});
						}
					}
				}),
				"案卷: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.anjuanStore,
					width: 100,
					id : ID_SEARCH_LEVEL,
					hiddenName: 'id',
					valueField: 'id',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"起始日期",
				{
					xtype : "datefield",
					format : "Y-m-d",
					id : ID_SEARCH_STIME,
					width : 100
				},
				"终止日期",
				{
					xtype : "datefield",
					format : "Y-m-d",
					id : ID_SEARCH_ETIME,
					width : 100
				},
				{
					xtype: "button",
					text: "查询",
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.number 		= Ext.getCmp(ID_SEARCH_NUMBER).getValue();
						_this.storeBar.sort 		= Ext.getCmp(ID_SEARCH_SORT).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						_this.storeBar.level 		= Ext.getCmp(ID_SEARCH_LEVEL).getValue();
						_this.storeBar.stime 		= Ext.getCmp(ID_SEARCH_STIME).getRawValue();
						_this.storeBar.etime 		= Ext.getCmp(ID_SEARCH_ETIME).getRawValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:"清空",
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NUMBER).setValue("");
						Ext.getCmp(ID_SEARCH_SORT).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
						Ext.getCmp(ID_SEARCH_STIME).setValue("");
						Ext.getCmp(ID_SEARCH_ETIME).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.number 		= "";
						_this.storeBar.sort 		= "";
						_this.storeBar.type 		= "";
						_this.storeBar.level 		= "";
						_this.storeBar.stime 		= "";
						_this.storeBar.etime 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]
		});
	},
	
	operate : function(value, cellmeta, record, rowIndex, columnIndex, color_store){
		var _this = this;
		if(_this.storeBar.storeType == "history"){
			return "<a href='javascript:void(0)' onclick='CNOA_odoc_files_dananmgr.newSplit("+value+", \"view\")'>查看分发</a>";
		}else{
			var id = record.data.id;
			/*
			var _this	= this; //cdump(record);
			
			var sUrl	= _this.baseUrl;
			
			var x = 0;
			var y = 0;
			var sWin	= 'window.open("' + sUrl + '&task=view&act=getHtml&id=' + id + '", "", "width='+(screen.availWidth)+',height='+(screen.availHeight)+',left=' + x +',top=' + y + ',scrollbars=yes,resizable=yes,status=no");';
			
			return "<a href='javascript:void(0)' onclick='" + sWin + "'>查看档案</a>";
			*/
			return "<a href='javascript:void(0)' onclick='CNOA_odoc_files_dananmgr.viewOdocFiles("+id+");'>查看档案</a>";
		}
	},

	viewOdocFiles : function(id){
		CNOA_odoc_viewFiles = new CNOA_odoc_viewFilesClass(id, this.baseUrl);
	},
	
	issueSend:function(id){
		var _this = this;
		
		var rows = _this.grid.getSelectionModel().getSelections();
		
		if(rows.length <= 0){
			CNOA.msg.alert('您好，请至少选择一个发文进行操作.');
			return;
		}
		var slid = rows[0].json.id;

		var frm = new Ext.form.FormPanel({
			border: false,
			labelWidth: 50,
			labelAlign: 'right',
			bodyStyle:'padding: 10px 0 0 15px',
			defaults:{
				style: 'margin-bottom: 10px'
			},
			items: [
				{
					xtype:'textarea',
					fieldLabel:'收文人',
					name:'recvMan',
					width:300,
					height:150,
					readOnly:true,
					allowBlank:false
				},
				{
					xtype:"hidden",
					name:"recvUids",
					id:_this.ID_recvUids
				},
				{
					xtype:"panel",
					hidden:false,
					layout:"form",
					border:false,
					items:[
						{
							xtype:"btnForPoepleSelector",
							fieldLabel:"",
							text:'选择',
							allowBlank: false,
							name:"checkName",
							dataUrl: _this.baseUrl+"&task=getAllUserListsInPermitDeptTree",
							width:70,
							style:'margin: 0 0 0 55px',
							listeners:{
								"selected":function(th, data){
									var names = new Array();
									var uids = new Array();
									
									if (data.length>0){
										for (var i=0;i <= data.length - 1; i++){
											names.push(data[i].uname);
											uids.push(data[i].uid);
										}
									}
									var sNames	= names.join(",");
									var sUids	= uids.join(",");
									
									frm.getForm().findField("recvUids").setValue(sUids);
									frm.getForm().findField("recvMan").setValue(sNames);
								}
							}
						}
					]
				}
			]
		})
		
		submit = function(){
			var f = frm.getForm();
			if (f.isValid()) {
				f.submit({
					url: _this.baseUrl + '&task=submitIssue',
					method: 'POST',
					params: {id:slid},
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						_this.store.reload();
						win.close();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg);
					}
				});
			}else{
				CNOA.msg.alert("部分表单未完成,请检查");
			}
		};
		
		var win = new Ext.Window({
			title: '分发',
			width: 400,
			height: 300,
			layout: 'fit',
			modal: true,
			resizable: false,
			maximizable: false,
			items: [frm],
			buttons:[
				{
					text: '确定分发',
					handler: function(){
						submit();
					}
				},{
					text: '关闭',
					handler: function (){						
						win.close();
					}
				}
			]
		}).show();
		
		return win;
	}
}


/**
 * 全局变量
 */

var CNOA_odoc_files_setting, CNOA_odoc_files_settingClass;
CNOA_odoc_files_settingClass = CNOA.Class.create();
CNOA_odoc_files_settingClass.prototype = {	
	init : function(){
		var _this = this;
		
		var ID_BTN_SETTING_TYPE = Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=files&action=setting";
		
		this.storeBar = {
			from : "room"
		};
		
		this.dsc = Ext.data.Record.create([
		{
			name: 'title',
			type: 'string'
		}]);
		
		this.fields = [
			{name : "id"},
			{name : "title"},
			{name : "postname"},
			{name : "order"}
		];
		
		this.store = new Ext.data.GroupingStore({
			autoLoad: true,
			proxy: new Ext.data.HttpProxy({
				url: this.baseUrl + '&task=getJsonData'
			}),
			reader: new Ext.data.JsonReader({
				totalProperty: "total",
				root: "data",
				fields: this.fields
			}),
			listeners: {
				'update': function(thiz, record, operation) {
					var user = record.data;
					if (operation == Ext.data.Record.EDIT) {//判断update时间的操作类型是否为 edit 该事件还有其他操作类型比如 commit,reject 
						user.from = _this.storeBar.from;  
						_this.submit(user);
					}
				}
			}
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.editor = new Ext.ux.grid.RowEditor({
			cancelText: '取消',
			saveText: '更新',
			errorSummary: false
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			
		});
		
		this.cm = [new Ext.grid.RowNumberer(), this.sm,
		{
			header: '',
			dataIndex: 'id',
			hidden: true
		}, {
			header: '档案室名称',
			dataIndex: 'title',
			width: 300,
			sortable: false,
			editor: {
				xtype: 'textfield',
				allowBlank: false
			}
		}, {
			header : '排序',
			dataIndex : 'order',
			width : 100,
			sortable : false,
			editor: {
				xtype : 'textfield',
				allowBlank : true,
				regex: /^\+?[1-9][0-9]*$/i,
				regexText: '必须设置为正整数'
			}
		}, {
			header: '发布人',
			dataIndex: 'postname',
			width: 80,
			sortable: false
		}];
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			store: this.store,
			plain: false,
			loadMask : {msg: lang('loading')},
			region: "center",
			border: false,
			autoScroll: true,
			plugins: [this.editor],
			columns: this.cm,
			sm : this.sm,
			view: new Ext.grid.GroupingView({
				markDirty: false
			}),
			listeners:{
				cellclick:function(th, rowNum, columnNum, e){
					if(columnNum == 1){
						return false;
					}
				}
			},
			tbar: [
				{
					handler : function(button, event) {
						_this.store.reload();
					}.createDelegate(this),
					iconCls: 'icon-system-refresh',
					text : lang('refresh')
				},'-',
				{
					handler : function(button, event) {
						var e = new _this.dsc({
   							name: ''
   						});
   						_this.editor.stopEditing();
   						_this.store.insert(0, e);
   						_this.grid.getView().refresh();
   						_this.grid.getSelectionModel().selectRow(0);
   						_this.editor.startEditing(0);
					}.createDelegate(this),
					iconCls: 'icon-system-refresh',
					text : "添加"
				},'-',
				{
					text : "删除",
					iconCls: 'icon-utils-s-delete',
					handler : function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, lang('mustSelectOneRow'));
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要删该记录吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.deleteData(ids);
								}
							});
						}
					}
				},
				"<span class='cnoa_color_gray'>双击可修改记录,按住Ctrl或Shift键可以一次选择多条记录</span>",
				'->',{xtype: 'cnoa_helpBtn', helpid:5002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid],
			tbar : [
				{
					text : "档案室列表",
					iconCls: 'icon-ui-combo-boxes',
					enableToggle: true,
					toggleGroup: "odoc_files_set_types",
					pressed:true,
					allowDepress:false,
					handler : function(){
						_this.storeBar.from = "room";
						_this.grid.getColumnModel().setColumnHeader(3, "档案室名称");
						_this.grid.getColumnModel().setColumnHeader(4, "排序");
						_this.store.load({params : _this.storeBar});
						//Ext.getCmp(ID_BTN_SETTING_TYPE).show();
					}
				},'-',
				{
					text : "内目",
					iconCls: 'icon-ui-combo-box',
					enableToggle: true,
					toggleGroup: "odoc_files_set_types",
					allowDepress:false,
					handler : function(){
						_this.storeBar.from = "type";
						_this.grid.getColumnModel().setColumnHeader(3, "内目名称");
						_this.grid.getColumnModel().setColumnHeader(4, "排序");
						_this.store.load({params : _this.storeBar});
						//Ext.getCmp(ID_BTN_SETTING_TYPE).hide();
					}
				},'-',
				{
					text : "文种",
					iconCls: 'icon-ui-combo-box-blue',
					enableToggle: true,
					toggleGroup: "odoc_files_set_types",
					allowDepress:false,
					handler : function(){
						_this.storeBar.from = "wenzhong";
						_this.grid.getColumnModel().setColumnHeader(3, "文种名称");
						_this.grid.getColumnModel().setColumnHeader(4, "排序");
						_this.store.load({params : _this.storeBar});
						//Ext.getCmp(ID_BTN_SETTING_TYPE).hide();
					}
				},'-',
				{
					text : "保管期限",
					iconCls: 'icon-ui-combo-boxes',
					enableToggle: true,
					toggleGroup: "odoc_files_set_types",
					allowDepress:false,
					handler : function(){
						_this.storeBar.from = "savetime";
						_this.grid.getColumnModel().setColumnHeader(3, "保管期限");
						_this.grid.getColumnModel().setColumnHeader(4, "排序");
						_this.store.load({params : _this.storeBar});
						//Ext.getCmp(ID_BTN_SETTING_TYPE).hide();
					}
				}
			]
		})
	},
	
	submit : function(user){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + '&task=add',
			params: user,
			method: "POST",
			success: function(r, opts) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.store.reload();
				}else{
					CNOA.msg.alert(result.msg, function(){
						_this.store.reload();
					});
				}
			},
			failure: function(response, opts) {
				CNOA.msg.alert(result.msg, function(){
					_this.store.reload();
				});
			}
		});
	},
	
	deleteData : function(ids){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + '&task=delete',
			params: {ids : ids, from : _this.storeBar.from},
			method: "POST",
			success: function(r, opts) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.store.reload();
				}else{
					CNOA.msg.alert(result.msg, function(){
						_this.store.reload();
					});
				}
			},
			failure: function(response, opts) {
				CNOA.msg.alert(result.msg, function(){
					_this.store.reload();
				});
			}
		});
	}
}


/**
 * 全局变量
 */

var CNOA_odoc_read_meetingClass, CNOA_odoc_read_meeting;
CNOA_odoc_read_meetingClass = CNOA.Class.create();
CNOA_odoc_read_meetingClass.prototype = {
	init : function(){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NAME		= Ext.id();
		var ID_SEARCH_STIME		= Ext.id();
		var ID_SEARCH_ETIME		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=read&action=meeting";
			
		this.storeBar = {
			storeType : "waiting",
			title : "",
			name : "",
			stime : "",
			etime : ""
		};
		
		this.fields = [
			{name : "rid"},
			{name : "aid"},
			{name : "name"},
			{name : "markname"},
			{name : "title"},
			{name : "stime"},
			{name : "etime"},
			{name : "statusname"},
			{name : "appname"},
			{name : "checktime"},
			{name : "opinion"}
		];
		
		this.store = new Ext.data.Store({
			autoLoad : true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: false
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "rid", dataIndex: 'rid', hidden: true},
			{header: '会议名称', dataIndex: 'name', width: 100, sortable: true, menuDisabled :true, renderer : this.showDetails.createDelegate(this)},
			{header: '主题', dataIndex: 'title', width: 200, sortable: true, menuDisabled :true},
			{header: '会议开始时间', dataIndex: 'stime', width: 120, sortable: true, menuDisabled :true},
			{header: '会议结束时间', dataIndex: 'etime', width: 120, sortable: true, menuDisabled :true},
			{header: '分发意见', dataIndex: 'opinion', width: 200, sortable: true, menuDisabled :true, renderer : this.opinion.createDelegate(this)},
			{header: lang('opt'), dataIndex: 'aid', width: 120, sortable: true, menuDisabled :true, renderer : this.operate.createDelegate(this)},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			border:false,
			store:this.store,
			loadMask : {msg: lang('waiting')},
			cm: this.colModel,
			sm: this.sm,
			hideBorders: true,
			listeners:{
				"rowdblclick":function(button, event){
					
				}
			}, 
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "waiting";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					pressed: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示待阅读的公文列表",
					text : '待阅读'
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "readed";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示已阅读的公文列表",
					text : '已阅读'
				},
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid],
			tbar : [
				"会议名称: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_NAME
				},
				"主题: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TITLE
				},
				"会议开始时间: ",
				{
					xtype : "datefield",
					width : 150,
					format : "Y-m-d",
					id : ID_SEARCH_STIME
				},
				"会议结束时间: ",
				{
					xtype : "datefield",
					width : 150,
					format : "Y-m-d",
					id : ID_SEARCH_ETIME
				},
				{
					xtype: "button",
					text: lang('search'),
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.name 		= Ext.getCmp(ID_SEARCH_NAME).getValue();
						_this.storeBar.stime 		= Ext.getCmp(ID_SEARCH_STIME).getRawValue();
						_this.storeBar.etime 		= Ext.getCmp(ID_SEARCH_ETIME).getRawValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:lang('clear'),
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NAME).setValue("");
						Ext.getCmp(ID_SEARCH_STIME).setValue("");
						Ext.getCmp(ID_SEARCH_ETIME).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.name 		= "";
						_this.storeBar.stime 		= "";
						_this.storeBar.etime 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]
		});
	},
	
	showDetails : function(value, cellmeta, record, rowIndex, columnIndex, color_store){
		return "<a href='javascript:void(0)' onclick='CNOA_odoc_read_meeting.showDetailsWin("+record.data.rid+", "+record.data.aid+")'>"+value+"</a>";
	},
	
	showDetailsWin : function(rid, aid){
		var _this = this;
		
		if(_this.storeBar.storeType == "waiting"){
			Ext.Ajax.request({  
				url: this.baseUrl + "&task=readed",
				method: 'POST',
				params: {rid : rid},
				success: function(r) {
					var result = Ext.decode(r.responseText);
					if(result.success === true){
					
					}else{
						CNOA.msg.alert(result.msg);
					}
				}
			});
		}
		
		var src = _this.baseUrl+"&task=viewMeetingRoomApplyDetails&aid="+aid;
		var win = Ext.id();
		var panel = new Ext.Panel({
			border:false,
			html: '<div style="width:100%;height:570px;"><iframe scrolling=auto frameborder=0 width=100% height=100% id="'+win+'"></iframe></div>',
			listeners:{
				afterrender:function(){
					Ext.getDom(win).contentWindow.location.href = src;
				}
			}
		});
		
		var win = new Ext.Window({
			title : "查看会议详细信息",
			width:800,
			height:makeWindowHeight(600),
			resizable: false,
			modal: true,
			items : [panel],
			buttons : [
				{
					text : lang('close'),
					handler : function(btn, e){
						if (_this.storeBar.storeType == "waiting") {
							CNOA.msg.alert("您阅读的会议信息已经转移到已阅读列表中,可在已阅读列表中查看", function(){
								win.close();
							});
						}else{
							win.close();
						}
					}
				}
			],
			listeners : {
				"beforeclose" : function(th){
					if (_this.storeBar.storeType == "waiting") {
						_this.store.reload();
					}
				}
			}
		}).show();
	},
	
	operate : function(value, c, record){
		return "<a href='javascript:void(0)' onclick='CNOA_odoc_read_meeting.read("+record.data.aid+")'>阅读情况</a>";
	},
	
	opinion : function(value, c, record){
		var _this = this;
		return "<a href='javascript:void(0)' onclick='CNOA_odoc_read_meeting.viewopinion(\""+value+"\")'>"+value+"</a>";
	},
	
	viewopinion : function(value){
		var _this = this;
		
		CNOA.msg.alert(value);
	},
	
	read : function(aid){
		var _this = this;
		
		var fields = [
			{name:"deptname"},
			{name:"name"},
			{name:"readtime"}
		];
		
		var store = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({url: _this.baseUrl+"&task=getReaderList&aid="+aid, disableCaching: true}),
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: fields})
		});
		
		store.load();
		
		var sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:false
		});
		
		var colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			{header: "所属部门", dataIndex: 'deptname', width: 100, sortable: true, menuDisabled :true},
			{header: "名字", dataIndex: 'name', width: 100, sortable: false,menuDisabled :true},
			{header: "阅读日期", dataIndex: 'readtime', width: 150, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		var Grid = new Ext.grid.GridPanel({
			stripeRows : true,
			store : store,
			region : "center",
			layout : "fit",
			loadMask : {msg: lang('waiting')},
			cm : colModel,
			sm : sm,
			hideBorders : true,
			border : false,
			viewConfig : {
				forceFit : true
			}
		});
		
		var win = new Ext.Window({
			title : "阅读情况",
			layout : "border",
			width : 600,
			height : makeWindowHeight(500),
			resizable : false,
			modal : true,
			items : [Grid],
			buttons : [
				{
					text : lang('close'),
					handler : function(){
						win.close();
					}
				}
			]
		}).show();
	}
};
/**
 * 全局变量
 */
var CNOA_odoc_read_file, CNOA_odoc_read_fileClass;
CNOA_odoc_read_fileClass = CNOA.Class.create();
CNOA_odoc_read_fileClass.prototype = {
	init : function(){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NUMBER	= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_HURRY		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=read&action=file";
		
		this.storeBar = {
			storeType : "waiting",
			title : "",
			number : "",
			type : "",
			level : "",
			hurry : ""
		};
		
		this.fields = [
			{name : "id"},
			{name : "title"},
			{name : "number"},
			{name : "type"},
			{name : "type1"},
			{name : "level"},
			{name : "wenzhong"},
			{name : "danganshi"},
			{name : "anjuan"},
			{name : "anjuandate"},
			{name : "filesnum"},
			{name : "page"},
			{name : "reader"},
			{name : "stime"},
			{name : "etime"},
			{name : "fileid"}
		];
		
		this.store = new Ext.data.Store({
			autoLoad : true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: false
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "id", dataIndex: 'id', hidden: true},
			{header: '类型', dataIndex: 'type', width: 80, sortable: true, menuDisabled :true},
			{header: '借阅开始时间', dataIndex: 'stime', width: 100, sortable: true, menuDisabled :true},
			{header: '借阅结束时间', dataIndex: 'etime', width: 100, sortable: true, menuDisabled :true},
			{header: '档案室', dataIndex: 'danganshi', width: 100, sortable: true, menuDisabled :true},
			//{header: '类别', dataIndex: 'type1', width: 100, sortable: true, menuDisabled :true},
			{header: '案卷', dataIndex: 'anjuan', width: 80, sortable: true, menuDisabled :true},
			{header: '文件提名', dataIndex: 'title', width: 120, sortable: true, menuDisabled :true},
			{header: '文种', dataIndex: 'wenzhong', width: 80, sortable: true, menuDisabled :true},
			{header: '操作', dataIndex: 'fileid', width: 120, sortable: true, menuDisabled :true, renderer : this.operate.createDelegate(this)},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			border:false,
			store:this.store,
			loadMask : {msg: lang('loading')},
			cm: this.colModel,
			sm: this.sm,
			hideBorders: true,
			listeners:{
				"rowdblclick":function(button, event){
					
				}
			},
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "waiting";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					pressed: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示待阅读的公文列表",
					text : '待阅读'
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "readed";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示已阅读的公文列表",
					text : '已阅读'
				},
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid],
			tbar : [
				"标题: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TITLE
				},
				"文号: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_NUMBER
				},
				"类型: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.typeListStore,
					width: 100,
					id : ID_SEARCH_TYPE,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"密级: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.levelListStore,
					width: 100,
					id : ID_SEARCH_LEVEL,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"缓急: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.hurryListStore,
					width: 100,
					id : ID_SEARCH_HURRY,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				{
					xtype: "button",
					text: "查询",
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.number 		= Ext.getCmp(ID_SEARCH_NUMBER).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						_this.storeBar.level 		= Ext.getCmp(ID_SEARCH_LEVEL).getValue();
						_this.storeBar.hurry 		= Ext.getCmp(ID_SEARCH_HURRY).getValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:"清空",
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NUMBER).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
						Ext.getCmp(ID_SEARCH_HURRY).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.number 		= "";
						_this.storeBar.type 		= "";
						_this.storeBar.level 		= "";
						_this.storeBar.hurry 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]
		});
	},
	
	operate : function(value,c,record) {
		var _this	= this; 
		var rd = record.data;
		return "<a href='javascript:void(0)' onclick='CNOA_odoc_read_file.viewFlow("+value+","+rd.id+")'>阅读</a>";
	},
	
	viewFlow:function(value,id){
		mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
		mainPanel.loadClass(this.baseUrl+"&task=loadpage&from=viewflow&fileid="+value+"&id="+id, "CNOA_MENU_WF_USE_OPENFLOW", "查看工作流程", "icon-flow");
	}
}


/**
 * 全局变量
 */
var CNOA_odoc_read_receive, CNOA_odoc_read_receiveClass;
CNOA_odoc_read_receiveClass = CNOA.Class.create();
CNOA_odoc_read_receiveClass.prototype = {
	init : function(){
		var _this = this;
		
		this.baseUrl = "index.php?app=odoc&func=read&action=receive";
		
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=loadColumn",
			method: 'POST',
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.layoutPanel(result);
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	layoutPanel:function(result){
		var _this = this;
			
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:true
		});
		
		this.cm = [new Ext.grid.RowNumberer(), this.sm,
			{header:lang('opt'),sortable:true,dataIndex:'id',width:50,menuDisabled:true,renderer:function(v, c, record){
				var rd = record.data;
					l = '<a href="javascript:void(0)" onclick="CNOA_odoc_read_receive.viewAttach('+v+')">查看</a>';
				return l;
			}},
			{header:'添加时间',sortable:true,dataIndex:'posttime',width:110,menuDisabled:true},
			{header:'来文机关',sortable:true,dataIndex:'deptment',width:100,menuDisabled:true},
			{header:'来文标题',sortable:true,dataIndex:'title',width:100,menuDisabled:true}
		];
		
		var fields = [{name:'id'},{name:'posttime'},{name:'status'},{name:'uFlowId'},{name:'deptment'},{name:'title'}];
		Ext.each(result.column, function(v,i){
			fields.push({name:'field_'+v.field});
			_this.cm.push({
				header			:v.title,
				sortable		:true,
				dataIndex		:'field_'+v.field,
				width			:v.width,
				menuDisabled	:true
			});
		});
		
		this.store = new Ext.data.Store({
			autoLoad: true,
			proxy: new Ext.data.HttpProxy({
				url: this.baseUrl + '&task=getJsonList'
			}),
			reader: new Ext.data.JsonReader({
				totalProperty: "total",
				root: "data",
				fields:fields
			})
		});
		
		this.grid = new Ext.grid.GridPanel({
			store:this.store,
			width:600,
			plain:false,
       		stripeRows:true,
			loadMask:{msg: lang('waiting')},
			region:"center",
			border:false,
			autoScroll:true,
			sm:this.sm,
			columns:this.cm,
			tbar:[
				{
					handler:function(button, event) {
						_this.store.reload();
					}.createDelegate(this),
					iconCls:'icon-system-refresh',
					text:lang('refresh')
				},'-',
				"<span class='cnoa_color_gray'>双击可修改记录,按住Ctrl或Shift键可以一次选择多条记录</span>"
			],
			bbar: new Ext.PagingToolbar({
				displayInfo:true,
				
				   
				store: this.store,
				pageSize:30,
				listeners: {
					"beforechange" : function(th, params){
						//Ext.apply(params, _this.search);
					}
				}
			})
		});
		
		this.treeStore = new Ext.data.Store({
			autoLoad:true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getSearchList", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:[{name:'field'},{name:'title'}]})
		});
		
		this.searchPanel = new Ext.form.FormPanel({
			region:'north',
			height:100,
			border:false,
			hidden:true,
			defaults:{
				border:false
			},
			padding:5,
			items:[
				{
					xtype:'panel',
					defaults:{
						border:false
					},
					items:[
						{
							xtype:'hidden',
							name:'id'
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:6
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong1',
									hiddenName: 'kong1',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition1',
									hiddenName:'condition1',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									name:'value1'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong1').setValue('');
										searchForm.findField('condition1').setValue('equal');
										searchForm.findField('value1').setValue('');
									}
								}
							]
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:4
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong2',
									hiddenName: 'kong2',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition2',
									hiddenName:'condition2',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									//emptyText:'查询条件',
									name:'value2'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong2').setValue('');
										searchForm.findField('condition2').setValue('equal');
										searchForm.findField('value2').setValue('');
									}
								}
							]
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:4
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[								
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong3',
									hiddenName: 'kong3',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition3',
									hiddenName:'condition3',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									//emptyText:'查询条件',
									name:'value3'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong3').setValue('');
										searchForm.findField('condition3').setValue('equal');
										searchForm.findField('value3').setValue('');
									}
								}
							]
						}
					]
				}
			]
		});
		
		var searchForm = _this.searchPanel.getForm();
		
		this.mainPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			layout:'border',
			autoScroll:false,
			items:[this.searchPanel,this.grid]/*,
			tbar:[
				{
					text:'展开查询',
					id:'EXPAND_SEARCH_PANEL',
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						if(_this.searchExpandBtn == 'close'){
							//如果要打开
							_this.searchPanel.show();
							_this.searchExpandBtn = 'open';
							Ext.getCmp('EXPAND_SEARCH_PANEL').setText('折叠查询');
							Ext.getCmp('ID_BTN_SEARCH').show();
						}else{
							//如果要关闭
							_this.searchPanel.hide();
							_this.searchExpandBtn = 'close';
							Ext.getCmp('EXPAND_SEARCH_PANEL').setText('展开查询');
							Ext.getCmp('ID_BTN_SEARCH').hide();
						}
						_this.mainPanel.doLayout();
					}
				},
				{
					text:lang('search'),
					style: "margin-left:5px",
					id:'ID_BTN_SEARCH',
					iconCls: "icon-search",
					hidden:true,
					cls: "x-btn-over",
					enableToggle:false,
		    		//allowDepress:false,
		   	 		toggleGroup:"search_definde_btn_group",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						_this.searchDatas = searchForm.getValues();
						_this.searchDatas.search = 'now';
						_this.store.load({params:_this.searchDatas});
					}
				},
				{
					text:lang('clear'),
					style: "margin-left:5px",
					cls: "x-btn-over",
		   	 		toggleGroup:"search_definde_btn_group",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						_this.store.load();
						searchForm.reset();
						_this.searchDatas = {};
					}
				}
			]*/
		});
		
		Ext.getCmp(CNOA.odoc.read.receive.parentID).add(this.mainPanel);
		Ext.getCmp(CNOA.odoc.read.receive.parentID).doLayout();
	},
	
	viewAttach : function(id){
		var _this = this;
		
		var ID_fieldSet_Word = Ext.id();
		var ID_fieldSet_Attach = Ext.id();
		var ID_fieldSet_Form = Ext.id();
		
		var loadAttachList = function(){
			Ext.Ajax.request({
				url: _this.baseUrl + "&task=loadAttachList",
				method: 'POST',
				params:{id:id},
				success: function(r) {
					var result = Ext.decode(r.responseText);
					if(result.success === true){
						if(result.data.word){
							Ext.getCmp(ID_fieldSet_Word).show();
							Ext.getCmp(ID_fieldSet_Word).body.update(result.data.word);
						}
						if(result.data.attach){
							Ext.getCmp(ID_fieldSet_Attach).show();
							Ext.getCmp(ID_fieldSet_Attach).body.update(result.data.attach);
						}
						if(result.data.form){
							Ext.getCmp(ID_fieldSet_Form).show();
							Ext.getCmp(ID_fieldSet_Form).body.update(result.data.form);
						}
						
					}else{
						//CNOA.msg.alert(result.msg, function(){});
					}
				}
			});
		};
		
		var win = new Ext.Window({
			title:'查看发文内容',
			width:800,
			height:makeWindowHeight(Ext.getBody().getBox().height-40),
			modal:true,
			bodyStyle: 'background-color:#FFF;padding:10px;',
			autoScroll: true,
			maximizable: true,
			border:false,
			items: [
				{
					xtype: 'fieldset',
					title: '文件查看',
					hidden: true,
					id: ID_fieldSet_Word
				},
				{
					xtype: 'fieldset',
					title: '表单查看',
					hidden: true,
					id: ID_fieldSet_Form
				},
				{
					xtype: 'fieldset',
					title: '附件查看',
					hidden: true,
					id: ID_fieldSet_Attach
				}
			],
			listeners: {
				afterrender : function(){
					loadAttachList();
				}
			},
			buttons:[
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
	}
}

/**
 * 全局变量
 */
var CNOA_odoc_read_send, CNOA_odoc_read_sendClass;
CNOA_odoc_read_sendClass = CNOA.Class.create();
CNOA_odoc_read_sendClass.prototype = {
	init : function(){
		var _this = this;
		
		this.baseUrl = "index.php?app=odoc&func=read&action=send";
		
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=loadColumn",
			method: 'POST',
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.layoutPanel(result);
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	layoutPanel:function(result){
		var _this = this;
			
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:true
		});
		
		this.cm = [new Ext.grid.RowNumberer(), this.sm,
			{header:lang('opt'),sortable:true,dataIndex:'id',width:50,menuDisabled:true,renderer:function(v, c, record){
				var rd = record.data;
					l = '<a href="javascript:void(0)" onclick="CNOA_odoc_read_send.viewAttach('+v+')">查看</a>';
				return l;
			}},
			{header:'添加时间',sortable:true,dataIndex:'posttime',width:110,menuDisabled:true}
		];
		
		var fields = [{name:'id'},{name:'posttime'},{name:'status'},{name:'uFlowId'},{name:'activeAccount'}];
		Ext.each(result.column, function(v,i){
			fields.push({name:'field_'+v.field});
			_this.cm.push({
				header			:v.title,
				sortable		:true,
				dataIndex		:'field_'+v.field,
				width			:v.width,
				menuDisabled	:true
			});
		});
		
		this.store = new Ext.data.Store({
			autoLoad: true,
			proxy: new Ext.data.HttpProxy({
				url: this.baseUrl + '&task=getJsonList'
			}),
			reader: new Ext.data.JsonReader({
				totalProperty: "total",
				root: "data",
				fields:fields
			})
		});
		
		this.grid = new Ext.grid.GridPanel({
			store:this.store,
			width:600,
			plain:false,
       		stripeRows:true,
			loadMask:{msg: lang('waiting')},
			region:"center",
			border:false,
			autoScroll:true,
			sm:this.sm,
			columns:this.cm,
			tbar:[
				{
					handler:function(button, event) {
						_this.store.reload();
					}.createDelegate(this),
					iconCls:'icon-system-refresh',
					text:lang('refresh')
				},'-',
				"<span class='cnoa_color_gray'>双击可修改记录,按住Ctrl或Shift键可以一次选择多条记录</span>"
			],
			bbar: new Ext.PagingToolbar({
				displayInfo:true,
				
				   
				store: this.store,
				pageSize:30,
				listeners: {
					"beforechange" : function(th, params){
						//Ext.apply(params, _this.search);
					}
				}
			})
		});
		
		this.treeStore = new Ext.data.Store({
			autoLoad:true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getSearchList", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:[{name:'field'},{name:'title'}]})
		});
		
		this.searchPanel = new Ext.form.FormPanel({
			region:'north',
			height:100,
			border:false,
			hidden:true,
			defaults:{
				border:false
			},
			padding:5,
			items:[
				{
					xtype:'panel',
					defaults:{
						border:false
					},
					items:[
						{
							xtype:'hidden',
							name:'id'
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:6
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong1',
									hiddenName: 'kong1',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition1',
									hiddenName:'condition1',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									name:'value1'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong1').setValue('');
										searchForm.findField('condition1').setValue('equal');
										searchForm.findField('value1').setValue('');
									}
								}
							]
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:4
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong2',
									hiddenName: 'kong2',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition2',
									hiddenName:'condition2',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									//emptyText:'查询条件',
									name:'value2'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong2').setValue('');
										searchForm.findField('condition2').setValue('equal');
										searchForm.findField('value2').setValue('');
									}
								}
							]
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:4
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[								
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong3',
									hiddenName: 'kong3',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition3',
									hiddenName:'condition3',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									//emptyText:'查询条件',
									name:'value3'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong3').setValue('');
										searchForm.findField('condition3').setValue('equal');
										searchForm.findField('value3').setValue('');
									}
								}
							]
						}
					]
				}
			]
		});
		
		var searchForm = _this.searchPanel.getForm();
		
		this.mainPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			layout:'border',
			autoScroll:false,
			items:[this.searchPanel,this.grid]/*,
			tbar:[
				{
					text:'展开查询',
					id:'EXPAND_SEARCH_PANEL',
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						if(_this.searchExpandBtn == 'close'){
							//如果要打开
							_this.searchPanel.show();
							_this.searchExpandBtn = 'open';
							Ext.getCmp('EXPAND_SEARCH_PANEL').setText('折叠查询');
							Ext.getCmp('ID_BTN_SEARCH').show();
						}else{
							//如果要关闭
							_this.searchPanel.hide();
							_this.searchExpandBtn = 'close';
							Ext.getCmp('EXPAND_SEARCH_PANEL').setText('展开查询');
							Ext.getCmp('ID_BTN_SEARCH').hide();
						}
						_this.mainPanel.doLayout();
					}
				},
				{
					text:lang('search'),
					style: "margin-left:5px",
					id:'ID_BTN_SEARCH',
					iconCls: "icon-search",
					hidden:true,
					cls: "x-btn-over",
					enableToggle:false,
		    		//allowDepress:false,
		   	 		toggleGroup:"search_definde_btn_group",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						_this.searchDatas = searchForm.getValues();
						_this.searchDatas.search = 'now';
						_this.store.load({params:_this.searchDatas});
					}
				},
				{
					text:lang('clear'),
					style: "margin-left:5px",
					cls: "x-btn-over",
		   	 		toggleGroup:"search_definde_btn_group",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						_this.store.load();
						searchForm.reset();
						_this.searchDatas = {};
					}
				}
			]*/
		});
		
		Ext.getCmp(CNOA.odoc.read.send.parentID).add(this.mainPanel);
		Ext.getCmp(CNOA.odoc.read.send.parentID).doLayout();
	},
	
	viewAttach : function(id){
		var _this = this;
		
		var ID_fieldSet_Word = Ext.id();
		var ID_fieldSet_Attach = Ext.id();
		var ID_fieldSet_Form = Ext.id();
		
		var loadAttachList = function(){
			Ext.Ajax.request({
				url: _this.baseUrl + "&task=loadAttachList",
				method: 'POST',
				params:{id:id},
				success: function(r) {
					var result = Ext.decode(r.responseText);
					if(result.success === true){
						if(result.data.word){
							Ext.getCmp(ID_fieldSet_Word).show();
							Ext.getCmp(ID_fieldSet_Word).body.update(result.data.word);
						}
						if(result.data.attach){
							Ext.getCmp(ID_fieldSet_Attach).show();
							Ext.getCmp(ID_fieldSet_Attach).body.update(result.data.attach);
						}
						if(result.data.form){
							Ext.getCmp(ID_fieldSet_Form).show();
							Ext.getCmp(ID_fieldSet_Form).body.update(result.data.form);
						}
						
					}else{
						//CNOA.msg.alert(result.msg, function(){});
					}
				}
			});
		};
		
		var win = new Ext.Window({
			title:'查看发文内容',
			width:800,
			height:makeWindowHeight(Ext.getBody().getBox().height-40),
			modal:true,
			bodyStyle: 'background-color:#FFF;padding:10px;',
			autoScroll: true,
			maximizable: true,
			border:false,
			items: [
				{
					xtype: 'fieldset',
					title: '文件查看',
					id: ID_fieldSet_Word
				},
				{
					xtype: 'fieldset',
					title: '表单查看',
					id: ID_fieldSet_Form
				},
				{
					xtype: 'fieldset',
					title: '附件查看',
					id: ID_fieldSet_Attach
				}
			],
			listeners: {
				afterrender : function(){
					loadAttachList();
				}
			},
			buttons:[
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
	}
}

/**
 * 全局变量
 */

var CNOA_odoc_receive_apply, CNOA_odoc_receive_applyClass;

CNOA_odoc_receive_applyClass = CNOA.Class.create();
CNOA_odoc_receive_applyClass.prototype = {
	init : function(){
		var _this = this;
				
		this.baseUrl = "index.php?app=odoc&func=receive&action=apply";
		
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=loadColumn",
			method: 'POST',
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.layoutPanel(result);
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	layoutPanel:function(result){
		var _this = this;
			
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:true
		});
		
		this.cm = [new Ext.grid.RowNumberer(), this.sm,
			{header:lang('opt'),sortable:true,dataIndex:'id',width:120,menuDisabled:true,renderer:function(v, c, record){
				var rd = record.data;
				var l = '';
				if(rd.status == 2){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_receive_apply.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}else if(rd.status == 0){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_receive_apply.operate('+v+')">发起审批</a>';
				}else if(rd.status == 1){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_receive_apply.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}
				l += '&nbsp;&nbsp;<a href="javascript:void(0)" onclick="CNOA_odoc_receive_apply.viewAttach('+v+')">来文内容</a>';
				/*
				if(rd.puFlowId > 0){
					l += ' <a href="javascript:void(0)" onclick="CNOA_odoc_receive_apply.viewFlow('+rd.puFlowId+')">查看发文流程</a>';
				}
				*/
				return l;
			}},
			{header:'添加时间',sortable:true,dataIndex:'posttime',width:100,menuDisabled:true},
			{header:'状态',sortable:true,dataIndex:'status',width:100,menuDisabled:true,renderer:function(v){
				if(v == 1){
					return '<span style="color:green;">审批中</span>';
				}else if(v == 2){
					return '<span style="color:#333333;">审批结束</span>';
				}else{
					return '<span style="color:red;">未提交审批</span>';
				}
			}},
			{header:'来文机关',sortable:true,dataIndex:'deptment',width:100,menuDisabled:true},
			{header:'来文标题',sortable:true,dataIndex:'title',width:100,menuDisabled:true},
			{header:'来文编号',sortable:true,dataIndex:'number',width:100,menuDisabled:true},
			{header:'打印份数',sortable:true,dataIndex:'print',width:100,menuDisabled:true}
		];

		var fields = [{name:'id'},{name:'posttime'},{name:'status'},{name:'uFlowId'},{name:'deptment'},{name:'title'},{name:'number'},{name:'print'},{name:'puFlowId'}];
		Ext.each(result.column, function(v,i){
			fields.push({name:'field_'+v.field});
			_this.cm.push({
				header			:v.title,
				sortable		:true,
				dataIndex		:'field_'+v.field,
				width			:v.width,
				menuDisabled	:true
			});
		});

		this.store = new Ext.data.Store({
			autoLoad: true,
			proxy: new Ext.data.HttpProxy({
				url: this.baseUrl + '&task=getJsonList'
			}),
			reader: new Ext.data.JsonReader({
				totalProperty: "total",
				root: "data",
				fields:fields
			})
		});

		this.grid = new Ext.grid.GridPanel({
			store:this.store,
			width:600,
			plain:false,
       		stripeRows:true,
			loadMask:{msg: lang('waiting')},
			region:"center",
			border:false,
			autoScroll:true,
			sm:this.sm,
			columns:this.cm,
			tbar:[
				{
					handler:function(button, event) {
						_this.store.reload();
					}.createDelegate(this),
					iconCls:'icon-system-refresh',
					text:lang('refresh')
				},'-',
				{
					handler:function(button, event) {
						_this.addWin('new', 0);
					}.createDelegate(this),
					iconCls:'icon-utils-s-add',
					text:"添加收文"
				},'-',
				{
					handler:function(button, event){
						var rows = _this.grid.getSelectionModel().getSelections();
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, '您还没有选择要编辑的列');
						}else{
							var id = rows[0].get("id");
							var status = rows[0].get("status");
							
							if(status != 0){
								CNOA.msg.alert("流程已经启动或者已经结束，不能再编辑！");
							}else{
								_this.addWin('edit', id);
							}
						}
					},
					iconCls: 'icon-utils-s-edit',
					text:lang('modify')
				},'-',
				{
					text:lang('del'),
					iconCls:'icon-utils-s-delete',
					handler:function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections();
						if(rows.length == 0){
							CNOA.miniMsg.alertShowAt(button, lang('mustSelectOneRow'));
						}else{
							CNOA.miniMsg.cfShowAt(button, lang('confirmToDelete'), function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									Ext.Ajax.request({
										url: _this.baseUrl + "&task=deleteData",
										method: 'POST',
										params:{ids:ids},
										success: function(r) {
											var result = Ext.decode(r.responseText);
											if(result.success === true){
												_this.store.reload();
											}else{
												CNOA.msg.alert(result.msg, function(){});
											}
										}
									});
								}
							});
						}
					}
				},"-",
				{
					text: '分发', //所有人
					handler: function(){
						var rows = _this.grid.getSelectionModel().getSelections();

						if(rows.length <= 0){
							CNOA.msg.alert('您好，请至少选择一个发文进行操作.');
							return;
						}
						if(rows[0].json.status != 2){
							CNOA.msg.alert('该信息还没有审批通过。 审批通过才能签发。');
							return;
						}
						var slid = rows[0].json.id;
						
						_this.issueSend(slid);
					}.createDelegate(this),
					iconCls: 'icon-applications-stack',
					cls: 'x-btn-over',
					listeners: {
						'mouseout': function(btn){
							btn.addClass('x-btn-over');
						}
					}
				},
				"<span class='cnoa_color_gray'>双击可修改记录,按住Ctrl或Shift键可以一次选择多条记录</span>"
			],
			bbar: new Ext.PagingToolbar({
				displayInfo:true,
				
				   
				store: this.store,
				pageSize:30,
				listeners: {
					"beforechange" : function(th, params){
						//Ext.apply(params, _this.search);
					}
				}
			})
		});

		this.treeStore = new Ext.data.Store({
			autoLoad:true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getSearchList", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:[{name:'field'},{name:'title'}]})
		});		
	
		
		this.mainPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			layout:'border',
			autoScroll:false,
			items:[this.grid]
		});
		
		Ext.getCmp(CNOA.odoc.receive.apply.parentID).add(this.mainPanel);
		Ext.getCmp(CNOA.odoc.receive.apply.parentID).doLayout();
	},
	
	addWin:function(from, edit_id){
		var _this = this;
		
		var baseField = [
			{
				xtype:'fieldset',
				title: '请选择要发起的流程',
				layout:'column',
				//style:'margin-bottom:5px;',
				id:'CNOA_ODOC_NEW_FLOW_CT',
				hideLabel:true,
				width:660,
				autoHeight: true,
	            items: []
			},
			{
				xtype:'fieldset',
				title: '来文信息',
				hideLabel:true,
				width:660,
				layout:'column',
				autoHeight: true,
				defaults: {border: false},
	            items: [
	            	{
						xtype:'panel',
						layout:'form',
						items:[{
							xtype:'textfield',
							fieldLabel:'来文单位',
							name:'deptment',
							width:180,
							allowBlank:false
						},{
							xtype:'textfield',
							fieldLabel:'来文标题',
							name:'title',
							width:180,
							allowBlank:false
						}]
					},
					{
						xtype:'panel',
						layout:'form',
						items:[{
							xtype:'numberfield',
							fieldLabel:'打印份数',
							name:'print',
							width:180,
							allowBlank:false
						}]
					}
				]
			},
			{
				xtype:'panel',
				border:false,
				layout: "form",
				width:660,
				defaults:{
				},
				id:'ID_DEFINDE_FIELDS'
			}
		];
		
		this.addFormPanel = new Ext.form.FormPanel({
			border:false,
			labelWidth:90,
			width:640,
			labelAlign:'right',
			waitMsgTarget:true,
			bodyStyle:"padding-left:5px;",
			items:baseField,
			autoScroll:true,
			listeners:{
				"render" : function(form){}
			}
		});
		
		var checkSelectedFlow = function(){
			var msg = "请选择要发起哪条流程", v;
			try{
				v = _this.addFormPanel.getForm().findField("ococ_send_apply_flowList").getGroupValue();
			}catch(e){
				v = "";
				msg = "还没有可以发起的流程，请到公文设置功能里面添加公文与流程的绑定！";
			}
			if(Ext.isEmpty(v)){
				CNOA.msg.alert(msg);
				return false;
			}
			return true;
		};
		
		var submitData = function(){
			var f = _this.addFormPanel.getForm();
			if(f.isValid()) {
				f.submit({
			        url: _this.baseUrl+"&task=submitData",
			        method: 'POST',
			        waitMsg: lang('waiting'),
			        params: {id: edit_id},
			        success: function(form, action) {
						if(action.result.success == true){
							win.close();
							_this.store.reload();
							
							_this.operate(action.result.msg);
						}
			        }.createDelegate(this),
			        failure:function(form, action){}.createDelegate(this)
				});
			}
		};
		
		var win = new Ext.Window({
			title:'添加收文',
			width:700,
			height:makeWindowHeight(500),
			modal:true,
			layout:"fit",
			resizable:false,
			border:false,
			items:this.addFormPanel,
			buttons:[
				{
					text:'确定发起',
					handler:function(){
						if(checkSelectedFlow()){
							submitData(edit_id);
						}
					}
				},
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
		
		this.superField = Ext.getCmp('ID_DEFINDE_FIELDS');
		
		_this.loadLayout(from,edit_id);
	},
	
	viewFlow:function(uFlowId){
		mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
		mainPanel.loadClass(this.baseUrl+"&task=loadPage&from=viewflow&uFlowId="+uFlowId, "CNOA_MENU_WF_USE_OPENFLOW", "查看工作流程", "icon-flow");
	},
	
	operate:function(v){
		var _this = this;
		
		Ext.Ajax.request({
			url:_this.baseUrl + "&task=getFaqiFlow",
			method:'POST',
			params:{id:v},
			success:function(r) {
				var result = Ext.decode(r.responseText);
				
				if(result.success === true){
					_this.goNewFlow(result);
				}else{
					if(result.msg == 'no_bind_flow'){
						_this.addWin('edit', v);
					}else{
						CNOA.msg.alert(result.msg);
					}
				}
			}
		});
	},
	
	viewAttach : function(id){
		var _this = this;
		
		var ID_fieldSet = Ext.id();
		
		var loadAttachList = function(){
			Ext.Ajax.request({
				url: _this.baseUrl + "&task=loadAttachList",
				method: 'POST',
				params:{id:id},
				success: function(r) {
					var result = Ext.decode(r.responseText);
					if(result.success === true){
						Ext.getCmp(ID_fieldSet).body.update(result.data);
					}else{
						//CNOA.msg.alert(result.msg, function(){});
					}
				}
			});
		};
		
		var win = new Ext.Window({
			title:'查看发文内容',
			width:500,
			height:makeWindowHeight(500),
			modal:true,
			bodyStyle: 'background-color:#FFF;padding:10px;',
			resizable:false,
			autoScroll: true,
			border:false,
			items: [
				{
					xtype: 'fieldset',
					title: '文件查看',
					id: ID_fieldSet
				}
			],
			listeners: {
				afterrender : function(){
					loadAttachList();
				}
			},
			buttons:[
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
	},
	
	goNewFlow : function(result){
		var flowType = result.flowType;
		var flowId = result.flowId;
		var nameRuleId = result.nameRuleId;
		var tplSort = result.tplSort;
		var childId = 0;
		var otherApp = result.otherApp;
		
		if(flowType == 0){
			mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
			mainPanel.loadClass("index.php?app=wf&func=flow&action=use&modul=new&task=loadPage&from=newflow&flowId="+flowId+"&nameRuleId="+nameRuleId+"&flowType="+flowType+"&tplSort="+tplSort+"&childId="+childId+"&otherApp="+otherApp, "CNOA_MENU_WF_USE_OPENFLOW", "发起新的固定流程", "icon-flow-new");
		}else{
			mainPanel.closeTab("CNOA_USE_FLOW_NEWFREE_FLOWDESIGN");
			mainPanel.loadClass("index.php?app=wf&func=flow&action=use&modul=newfree&task=loadPage&from=flowdesign&flowId="+flowId+"&flowType="+flowType+"&tplSort="+tplSort+"&childId="+childId+"&otherApp="+otherApp, "CNOA_USE_FLOW_NEWFREE_FLOWDESIGN", "设计流程", "icon-flow-new");
		}
	},
	
	loadLayout:function(from,edit_id){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=loadLayout",
			method: 'POST',
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					Ext.each(result.fieldset, function(v, i){
						_this.addFieldSet(v.name, v.fieldset);
					});
					Ext.each(result.field, function(v,i){
						Ext.getCmp('ID_FIELD_SET_'+v.fieldset).add(_this.addField(v.fstfield, v.secfield, v.fstname, v.secname, v.type));
					});
					
					var flowListCt = Ext.getCmp("CNOA_ODOC_NEW_FLOW_CT");
					Ext.each(result.flowList, function(v,i){
						flowListCt.add({
							xtype: 'radio',
							name: 'ococ_send_apply_flowList',
							style: 'margin-left: 10px;',
							boxLabel: v.name,
							inputValue: v.id
						});
					});
					flowListCt.doLayout();
					
					_this.superField.doLayout();
					
					if(from == 'edit'){
						_this.addFormPanel.getForm().load({
						    url: _this.baseUrl + "&task=loadFormData",
						    method:'POST',
						    params : {id:edit_id},
						    success: function(form, action){
						        var rd = action.result.data;
						    },
						    failure: function(form, action) {
						        CNOA.msg.alert(action.result.msg, function(){
						            
						        });
						    }
						});
					}
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	addFieldSet:function(msg, fieldsetid){
		var _this = this;
		
		_this.superField.add({
			xtype:'fieldset',
			title:msg,
			width:660,
			autoHeight: true,
			id:"ID_FIELD_SET_"+fieldsetid
		});
	},
	
	addField:function(firstId, secondId, fstname, secname, typeFrom){
		var _this = this;
		
		if (typeFrom == 'textarea') {
			var items = {
					xtype: 'panel',
					layout: 'form',
					items: [{
						xtype: 'textarea',
						width: 464,
						fieldLabel: fstname,
						name: 'field_' + firstId
					}]
				}
		}else if(typeFrom == 'sort'){
			var items = {
				xtype:'panel',
				layout:'form',
				items:[{
					xtype:"combo",
					fieldLabel:fstname,
					name:'field_'+firstId,
					store: this.sortStore,
					hiddenName:'field_' + firstId,
					valueField:'iid',
					displayField:'sort',
					mode:'local',
					width:180,
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}]
			}
		}else if(typeFrom == 'type'){
			var items = {
				xtype:'panel',
				layout:'form',
				items:[{
					xtype:"combo",
					fieldLabel:fstname,
					name:'field_'+firstId,
					store:this.typeStore,
					hiddenName:'field_' + firstId,
					valueField:'id',
					displayField:'sid',
					mode:'local',
					width:180,
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}]
			}
		}else if(typeFrom == 'region'){
			var items = [{
				xtype:"panel",
				layout:"form",
				items:[{
					xtype:"combo",
					fieldLabel:fstname,
					name:'field_' + firstId,
					store:this.regionStore,
					name:'field_' + firstId,
					secondId:secondId,
					valueField:'rid',
					displayField:'name',
					mode:'local',
					width:180,
					triggerAction:'all',
					forceSelection:true,
					editable:false,
					listeners:{
						change:function(th, newValue, oldValue){
							_this.region2 = "";
							_this.addFormPanel.getForm().findField('field_' + th.secondId).setValue("");
							_this.regionStore2.load({params : {rid : newValue}});
						}
					}
				}]
			}, {
				xtype: "panel",
				layout: "form",
				items: [{
					xtype:"combo",
					fieldLabel:secname,
					name:'field_' + secondId,
					store:this.regionStore2,
					name:'field_' + secondId,
					valueField:'pid',
					displayField:'name',
					mode:'local',
					width:180,
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}]
			}]
		}
		else {
			var items = [];
			
			if(fstname == '' || secname == ''){
				var fieldName = fstname == ''?secondId:firstId;
				items = [
					{
						xtype:'panel',
						layout:'form',
						items:[{
							xtype:'textfield',
							width:464,
							fieldLabel:fstname == ''?secname:fstname,
							name:'field_'+ fieldName
						}]
					}
				];
			}else{
				items = [
					{
						xtype:'panel',
						layout:'form',
						items:[{
							xtype:'textfield',
							width:180,
							fieldLabel:fstname,
							name:'field_'+firstId
						}]
					},{
						xtype: 'panel',
						layout: 'form',
						items: [{
							xtype:'textfield',
							width:180,
							fieldLabel:secname,
							name:'field_'+secondId
						}]
					}
				];
			}
		}
		
		var result = {
			xtype: 'panel',
			layout: 'table',
			layoutConfig: {
				columns: 2
			},
			style: 'margin-top:10px',
			border: false,labelWidth:90,
			defaults: {
				border: false
			},
			items:items
		}
		
		return result;
	},
	
	/**
	 * 分发
	 */
	issueSend : function(id){
		var _this = this;
		
		var rows = _this.grid.getSelectionModel().getSelections();
		//cdump(rows);return;
		if(rows.length <= 0){
			CNOA.msg.alert('您好，请至少选择一个发文进行操作.');
			return;
		}
		var slid = rows[0].json.id;

		var frm = new Ext.form.FormPanel({
			border: false,
			labelWidth: 60,
			labelAlign: 'right',
			bodyStyle:'padding: 10px',
			items: [
				{
					xtype: 'checkboxgroup',
					fieldLabel: '分发内容',
					columns: 3,
					allowBlank: false,
					items: [
						{boxLabel: '审批表单', name: "viewForm"},
						{boxLabel: '审批正文(Word)', name: "viewWord", checked: true},
						{boxLabel: '流程附件', name: "viewAttach", checked: true}//,
						//{boxLabel: '审批步骤', name: "viewConfig[step]"},
						//{boxLabel: '审批事件', name: "viewConfig[event]"},
						//{boxLabel: '允许打印', name: "viewConfig[print]"}
					]
				},
				{
					xtype:'textarea',
					fieldLabel:'查看人',
					name:'recvMan',
					width:333,
					height:150,
					readOnly:true,
					allowBlank:false
				},
				{
					xtype:"hidden",
					name:"recvUids",
					id:_this.ID_recvUids
				},
				{
					xtype:"btnForPoepleSelector",
					fieldLabel:"",
					text:lang('select'),
					allowBlank: false,
					name:"checkName",
					dataUrl: _this.baseUrl+"&task=getAllUserListsInPermitDeptTree",
					width:70,
					style:'margin: 0 0 0 65px',
					listeners:{
						"selected":function(th, data){
							var names = new Array();
							var uids = new Array();
							
							if (data.length>0){
								for (var i=0;i <= data.length - 1; i++){
									names.push(data[i].uname);
									uids.push(data[i].uid);
								}
							}
							var sNames	= names.join(",");
							var sUids	= uids.join(",");
							
							frm.getForm().findField("recvUids").setValue(sUids);
							frm.getForm().findField("recvMan").setValue(sNames);
						}
					}
				}
			]
		})
		
		submit = function(){
			var f = frm.getForm();
			if (f.isValid()) {
				f.submit({
					url: _this.baseUrl + '&task=submitIssue',
					method: 'POST',
					params: {id:slid},
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						_this.store.reload();
						win.close();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg);
					}
				});
			}else{
				CNOA.msg.alert(lang('formValid'));
			}
		};
		
		var win = new Ext.Window({
			title: '分发',
			width: 430,
			height: 330,
			layout: 'fit',
			modal: true,
			resizable: false,
			maximizable: false,
			items: [frm],
			buttons:[
				{
					text: '确定分发',
					handler: function(){
						submit();
					}
				},{
					text: lang('close'),
					handler: function (){						
						win.close();
					}
				}
			]
		}).show();
		
		return win;
	}
}

//CNOA_odoc_receive_apply = new CNOA_odoc_receive_applyClass();



/**
 * 全局变量
 */

var CNOA_odoc_receive_list, CNOA_odoc_receive_listClass;

CNOA_odoc_receive_listClass = CNOA.Class.create();
CNOA_odoc_receive_listClass.prototype = {
	init : function(){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NUMBER	= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_HURRY		= Ext.id();
		var ID_BTN_SPLIT		= Ext.id();
		this.ID_BTN_SAVE		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=receive&action=list";
		
		this.storeBar = {
			storeType : "waiting",
			title : "",
			number : "",
			type : "",
			level : "",
			hurry : ""
		};
		
		this.fields = [
			{name : "id"},
			{name : "title"},
			{name : "number"},
			{name : "type"},
			{name : "level"},
			{name : "hurry"},
			{name : "status"},
			{name : "many"},
			{name : "page"},
			{name : "fromdept"},
			{name : "createname"},
			{name : "createtime"},
			{name : "receivedate"}
		];
		
		this.typeListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getTypeList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.typeListStore.load();
		
		this.levelListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getLevelList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.levelListStore.load();
		
		this.hurryListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getHurryList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.hurryListStore.load();
		
		this.store = new Ext.data.Store({
			autoLoad : true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: true
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "id", dataIndex: 'id', hidden: true},
			{header: lang('opt'), dataIndex: 'id', width: 120, sortable: true, menuDisabled :true, renderer : this.operate.createDelegate(this)},
			{header: lang('title'), dataIndex: 'title', width: 150, sortable: true, menuDisabled :true},
			{header: '文号', dataIndex: 'number', width: 100, sortable: true, menuDisabled :true},
			{header: '类型', dataIndex: 'type', width: 100, sortable: true, menuDisabled :true},
			{header: '密级', dataIndex: 'level', width: 80, sortable: true, menuDisabled :true},
			{header: '缓急', dataIndex: 'hurry', width: 80, sortable: true, menuDisabled :true},
			{header: '份数', dataIndex: 'many', width: 80, sortable: true, menuDisabled :true},
			{header: '页数', dataIndex: 'page', width: 80, sortable: true, menuDisabled :true},
			{header: '发文单位', dataIndex: 'fromdept', width: 80, sortable: true, menuDisabled :true},
			{header: '收文人', dataIndex: 'createname', width: 80, sortable: true, menuDisabled :true},
			{header: '登记时间', dataIndex: 'createtime', width: 120, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			border:false,
			store:this.store,
			loadMask : {msg: lang('waiting')},
			cm: this.colModel,
			sm: this.sm,
			hideBorders: true,
			listeners:{
				"rowdblclick":function(button, event){
					
				}
			},
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "all";
						_this.store.load({params: _this.storeBar});
						Ext.getCmp(ID_BTN_SPLIT).show();
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					pressed: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示所有的收文公文列表",
					text : '收文列表'
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "history";
						_this.store.load({params: _this.storeBar});
						Ext.getCmp(ID_BTN_SPLIT).hide();
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示已分发记录的列表",
					text : '已分发记录'
				},"-",
				{
					handler : function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, "您还没有选择要分发的文件");
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要分发该文件吗?", function(){						
								_this.newSplit(rows[0].get("id"));
							});
						}
					}.createDelegate(this),
					id : ID_BTN_SPLIT,
					iconCls: 'icon-applications-stack',
					tooltip: "分发文件",
					text : '分发'
				},
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid],
			tbar : [
				(lang('title')+':'),
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TITLE
				},
				"文号: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_NUMBER
				},"类型: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.typeListStore,
					width: 100,
					id : ID_SEARCH_TYPE,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"密级: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.levelListStore,
					width: 100,
					id : ID_SEARCH_LEVEL,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"缓急: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.hurryListStore,
					width: 100,
					id : ID_SEARCH_HURRY,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				{
					xtype: "button",
					text: lang('search'),
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.number 		= Ext.getCmp(ID_SEARCH_NUMBER).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						_this.storeBar.level 		= Ext.getCmp(ID_SEARCH_LEVEL).getValue();
						_this.storeBar.hurry 		= Ext.getCmp(ID_SEARCH_HURRY).getValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:lang('clear'),
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NUMBER).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
						Ext.getCmp(ID_SEARCH_HURRY).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.number 		= "";
						_this.storeBar.type 		= "";
						_this.storeBar.level 		= "";
						_this.storeBar.hurry 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]
		});
	},
	
	operate : function(value, cellmeta, record, rowIndex, columnIndex, color_store){
		var _this = this;
		
		if(_this.storeBar.storeType == "history"){
			return "<a href='index.php?app=odoc&func=receive&action=list&task=view&act=getHtml&id="+value+"' target='viewodoc'>查看公文</a> / <a href='javascript:void(0)' onclick='CNOA_odoc_receive_list.read("+value+", \"view\")'>阅读情况</a>";
		}else{
			return "<a href='index.php?app=odoc&func=receive&action=list&task=view&act=getHtml&id="+value+"' target='viewodoc'>查看公文</a>";
		}
	},
	
	view : function(value){
		
	},
	
	read : function(id){
		var _this = this;
		
		var fields = [
			{name:"deptname"},
			{name:"name"},
			{name:"readtime"}
		];
		
		var store = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({url: _this.baseUrl+"&task=getReaderList&id="+id, disableCaching: true}),
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: fields})
		});
		
		store.load();
		
		var sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:false
		});
		
		var colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			{header: "所属部门", dataIndex: 'deptname', width: 100, sortable: true, menuDisabled :true},
			{header: "名字", dataIndex: 'name', width: 100, sortable: false,menuDisabled :true},
			{header: "阅读日期", dataIndex: 'readtime', width: 150, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		var Grid = new Ext.grid.GridPanel({
			stripeRows : true,
			store : store,
			region : "center",
			layout : "fit",
			loadMask : {msg: lang('waiting')},
			cm : colModel,
			sm : sm,
			hideBorders : true,
			border : false,
			viewConfig : {
				forceFit : true
			}
		});
		
		var win = new Ext.Window({
			title : "阅读情况",
			layout : "border",
			width : 600,
			height : makeWindowHeight(500),
			resizable : false,
			modal : true,
			items : [Grid],
			buttons : [
				{
					text : lang('close'),
					handler : function(){
						win.close();
					}
				}
			]
		}).show();
	},
	
	newSplit : function(ids, from){
		var _this = this;
		
		var loadFormData = function(ids){
			form.getForm().load({
				url: _this.baseUrl + "&task=loadFormData",
				method:'POST',
				params : {id : ids},
				waitTitle: lang('notice'),
				success: function(form, action){
					
				},
				failure: function(form, action) {
					CNOA.msg.alert(action.result.msg, function(){
						
					});
				}
			})
		};
		
		var submit = function(ids){
			if (form.getForm().isValid()) {
				form.getForm().submit({
					url: _this.baseUrl + "&task=sendFile",
					waitTitle: lang('notice'),
					params : {id : ids},
					method: 'POST',
					waitMsg: lang('waiting'),
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						win.close();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg, function(){
							
						});
					}.createDelegate(this)
				});
			}
		};
		
		var baseField = [
			{
				xtype: "fieldset",
				title: "分发文件",
				autoHeight: true,
				defaults : {
					border : false,
					style : "margin-bottom : 5px"
				},
				items: [
					{
						xtype : "panel",
						layout : "table",
						defaults : {
							border : false
						},
						colunm : 2,
						items : [
							{
								xtype : "panel",
								layout : "form",
								items : [
									{
										xtype : "datefield",
										name : "stime",
										fieldLabel : lang('startTime'),
										width : 150,
										format : "Y-m-d",
										allowBlank : false
									}
								]
							},
							{
								xtype : "panel",
								layout : "form",
								items : [
									{
										xtype : "datefield",
										name : "etime",
										fieldLabel : lang('endTime'),
										width : 150,
										format : "Y-m-d"
									}
								]
							}
						]
					},
					new Ext.BoxComponent({
						autoEl: {
							tag: 'div',
							style: "margin-left:80px;margin-top:5px;margin-bottom:5px;color:#676767;",
							html: '注意:如果不填写结束时间则表示阅读该文件没有时间限制'
						}
					}),
					{
						xtype: "textarea",
						readOnly: true,
						width:365,
						height: 80,
						readOnly: true,
						fieldLabel: '分发给',
						name: "split",
						allowBlank : false
					},
					{
						xtype: "hidden",
						name: "splituid"
					},
					{
						xtype: "btnForPoepleSelector",
						text: "选择",
						dataUrl: _this.baseUrl + "&task=getAllUserListsInPermitDeptTree",
						style: "margin-left:65px; margin-bottom:5px",
						listeners: {
							"selected" : function(th, data){
								var names = new Array();
								var uids = new Array();
								if (data.length>0){
									for (var i=0;i<data.length;i++){
										names.push(data[i].uname);
										uids.push(data[i].uid);
									}
								}
								form.getForm().findField("split").setValue(names.join(", "));
								form.getForm().findField("splituid").setValue(uids.join(","));
							},
							"onrender" : function(th){
								th.setSelectedUids(form.getForm().findField("splituid").getValue().split(","));
							}
						}
					}
				]
			}
		];
		
		var form = new Ext.form.FormPanel({
			border: false,
			labelWidth: 60,
			labelAlign: 'right',
			region : "center",
			layout : "fit",
			waitMsgTarget: true,
			items:[
				{
					xtype: "panel",
					border: false,
					bodyStyle: "padding:10px",
					layout: "form",
					region: "center",
					autoScroll: true,
					items: baseField
				}
			]
		});
		
		var win = new Ext.Window({
			title : "分发窗口",
			layout : "border",
			width : 520,
			height : 300,
			resizable : false,
			modal : true,
			items : [form],
			buttons : [
				{
					text : lang('save'),
					iconCls : "icon-btn-save",
					id : _this.ID_BTN_SAVE,
					handler : function(){
						submit(ids);
					}
				},
				{
					text : lang('close'),
					handler : function(){
						win.close();
					}
				}
			]
		}).show();
		
		loadFormData(ids);
	}
}


/**
 * 全局变量
 */

var CNOA_odoc_send_apply, CNOA_odoc_send_applyClass;

CNOA_odoc_send_applyClass = CNOA.Class.create();
CNOA_odoc_send_applyClass.prototype = {
	init : function(){
		var _this = this;
				
		this.baseUrl = "index.php?app=odoc&func=send&action=apply";
		
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=loadColumn",
			method: 'POST',
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.layoutPanel(result);
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	layoutPanel:function(result){
		var _this = this;

		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:true
		});
		
		this.cm = [new Ext.grid.RowNumberer(), this.sm,
			{header:lang('opt'),sortable:true,dataIndex:'id',width:140,menuDisabled:true,renderer:function(v, c, record){
				var rd = record.data;
				var l = '';
				if(rd.status == 2){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_send_apply.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}else if(rd.status == 0){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_send_apply.operate('+v+')">发起审批</a>';
				}else if(rd.status == 1){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_send_apply.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}
				return l;
			}},
			{header:'添加时间',sortable:true,dataIndex:'posttime',width:100,menuDisabled:true},
			{header:'状态',sortable:true,dataIndex:'status',width:100,menuDisabled:true,renderer:function(v){
				if(v == 1){
					return '<span style="color:green;">审批中</span>';
				}else if(v == 2){
					return '<span style="color:gray;">审批结束</span>';
				}else{
					return '<span style="color:red;">未提交审批</span>';
				}
			}}
		];
		
		var fields = [{name:'id'},{name:'posttime'},{name:'status'},{name:'uFlowId'},{name:'activeAccount'}];
		Ext.each(result.column, function(v,i){
			fields.push({name:'field_'+v.field});
			_this.cm.push({
				header			:v.title,
				sortable		:true,
				dataIndex		:'field_'+v.field,
				width			:v.width,
				menuDisabled	:true
			});
		});
		
		this.store = new Ext.data.Store({
			autoLoad: true,
			proxy: new Ext.data.HttpProxy({
				url: this.baseUrl + '&task=getJsonList'
			}),
			reader: new Ext.data.JsonReader({
				totalProperty: "total",
				root: "data",
				fields:fields
			})
		});
		
		this.grid = new Ext.grid.GridPanel({
			store:this.store,
			width:600,
			plain:false,
       		stripeRows:true,
			loadMask:{msg: lang('waiting')},
			region:"center",
			border:false,
			autoScroll:true,
			sm:this.sm,
			columns:this.cm,
			tbar:[
				{
					handler:function(button, event){
						_this.store.reload();
					}.createDelegate(this),
					iconCls:'icon-system-refresh',
					text:lang('refresh')
				},'-',
				{
					handler:function(button, event) {
						_this.addWin('add', 0);
					}.createDelegate(this),
					iconCls:'icon-utils-s-add',
					text:"发起发文"
				},'-',
				{
					handler:function(button, event){
						var rows = _this.grid.getSelectionModel().getSelections();
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, '您还没有选择要编辑的列');
						}else{
							var id = rows[0].get("id");
							var status = rows[0].get("status");
							
							if(status != 0){
								CNOA.msg.alert("流程已经启动或者已经结束，不能再编辑！");
							}else{
								_this.addWin('edit', id);
							}
						}
					},
					iconCls: 'icon-utils-s-edit',
					text:lang('modify')
				},'-',
				{
					text:lang('del'),
					iconCls:'icon-utils-s-delete',
					handler:function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections();
						if(rows.length == 0){
							CNOA.miniMsg.alertShowAt(button, lang('mustSelectOneRow'));
						}else{
							CNOA.miniMsg.cfShowAt(button, lang('confirmToDelete'), function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									Ext.Ajax.request({
										url: _this.baseUrl + "&task=deleteData",
										method: 'POST',
										params:{ids:ids},
										success: function(r) {
											var result = Ext.decode(r.responseText);
											if(result.success === true){
												_this.store.reload();
											}else{
												CNOA.msg.alert(result.msg, function(){});
											}
										}
									});
								}
							});
						}
					}
				},"-",
				{
					text: '分发', //所有人
					handler: function(){
						var rows = _this.grid.getSelectionModel().getSelections();

						if(rows.length <= 0){
							CNOA.msg.alert('您好，请至少选择一个发文进行操作.');
							return;
						}
						if(rows[0].json.status != 2){
							CNOA.msg.alert('该信息还没有审批通过。 审批通过才能签发。');
							return;
						}
						var slid = rows[0].json.id;
						
						_this.issueSend(slid);
					}.createDelegate(this),
					iconCls: 'icon-applications-stack',
					cls: 'x-btn-over',
					listeners: {
						'mouseout': function(btn){
							btn.addClass('x-btn-over');
						}
					}
				},
				'-',
				{
					text: '签发', //下级部门 － 阅读
					handler: function(){
						var rows = _this.grid.getSelectionModel().getSelections();

						if(rows.length <= 0){
							CNOA.msg.alert('您好，请至少选择一个发文进行操作.');
							return;
						}
						if(rows[0].json.status != 2){
							CNOA.msg.alert('该信息还没有审批通过。 审批通过才能签发。');
							return;
						}
						var slid = rows[0].json.id;
						
						_this.signSend(slid);
					}.createDelegate(this),
					iconCls: 'icon-arrow_down',
					cls: 'x-btn-over',
					listeners: {
						'mouseout': function(btn){
							btn.addClass('x-btn-over');
						}
					}		
				},
				"<span class='cnoa_color_gray'>双击可修改记录,按住Ctrl或Shift键可以一次选择多条记录</span>"
			],
			bbar: new Ext.PagingToolbar({
				displayInfo:true,
				
				   
				store: this.store,
				pageSize:30,
				listeners: {
					"beforechange" : function(th, params){
						//Ext.apply(params, _this.search);
					}
				}
			})
		});
		
		this.treeStore = new Ext.data.Store({
			autoLoad:true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getSearchList", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:[{name:'field'},{name:'title'}]})
		});
		
		this.searchPanel = new Ext.form.FormPanel({
			region:'north',
			height:100,
			border:false,
			hidden:true,
			defaults:{
				border:false
			},
			padding:5,
			items:[
				{
					xtype:'panel',
					defaults:{
						border:false
					},
					items:[
						{
							xtype:'hidden',
							name:'id'
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:6
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong1',
									hiddenName: 'kong1',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition1',
									hiddenName:'condition1',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									name:'value1'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong1').setValue('');
										searchForm.findField('condition1').setValue('equal');
										searchForm.findField('value1').setValue('');
									}
								}
							]
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:4
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong2',
									hiddenName: 'kong2',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition2',
									hiddenName:'condition2',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									//emptyText:'查询条件',
									name:'value2'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong2').setValue('');
										searchForm.findField('condition2').setValue('equal');
										searchForm.findField('value2').setValue('');
									}
								}
							]
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:4
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[								
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong3',
									hiddenName: 'kong3',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition3',
									hiddenName:'condition3',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									//emptyText:'查询条件',
									name:'value3'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong3').setValue('');
										searchForm.findField('condition3').setValue('equal');
										searchForm.findField('value3').setValue('');
									}
								}
							]
						}
					]
				}
			]
		});
		
		var searchForm = _this.searchPanel.getForm();
		
		this.mainPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			layout:'border',
			autoScroll:false,
			items:[this.searchPanel,this.grid]/*,
			tbar:[
				{
					text:'展开查询',
					id:'EXPAND_SEARCH_PANEL',
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						if(_this.searchExpandBtn == 'close'){
							//如果要打开
							_this.searchPanel.show();
							_this.searchExpandBtn = 'open';
							Ext.getCmp('EXPAND_SEARCH_PANEL').setText('折叠查询');
							Ext.getCmp('ID_BTN_SEARCH').show();
						}else{
							//如果要关闭
							_this.searchPanel.hide();
							_this.searchExpandBtn = 'close';
							Ext.getCmp('EXPAND_SEARCH_PANEL').setText('展开查询');
							Ext.getCmp('ID_BTN_SEARCH').hide();
						}
						_this.mainPanel.doLayout();
					}
				},
				{
					text:lang('search'),
					style: "margin-left:5px",
					id:'ID_BTN_SEARCH',
					iconCls: "icon-search",
					hidden:true,
					cls: "x-btn-over",
					enableToggle:false,
		    		//allowDepress:false,
		   	 		toggleGroup:"search_definde_btn_group",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						_this.searchDatas = searchForm.getValues();
						_this.searchDatas.search = 'now';
						_this.store.load({params:_this.searchDatas});
					}
				},
				{
					text:lang('clear'),
					style: "margin-left:5px",
					cls: "x-btn-over",
		   	 		toggleGroup:"search_definde_btn_group",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						_this.store.load();
						searchForm.reset();
						_this.searchDatas = {};
					}
				}
			]*/
		});
		
		Ext.getCmp(CNOA.odoc.send.apply.parentID).add(this.mainPanel);
		Ext.getCmp(CNOA.odoc.send.apply.parentID).doLayout();
	},
	
	addWin:function(from, edit_id){
		var _this = this;
		
		var baseField = [
			{
				xtype:'fieldset',
				title: '请选择要发起的流程',
				layout:'column',
				//style:'margin-bottom:5px;',
				id:'CNOA_ODOC_NEW_FLOW_CT',
				hideLabel:true,
				width:660,
				autoHeight: true,
	            items: []
			},
			{
				xtype:'panel',
				border:false,
				layout: "form",
				width:660,
				defaults:{
				},
				id:'ID_DEFINDE_FIELDS'
			}
		];
		
		this.addFormPanel = new Ext.form.FormPanel({
			border:false,
			labelWidth:90,
			width:640,
			labelAlign:'right',
			waitMsgTarget:true,
			bodyStyle:"padding-left:5px;",
			items:baseField,
			autoScroll:true,
			listeners:{
				"render" : function(form){}
			}
		});
		
		var checkSelectedFlow = function(){
			var msg = "请选择要发起哪条流程", v;
			try{
				v =  _this.addFormPanel.getForm().findField("ococ_send_apply_flowList").getGroupValue();
			}catch(e){
				v = "";
				msg = "还没有可以发起的流程，请到公文设置功能里面添加公文与流程的绑定！";
			}
			if(Ext.isEmpty(v)){
				CNOA.msg.alert(msg);
				return false;
			}
			return true;
		};
		
		var submitData = function(){
			var f = _this.addFormPanel.getForm();
			if(f.isValid()) {
				f.submit({
			        url: _this.baseUrl+"&task=submitData",
			        method: 'POST',
			        waitMsg: lang('waiting'),
			        params: {id:edit_id},
			        success: function(form, action) {
						if(action.result.success == true){
							win.close();
							_this.store.reload();
							_this.operate(action.result.msg);
						}
			        }.createDelegate(this),
			        failure:function(form, action){}.createDelegate(this)
				});
			}
		};
		
		var win = new Ext.Window({
			title:lang('add'),
			width:700,
			height:makeWindowHeight(500),
			modal:true,
			layout:"fit",
			resizable:false,
			border:false,
			items:this.addFormPanel,
			buttons:[
				{
					text:'确定发起',
					handler:function(){
						if(checkSelectedFlow()){
							submitData(edit_id);
						}
					}
				},
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
		
		this.superField = Ext.getCmp('ID_DEFINDE_FIELDS');
		
		_this.loadLayout(from,edit_id);
	},
	
	loadLayout:function(from,edit_id){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=loadLayout",
			method: 'POST',
			success: function(r) {
				
				
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					Ext.each(result.fieldset, function(v, i){
						_this.addFieldSet(v.name, v.fieldset);
					});
					
					Ext.each(result.field, function(v,i){
						Ext.getCmp('ID_FIELD_SET_'+v.fieldset).add(_this.addField(v.fstfield, v.secfield, v.fstname, v.secname, v.type));
					});
					
					var flowListCt = Ext.getCmp("CNOA_ODOC_NEW_FLOW_CT");
					Ext.each(result.flowList, function(v,i){
						flowListCt.add({
							xtype: 'radio',
							name: 'ococ_send_apply_flowList',
							style: 'margin-left: 10px;',
							boxLabel: v.name,
							inputValue: v.id
						});
					});
					flowListCt.doLayout();
					
					_this.superField.doLayout();
					
					if(from == 'edit'){
						_this.addFormPanel.getForm().load({
						    url: _this.baseUrl + "&task=loadFormData",
						    method:'POST',
						    params : {id:edit_id},
						    success: function(form, action){
						        var rd = action.result.data;
						    },
						    failure: function(form, action) {
						        CNOA.msg.alert(action.result.msg, function(){
						            
						        });
						    }
						});
					}
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	addFieldSet:function(msg, fieldsetid){
		var _this = this;
		
		_this.superField.add({
			xtype:'fieldset',
			title:msg,
			autoHeight: true,
			id:"ID_FIELD_SET_"+fieldsetid
		});
	},
	
	addField:function(firstId, secondId, fstname, secname, typeFrom){
		var _this = this;
		
		if (typeFrom == 'textarea') {
			var items = {
					xtype: 'panel',
					layout: 'form',
					items: [{
						xtype: 'textarea',
						width: 464,
						fieldLabel: fstname,
						name: 'field_' + firstId
					}]
				}
		}else if(typeFrom == 'sort'){
			var items = {
				xtype: 'panel',
				layout: 'form',
				items: [{
					xtype:"combo",
					fieldLabel:fstname,
					name:'field_'+firstId,
					store: this.sortStore,
					hiddenName:'field_' + firstId,
					valueField:'iid',
					displayField:'sort',
					mode:'local',
					width:180,
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}]
			}
		}else if(typeFrom == 'type'){
			var items = {
				xtype: 'panel',
				layout: 'form',
				items: [{
					xtype:"combo",
					fieldLabel:fstname,
					name:'field_'+firstId,
					store:this.typeStore,
					hiddenName:'field_' + firstId,
					valueField: 'id',
					displayField: 'sid',
					mode: 'local',
					width: 180,
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}]
			}
		}else if(typeFrom == 'region'){
			var items = [{
				xtype : "panel",
				layout : "form",
				items : [{
					xtype : "combo",
					fieldLabel: fstname,
					name: 'field_' + firstId,
					store : this.regionStore,
					name: 'field_' + firstId,
					secondId:secondId,
					valueField : 'rid',
					displayField : 'name',
					mode : 'local',
					width : 180,
					triggerAction : 'all',
					forceSelection : true,
					editable : false,
					listeners:{
						change:function(th, newValue, oldValue){
							_this.region2 = "";
							_this.addFormPanel.getForm().findField('field_' + th.secondId).setValue("");
							_this.regionStore2.load({params : {rid : newValue}});
						}
					}
				}]
			}, {
				xtype: "panel",
				layout: "form",
				items: [{
					xtype:"combo",
					fieldLabel:secname,
					name:'field_' + secondId,
					store:this.regionStore2,
					name:'field_' + secondId,
					valueField:'pid',
					displayField:'name',
					mode:'local',
					width:180,
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}]
			}]
		}
		else {
			var items = [];
			
			if(fstname == '' || secname == ''){
				var fieldName = fstname == ''?secondId:firstId;
				items = [
					{
						xtype:'panel',
						layout:'form',
						items:[{
							xtype:'textfield',
							width:464,
							fieldLabel:fstname == ''?secname:fstname,
							name:'field_'+ fieldName
						}]
					}
				];
			}else{
				items = [
					{
						xtype:'panel',
						layout:'form',
						items:[{
							xtype:'textfield',
							width:180,
							fieldLabel:fstname,
							name:'field_'+firstId
						}]
					},{
						xtype: 'panel',
						layout: 'form',
						items: [{
							xtype:'textfield',
							width:180,
							fieldLabel:secname,
							name:'field_'+secondId
						}]
					}
				];
			}
		}
		
		var result = {
			xtype: 'panel',
			layout: 'table',
			layoutConfig: {
				columns: 2
			},
			style: 'margin-top:10px',
			border: false,
			defaults: {
				border: false
			},
			items:items
		}
		
		return result;
	},
	
	operate:function(v){
		var _this = this;
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=getFaqiFlow",
			method: 'POST',
			params:{id:v},
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					var flowType = result.flowType;
					var flowId = result.flowId;
					var nameRuleId = result.nameRuleId;
					var tplSort = result.tplSort;
					var childId = 0;
					var otherApp = result.otherApp;
					
					if(flowType == 0){
						mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
						mainPanel.loadClass("index.php?app=wf&func=flow&action=use&modul=new&task=loadPage&from=newflow&flowId="+flowId+"&nameRuleId="+nameRuleId+"&flowType="+flowType+"&tplSort="+tplSort+"&childId="+childId+"&otherApp="+otherApp, "CNOA_MENU_WF_USE_OPENFLOW", "发起新的固定流程", "icon-flow-new");
					}else{
						mainPanel.closeTab("CNOA_USE_FLOW_NEWFREE_FLOWDESIGN");
						mainPanel.loadClass("index.php?app=wf&func=flow&action=use&modul=newfree&task=loadPage&from=flowdesign&flowId="+flowId+"&flowType="+flowType+"&tplSort="+tplSort+"&childId="+childId+"&otherApp="+otherApp, "CNOA_USE_FLOW_NEWFREE_FLOWDESIGN", "设计流程", "icon-flow-new");
					}
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	viewFlow:function(uFlowId){
		mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
		mainPanel.loadClass(this.baseUrl+"&task=loadPage&from=viewflow&uFlowId="+uFlowId, "CNOA_MENU_WF_USE_OPENFLOW", "查看工作流程", "icon-flow");
	},
	
	/**
	 * 签发
	 */
	signSend:function(slid){
		var _this = this;
		
		var receiveUid_ID = Ext.id();
		
		var frm = new Ext.form.FormPanel({
			border:false,
			labelWidth:80,
			labelAlign:'right',
			bodyStyle:'padding: 10px 0 0 15px',
			defaults:{
				style:'margin-bottom: 10px',
				width: 330
			},
			items: [
				{
					xtype:'textfield',
					fieldLabel:'来文单位',
					name:'deptment',
					allowBlank:false
				},
				{
					xtype:'textfield',
					fieldLabel:lang('title'),
					name:'title',
					allowBlank:false
				},
				{
					xtype:'textfield',
					fieldLabel:'收文编号',
					name:'number',
					allowBlank:false
				},
				{
					xtype:'numberfield',
					fieldLabel:'打印份数',
					name:'print',
					allowBlank:false
				},
				{
					xtype: 'checkboxgroup',
					fieldLabel: '签发内容',
					allowBlank: false,
					items: [
						{boxLabel: '审批正文(Word)', name: "withWord"},
						{boxLabel: '流程附件', name: "withAttach"}
					]
				},
				{
					xtype: "hidden",
					id: receiveUid_ID,
					name: "uids"
				},
				{
					xtype: "textfield",
					readOnly: true,
					allowBlank: false,
					fieldLabel: '接收人员',
					emptyText: "请选择接收人员",
					blankText: "请选择接收人员",
					name: "names",
					listeners: {
						'render': function(th){
							th.to = receiveUid_ID;
						},
						'focus': function(th){
							people_selector('user', th, false);
						}
					}

				}/*,
				{
					xtype: 'textarea',
					width: 300,
					height: 120,
					name: 'names',
					allowBlank: false,
					readOnly:true,
					fieldLabel: '接收人员'
				},
				{
					xtype: "btnForPoepleSelector",
					//fieldLabel:lang('selectPeople'),
					text: lang('selectPeople'),
					allowBlank: false,
					name:"asdfasdf",
					style: 'margin:0 0 0 85px',
					dataUrl: _this.baseUrl+"&task=getAllUserListsInPermitDeptTree",
					width: 80,
					listeners: {
						"selected": function(th, data){
							//cdump(data);
							var names = new Array();
							var uids = new Array();
							
							if (data.length>0){
								for (var i=0;i <= data.length - 1; i++){
									names.push(data[i].uname);
									uids.push(data[i].uid);
								}
							}
							var sNames	= names.join(",");
							var sUids	= uids.join(",");
							
							frm.getForm().findField("uids").setValue(sUids);
							frm.getForm().findField("names").setValue(sNames);
						}
					}
				}*/
			]
		});
				
		var win = new Ext.Window({
			title:'签发',
			width:460,
			height: 305,
			layout:'fit',
			modal:true,
			resizable:false,
			maximizable:false,
			items:frm,
			buttons:[
				{
					text:lang('ok'),
					handler:function(){
						var f = frm.getForm();
						if (f.isValid()){
							f.submit({
								url:_this.baseUrl + '&task=submitSign',
								method:'POST',
								params:{pid:slid},
								success:function(form, action){
									CNOA.msg.notice(action.result.msg, "公文管理");
									_this.store.reload();
									win.close();
								},
								failure:function(form, action){
									CNOA.msg.alert(action.result.msg);
								}
							});
						}else{
							CNOA.msg.alert(lang('formValid'));
						}
					}
				},
				{
					text:lang('close'),
					handler:function (){
						win.close();
					}
				}
			]
		}).show();
		
		return win;
	},
	
	/**
	 * 分发
	 */
	issueSend : function(id){
		var _this = this;
		
		var rows = _this.grid.getSelectionModel().getSelections();
		//cdump(rows);return;
		if(rows.length <= 0){
			CNOA.msg.alert('您好，请至少选择一个发文进行操作.');
			return;
		}
		var slid = rows[0].json.id;

		var frm = new Ext.form.FormPanel({
			border: false,
			labelWidth: 60,
			labelAlign: 'right',
			bodyStyle:'padding: 10px',
			items: [
				{
					xtype: 'checkboxgroup',
					fieldLabel: '分发内容',
					columns: 3,
					allowBlank: false,
					items: [
						{boxLabel: '审批表单', name: "viewForm"},
						{boxLabel: '审批正文(Word)', name: "viewWord", checked: true},
						{boxLabel: '流程附件', name: "viewAttach", checked: true}//,
						//{boxLabel: '审批步骤', name: "viewConfig[step]"},
						//{boxLabel: '审批事件', name: "viewConfig[event]"},
						//{boxLabel: '允许打印', name: "viewConfig[print]"}
					]
				},
				{
					xtype:'textarea',
					fieldLabel:'查看人',
					name:'recvMan',
					width:333,
					height:150,
					readOnly:true,
					allowBlank:false
				},
				{
					xtype:"hidden",
					name:"recvUids",
					id:_this.ID_recvUids
				},
				{
					xtype:"btnForPoepleSelector",
					fieldLabel:"",
					text:lang('select'),
					allowBlank: false,
					name:"checkName",
					dataUrl: _this.baseUrl+"&task=getAllUserListsInPermitDeptTree",
					width:70,
					style:'margin: 0 0 0 65px',
					listeners:{
						"selected":function(th, data){
							var names = new Array();
							var uids = new Array();
							
							if (data.length>0){
								for (var i=0;i <= data.length - 1; i++){
									names.push(data[i].uname);
									uids.push(data[i].uid);
								}
							}
							var sNames	= names.join(",");
							var sUids	= uids.join(",");
							
							frm.getForm().findField("recvUids").setValue(sUids);
							frm.getForm().findField("recvMan").setValue(sNames);
						}
					}
				}
			]
		})
		
		submit = function(){
			var f = frm.getForm();
			if (f.isValid()) {
				f.submit({
					url: _this.baseUrl + '&task=submitIssue',
					method: 'POST',
					params: {id:slid},
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						_this.store.reload();
						win.close();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg);
					}
				});
			}else{
				CNOA.msg.alert(lang('formValid'));
			}
		};
		
		var win = new Ext.Window({
			title: '分发',
			width: 430,
			height: 330,
			layout: 'fit',
			modal: true,
			resizable: false,
			maximizable: false,
			items: [frm],
			buttons:[
				{
					text: '确定分发',
					handler: function(){
						submit();
					}
				},{
					text: lang('close'),
					handler: function (){						
						win.close();
					}
				}
			]
		}).show();
		
		return win;
	}
}
var CNOA_odoc_setting_flowClass, CNOA_odoc_setting_flow;
var CNOA_odoc_setting_setAddWin1,CNOA_odoc_setting_setAddWin2, CNOA_odoc_setting_setAddWinClass;
var CNOA_odoc_setting_setWinList1,CNOA_odoc_setting_setWinList2, CNOA_odoc_setting_setWinListClass;
var CNOA_odoc_setting_setBindFlowClass;

CNOA_odoc_setting_setAddWinClass = function(from){
	var _this = this;

	this.baseUrl = "index.php?app=odoc&func=setting&action=flow";
		
	var baseField = [
		{
			xtype:'panel',
			border:false,
			layout:"form",
			defaults:{},
			id:'ID_DEFINDE_FIELDS'
		}
	];
	
	this.form = new Ext.form.FormPanel({
		border:false,
		labelWidth:60,
		labelAlign:'left',
		autoWidth:true,
		waitMsgTarget:true,
		bodyStyle:"padding:5px 10px 10px 10px;",
		items:baseField,
		autoScroll:true,
		hideLabel:true,
		listeners:{
			"render":function(form){}
		}
	});
	
	this.fieldStore = new Ext.data.SimpleStore({
		fields:['value', 'name'],
		data:[]
	});
	
	this.superField = Ext.getCmp('ID_DEFINDE_FIELDS');
	
	//fieldset的id
	this.fieldsetid = 1;
	this.fieldStoreData = [];
	
	this.childFieldid = 1;
	
	this.childFieldArr = [];
	
	var win = new Ext.Panel({
		layout:'fit',
		id: 'odoc_view_' + from,
		items:this.form,
		tbar:[
			{
				text:'添加分类',
				handler:function(btn){
					Ext.MessageBox.prompt("", "添加您需要的类别名称", function(btn, msg){
						if(btn == 'ok'){
							if(msg != ''){
								_this.addFieldSet(msg, _this.fieldsetid);
								_this.fieldsetid++;
							}else{
								CNOA.msg.alert('您还没有添加名称');
							}
						}
					});
					
				}
			},'-',
			{
				text:'添加输入框',
				handler:function(btn){
					_this.addChildField('add', '', '', '', '');
				}
			},'-',
			{
				text:lang('save'),
				iconCls: 'icon-btn-save',
				handler:function(btn){
					var	temp = [];
					Ext.each(_this.fieldStore.data.items,function(v, i){
						temp.push(v.data);
					});
					var tempStoreData = Ext.encode(temp);
					_this.form.getForm().submit({
						url: _this.baseUrl+"&task=submitAddWinLayout",
						method: 'POST',
						waitMsg: lang('waiting'),
						params: {tempStoreData:tempStoreData,from:from},
						success: function(form, action) {
							CNOA.msg.alert(lang('successopt'), function(){
							});
						}.createDelegate(this),
						failure: function(form, action) {
							CNOA.msg.alert(action.result.msg, function(){
								
							}.createDelegate(this));
						}.createDelegate(this)
					});
				}
			},'-',
			('<span class="cnoa_color_gray">添加'+(from == 'send'?'发':'收')+'文的窗口设置</span>')
		]
	});
	
	this.addChildField = function(from, editFirstField, editSecondField, sortFrom, typeFrom){
		var _this = this;
		
		var addToFieldset = function(){
			var values = form.getForm().getValues();
			var sortFrom = values.sortFrom;
			var typeFrom = values.typeFrom;
			if(sortFrom == 0){
				_this.superField.add(_this.childFormat(from, values, _this.superField, sortFrom, typeFrom));
				_this.superField.doLayout();
			}else{
				var childField = Ext.getCmp('ID_FIELD_SET_' + sortFrom);
				childField.add(_this.childFormat(from, values, childField, sortFrom, typeFrom));
				childField.doLayout();
			}
		};
		
		var baseField = [
			{
				xtype:'combo',
				fieldLabel:"类型",
				name:'typeFrom',
				hiddenName:'typeFrom',
				store:new Ext.data.SimpleStore({
					fields:['value', 'name'],
					data:[['text', '单行文本'], ['textarea', '多行文本']]
				}),
				valueField:'value',
				displayField:'name',
				mode:'local',
				triggerAction:'all',
				forceSelection:true,
				editable:false,
				width:200,
				value:'text',
				listeners:{
					'change':function(th, newValue, oldValue){
						if(newValue == 'textarea' || newValue == 'type' || newValue == 'sort'){
							form.getForm().findField('secname').setValue('');
							form.getForm().findField('secname').hide();
						}else{
							form.getForm().findField('secname').show();
						};
					}
				}
			},
			{
				xtype:'combo',
				fieldLabel:"分类列表",
				name:'sortFrom',
				hiddenName:'sortFrom',
				store:this.fieldStore,
				valueField:'value',
				displayField:'name',
				mode:'local',
				triggerAction:'all',
				forceSelection:true,
				editable:false,
				width:200,
				allowBlank:false,
				listeners:{
					'select':function(th, record, index){}
				}
			},
			{
				xtype:'textfield',
				name:'fstname',
				width:200,
				fieldLabel:'第一个名称'
			},
			{
				xtype:'textfield',
				name:'secname',
				width:200,
				fieldLabel:'第二个名称'
			}
		];
		
		var form = new Ext.form.FormPanel({
			border: false,
			labelWidth: 90,
			labelAlign: 'right',
			autoWidth: true,
			waitMsgTarget: true,
			bodyStyle: "padding:5px 10px 10px 10px;",
			items:baseField,
			autoScroll:true,
			listeners: {
				"render" : function(form){}
			}
		});
		
		var win = new Ext.Window({
			title:lang('add'),
			modal:true,
			resizable:false,
			width:400,
			height:200,
			layout:'fit',
			items:form,
			buttons:[
				{
					text:lang('ok'),
					hidden:from == 'add'?false:true,
					handler:function(btn){
						if(!form.getForm().isValid()){
							CNOA.msg.alert('您还没有设置分类.');
							return false;
						}
						var values = form.getForm().getValues();
//						if(!_this.checkChildField(values, _this.childFieldArr)){
//							return false;
//						}
						_this.childFieldArr.push(values.fstname);
						_this.childFieldArr.push(values.secname);
						addToFieldset();
						win.close();
					}
				},
				{
					text:lang('modify'),
					hidden:from == 'edit'?false:true,
					handler:function(btn){
						if(!form.getForm().isValid()){
							CNOA.msg.alert('您还没有设置分类.');
							return false;
						}
						
						var childFieldArr = [];
						Ext.each(_this.childFieldArr, function(v,i){
							if(v != editFirstField.hideValue && v != editSecondField.hideValue){
								childFieldArr.push(v);
							}
						});
						
						var values = form.getForm().getValues();
//						if(!_this.checkChildField(values, childFieldArr)){
//							return false;
//						}
						
						editFirstField.hideValue = values.fstname;
						editSecondField.hideValue = values.secname;
						
						var note = _this.formatNote(typeFrom);
						
						editFirstField.setValue(note.note_one+values.fstname);
						editSecondField.setValue(note.note_two+values.secname);
						
						_this.childFieldArr = childFieldArr;
						
						_this.childFieldArr.push(values.fstname);
						_this.childFieldArr.push(values.secname);
						win.close();
					}
				},
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
		
		if(from == 'edit'){
			var record = {};
			var fstname = '';
			var secname = '';
				record.data = {'typeFrom':typeFrom, 'sortFrom':sortFrom, 'fstname':editFirstField.hideValue, 'secname':editSecondField.hideValue};
			form.getForm().loadRecord(record);
			form.getForm().findField('sortFrom').setDisabled(true);
			form.getForm().findField('typeFrom').setDisabled(true);
			if(typeFrom == 'textarea'){
				form.getForm().findField('secname').hide();
			}
		}
	};
	
	this.formatNote = function(from){
		var result = {};
		switch(from){
			case 'text':
				result.note_one = '{[单行文本]}';
				result.note_two = '{[单行文本]}';
			break;
			case 'textarea':
				result.note_one = '{[多行文本]}';
				result.note_two = '{[多行文本]}';
			break;
			case 'type':
				result.note_one = '{[自定义类别]}';
				result.note_two = '';
			break;
			case 'sort':
				result.note_one = '{[行业信息]}';
				result.note_two = '';
			break;
			case 'region':
				result.note_one = '{[地区]}';
				result.note_two = '{[二级地区]}';
			break;
			case 'account':
				result.note_one = '{[登陆账号]}';
				result.note_two = '{[真实姓名]}';
			break;
		}
		return result;
	};
	
	this.childFormat = function(from, values, fieldset, sortFrom, typeFrom){
		var _this = this;

		var firstId		= this.childFieldid++;
		var secondId	= this.childFieldid++;
		
		var note = this.formatNote(typeFrom);
		if(typeFrom == 'textarea'){
			var items = [
					{
						xtype:'textarea',
						width:378,
						readOnly:true,
						name:'field_'+firstId+'_'+sortFrom+'_'+typeFrom,
						hideValue:values.fstname,
						value:note.note_one+values.fstname
					},
					{
						xtype:'hidden',
						readOnly:true,
						name:'field_'+secondId+'_'+sortFrom+'_'+typeFrom+'_hide',
						hideValue:values.secname,
						value:note.note_two+values.secname
					}
				];
		}else if(typeFrom == 'sort'){
			var items = [
				{
					xtype:'textfield',
					width:180,
					readOnly:true,
					name:'field_'+firstId+'_'+sortFrom+'_'+typeFrom,
					hideValue:values.fstname,
					value:note.note_one+values.fstname
				},
				{
					xtype:'hidden',
					width:180,
					readOnly:true,
					name:'field_'+secondId+'_'+sortFrom+'_'+typeFrom+'_hide',
					style:'margin-left:20px',
					hideValue:values.secname,
					value:note.note_two+values.secname
				}
			];
		}else if(typeFrom == 'type'){
			var items = [
				{
					xtype:'textfield',
					width:180,
					readOnly:true,
					name:'field_'+firstId+'_'+sortFrom+'_'+typeFrom,
					hideValue:values.fstname,
					value:note.note_one+values.fstname
				},
				{
					xtype:'hidden',
					width:180,
					readOnly:true,
					name:'field_'+secondId+'_'+sortFrom+'_'+typeFrom+'_hide',
					style:'margin-left:20px',
					hideValue:values.secname,
					value:note.note_two+values.secname
				}
			];
		}else{
			var displayF = '';
			var displayS = '';
			if(values.fstname == ''){
				displayF = '_hide';
			}
			if(values.secname == ''){
				displayS = '_hide';
				values.secname = 'aa';
			}
			var items = [
				{
					xtype:'textfield',
					width:180,
					readOnly:true,
					name:'field_'+firstId+'_'+sortFrom+'_'+typeFrom+displayF,
					hideValue:values.fstname,
					value:note.note_one+values.fstname
				},
				{
					xtype:'textfield',
					width:180,
					readOnly:true,
					name:'field_'+secondId+'_'+sortFrom+'_'+typeFrom+displayS,
					style:'margin-left:20px',
					hideValue:values.secname,
					value:note.note_two+values.secname
				}
			];
		}
		
		items.push(
			{
				xtype:'button',
				text:'编辑',
				firstId:firstId,
				secondId:secondId,
				sortFrom:sortFrom,
				typeFrom:typeFrom,
				handler:function(btn){
					var firstGroup = {};
					var secondGroup = {};
					try{
						firstGroup = _this.form.getForm().findField('field_'+btn.firstId+'_'+btn.sortFrom+'_'+btn.typeFrom);
					}catch(e){
						firstGroup = _this.form.getForm().findField('field_'+btn.firstId+'_'+btn.sortFrom+'_'+btn.typeFrom+'_hide');
					}
					try{
						secondGroup = _this.form.getForm().findField('field_'+btn.secondId+'_'+btn.sortFrom+'_'+btn.typeFrom);
					}catch(e){
						secondGroup = _this.form.getForm().findField('field_'+btn.secondId+'_'+btn.sortFrom+'_'+btn.typeFrom+'_hide');
					}
					_this.addChildField('edit', firstGroup,secondGroup, btn.sortFrom, btn.typeFrom);
				}
			},
			{
				xtype:'button',
				text:lang('del'),
				tableId:firstId,
				style:'margin-left:20px',
				handler:function(btn){
					fieldset.remove(Ext.getCmp('ID_GROUP_CHILD_FIELD' + btn.tableId));
				}
			}
		);
		
		var result = {
			xtype: 'panel',
			layout: 'table',
			layoutConfig: {
				columns: 5
			},
			style: 'margin-top:10px',
			border: false,
			id: 'ID_GROUP_CHILD_FIELD' + firstId,
			defaults: {
				border: false
			},
			items:items
		}
		
		return result;
	};
	
	this.addField = function(name, sortFrom, typeFrom, values){
		var _this = this;

		var childField = Ext.getCmp('ID_FIELD_SET_' + sortFrom);
		childField.add(_this.childFormat('add', values, childField, sortFrom, typeFrom));
		childField.doLayout();
	};
	
	this.addFieldSet = function(msg, fieldsetid){
		this.superField = Ext.getCmp('ID_DEFINDE_FIELDS');
		
		this.superField.add({
			xtype:'fieldset',
			title:msg,
			anchor: "99%",
			autoHeight: true,
			id:"ID_FIELD_SET_" + fieldsetid,
			items:[
				{
					xtype:'button',
					text:'删除分类',
					fieldsetid:fieldsetid,
					handler:function(botton){
						CNOA.msg.cf('删除该分类，也会删除分类里面的内容', function(btn){
							if(btn == 'yes'){
								_this.superField.remove(Ext.getCmp("ID_FIELD_SET_" + botton.fieldsetid));
								var fieldStoreData2 = [];
								Ext.each(_this.fieldStoreData,function(v,i){
									if(v[0] != botton.fieldsetid){
										fieldStoreData2.push(v);
									}
								});
								_this.fieldStore.loadData(fieldStoreData2);
							}
						})
					}
				}
			]
		});
		_this.superField.doLayout();
		_this.fieldStoreData.push([fieldsetid, msg]);
		_this.fieldStore.loadData(_this.fieldStoreData);
	};
	
	this.loadData = function(){
		Ext.Ajax.request({
			url:_this.baseUrl + "&task=loadFormData",
			method:'POST',
			params:{from:from},
			success:function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					Ext.each(result.fieldset, function(v, i){
						_this.addFieldSet(v.name, v.fieldset);
					});
					Ext.each(result.field, function(v,i){
						var values = {};
						values.fstname = v.fstname;
						values.secname = v.secname;
						
						_this.childFieldArr.push(v.fstname);
						_this.childFieldArr.push(v.secname);
						
						_this.addField(v.name, v.fieldset, v.type, values);
						_this.fieldsetid++;
					});
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	};
	
	this.loadData();

	return win;
};


CNOA_odoc_setting_setWinListClass = function(from){
	var _this = this;
	
	this.baseUrl = "index.php?app=odoc&func=setting&action=flow";
		
	var wordFields = [
		'field',
		'name',
		'title',
		'width'
	];
	
	var wordStore = new Ext.data.Store({
		proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getFieldList", disableCaching: true}),   
		reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:wordFields}),
		listeners:{
			load:function(th, records, options){}
		}
	});
	
	wordStore.load({params:{from:from}});
	
	var wordColModel = new Ext.grid.ColumnModel([
        {id:'name',header: "输入框名称", sortable: true, dataIndex: 'name', menuDisabled: true}
    ]);
	
	var leftGrid = new Ext.grid.GridPanel({
		region:'west',
		width:240,
		ddGroup:'wordDDGroup',
		layout:'fit',
		bodyStyle: 'border-right-width:1px;',
		enableDragDrop:true,
        store:wordStore,
        cm:wordColModel,
		autoExpandColumn:'name',
        sm:new Ext.grid.RowSelectionModel({
            singleSelect: true
        }),
		dropConfig:{
			appendOnly:true
		},
        border: false,
		listeners:{
			afterrender: function(th){
				setTimeout(function(){
					new Ext.dd.DropTarget(rightGrid.getView().scroller.dom, {
						ddGroup:'wordDDGroup',
						notifyDrop  : function(ddSource, e, data){
							var records =  ddSource.dragData.selections;
							Ext.each(records, ddSource.grid.store.remove, ddSource.grid.store);
							
							var index = ddSource.getDragData(e).rowIndex;
							if (typeof(index) == "undefined") {
								rightGrid.store.add(records);
							}else{
								templeStore.insert(index, records);
							}
						}
					});
				}, 1000);
			}
		}
	});
	
	var templeStore = new Ext.data.Store({
		proxy:new Ext.data.HttpProxy({url:this.baseUrl+"&task=getWordList", disableCaching: true}),   
		reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:wordFields})
	});
	
	templeStore.load({params:{from:from}});
	
	var templeColModel = new Ext.grid.ColumnModel([
        {header:"", hidden:true, dataIndex:'fieldid'},
        {header:"输入框名称", width:150, sortable:true, dataIndex:'name', menuDisabled:true},
        {id:'title', header:"自定义名称", sortable:true, dataIndex:'title', menuDisabled:true,
			editor:{
				xtype:'textfield',
				allowBlank:true
			}},
        {header:"宽度", width:80, sortable:true, dataIndex:'width', menuDisabled:true,
			editor:{
				xtype:'textfield',
				allowBlank:true
			}}
	]);
	
	var rightGrid = new Ext.grid.EditorGridPanel({
		region:'center',
		border: false,
		ddGroup:'wordDDGroup',
		layout:'fit',
		enableDragDrop:true,
        store:templeStore,
        cm:templeColModel,
		autoExpandColumn:'title',
        sm:new Ext.grid.RowSelectionModel({
            singleSelect: true
        }),
		clicksToEdit: 1,
		listeners:{
			afterrender:function(th){
				setTimeout(function(){
					new Ext.dd.DropTarget(leftGrid.getView().scroller.dom, {
						ddGroup:'wordDDGroup',
						notifyEnter : function(ddSource, e, data) {},
						notifyDrop  : function(ddSource, e, data){
							var records =  ddSource.dragData.selections;
							Ext.each(records, ddSource.grid.store.remove, ddSource.grid.store);
							
							var index = ddSource.getDragData(e).rowIndex;
							if (typeof(index) == "undefined") {
								leftGrid.store.add(records);
							}else{
								wordStore.insert(index, records);
							}
						}
					});
				}, 1000);
			}
		}
	});
	

	var win = new Ext.Panel({
		resizable:false,
		modal:true,
		layout:'border',
		items:[leftGrid, rightGrid],
		id: 'odoc_list_' + from,
		tbar:[
			{
				text:lang('save'),
				iconCls: 'icon-btn-save',
				handler:function(btn){
					var data = [];
					Ext.each(templeStore.data.items, function(v, i){
						data.push(v.data);
					});
					Ext.Ajax.request({
						url: _this.baseUrl + "&task=submitList",
						method: 'POST',
						params:{data:Ext.encode(data),from: from},
						success: function(r) {
							var result = Ext.decode(r.responseText);
							if(result.success === true){
								CNOA.msg.alert(result.msg,function(){
									
								})
							}else{
								CNOA.msg.alert(result.msg, function(){});
							}
						}
					});
				}
			},'-',
			('<span class="cnoa_color_gray">设置'+(from == 'send'?'发':'收')+'文的列表显示</span>'),'-',
			'<span class="cnoa_color_gray">可以拖动左边的输入框到右边栏目里添加列，双击“自定义名称”/“宽度”可以修改相应内容。</span>'
		]
	});

	return win;
};

CNOA_odoc_setting_setBindFlowClass = CNOA.Class.create();
CNOA_odoc_setting_setBindFlowClass.prototype = {
	init : function(from){
		var _this = this;
		
		this.from = from;
		
		this.baseUrl = "index.php?app=odoc&func=setting&action=flow";
			
		var fields = [
			{name:"id"},
			{name:"name"},
			{name:"flowId"},
			{name:"flowName"},
			{name:"status"},
			{name:"bindKJ"}
		];
		
		this.store = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getFlowJsonData&from="+this.from, disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: fields})
		});
		
		var sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:true
		});
		
		this.store.load();
	
		var colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			{header: "id", dataIndex: 'id', hidden: true},
			{header: lang('flowName'), dataIndex: 'name',width: 180, sortable: true, menuDisabled :true},
			{header: '绑定工作流', dataIndex: 'flowName',width: 180, sortable: true, menuDisabled :true},
			{header: "状态", dataIndex: 'status', width: 60, sortable: false,menuDisabled :true, renderer:function(value, c, r){
				var _this = this;
				if (value==1){
					return '<span class=cnoa_color_green>启用</span>';
				}else{
					return '<span class=cnoa_color_red>停用</span>';
				}
			}},
			{header: "绑定控件", dataIndex: 'bindKJ', id: 'bindKJ', width: 140, sortable: false,menuDisabled :true},
			{header: lang('opt'), dataIndex: 'id', width: 160, sortable: false,menuDisabled :true, renderer:function(value, c, r){
				var rd = r.data, sText='';
				if(rd.status == 1){
					sText = '停用';
				}else{
					sText = '启用';
				}
				var h  = "<a href='javascript:void(0);' onclick='CNOA_odoc_setting_setBindFlow.setStatus("+value+", "+rd.status+")'>"+sText+"</a>&nbsp;&nbsp;";
					h += "<a href='javascript:void(0);' onclick='CNOA_odoc_setting_setBindFlow.addFlow(\"edit\", "+value+")'>修改</a>&nbsp;&nbsp;";
					h += "<a href='javascript:void(0);' onclick='CNOA_odoc_setting_setBindFlow.bindKongJian("+value+")'>绑定控件</a>&nbsp;&nbsp;";
					h += "<a href='javascript:void(0);' onclick='CNOA_odoc_setting_setBindFlow.deleteFlow("+value+")'>删除</a>";
				return h;
			}},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
				
		this.right = new Ext.grid.GridPanel({
			store: this.store,
			loadMask:{msg: lang('waiting')},
			cm:colModel,
			hideBorders:true,
			border:false,
			region:"center",
			layout:'fit',
			autoExpandColumn:'bindKJ',
			stripeRows:true,
			tbar: new Ext.Toolbar({
				items: [
					{
						text:lang('refresh'),
						iconCls: 'icon-system-refresh',
						handler:function(btn){
							_this.store.reload();
						}
					},'-',{
						text:lang('add'),
						iconCls: 'icon-utils-s-add',
						handler:function(btn){
							_this.addFlow("add");
						}
					},'-',
					(function(){
						var h = '<span class="cnoa_color_gray">';
						switch(this.from){
							case 'send':
								h += '绑定发文流程';
								break;
							case 'receive':
								h += '绑定收文流程';
								break;
							case 'borrow':
								h += '绑定借阅流程';
								break;
							return 
						}
						h += '</span>';
						return h;
					})()
				]
			})
		});
		
		this.mainPanel = new Ext.Panel({
			layout:'border',
			id: 'odoc_bind_' + this.from,
			items:[this.right]
		});
	},
	
	setStatus : function(id, status){
		var _this = this;
		
		CNOA.msg.cf("确定要"+(status == 0 ? "启用" : "停用")+"此条公文流程吗？", function(btn){
			if(btn == 'yes'){
				Ext.Ajax.request({
					url: _this.baseUrl + "&task=setStatus",
					method: 'POST',
					params:{id:id},
					success: function(r){
						var result = Ext.decode(r.responseText);
						if(result.success === true){
							CNOA.msg.alert(result.msg,function(){
								_this.store.load();
							});
						}else{
							CNOA.msg.alert(result.msg, function(){});
						}
					}
				});
			}
		});
	},
	
	deleteFlow: function(id){
		var _this = this;
		
		CNOA.msg.cf("确定要删除此条公文流程吗？", function(btn){
			if(btn == 'yes'){
				Ext.Ajax.request({
					url: _this.baseUrl + "&task=deleteFlow",
					method: 'POST',
					params:{id:id},
					success: function(r){
						var result = Ext.decode(r.responseText);
						if(result.success === true){
							CNOA.msg.alert(result.msg,function(){
								_this.store.load();
							});
						}else{
							CNOA.msg.alert(result.msg, function(){});
						}
					}
				});
			}
		});
	},
	
	addFlow : function(tp, id){
		var _this = this;
		var form, flowStore, win;
		
		var loadForm = function(){
			form.getForm().load({
				url: _this.baseUrl + "&task=editLoadBindFlowData",
				params: {id: id},
				method:'POST',
				waitMsg: lang('waiting'),
				success: function(form, action){
					
				}.createDelegate(this),
				failure: function(form, action) {
					CNOA.msg.alert(action.result.msg, function(){
						win.close();
					});
				}.createDelegate(this)
			});
		};
		
		flowStore = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({
				url: this.baseUrl + "&task=getFlowList",
				method:'POST'
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields:[{
					name:'flowId'
				}, {
					name:'name'
				}]
			}),
			listeners:{
				load:function(th, record, opt){
					
				}
			}
		});
		flowStore.load();
		form = new Ext.form.FormPanel({
			border:false,
			labelWidth:60,
			labelAlign:'left',
			autoWidth:true,
			waitMsgTarget:true,
			bodyStyle:"padding:5px",
			items: [
				{
					xtype: 'textfield',
					fieldLabel: lang('flowName'),
					name: 'name',
					width:400
				},
				{
					xtype:'combo',
					fieldLabel:"绑定流程",
					name:'bindFlow',
					hiddenName: 'bindFlow',
					store: flowStore,
					valueField:'flowId',
					displayField:'name',
					mode:'local',
					triggerAction:'all',
					forceSelection:true,
					editable:false,
					width:400
				}
			],
			listeners:{
				"render":function(form){
					if(tp){
						loadForm();
					}
				}
			}
		});
		
		win = new Ext.Window({
			title: (tp == "edit" ? lang('modify') : lang('add')) + (this.from == 'send'?'发文流程':'收文流程') + "绑定",
			width:492,
			height:150,
			modal:true,
			resizable:false,
			layout:'fit',
			items: form,
			buttons:[
				{
					text:lang('save'),
					handler:function(btn){
						
						form.getForm().submit({
					        url: _this.baseUrl+"&task=submitBindFlow",
					        method: 'POST',
					        waitMsg: lang('waiting'),
					        params: {from: _this.from, tp: tp, id: id},
					        success: function(form, action) {
								CNOA.msg.alert(lang('successopt'), function(){
									win.close();
									_this.store.load();
								});
					        }.createDelegate(this),
					        failure: function(form, action) {
					            CNOA.msg.alert(action.result.msg, function(){
					                
					            }.createDelegate(this));
					        }.createDelegate(this)
						});
					}
				},
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
	},
	
	bindKongJian : function(id){
		var _this = this;
				
		var fields = [
			{name:'field'},
			{name:'kongjian'},
			{name:'name'}
		];
		
		var bingFlowStore = new Ext.data.GroupingStore({
			proxy:new Ext.data.HttpProxy({
				url:this.baseUrl + '&task=getBindFieldList'
			}),
			reader:new Ext.data.JsonReader({
				totalProperty:"total",
				root:"data",
				fields:fields
			}),
			listeners:{
				load:function(th, record, opt){}
			}
		});
		
		var flowFieldStore = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({
				url:this.baseUrl + "&task=getFlowFieldList",
				method:'POST'
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields:[{
					name:'id'
				}, {
					name:'name'
				}]
			}),
			listeners:{
				load:function(th, record, opt){
					bingFlowStore.load({params:{from:_this.from, id: id}});
					//if(record.length == 0){
					//	_this.setBindFlow();
					//}
				}
			}
		});
		
		flowFieldStore.load({params:{from:_this.from, id: id}});
		
		var editor = new Ext.ux.grid.RowEditor({
			cancelText: lang('cancel'),
			saveText: lang('update'),
			errorSummary: false
		});
		
		var sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:true
		});
		
		var sortCombo = new Ext.form.ComboBox({
			width:150,
			autoLoad:true,
			triggerAction:'all',
			selectOnFocus:true,
			editable:false,
			store: flowFieldStore,
			valueField:'id',
			displayField:'name',
			mode:'local',
			forceSelection:true
		});
		
		var cm = [new Ext.grid.RowNumberer(),
			{header:'', hidden:true, dataIndex:'field'},
			{header:"输入框",sortable:true,dataIndex:'name',width:200,menuDisabled:true},
			{header:"流程控件",sortable:true,dataIndex:'kongjian',width:200,menuDisabled:true,
				editor: sortCombo,
	            renderer: function(v){
	                var recor;
	                flowFieldStore.each(function(r){
	                    if(r.get('id')==v){
	                        recor=r;
	                        return;
	                    };
	                });
	                return recor==null?"":recor.get("name");
	            }}
		];
		
		var grid = new Ext.grid.GridPanel({
			store:bingFlowStore,
			plain:false,
       		stripeRows:true,
			loadMask:{msg:lang('waiting')},
			region:"center",
			layout:'fit',
			border:false,
			autoScroll:true,
			columns:cm,
			plugins:editor,
			view:new Ext.grid.GroupingView({
				markDirty: false
			})
		});
		
		var win = new Ext.Window({
			title:'绑定流程控件',
			width: 700,
			height: 550,
			resizable: false,
			modal: true,
			layout: 'fit',
			items:grid,
			buttons:[
				{
					text:lang('save'),
					handler:function(btn){
						var data = [];
						Ext.each(bingFlowStore.data.items,function(v, i){
							data.push(v.data);
						});

						Ext.Ajax.request({
							url: _this.baseUrl + "&task=submitBindFlowField",
							method: 'POST',
							params:{data:Ext.encode(data),from:_this.from},
							success: function(r){
								var result = Ext.decode(r.responseText);
								if(result.success === true){
									CNOA.msg.alert(result.msg,function(){
										win.close();
									});
								}else{
									CNOA.msg.alert(result.msg, function(){});
								}
							}
						});
					}
				},
				{
					text:lang('close'),
					handler:function(){
						win.close();
					}
				}
			]
		}).show();
	}
};



CNOA_odoc_setting_flowClass = CNOA.Class.create();
CNOA_odoc_setting_flowClass.prototype = {
	init : function(){
		var _this = this;
		this.from = '';
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_HURRY		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=setting&action=flow";
		
		this.mainPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			region: 'center',
			layout: 'fit',
			items: [
				new CNOA_odoc_setting_setAddWinClass('send')
			],
			tbar:[
				{
		            xtype: 'buttongroup',
		            title: '界面设置',
		            columns: 2,
		            defaults: {
		                scale: 'small',
		                allowDepress: false,
		                toggleGroup: 'odocSettings',
		                iconCls: 'icon-setting',
		                enableToggle: true
		            },
		            items: [
						{
							handler : function(button, event) {
								_this.getSetAddWin('send');
							}.createDelegate(this),
							pressed: true,
							text : "发文"
						},
						{
							handler : function(button, event) {
								_this.getSetAddWin('receive');
							}.createDelegate(this),
							text : "收文"
						}
					]
				},
				{
		            xtype: 'buttongroup',
		            title: '列表设置',
		            columns: 2,
		            defaults: {
		                scale: 'small',
		                allowDepress: false,
		                toggleGroup: 'odocSettings',
		                iconCls: 'icon-setting',
		                enableToggle: true
		            },
					items:[
						{
							handler:function(btn,event){
								_this.getSetWinList('send');
							},
							text:"发文"
						},
						{
							handler:function(btn,event){
								_this.getSetWinList('receive');
							},
							text:"收文"
						}
					]
				},
				{
		            xtype: 'buttongroup',
		            title: '绑定工作流',
		            columns: 3,
		            defaults: {
		                scale: 'small',
		                allowDepress: false,
		                toggleGroup: 'odocSettings',
		                iconCls: 'icon-setting',
		                enableToggle: true
		            },
					items:[
						{
							handler:function(btn,event){
								_this.getSetBindFlow('send');
							},
							text : "发文"
						},
						{
							handler:function(btn,event){
								_this.getSetBindFlow('receive')
							},
							text : "收文"
						},
						{
							handler:function(btn,event){
								CNOA.msg.alert("借阅流程需绑定一个字符型的单选框，来确定是否同意借阅，该控件包含[同意][不同意]", function(){
									_this.getSetBindFlow('borrow');
								})
							},
							text : "借阅"
						}
					]
				},
				"<span class='cnoa_color_red'>创建流程后，如没启用则无法显示</span>"
			]
		});
	},
	
	clearItems : function(){
		try{
			Ext.destroy(this.mainPanel.items.items);
		}catch(e){}
	},
	
	getSetAddWin :function(from){
		this.clearItems();
		this.mainPanel.add(new CNOA_odoc_setting_setAddWinClass(from));
		this.mainPanel.doLayout();
	},
	
	getSetWinList :function(from){
		this.clearItems();
		this.mainPanel.add(new CNOA_odoc_setting_setWinListClass(from));
		this.mainPanel.doLayout();
	},
	
	getSetBindFlow :function(from){
		CNOA_odoc_setting_setBindFlow = new CNOA_odoc_setting_setBindFlowClass(from);
		this.clearItems();
		this.mainPanel.add(CNOA_odoc_setting_setBindFlow.mainPanel);
		this.mainPanel.doLayout();
	}
};



var sm_odoc_odoc=1;