var CNOA_odoc_viewFiles, CNOA_odoc_viewFilesClass;


CNOA_odoc_viewFilesClass = CNOA.Class.create();
CNOA_odoc_viewFilesClass.prototype = {
	init : function(id, baseUrl){
		var _this = this;

		this.id				= id;
		this.baseUrl		= baseUrl;
		//this.func			= CNOA.odoc.func;
		//this.action		= CNOA.odoc.action;
		//this.fromType		= CNOA.odoc.fromType;
		this.ID_attachCt	= Ext.id();
		this.ID_printArea	= Ext.id();
		this.ID_baseInfo	= Ext.id();

		var _this = this;
		
		var ID_fieldSet_Base = Ext.id();
		var ID_fieldSet_Word = Ext.id();
		var ID_fieldSet_Attach = Ext.id();
		var ID_fieldSet_Form = Ext.id();
		
		this.mainPanel = new Ext.Window({
			title:'查看档案内容',
			width:800,
			height:makeWindowHeight(Ext.getBody().getBox().height-40),
			modal:true,
			bodyStyle: 'background-color:#FFF;padding:10px;',
			autoScroll: true,
			maximizable: true,
			border:false,
			items: [
				{
					xtype: 'fieldset',
					title: '档案信息',
					hidden: true,
					id: ID_fieldSet_Base
				},
				{
					xtype: 'fieldset',
					title: '公文表单',
					hidden: true,
					id: ID_fieldSet_Form
				},
				{
					xtype: 'fieldset',
					title: '公文正文',
					hidden: true,
					id: ID_fieldSet_Word
				},
				{
					xtype: 'fieldset',
					title: '附件',
					hidden: true,
					id: ID_fieldSet_Attach
				}
			],
			listeners: {
				afterrender : function(){
					_this.loadInfo();
				}
			},
			buttons:[
				{
					text:lang('close'),
					handler:function(btn){
						_this.mainPanel.close();
					}
				}
			]
		}).show();
	},

	loadInfo : function(){
		var _this = this;

		Ext.Ajax.request({
			url: _this.baseUrl + "&task=loadFilesInfo",
			method: 'POST',
			params:{id: this.id},
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					if(result.data.word){
						//Ext.getCmp(ID_fieldSet_Word).show();
						//Ext.getCmp(ID_fieldSet_Word).body.update(result.data.word);
					}
					if(result.data.attach){
						//Ext.getCmp(ID_fieldSet_Attach).show();
						//Ext.getCmp(ID_fieldSet_Attach).body.update(result.data.attach);
					}
					if(result.data.form){
						//Ext.getCmp(ID_fieldSet_Form).show();
						//Ext.getCmp(ID_fieldSet_Form).body.update(result.data.form);
					}
				}else{
					//CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	}
};
