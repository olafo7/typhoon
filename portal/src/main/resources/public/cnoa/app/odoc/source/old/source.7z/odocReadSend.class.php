<?php 
class odocReadSend extends model{
	private $t_read_file	= "odoc_read_file";
	
	private $rows			= 15;
	
	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getTypeList" :
				app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "settingWord")->api_getLevelList();
				break;
			case "getHurryList" :
				app::loadApp("odoc", "settingWord")->api_getHurryList();
				break;
			#查看发文
			case 'view':
				$this->_viewDoc();
				break;
		}
	}
	 
	
	private function _viewDoc(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$cuid	= $CNOA_SESSION->get('UID');
		
		$id		= getPar($_GET, 'id');
		if(empty($id)){
			$id	= getPar($_POST, 'fid');
		}
		if(empty($id)){
			$id	= $GLOBALS['id'];
		}
		
		
		$_POST['id']	= $id;
		
		$where	= "WHERE 1";
		$where	.= " AND `receiveuid`={$cuid} AND `type`=1 AND `fileid`={$id}";
		
		//debug::xprint($_GET); debug::xprint($_POST); debug::xprint($GLOBALS['id']);
		
		//debug::xprint($_GET); debug::xprint($_POST); debug::xprint($where); //return ;
		
		
		//如果没有阅读过
		$readed = $CNOA_DB->db_getfield('readed', $this->t_read_file, $where);
		if(intval($readed) == 0){
			//记录谁已阅读过
			$data = array();
			$data['readed']		= 1;
			$data['readtime']	= $GLOBALS['CNOA_TIMESTAMP'];
			$CNOA_DB->db_update($data, $this->t_read_file, $where);
		}
		
		
		
		$_POST['func']	= 'read';
		app::loadApp("odoc", "commonView")->run("send");
	}
	
	private function _loadpage(){
		
	}
	
	private function _getJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		$start = getPar($_POST, "start", 0);
		$uid = $CNOA_SESSION->get("UID");
		$WHERE = "WHERE 1 ";
		$storeType = getPar($_POST, "storeType", "waiting");
		
		//是否已经查看过
		if($storeType == "waiting"){
			$WHERE .= " AND `readed` = '0' ";
		}elseif($storeType == "readed"){
			$WHERE .= " AND `readed` = '1' ";
		}
		
		$dblist = $CNOA_DB->db_select(array("fileid", "id", "type"), $this->t_read_file, $WHERE . " AND `receiveuid` = '{$uid}' AND `type`='1' ORDER BY `id` DESC LIMIT {$start}, {$this->rows} ");
		!is_array($dblist) && $dblist = array();
		
		$fileArr = array();
		foreach ($dblist as $k=>$v) {
			$fileArr[] = $v['fileid'];
		}
		if(count($fileArr) > 0){
			$fileData = app::loadApp("odoc", "sendApply")->api_getData($fileArr);
			
		 	$typeData = app::loadApp("odoc", "settingWord")->api_getTypeAllArr();
		 	$levelData = app::loadApp("odoc", "settingWord")->api_getLevelAllArr();
		 	$hurryData = app::loadApp("odoc", "settingWord")->api_getHurryAllArr();
		}
	 	
	 	
	 	foreach ($dblist as $k=>$v) {
	 		
	 		$fid	= $v['fileid'];
	 		$type	= $v['type'];
	 			 		
	 		$dblist[$k]['rftype']	= $type;
	 		$dblist[$k]['title']	= $fileData[$v['fileid']]['title'];
	 		$dblist[$k]['number']	= $fileData[$v['fileid']]['number'];
	 		$dblist[$k]['fromdept']	= $fileData[$v['fileid']]['fromdept'];
	 		$dblist[$k]['type']		= $typeData[$fileData[$v['fileid']]['type']]['title'];
	 		$dblist[$k]['level']	= $levelData[$fileData[$v['fileid']]['level']]['title'];
	 		$dblist[$k]['hurry']	= $hurryData[$fileData[$v['fileid']]['hurry']]['title'];
	 	}
	 	
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	
	
	
	
	
	
	/**
	 * 添加发文阅读
	 * Enter description here ...
	 * @param unknown_type $data
	 */
	public function api_addRead($data){
		global $CNOA_DB, $CNOA_SESSION;
		
		//debug::xprint($data);
		return $CNOA_DB->db_insert($data, $this->t_read_file);
	}
	
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $where
	 */
	public function api_getList($where){
		global $CNOA_DB;
		return $CNOA_DB->db_select('*', $this->t_read_file, $where);
	}
}
?>