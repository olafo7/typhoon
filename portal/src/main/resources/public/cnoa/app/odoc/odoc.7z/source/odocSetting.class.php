<?php 
class odocSetting extends model{								
	/**
	 * ���캯��
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * ��������
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function actionWord(){
		app::loadApp("odoc", "settingWord")->run();
	}
	
	public function actionTemplate(){
		app::loadApp("odoc", "settingTemplate")->run();
	}
	
	public function actionReceive(){
		app::loadApp("odoc", "settingReceive")->run();
	}
	
	public function actionReceivetemplate(){
		app::loadApp("odoc", "settingReceivetemplate")->run();
	}
	
	public function actionPermit(){
		app::loadApp("odoc", "settingPermit")->run();
	}
	
	public function actionFlow(){
		app::loadApp("odoc", "settingFlow")->run();
	}
}
?>