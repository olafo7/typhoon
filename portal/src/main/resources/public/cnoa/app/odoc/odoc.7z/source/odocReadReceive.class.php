<?php 
class odocReadReceive extends model{
	private $t_odoc_view_fieldset="odoc_view_fieldset";
	private $t_odoc_view_field	="odoc_view_field";
	private $t_odoc_data		="odoc_data";
	private $t_odoc_view_field_list ="odoc_view_field_list";
	private $t_odoc_bind_flow_kj	= "odoc_bind_flow_kj";
	private $t_odoc_fenfa		= "odoc_fenfa";
	
	private $t_s_flow_other_app_data= 'wf_s_flow_other_app_data';
	
	private $rows			= 15;
									
	/**
	 * 构造函数
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * 析构函数
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadPage();
				break;
			case "loadLayout":
				$this->_loadLayout();
				break;
			case "getJsonList":
				$this->_getJsonList();
				break;
			case 'loadColumn':
				$this->_loadColumn();
				break;
			case 'loadAttachList':
				$this->_loadAttachList();
				break;
		}
	}
	
	private function _loadPage(){
		global $CNOA_SESSION, $CNOA_CONTROLLER, $CNOA_DB;
		$from = getPar($_GET, "from", "");
	
		switch($from){
			case 'viewflow'	:
				//查看流程
				$GLOBALS['app']['uFlowId'] 			= getPar($_GET, "uFlowId", 0);
				$GLOBALS['app']['step']				= getPar($_GET, "step", 0);
				
				$uid = $CNOA_SESSION->get("UID");
				$CNOA_DB->db_update(array('isread'=>1, 'uid'=>$uid, 'viewtime'=>$GLOBALS['CNOA_TIMESTAMP']), "wf_u_fenfa", "WHERE `touid` = {$uid} AND `uFlowId` = {$GLOBALS['app']['uFlowId']} ");
				
				$GLOBALS['app']['wf']['type']		= "done";//已办流程， 用于查看页面显示召回和撤销按钮
				$DB									= $CNOA_DB->db_getone(array("status", "flowId"), "wf_u_flow", "WHERE `uFlowId`='{$GLOBALS['app']['uFlowId']}'");
				$GLOBALS['app']['flowId']			= $DB['flowId'];
				$flow								= $CNOA_DB->db_getone(array("tplSort", "flowType"), "wf_s_flow", "WHERE `flowId` = {$DB['flowId']} ");
				$GLOBALS['app']['wf']['allowCallback']	= 0;
				$GLOBALS['app']['wf']['allowCancel']	= 0;
				$GLOBALS['app']['allowPrint']			='false';
				$GLOBALS['app']['allowFenfa']			='false';
				$GLOBALS['app']['allowExport']			='false';
				$GLOBALS['app']['status']				= 1;
				$GLOBALS['app']['wf']['tplSort']		= $flow["tplSort"];
				$GLOBALS['app']['wf']['flowType']		= $flow["flowType"];
				$GLOBALS['app']['wf']['owner']			= 0;//getpar($_GET, "owner", 0);
				$tplPath = CNOA_PATH . '/app/wf/tpl/default/flow/use/showflow.htm';
				$CNOA_CONTROLLER->loadExtraTpl($tplPath);exit;
		}
	}
	
	private function _loadLayout(){
		global $CNOA_DB, $CNOA_SESSION;
	
		$dbFieldSetDB	= $CNOA_DB->db_select("*", $this->t_odoc_view_fieldset, "WHERE `from` = 'receive' ");
		$dbFieldDB		= $CNOA_DB->db_select("*", $this->t_odoc_view_field, "WHERE `from` = 'receive' ");
	
		!is_array($dbFieldSetDB) && $dbFieldSetDB = array();
	
		!is_array($dbFieldDB) && $dbFieldDB = array();
		$dbFieldArr = array();
		$temp = array();
		foreach ($dbFieldDB as $k=>$v){
			if($v['field']%2 == 0){
				$temp['secname'] = $v['name'];
				$temp['secfield']= $v['field'];
				$dbFieldArr[] = $temp;
				$temp = array();
			}else{
				$temp['fstname'] = $v['name'];
				$temp['type']	 = $v['type'];
				$temp['fstfield']= $v['field'];
				$temp['fieldset']= $v['fieldset'];
			}
		}
	
		$result = array(
			'success'=>true,
			'fieldset'=>$dbFieldSetDB,
			'field'=>$dbFieldArr
		);
	
		echo json_encode($result);exit();
	}
	
	/**
	 * 获取数据
	 * @author 高超
	 * @date 2012-12-25
	 */
	private function _getJsonList(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid = $CNOA_SESSION->get('UID');
	
		$WHERE = "WHERE `from` = 'receive' ";
		
		$start = getPar($_POST, 'start', 0);
		$dblist = $CNOA_DB->db_select("*", $this->t_odoc_fenfa, $WHERE."AND `uid` = {$uid} LIMIT {$start}, {$this->rows} ");
		!is_array($dblist) && $dblist = array();
		$idArr = array(0);$date = array();
		foreach ($dblist as $k=>$v){
			$idArr[] = $v['id'];
			$date[$v['id']] = date("Y-m-d H:i", $v['posttime']);
		}
		$dblist = $CNOA_DB->db_select("*", $this->t_odoc_data, "WHERE `id` IN (".implode(',', $idArr).")  ORDER BY `id` DESC");
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v){
			$dblist[$k]['posttime'] = $date[$v['id']];
		}
		
		$ds = new dataStore();
		$ds->data = $dblist;
		echo $ds->makeJsonData();exit();
	}
	
	private function _loadColumn(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select("*", $this->t_odoc_view_field_list, "WHERE `from` = 'receive' ");
		!is_array($dblist) && $dblist = array();
		$field = array();
		foreach ($dblist as $k=>$v){
			$field[] = 'field_'.$v['field'];
		}
	
		$result = array(
				'success'=>true,
				'field'=>$field,
				'column'=>$dblist
		);
		echo json_encode($result);exit();
	}
	
	private function _loadAttachList(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$id = getPar($_POST, "id", '0');
		$uid = $CNOA_SESSION->get("UID");
		
		$list = array();
		
		//获取分类权限数据
		$fenfaInfo = $CNOA_DB->db_getone("*", $this->t_odoc_fenfa, "WHERE `id`='{$id}' AND `uid`='{$uid}'");

		$odocInfo = $CNOA_DB->db_getone("*", $this->t_odoc_data, "WHERE `id`='{$id}'");
		$uFlowId = $odocInfo['uFlowId'];
		$attachList = json_decode($odocInfo['attach'], true);
		!is_array($attachList) && $attachList=array();
		
		$fs = new fs();
		if($fenfaInfo['viewWord'] == 1){
			$attachid = intval($attachList[0]);
			if($attachid == 0){
				$list['word'] = "无文件可以查看";
			}else{
				$wordInfo = $fs->getDownLoadItems4normal(array($attachList[0]), true);
				if(ereg("\[正文\]", $wordInfo)){
					$list['word'] = $wordInfo;
				}else{
					$list['word'] = "无文件可以查看";
				}
			}
		}
		
		if($fenfaInfo['viewAttach'] == 1){
			if($fenfaInfo['viewWord'] == 1){
				array_shift($attachList);
			}
			
			if(is_array($attachList)){
				if(count($attachList)>0){
					$list['attach'] = $fs->getDownLoadItems4normal($attachList, true);
				}else{
					$list['attach'] = "无文件可以查看";
				}
			}else{
				$list['attach'] = "无文件可以查看";
			}
		}
		
		if($fenfaInfo['viewForm'] == 1){
			$targetPath = CNOA_PATH_FILE . '/common/odoc/sendForm/'.($uFlowId%300).'/'.$uFlowId.".php";
			$list['form'] = @file_get_contents($targetPath);
		}
		
		$dataStore  = new dataStore();
		$dataStore->data = $list;
			
		echo $dataStore->makeJsonData();
		exit;
	}
}
?>