<?php 
class odocRead extends model{								
	/**
	 * ���캯��
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * ��������
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function actionFile(){
		app::loadApp("odoc", "readFile")->run();
	}
	
	public function actionReceive(){
		app::loadApp("odoc", "readReceive")->run();
	}

	public function actionSend(){
		app::loadApp("odoc", "readSend")->run();
	}
	
	public function actionMeeting(){
		app::loadApp("odoc", "readMeeting")->run();
	}
}
?>