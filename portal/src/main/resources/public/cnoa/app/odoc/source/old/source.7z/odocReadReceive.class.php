<?php 
class odocReadReceive extends model{
	private $t_read_file	= "odoc_read_file";
	
	private $rows			= 15;
	
	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getTypeList" :
				app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "settingWord")->api_getLevelList();
				break;
			case "getHurryList" :
				app::loadApp("odoc", "settingWord")->api_getHurryList();
				break;
			#查看发文
			case 'view':
				global $CNOA_DB;
				$_POST['func']	= 'read';
				$rid = getPar($_GET, "rid", 0);
				$CNOA_DB->db_update(array("readtime"=>$GLOBALS['CNOA_TIMESTAMP'], "readed"=>1), $this->t_read_file, "WHERE `id` = '{$rid}' ");
				app::loadApp("odoc", "commonView")->run("receive");
				break;
		}
	}
	
	private function _loadpage(){
		
	}
	
	private function _getJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		$start = getPar($_POST, "start", 0);
		$uid = $CNOA_SESSION->get("UID");
		$WHERE = "WHERE 1 ";
		$storeType = getPar($_POST, "storeType", "waiting");
		if($storeType == "waiting"){
			$WHERE .= "AND `readed` = '0' ";
		}elseif($storeType == "readed"){
			$WHERE .= "AND `readed` = '1' ";
		}
		$dblist = $CNOA_DB->db_select(array("fileid", "id"), $this->t_read_file, $WHERE . "AND `receiveuid` = '{$uid}' AND `type` = '2' ORDER BY `id` DESC LIMIT {$start}, {$this->rows} ");
		!is_array($dblist) && $dblist = array();
		$fileArr = array(0);
		foreach ($dblist as $k=>$v) {
			$fileArr[] = $v['fileid'];
		}
	 	$fileData = app::loadApp("odoc", "receiveList")->api_getReceiveData($fileArr);
		
	 	$typeData = app::loadApp("odoc", "settingWord")->api_getTypeAllArr();
	 	$levelData = app::loadApp("odoc", "settingWord")->api_getLevelAllArr();
	 	$hurryData = app::loadApp("odoc", "settingWord")->api_getHurryAllArr();
	 	
	 	foreach ($dblist as $k=>$v) {
	 		$dblist[$k]['title']	= $fileData[$v['fileid']]['title'];
	 		$dblist[$k]['number']	= $fileData[$v['fileid']]['number'];
	 		$dblist[$k]['fromdept']	= $fileData[$v['fileid']]['fromdept'];
	 		$dblist[$k]['type']		= $typeData[$fileData[$v['fileid']]['type']]['title'];
	 		$dblist[$k]['level']	= $levelData[$fileData[$v['fileid']]['level']]['title'];
	 		$dblist[$k]['hurry']	= $hurryData[$fileData[$v['fileid']]['hurry']]['title'];
	 	}
	 	
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
}
?>