<?php
class odocSend extends model{								
	/**
	 * ���캯��
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * ��������
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function actionApply(){
		app::loadApp("odoc", "sendApply")->run();
	}
	
	public function actionPass(){
		app::loadApp("odoc", "sendPass")->run();
	}
	
	public function actionCheck(){
		app::loadApp("odoc", "sendCheck")->run();
	}
	
	public function actionSign(){
		app::loadApp("odoc", "sendSign")->run();
	}
	
	public function actionList(){
		app::loadApp("odoc", "sendList")->run();
	}
}
?>