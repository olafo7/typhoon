<?php 
class odocFilesDananmgr extends model{
	private $t_files_dangan	= "odoc_files_dangan";
	private $t_read_file	= "odoc_read_file";
	private $t_dangan_room	= "odoc_files_dangan_room";
	private $t_anjuan_list	= "odoc_files_anjuan_list";
	
	private $f_from			= array(0=>"其他", 1=>"发文", 2=>"收文");
	
	private $rows			= 15;
	
	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getTypeList" :
					app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "settingWord")->api_getLevelList();
				break;
			case "getAllUserListsInPermitDeptTree" :
				$GLOBALS['user']['permitArea']['area'] = "all";
				$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
				echo json_encode($userList);
				exit;
			case "sendFile" :
				$this->_sendFile();
				break;
			case "loadFormData" :
				$this->_loadFormData();
				break;
			case "roomList" :
				$this->_roomList();
				break;
			case "anjuanList" :
				$this->_anjuanList();
				break;
			#查看
			case 'view':
				app::loadApp("odoc", "commonFilesView")->run();
				break;
		}
	}
	
	private function _loadpage(){
		
	}
	
	private function _getJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid = $CNOA_SESSION->get("UID");
		$start = getPar($_POST, "start", 0);
		$WHERE = "WHERE 1 ";
		$storeType = getPar($_POST, "storeType", "all");
		
		$s_title	= getPar($_POST, "title", "");
		$s_number	= getPar($_POST, "number", "");
		$s_sort		= getPar($_POST, "sort", 0);
		$s_type		= getPar($_POST, "type", 0);
		$s_level	= getPar($_POST, "level", 0);
		$s_stime	= getPar($_POST, "stime", 0);
		$s_etime	= getPar($_POST, "etime", 0);
		if(!empty($s_title)){
			$WHERE .= "AND `title` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_number)){
			$WHERE .= "AND `number` LIKE '%{$s_number}%' ";
		}
		if(!empty($s_sort)){
			$WHERE .= "AND `from` = '{$s_sort}' ";
		}
		if(!empty($s_type)){
			$WHERE .= "AND `danganshi` = '{$s_type}' ";
		}
		if(!empty($s_level)){
			$WHERE .= "AND `anjuan` = '{$s_level}' ";
		}
		if(!empty($s_stime)){
			$s_stime = strtotime($s_stime);
			$WHERE .= "AND `collectdate` > '{$s_stime}' ";
		}
		if(!empty($s_etime)){
			$s_etime = strtotime($s_etime);
			$WHERE .= "AND `collectdate` < '{$s_etime}' ";
		}
		
		if($storeType == "all") {
			$dblist = $CNOA_DB->db_select("*", $this->t_files_dangan, $WHERE . "ORDER BY `id` DESC LIMIT {$start}, {$this->rows}");
		}elseif ($storeType == "history") {
			$this->__getJsonDataHistory();
		}
		!is_array($dblist) && $dblist = array();
		$typeArr	= app::loadApp("odoc", "settingWord")->api_getTypeAllArr();
		$levelArr	= app::loadApp("odoc", "settingWord")->api_getLevelAllArr();
		$roomArr	= app::loadApp("odoc", "filesSetting")->api_getRoomData();
		$anjuanArr	= app::loadApp("odoc", "filesAnjuanmgr")->api_anjuanArr();
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['from'] = $this->f_from[$v['from']];
			$dblist[$k]['type']	= $typeArr[$v['type']]['title'];
			$dblist[$k]['level']= $levelArr[$v['level']]['title'];
			$dblist[$k]['danganshi'] = $roomArr[$v['danganshi']]['title'];
			$dblist[$k]['anjuan']	= $anjuanArr[$v['anjuan']]['title'];
			$dblist[$k]['senddate'] = formatDate($v['senddate']);
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		$dataStore->total = $CNOA_DB->db_getcount($this->t_files_dangan, $WHERE);
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function __getJsonDataHistory(){
		global $CNOA_DB, $CNOA_SESSION;
		$WHERE = "WHERE 1 ";
		$start = getPar($_POST, "start", 0);
		$uid = $CNOA_SESSION->get("UID");
		$dblist = $CNOA_DB->db_select("*", $this->t_read_file, $WHERE . "AND `type` = '3' AND `senduid` = '{$uid}' GROUP BY `fileid` LIMIT {$start}, {$this->rows}");
		!is_array($dblist) && $dblist = array();
		$idArr = array(0);
		foreach ($dblist as $k=>$v) {
			$idArr[] = $v['fileid'];
		}
		$roomArr		= app::loadApp("odoc", "filesSetting")->api_getRoomData();
		$typeArr		= app::loadApp("odoc", "filesSetting")->api_getTypeData();
		$wenzhongArr	= app::loadApp("odoc", "filesSetting")->api_getWenzhongData();
		$anjuanArr		= app::loadApp("odoc", "filesAnjuanmgr")->api_anjuanArr();
		$levelArr		= app::loadApp("odoc", "settingWord")->api_getLevelAllArr();
		$danganArr		= app::loadApp("odoc", "filesDananmgr")->api_getAllDanganArr($idArr);
		
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['title'] = $danganArr[$v['fileid']]['title'];
			$dblist[$k]['number']= $danganArr[$v['fileid']]['number'];
			$dblist[$k]['from'] = $this->f_from[$danganArr[$v['fileid']]['from']];
			$dblist[$k]['type']	= $typeArr[$danganArr[$v['fileid']]['type']]['title'];
			$dblist[$k]['level']= $levelArr[$danganArr[$v['fileid']]['level']]['title'];
			$dblist[$k]['danganshi'] = $roomArr[$danganArr[$v['fileid']]['danganshi']]['title'];
			$dblist[$k]['anjuan']	= $anjuanArr[$danganArr[$v['fileid']]['anjuan']]['title'];
			$dblist[$k]['senddate'] = formatDate($danganArr[$v['fileid']]['senddate']);
		}
		
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		$dataStore->total = $CNOA_DB->db_getcount($this->t_read_file, $WHERE . "AND `senduid` = '{$uid}' GROUP BY `fileid` ");
		echo $dataStore->makeJsonData();
		exit();
	}
	
	/**
	 * 档案管理的“分发”
	 * Enter description here ...
	 */
	private function _sendFile(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid	= $CNOA_SESSION->get("UID");
		$ids	= getPar($_POST, "ids", 0);
		$ids	= substr($ids, 0, -1);
		$idArr	= explode(",", $ids);
		$uids	= getPar($_POST, "splituid", 0);
		$uidArr	= explode(",", $uids);
		$stime	= strtotime(getPar($_POST, "stime", "") . " 00:00");
		$etime	= getPar($_POST, "etime", "");
		if(!empty($etime)){
			$etime	= strtotime(getPar($_POST, "etime", "") . " 23:59");
		}
		$data['stime'] = $stime;
		$data['etime'] = $etime;
		$data['senduid'] = $uid;
		$data['sendtime']= $GLOBALS['CNOA_TIMESTAMP'];
		$data['type']	= 3;
		foreach ($idArr as $v1) {
			$data['fileid'] = $v1;
			foreach ($uidArr as $v2) {
				$data['receiveuid'] = $v2;
				$CNOA_DB->db_insert($data, $this->t_read_file);
				
				//提醒
				$touid		= $v2;
				$uname		= app::loadApp('main', 'user')->api_getUserTruenameByUid($uid);;
				$noticeT	= "公文管理";
				$noticeC	= "{$uname}分发档案给您,您可以到“档案阅读”查看或阅读." ;
				$noticeH	= "index.php?app=odoc&func=read&action=file";
				$alarmid	= notice::add($touid, $noticeT, $noticeC, $noticeH, 0, 17, $uid);
			}
		}
		msg::callBack(true, "操作成功");
	}
	
	private function _loadFormData(){
		global $CNOA_DB;
		$id = getPar($_POST, "id", 0);
		$dblist = $CNOA_DB->db_select("*", $this->t_read_file, "WHERE `fileid` = '{$id}' ");
		!is_array($dblist) && $dblist = array();
		$uidArr = array(0);
		foreach ($dblist as $k=>$v) {
			$uidArr[] = $v['receiveuid'];
		}
		$truenameArr = app::loadApp("main", "user")->api_getUserNamesByUids($uidArr);
		$data = array();
		$data['stime'] = formatDate($dblist[0]['stime']);
		$data['etime'] = formatDate($dblist[0]['etime']);
		foreach ($dblist as $k=>$v) {
			$data['splituid']	.= $v['receiveuid'] . ",";
			$data['split']		.= $truenameArr[$v['receiveuid']]['truename'] . ", ";
		}
		$dataStore = new dataStore();
		$dataStore->data = $data;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _roomList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select("*", $this->t_dangan_room);
		!is_array($dblist) && $dblist = array();
		$ds = new dataStore();
		$ds->data = $dblist;
		echo $ds->makeJsonData();
		exit();
	}
	
	private function _anjuanList(){
		global $CNOA_DB;
		$id = getPar($_POST, "id", 0);
		$dblist = $CNOA_DB->db_select("*", $this->t_anjuan_list, "WHERE `danganshi` = '{$id}'");
		!is_array($dblist) && $dblist = array();
		$ds = new dataStore();
		$ds->data = $dblist;
		echo $ds->makeJsonData();
		exit();
	}
	
	public function api_getAllDanganJsonData($idArr){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select("*",$this->t_files_dangan, "WHERE `id` IN (" . implode(",", $idArr) . ")");
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['from']		= $this->f_from[$v['from']];
			$dblist[$k]['senddate']	= formatDate($v['senddate']);
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_getAllDanganArr($idArr){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select("*", $this->t_files_dangan, "WHERE `id` IN (" . implode(",", $idArr) . ")");
		!is_array($dblist) && $dblist = array();
		$data = array();
		foreach ($dblist as $k=>$v) {
			$data[$v['id']] = $v;
		}
		return $data;
	}
}
?>