<?php 
class odocSendCheck extends model{
	private $t_send_list	= "odoc_send_list";
	private $t_tpl_list		= "odoc_setting_template_list";
	private $t_setting_word_level		= "odoc_setting_word_level";//"odoc_setting_send_level"; 
	private $t_setting_word_hurry		= "odoc_setting_word_hurry";
	private $t_flow			= "odoc_setting_flow";
	private $t_flow_step	= "odoc_setting_flow_step";
	private $t_step			= "odoc_step";
	private $t_step_temp	= "odoc_step_temp";
	
	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getTemplateList" :
				$typeId = getPar($_POST, "id", 0);
				app::loadApp("odoc", "settingTemplate")->api_getTemplateList($typeId, 2);
				break;
			case "getTypeList" :
				app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "settingWord")->api_getLevelList();
				break;
			case "getHurryList" :
				app::loadApp("odoc", "settingWord")->api_getHurryList();
				break;
			case "loadFormData" :
				$this->_loadFormData();
				break;
				break;
			case "submitFormData" :
				$this->_submitFormData();
				break;
			case "submitFileData" :
				$this->_submitFileData();
				break;
			#获取拟稿页面的JS文件
			case "getOdocFawenForm" :
				$this->_getOdocFawenForm();
				break;
			#获取红头文件供前端显示&编辑
			case "loadTemplateFile" :
				$this->_loadTemplateFile();
				break;
			case "getAllUserListsInPermitDeptTree" :
				$GLOBALS['user']['permitArea']['area'] = "all";
				$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
				echo json_encode($userList);
				exit;
				break;
				
			case "editOdocTemplate" :
				global $CNOA_DB, $CNOA_CONTROLLER, $CNOA_SESSION;
				$id = getPar($_GET, "id", "");
				//debug::xprint($_GET);
				$GLOBALS['id']				= $id;
				$GLOBALS['CNOA_SYSTEM_NAME']= "发文审批";
				$GLOBALS['CNOA_USERNAME']	= $CNOA_SESSION->get("TRUENAME");
				$CNOA_CONTROLLER->loadViewCustom($CNOA_CONTROLLER->appPath . "/tpl/default/send/checkOdocTemplate.htm", true, true);
				exit;
			case "getStepList":
				$this->_getStepList();
				break;
			case "getAllUserListsInPermitDeptTree":
				$this->_getAllUserListsInPermitDeptTree();
				break;
			case 'getHuiQianInfo':
				$this->_getHuiQianInfo();
				break;
			case 'setHuiQianInfo':
				$this->_setHuiQianInfo();				
				break;
			case 'reStep':
				$this->_reStep();
				break;
			case 'saveSay':
				$this->_saveSay();
				break;
			case 'toPrevious':
				$this->_toPrevious();
				break;
			#查看发文
			case 'view':
				$_POST['func']	= 'send';
				app::loadApp("odoc", "commonView")->run("send");
				break;
		}
	}
	
	
	/**
	 * 退上一步
	 * Enter description here ...
	 */
	private function _toPrevious(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get('UID');
		$uname	= $CNOA_SESSION->get('TRUENAME');
		
		$fromId = getPar($_GET, 'fromId');
		$id		= getPar($_GET, 'id');
		$reason	= getPar($_POST, 'reason');
		//debug::xprint($_GET); debug::xprint($_POST); return ;
		
		//将id目标状态设置为“办理中”，结束时间为0，say为空
		$where	= "WHERE `id`={$id} AND `fromType`=1";
		$data	= array();
		$data['status'] = 1;
		$data['etime']	= 0;
		$data['say']	= '';
		$CNOA_DB->db_update($data, $this->t_step, $where);
		
		$info	= $CNOA_DB->db_getone('*', $this->t_step, "WHERE `fromId`={$fromId} AND `id`={$id}");
		$stepid	= $info['stepid'];
		$stepuid= $info['uid'];
		//$fromId
		
		//大于id的stepid，都设置为“未办理”，开始时间 为0，say为空
		$where	= "WHERE `fromId`={$fromId} AND `fromType`=1 AND `stepid`>{$stepid}";// AND `status`=1";
		$data = array();
		$data['status']	= 0;
		$data['say']	= '';
		$data['stime']	= 0;
		$data['etime']	= 0;
		$CNOA_DB->db_update($data, $this->t_step, $where);
		
		
		$sendInfo	= $CNOA_DB->db_getone('*', $this->t_send_list, "WHERE `id`={$fromId}");
		$send_title	= $sendInfo['title'];
		
		//给对方一个提醒		
		$this->__sendNotice($stepuid, $send_title, 1, 8, $reason);
		
		
		msg::callBack(true, "操作成功.");
	}
	
	
	private function _submitFileData(){
		return app::loadApp('odoc', 'sendApply')->api_submitFileData();
	}
	
	
	/**
	 *  保存审批结果和意见
	 * Enter description here ...
	 */
	private function _saveSay(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get('UID');
		$uname	= $CNOA_SESSION->get('TRUENAME');
		
		$fid	= getPar($_POST, 'id');
		$say	= getPar($_POST, 'say');
		
		$where = "WHERE `fromId`={$fid} AND `uid`={$uid} AND `fromType`=1 AND `status`=1";
		//debug::xprint($where); return ;
		
		//当前的步骤ID
		$stepInfo	= $CNOA_DB->db_getone('*', $this->t_step, $where);
		$stepid		= $stepInfo['stepid'];
		$step_id	= $stepInfo['id'];
		
		$sendInfo	= $CNOA_DB->db_getone('*', $this->t_send_list, "WHERE `id`={$stepInfo['fromId']}");
		$send_title	= $sendInfo['title'];
		
		//将状态改为：已办理，办理结束时间为当前
		$data = array();
		$data['status']	= 2;
		$data['etime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['say']	= $say;
		$CNOA_DB->db_update($data, $this->t_step, $where);
				
		///// 步骤ID+1的状态改为1，办理开始时间
		$where = "WHERE `fromId`={$fid} AND `fromType`=1 AND `stepid`=". intval($stepid + 1);
		$data = array();
		$data['stime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['status']	= 1;
		$CNOA_DB->db_update($data, $this->t_step, $where);
		
		
		//给个提醒、通知, 发送提醒 - 提醒所有步骤人
		//debug::xprint($stepInfo);
		/*
		$stepList = $CNOA_DB->db_select('*', $this->t_step, "WHERE `fromId`={$fid} AND `stepid`>1 AND `fromType`=1");
		!is_array($stepList) && $stepList = array();
		foreach ($stepList as $info){
			$suid = $info['uid'];
		}
		*/
		
		
		
		
		switch (intval($stepInfo['stepType'])){
			case 1:		//正常
				$info = $CNOA_DB->db_getone('*', $this->t_step, $where);
				if($info !== false){
					$this->__sendNotice(intval($info['uid']), $send_title, 1);
				}
				break;
			case 2:		//会签
				//通知成员来审批
				
				//获取该步骤的负责人UID，非会签人
				$where	= "WHERE `fromType`=1 AND `stepid`={$stepid} AND `fromId`={$fid} AND `stepType`=1";
				$info	= $CNOA_DB->db_getone('*', $this->t_step, $where);
				$touid	= $info['uid'];
								
				$noticeT	= "{$uname}已经会签完毕。他/她的意见是：";
				$noticeC	= $say ;
				$noticeH	= "index.php?app=odoc&func=send&action=check";
				$alarmid	= notice::add($touid, $noticeT, $noticeC, $noticeH, 0, 17, $uid);
				break;
		}
		
		
		
		
		$id = $step_id;		
		//修改快照文件名称
		$path = CNOA_PATH_FILE. '/common/odoc/send/'. $fid .'/';
		@rename($path . 'form.history.0.php', $path . 'form.history.'.$id.'.php');
		@rename($path . 'doc.history.0.php', $path . 'doc.history.'.$id.'.php');
		
		
		//检查该文稿的步骤是否已经走完，如果是，则
		//状态=2 && 添加一条信息到“收文登记”、“阅读-> 发文阅读”
		$isOver = $this->__isOver($fid);
		if($isOver){
			$where = "WHERE `id`={$fid}";
			//debug::xprint("over: " . $where);
			$data = array();
			$data['status']	= 2;
			$data['senddate']	= $GLOBALS['CNOA_TIMESTAMP'];
			$CNOA_DB->db_update($data, $this->t_send_list, $where);
			
			
			
			//全部审批结束，发个提醒给拟稿人
			$where	= "WHERE `fromId`={$fid} AND `stepid`=1 AND `fromType`=1 AND `stepType`=1 AND `status`=2";
			$info	= $CNOA_DB->db_getone('*', $this->t_step, $where);
			$uid	= $info['uid'];
			$this->__sendNotice($uid, $send_title, 1, 6);
		}
		
		
		msg::callBack(true, "操作成功.");	
	}
	
	
	/**
	 * 保存表单数据
	 * Enter description here ...
	 */
	private function _submitFormData(){
		
		global $CNOA_DB, $CNOA_SESSION;

		$id = getPar($_POST, "id", 0);
		
		$info = $CNOA_DB->db_getone("*", $this->t_send_list, "WHERE `id`='{$id}'");
		
		#保存进暂存字段
		$formdata = addslashes(json_encode($_POST));
		
		#处理表单数据
		$data = array();
		$data['formdata']	= $formdata;
		$data['createuid']	= $CNOA_SESSION->get("UID");
		$data['createtime']	= $GLOBALS['CNOA_TIMESTAMP'];
		
		foreach($_POST AS $k=>$v){
			$name = preg_replace("/id_[0-9]{1,}__(.*)/is", "\\1", $k);
			$in_array = array("number", "title", "sign", "createdept", "createname_send", "level", "hurry", "page", "many", "range", "regdate", "senddate");
			if(in_array($name, $in_array)){
				if($name == "createname_send"){
					$name = "createname";
				}
				$data[$name] = $v;
			}
		}
		/*
		$attach = $CNOA_DB->db_getfield("attach", $this->t_send_list, "WHERE `id` = '{$id}'");

		$fs = new fs();
		$filesUpload = getPar($_POST, "filesUpload", array());
		$attach = $fs->edit($filesUpload, json_decode($attach, false), 17);
		$data['attach'] = json_encode($attach);
		*/
		$CNOA_DB->db_update($data, $this->t_send_list, "WHERE `id`='{$id}'");
		
		#保存历史页面进缓存文件
		$formHtml = app::loadApp("odoc", "common")->getHtmlWithValue($info['form'], $_POST);
		app::loadApp("odoc", "common")->saveHistory($id, $formHtml, 0, "send");
		
		msg::callBack(true, "操作成功");
		exit();
		
	}
	
	
	
	
	/**
	 * 设置会签成员
	 */
	private function _setHuiQianInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$cuid	= $CNOA_SESSION->get('UID');
		$uname	= $CNOA_SESSION->get('TRUENAME');
		
		$unames	= getPar($_POST, 'allUserNames');
		$uids	= getPar($_POST, 'allUids');
		$fid	= getPar($_POST, 'fid');	
		
		
		$arrName	= explode(",", $unames);
		$arrUid		= explode(",", $uids);		
		//debug::xprint($_POST);exit;
		
		//
		//传递新的UIDS过来时，找出原步骤里的UID, 如果在UIDS里面找不到UID时，则删除UID
		//
		
		//先删除步骤成员
		$where = "WHERE `uid` NOT IN ({$uids}) AND `status`=1 AND `fromId`={$fid} AND `stepType`=2 AND `fromType`=1";
		$CNOA_DB->db_delete($this->t_step, $where);
		
		//当前的步骤ID和名称
		$where		= "WHERE `fromId`={$fid} AND `status`=1  AND `fromType`=1";
		$stepInfo	= $CNOA_DB->db_getone(array('stepname', 'stepid', 'fromId'), $this->t_step, $where);
		$stepid		= $stepInfo['stepid'];
		$stepname	= $stepInfo['stepname'];
		
		$sendInfo	= $CNOA_DB->db_getone('*', $this->t_send_list, "WHERE `id`={$stepInfo['fromId']}");
		$send_title	= $sendInfo['title'];
		
		//插入新步骤成员
		foreach ($arrUid as $key => $uid){			
			$name = $arrName[$key];

			if($uid == $cuid){
				//不允许会签人是他自己
				continue;
			}
			
			//fromType 1:发文 2:收文3:借阅	stepid 步骤ID	stepname 步骤名称
			//detpId 部门ID	deptName 部门名称
			
			//部门ID和名称
			$deptInfo = app::loadApp("main", "struct")->api_getDeptByUid($uid);
			$deptid		= $deptInfo['id'];
			$deptname	= $deptInfo['name'];
			
			$data = array();
			$data['uid']		= $uid;
			$data['uname']		= $name;
			$data['fromId']		= $fid;
			$data['fromType']	= 1;
			$data['stepid']		= $stepid;
			$data['stepname']	= $stepname;
			$data['detpId']		= $deptid;;
			$data['deptName']	= $deptname;
			//stepType 1:正常步骤 2:会签步骤 (2的作用是为了区分正常步骤，让被会签的人不能再发起会签)
			$data['stepType']	= 2;
			$data['status']		= 1;
			$data['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
			$CNOA_DB->db_insert($data, $this->t_step);
			
			//给个提醒、通知, 发送提醒
			$this->__sendNotice($uid, $send_title, 1, 2);		
		}
		
		msg::callBack(true, "操作成功.");		
	}
	
	
	
	
	/**
	 * 获取会签数据
	 * Enter description here ...
	 */
	private function _getHuiQianInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$fid	= getPar($_POST, 'fid');
		$uid	= $CNOA_SESSION->get('UID');
		
		//找status为1的，办理中
		$where		= "WHERE `fromId`={$fid} AND `status`=1";
		$stepInfo	= $CNOA_DB->db_getone('*', $this->t_step, $where);
		//debug::xprint($stepInfo);
		//debug::xprint($where);
		$stepName	= $stepInfo['stepname'];
		$stepid		= $stepInfo['stepid'];
		
		
		//会签的所有人员
		$data	= array();
		$where	= "WHERE `fromId`={$fid} AND `stepid`={$stepid} AND `uid`!={$uid}  AND `stepType`=2";
		$dblist	= $CNOA_DB->db_select('*', $this->t_step, $where);
		!is_array($dblist) && $dblist = array();
		//debug::xprint($dblist);
		
		$uids	= array();
		$unames = array();
		foreach ($dblist as $info){
			$uids[]		= $info['uid'];
			$unames[]	= $info['uname'];
		}
		
		$data	= array();
		$data['allUserNames']	= implode(',', $unames);
		$data['allUids']		= implode(',', $uids);
		
		$ds = new dataStore();
		$ds->data = $data;
		$ds->stepname	= $stepName;
		$js = $ds->makeJsonData();
		
		echo $js;
		exit;
	}
	
	
	/**
	 * 退件操作
	 */
	private function _reStep(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get('UID');
		$uname	= $CNOA_SESSION->get('TRUENAME');		
		
		//打回最原始状态，删除其他步骤，保留“拟稿”步骤，
		
		$fid	= getPar($_POST, 'fid');
		$reason	= getPar($_POST, 'reason');
		
		//debug::xprint($_POST); return ;
		
		
		
		
		
		
		//OK - 清空所有步骤为：未开始，并删除原步骤的FORM和DOC文件，
		//退件后，使用“拟稿”时的FORM和DOC文件和数据、步骤等
		//OK - 退件原因在退件人那个步骤，有结束时间
		
		
		//找到以前的步骤文件，并删除
		$where = "WHERE `stepid`>1 AND `fromId`={$fid} AND `fromType`=1";
		$dblist = $CNOA_DB->db_select('*', $this->t_step, $where);
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $dbinfo){
			$step_id = $dbinfo['id'];
			
			$path = CNOA_PATH_FILE. '/common/odoc/send/'. $fid .'/';
			@unlink($path . 'form.history.'.$step_id.'.php');
			@unlink($path . 'doc.history.'.$step_id.'.php');
		}
		
		//将所有步骤都设置为：未开始
		$data	= array();
		$data['status']	= 0;
		$data['stime']	= 0;
		$data['etime']	= 0;
		//$data['say']	= '';
		$where	= "WHERE `stepid`>1 AND `fromId`={$fid} AND `fromType`=1";
		$CNOA_DB->db_update($data, $this->t_step, $where);

		
		//给当前的步骤的say为“退件原因”
		$data = array();
		$data['say']	= '<b>[退件]：</b>'.nl2br($reason);
		$where	= "WHERE `status`=1 AND `fromId`={$fid} AND `stepType`=1 AND `fromType`=1 AND `uid`={$uid}";
		$CNOA_DB->db_update($data, $this->t_step, $where);
		
		
		/*
		//不删除？ 将这些
		$CNOA_DB->db_delete($this->t_step, "WHERE `stepid`<>1 AND `fromId`={$fid} AND `fromType`=1");
		
		
		//重新拟稿 - 状态设为：退件处理
		$data = array();
		$data['status']	= 3;
		$data['say']	= $reason;
		$CNOA_DB->db_update($data, $this->t_step, "WHERE `stepid`=1 AND `fromId`={$fid} AND `fromType`=1");
		
		*/
		
		
		//重新拟稿 - 状态设为：退件处理
		$data = array();
		$data['status']	= 1;
		$data['say']	= $reason;
		$CNOA_DB->db_update($data, $this->t_step, "WHERE `stepid`=1 AND `fromId`={$fid} AND `fromType`=1");
		
		
		
		//更新为拟稿中
		$data = array();
		$data['status'] = 0;
		$CNOA_DB->db_update($data, $this->t_send_list, "WHERE `id`={$fid}");
		
		
		
		//退件后，给拟稿人个提醒
		$where		= "WHERE `id`='{$fid}'";
		$send_info	= $CNOA_DB->db_getone(array("title", "number", "createuid"), $this->t_send_list, $where);
		$send_title	= $send_info['title'];
		$send_num	= $send_info['number'];		
		
		$where	= "WHERE `fromId`={$fid} AND `stepid`=1 AND `fromType`=1 AND `stepType`=1 AND `status`=1";
		$step_info	= $CNOA_DB->db_getone('*', $this->t_step, $where);
		$step_uid	= $step_info['uid'];
		//debug::xprint($where); debug::xprint($step_info);
				
		$this->__sendNotice($step_uid, $send_title, 1, 7, $reason);
				
		
		msg::callBack(true, "操作成功.");
	}
	
	
	/**
	 * 审批进度
	 * Enter description here ...
	 */
	private function _getStepList(){
		global $CNOA_DB;
		
		$where = "WHERE 1";
		
		$fid	= getPar($_POST, 'fid');
		$where	.= " AND `fromId`={$fid}";
		
		
		
		//如果是“退上一步”时，则只显示当前步骤的前步骤
		$prev	= getPar($_POST, 'prev');
		if(!empty($prev)){
			//$stepid	= getPar($_POST, 'stepid');
			$stepInfo	= $CNOA_DB->db_getone(array('stepid'), $this->t_step, "WHERE `fromId`={$fid} AND `status`=2 AND `stepType`=1 ORDER BY `stepid` DESC");
			$stepid		= $stepInfo['stepid'];
			$where		.= " AND `stepid`<={$stepid} AND `stepid`>1 AND `status`>0";
		}

		//发文
		$where .= " AND `fromType`=1";
		//debug::xprint($where);
		
		
		//上级为2的时候，下级为1，下下级为0
		$dblist = $CNOA_DB->db_select('*', $this->t_step, $where ." ORDER BY `stepid` ASC");
		!is_array($dblist) && $dblist = array();
		
		$data = array();
		foreach ($dblist as $info){
			$db = &$data[];
			$db	= $info;
			
			$db['status']	= app::loadApp('odoc', 'sendApply')->api_getStepStatus($db['status']);
			$db['from']		= $db['deptName'] .' / '. $db['uname'];
			if(intval($db['etime']) <= 0){
				$db['stime']	= formatDate($db['stime'], 'Y-m-d H:i');
				$db['etime'] = '';
			}else{
				$db['stime']	= formatDate($db['stime'], 'Y-m-d H:i');				
				$db['etime']	= formatDate($db['etime'], 'Y-m-d H:i');
				
			}
			
			$db['say']		= nl2br($db['say']);
			if($db['stepType'] == 2){
				$db['stepname'] = $db['stepname'] .' <b>[会签]</b>';
			}
			
		}
		
		//debug::xprint($data);
		
		$ds = new dataStore();
		$ds->data = $data;
		$js = $ds->makeJsonData();
		
		echo $js;
		exit;
	}
	
	
	
	/**
	 * 判断步骤流程是否已结束
	 */
	private function __isOver($fid){
		global $CNOA_DB, $CNOA_SESSION;
		
		
		//sendStatus = 2 AND stepStatus All = 2
		//$where	= "WHERE `status`=2 AND `id` IN (SELECT `fromId` FROM ".CNOA_DB_PRE."odoc_step WHERE `status`=2 AND `fromId`={$fid})";
		
		$where	= "WHERE `status`=1 AND `fromId`={$fid} AND `stepType`=1 AND `fromType`=1";		
		$data	= $CNOA_DB->db_getone('*', $this->t_step, $where);
		if($data === false){
			return true;
		}else{
			return false;
		}
	}
	
	
	/**
	 * 发送提醒
	 * Enter description here ...
	 * @param unknown_type $uid
	 */
	private function __sendNotice($uid, $title = '', $type = 1, $to = 1, $say = ''){
		global $CNOA_SESSION;
		
		$cuid	= $CNOA_SESSION->get('UID');	
		$uname	= $CNOA_SESSION->get('TRUENAME');
		
		//先检查通知表里面是否已经存在该用户的通知
		$where	= "WHERE `touid`={$uid} AND `sourceid`={$cuid}";
		$notice	= app::loadApp('notice', 'notice')->api_getData($where);
		if($notice !== false){
			return false;
		}
		
		
		$href		= "index.php?app=odoc&func=send&action=check";
		$noticeType	= 17;
		$say		= nl2br($say);
		
		
		$sType = '';
		if(intval($type) == 1){
			$sType = '发文稿';
		}elseif(intval($type) == 2){
			$sType = '收文稿';
			$noticeType = 18;
			$href = "index.php?app=odoc&func=receive&action=check";
		}
		
		$sDo = '';
		switch (intval($to)){
			case 1:
				$sDo	= '审批';
				break;
			case 2:
				$sDo	= '进行会签';
				break;
			case 3:
				$sDo		= '到“发文阅读”查看';
				$href		= "index.php?app=odoc&func=read&action=send";
				$noticeType	= 19;
				break;
			case 4:
				//$sDo	= '到“收文登记”查收';
				//$sType	= '新的公文';
				$sDo	= '审批';
				$sType	= '';
				break;
			case 5:
				$sDo		= '到“收文登记”查收';
				$sType		= '新的公文';
				$href		= "index.php?app=odoc&func=receive&action=apply";
				$noticeType	= 22;
				break;
			case 7:		//退件
				$sDo		= "重新拟稿";
				$sType		= "";
				break;
		}
		
		//通知成员来审批
		$noticeT = "公文管理";
		$noticeC = "“{$title}”{$sType}需要您{$sDo}.";
		$noticeH = $href;
		
		switch (intval($to)){
			case 6:		//发文审批结束
				$sDo		= "";
				$sType		= "发文稿已经审批结束";
				$href		= "";
				$noticeT	= "您的发文稿已经审批结束";
				$noticeC	= "“{$title}”{$sType}";
				$noticeH	= "index.php?app=odoc&func=send&action=list";
				$noticeType	= 17;
				break;
			case 7:
				$sDo		= "";
				$sType		= "的发文稿被退回. <br /> <b>原因：</b>{$say}";
				$href		= "";
				$noticeT	= "您的发文稿被退回.";
				$noticeC	= "“{$title}”{$sType}";
				$noticeH	= "index.php?app=odoc&func=send&action=apply";
				$noticeType	= 17;
				break;
			case 8:					//退上一步
				//$uname		= app::loadApp('main', 'user')->api_getUserTruenameByUid($cuid);;
				$sDo		= "";
				$sType		= "发文稿被退回给您重新审批. <br /> <b>原因：</b>{$say}";
				$href		= "";
				$noticeT	= "{$uname}将文稿退给您重新审批.";
				$noticeC	= "“{$title}”{$sType}";
				break;
		}
		
		$alarmid = notice::add($uid, $noticeT, $noticeC, $noticeH, 0, $noticeType, $cuid);
	}
	
	public function api_sendNotice($uid, $title, $type=1, $to=1, $say = ''){
		return $this->__sendNotice($uid, $title, $type, $to, $say);
	}
	
	
	
	
	private function _getAllUserListsInPermitDeptTree(){
		$GLOBALS['user']['permitArea']['area'] = "all";
		$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();	
		echo json_encode($userList);
		exit;
	}
	
	
	private function _loadFormData(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid = $CNOA_SESSION->get("UID");
		$id = getPar($_POST, "id", 0);
		
		$data = $CNOA_DB->db_getone("*", $this->t_send_list, "WHERE `id` = '{$id}'");
		$userInfo = app::loadApp("main", "user")->api_getUserDataByUid($uid);
		$deptmentInfo = app::loadApp("main", "struct")->api_getInfoById($userInfo['deptId']);
		$data['createpeople']	= $userInfo['truename'];
		$data['createdept']		= $deptmentInfo['name'];
		
		#eval("\$data = \$data['formdata'];");
		
		//附件
		$fs = new fs();
		$data['attach']		 	= json_decode($data['attach'], true);
		$data['attachCount']	= !$data['attach'] ? 0 : count($data['attach']);
		$data['attach']			= $fs->getDownLoadItems4normal($data['attach'], true);
		//$data['attach']   = $fs->getXXXXDownLoadFileListByIds(json_decode($data['attach']));
		//$data['attachCount'] = !$data['attach'] ? 0 : count($data['attach']);
		
		//当前的步骤
		$stepInfo	= $CNOA_DB->db_getone('*', $this->t_step, "WHERE `fromId`={$id} AND `status`=1 AND `uid`={$uid}");
		$data['stepData']	= $stepInfo;
		
		$dataStore = new dataStore();
		$dataStore->data = $data;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	
	private function _loadTemplateFile(){
		global $CNOA_DB;

		$id = intval(getPar($_GET, "id", 0));
		
		
		$info = $CNOA_DB->db_getone("*", $this->t_send_list, "WHERE `id`='{$id}'");
		
		#找出当前最后一个正在办理的步骤
		$maxid = $CNOA_DB->db_getmax("id", $this->t_step, "WHERE `fromType`=1 AND `fromId`='{$id}' AND `status`=2");
		
		$formPath = CNOA_PATH_FILE. "/common/odoc/send/{$id}/doc.history.{$maxid}.php";
		
		if (file_exists($formPath)){
			$form = file_get_contents($formPath);
		}else{
			$form = "无正文内容";
		}
		echo $form;	
		exit();
	}
	
	
	private function _getOdocFawenForm(){
		$_GET['OdocFawenForm_from']	= 'check';
		app::loadApp('odoc', 'sendApply')->api_getOdocFawenForm();
	}
	
	
	private function _loadpage(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task){
			
			
		}
	}
	
	private function _getJsonData(){
		$js	= app::loadApp('odoc', 'sendApply')->api_getSendList();
		echo $js; //debug::xprint($js);
		exit();
	}
	
	
	
	public function api_getStepList(){
		$this->_getStepList();
	}
}