<?php 
class odocSettingTemplate extends model{
	private $t_type_list	= "odoc_setting_word_type";
	private $t_list			= "odoc_setting_template_list";
									
	/**
	 * 构造函数
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * 析构函数
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getTypeList" ;
				$this->_getTypeList();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "add" :
				$this->_add();
				break;
			case "deleteData" :
				$this->_deleteData();
				break;
			case "loadTemplate" :
				$this->_loadTemplate();
			case "editLoadFormData" :
				$this->_editLoadFormData();
				break;
			#打开发文单制作界面
			case "editTemplate" :
				$this->_editTemplate();
				break;
			#打开发文红头模板制作界面
			case "editTemplateTpl" :
				$this->_editTemplateTpl();
				break;
			#保存红头模板
			case "saveDocTpl" :
				$this->_saveDocTpl();
				break;
			case "submit" :
				$this->_submit();
				break;
			case "getStructTree" :
				$GLOBALS['user']['permitArea']['area'] = "all";
				echo app::loadApp("main", "struct")->api_getStructTree();
				exit;
		}
	}
	
	private function _loadpage(){
		
	}

	private function _getTypeList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("tid", "title"), $this->t_type_list, "ORDER BY `order` ASC ");
		!is_array($dblist) && $dblist = array();
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _getJsonData(){
		global $CNOA_DB;
		$WHERE = "WHERE 1 ";
		
		$s_title	= getPar($_POST, "title", "");
		$s_type		= getPar($_POST, "type", 0);
		if(!empty($s_title)){
			$WHERE .= "AND `title` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_type)){
			$WHERE .= "AND `type` = '{$s_type}' ";
		}
		
		$dblist = $CNOA_DB->db_select("*", $this->t_list, $WHERE . "ORDER BY `order` ASC");
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v) {
			$uidArr[] = $v['postuid'];
		}
		$truenameArr = app::loadApp("main", "user")->api_getUserNamesByUids($uidArr);
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['postname'] = $truenameArr[$v['postuid']]['truename'];
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		$dataStore->total = $CNOA_DB->db_getcount($this->t_list, $WHERE);
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _add(){
		global $CNOA_DB, $CNOA_SESSION;
		$id 				= getPar($_POST, "id", 0);
		$data['title'] 		= getPar($_POST, "title", "");
		$data['order']		= getPar($_POST, "order", 0);
		$data['type']		= getPar($_POST, "type", 0);
		$data['postuid']	= $CNOA_SESSION->get("UID");
		$data['fromType']	= getPar($_POST, "fromType", 1);
		
		$num = $CNOA_DB->db_getcount($this->t_list, "WHERE `id` != '{$id}' AND `title` = '{$data['title']}' AND `type` = '{$data['type']}' ");
		
		if($num > 0){
			msg::callBack(false, "该名称已存在");
		}
		
		if(!empty($id)){
			$CNOA_DB->db_update($data, $this->t_list, "WHERE `id` = '{$id}'");
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('update', 3303, $data['title'], '模板信息');
		}else{
			$CNOA_DB->db_insert($data, $this->t_list);
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('add', 3303, $data['title'], '模板信息');
		}
		msg::callBack(true, lang('successopt'));
	}
	
	private function _deleteData(){
		global $CNOA_DB;
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$DB = $CNOA_DB->db_select(array('title'), $this->t_list, "WHERE `id` IN (" . $ids . ") ");
		
		$CNOA_DB->db_delete($this->t_list, "WHERE `id` IN (" . $ids . ") ");
		
		foreach ($DB as $v){
		    //系统操作日志
		    app::loadApp('main', 'systemLogs')->api_addLogs('del', 3304, $v['title'], '模板');
		}
		msg::callBack(true, lang('successopt'));
	}
	
	private function _loadTemplate(){
		global $CNOA_DB;

		$id = intval(getPar($_GET, "id", 0));
		
		$infoDb = $CNOA_DB->db_getone(array("template"), $this->t_list, "WHERE `id`='{$id}' ORDER BY `order` ASC");

		if(!empty($infoDb['template'])){
			echo @file_get_contents(CNOA_PATH_FILE . "/common/odoc/template/{$id}/{$infoDb['template']}.php");
		}else{
			echo " ";
		}
		exit;
	}
	
	private function _editTemplate(){
		global $CNOA_DB, $CNOA_CONTROLLER;
		
		$GLOBALS['id'] = intval(getPar($_GET, "id"));
		$GLOBALS['CNOA_SYSTEM_NAME'] = "修改发文模板";
		
		$CNOA_CONTROLLER->loadViewCustom($CNOA_CONTROLLER->appPath . "/tpl/default/setting/editTemplate.htm", true, true);
		exit;
	}
	
	private function _editTemplateTpl(){
		global $CNOA_DB, $CNOA_CONTROLLER;
		
		$GLOBALS['id'] = intval(getPar($_GET, "id"));
		$GLOBALS['CNOA_SYSTEM_NAME'] = "修改发文红头模板";
		
		$CNOA_CONTROLLER->loadViewCustom($CNOA_CONTROLLER->appPath . "/tpl/default/setting/editTemplateTpl.htm", true, true);
		exit;
	}
	
	private function _editLoadFormData(){
		global $CNOA_DB;
		
		$id = intval(getPar($_POST, "id", 0));
		$infoDb = $CNOA_DB->db_getone("*", $this->t_list, "WHERE `id`='{$id}' ORDER BY `order` ASC");
		
		$infoDb['tid'] = $infoDb['type'];
		#$infoDb['deptNames']	= $infoDb['permitdeptname'];
		#$infoDb['deptIds']		= $infoDb['permitdept'];
		
		if(empty($infoDb['template'])){
			$infoDb['template'] = "未制作红头模板 [<a style='color:red' href='index.php?app=odoc&func=setting&action=template&task=editTemplateTpl&id={$id}' target='cnoa_odoc_edittpl'>制作</a>]";
		}else{
			$infoDb['template'] .= ".doc [<a style='color:red' href='index.php?app=odoc&func=setting&action=template&task=editTemplateTpl&id={$id}' target='cnoa_odoc_edittpl'>编辑</a>]";
		}
		
		$ds = new dataStore();
		$ds->data = $infoDb;
		echo $ds->makeJsonData();
		exit;
	}

	private function _submit(){
		global $CNOA_DB;

		$data = array();
		$data['title']		= getPar($_POST, "title");
		$data['fromType']	= getPar($_POST, "fromType", 1);
		$data['type']		= getPar($_POST, "tid");
		$data['num1']		= getPar($_POST, "num1");
		$data['num2']		= getPar($_POST, "num2");
		$data['about']		= getPar($_POST, "about");
		#$data['permitdeptname']	= getPar($_POST, "deptNames");
		#$data['permitdept']		= getPar($_POST, "deptIds");
		$data['fawenform']	= getPar($_POST, "fawenform", "", 1, 0);

		if(empty($data['title'])){msg::callBack(false, "模板名称不能为空");}
		if(empty($data['type'])){msg::callBack(false, "请选择模板类型");}

		#if(empty($data['num1'])){msg::callBack(false, "请填写发文前缀，如: 粤[2011]第");}
		#if(empty($data['num2'])){msg::callBack(false, "请填写发文后缀，如：号");}

		$id = intval(getPar($_POST, "id", 0));

		$CNOA_DB->db_update($data, $this->t_list, "WHERE `id`='{$id}'");
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('update', 3303, $data['title'], '模板');
		msg::callBack(false, lang('successopt'));
		exit;
	}

	private function _saveDocTpl(){
		global $CNOA_DB;
		
		$id = intval(getPar($_POST, "id", 0));
		$infoDb = $CNOA_DB->db_getone("*", $this->t_list, "WHERE `id`='{$id}'");

		if(empty($infoDb['template'])){
			$infoDb['template'] = string::rands(20, 1);
		}
		
		$uploadfile = CNOA_PATH_FILE . "/common/odoc/template/{$id}/{$infoDb['template']}.php";
		
		mkdirs(dirname($uploadfile));
		
		if(!move_uploaded_file($_FILES['msOffice']['tmp_name'], $uploadfile)){
			echo '0';exit;
		}
		
		$CNOA_DB->db_update(array("template"=>$infoDb['template']), $this->t_list, "WHERE `id`='{$id}'");
		
		echo '1';
		exit;
	}
	
	public function api_getTemplateList($typeId, $fromType = 1){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_list, "WHERE 1 AND `fromType` = '{$fromType}' AND `type` = '{$typeId}' ORDER BY `order` ASC");
		!is_array($dblist) && $dblist = array();
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
}
?>