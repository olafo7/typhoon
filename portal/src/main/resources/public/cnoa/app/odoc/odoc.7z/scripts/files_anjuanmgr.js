/**
 * 全局变量
 */

var CNOA_odoc_files_anjuanmgr, CNOA_odoc_files_anjuanmgrClass;
CNOA_odoc_files_anjuanmgrClass = CNOA.Class.create();
CNOA_odoc_files_anjuanmgrClass.prototype = {	
	init : function(){
		var _this = this;
		
		var ID_SEARCH_STATUS	= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=files&action=anjuanmgr";
		
		this.typeListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getTypeList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.typeListStore.load();
		
		this.levelListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getLevelList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.levelListStore.load();
		
		this.savetimeListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getSavetimeList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.savetimeListStore.load();
		
		this.roomListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getRoomList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.roomListStore.load();
		
		this.storeBar = {
			id : 0,
			storeType : "waiting",
			status : "",
			type : ""
		};
		
		this.fields = [
			{name : "id"},
			{name : "title"},
			{name : "room"},
			{name : "hehao"},
			{name : "type"},
			{name : "title"},
			{name : "anjuandate"},
			{name : "page"},
			{name : "secret"},
			{name : "note"},
			{name : "status"}
		];
		
		this.store = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: false
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "id", dataIndex: 'id', hidden: true},
			{header: '属性', dataIndex: 'status', width: 40, sortable: true, menuDisabled :true, renderer : this.status.createDelegate(this)},
			{header: '所属内目', dataIndex: 'type', width: 100, sortable: true, menuDisabled :true},
			{header: '盒号', dataIndex: 'hehao', width: 100, sortable: true, menuDisabled :true},
			{header: '案卷提名', dataIndex: 'title', width: 80, sortable: true, menuDisabled :true},
			{header: '年度', dataIndex: 'anjuandate', width: 80, sortable: true, menuDisabled :true},
			{header: '页数', dataIndex: 'page', width: 80, sortable: true, menuDisabled :true},
			{header: '保管期限', dataIndex: 'secret', width: 80, sortable: true, menuDisabled :true},
			{header: '备注', dataIndex: 'note', width: 80, sortable: true, menuDisabled :true},
			//{header: '操作', dataIndex: 'operate', width: 120, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			bodyStyle: 'border-left-width:1px;',
			store:this.store,
			loadMask : {msg: lang('loading')},
			cm: this.colModel,
			sm: this.sm,
			hideBorders: true,
			listeners:{
				"rowdblclick":function(button, event){
					
				}
			},
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.add("add", 0);
					}.createDelegate(this),
					iconCls: 'icon-utils-s-add',
					text : '添加案卷'
				},"-",
				{
					text:"修改",
					iconCls: 'icon-utils-s-edit',
					handler : function(){
						var rows = _this.grid.getSelectionModel().getSelections();
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, lang('mustSelectOneRow'));
						} else {
							_this.add("edit", rows[0].get("id"));
						}
					}
				},"-",
				{
					text:"删除",
					iconCls: 'icon-utils-s-delete',
					handler : function(button){
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, lang('mustSelectOneRow'));
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要删该记录吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.deleteData(ids);
								}
							});
						}
					}
				},"-",
				{
					text:"封卷",
					iconCls: 'icon-folder-lock',
					handler : function(button){
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, "您还没有选择要封卷的案卷");
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要封卷该案卷吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.lock(ids, "lock");
								}
							});
						}
					}
				},"-",
				{
					text:"拆卷",
					iconCls: 'icon-folder-lock-unlock',
					handler : function(button){
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, "您还没有选择要封卷的案卷");
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要拆卷该案卷吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.lock(ids, "unlock");
								}
							});
						}
					}
				},
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.treeRoot = new Ext.tree.AsyncTreeNode({
			text: "档案室",
			expanded: true
		});

		this.treeLoader = new Ext.tree.TreeLoader({
			dataUrl: this.baseUrl + "&task=getRoom",
			preloadChildren: true,
			clearOnLoad: false,
			listeners:{
				"load":function(node){
					
				}.createDelegate(this)
			}
		});
		
		this.dirTree = new Ext.tree.TreePanel({
			hideBorders: true,
			border: false,
			rootVisible: true,
			lines: true,
			animCollapse: false,
			animate: false,
			loader: this.treeLoader,
			root: this.treeRoot,
			autoScroll: true,
			listeners:{
				"click":function(node){
					_this.storeBar.id = node.attributes.id;
					_this.store.load({params :  _this.storeBar});
				}.createDelegate(this),
				"render" : function(){
					//Ext.state.Manager.set("CNOA_main_user_index_treeState", "");
				}
			}
		});
		
		this.left = new Ext.Panel({
			region : "west",
			width : 200,
			layout:'fit',
			split: true,
			minWidth: 80,
			maxWidth: 380,
			bodyStyle: 'border-right-width:1px;',
			items: [this.dirTree],
			tbar : [
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.treeRoot.reload();
					}
				},"->",
				"档案室"
			]
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.left,this.grid],
			tbar : [
				"内目名称: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TYPE
				},
				/*
				"类型: ",
				new Ext.form.ComboBox({
					store: new Ext.data.SimpleStore({
						fields: ['value', 'title'],
						data: [['1', "发文"], ['2', "收文"], ['3', "其他"]]
					}),
					width: 60,
					id : ID_SEARCH_STATUS,
					valueField: 'value',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false,
					listeners : {
					
					}
				}),*/
				{
					xtype: "button",
					text: "查询",
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						//_this.storeBar.status 		= Ext.getCmp(ID_SEARCH_STATUS).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:"清空",
					handler:function(){
						//Ext.getCmp(ID_SEARCH_STATUS).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						
						//_this.storeBar.status 		= "";
						_this.storeBar.type 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]
		});
	},
	
	lock : function(ids, from){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + '&task=lock',
			params: {ids : ids, from : from},
			method: "POST",
			success: function(r, opts) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.store.reload();
				}else{
					CNOA.msg.alert(result.msg, function(){
						_this.store.reload();
					});
				}
			},
			failure: function(response, opts) {
				CNOA.msg.alert(result.msg, function(){
					_this.store.reload();
				});
			}
		});
	},
	
	status : function(value, c, rd){
		if(value == 0) {
			return '<img src="' + CNOA_EXTJS_PATH + '/resources/images/default/tree/lock-unlock.png" align="absmiddle">';
		}else if(value == 1) {
			return '<img src="' + CNOA_EXTJS_PATH + '/resources/images/default/tree/lock.png" align="absmiddle">';
		}
	},
	
	add : function(from, id){
		var _this = this;
		
		var loadFormData = function(id){		
			form.getForm().load({
				url: _this.baseUrl + "&task=loadFormData",
				params : {id : id},
				method:'POST',
				waitTitle: lang('waiting'),
				success: function(form, action){
	
				},
				failure: function(form, action) {
					CNOA.msg.alert(action.result.msg, function(){
						
					});
				}
			})
		};
		
		var submit = function(from, id){
			if (form.getForm().isValid()) {
				form.getForm().submit({
					url: _this.baseUrl + "&task=add",
					waitTitle: lang('waiting'),
					params : {from : from, id : id},
					method: 'POST',
					waitMsg: lang('loading'),
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						win.close();
						_this.store.reload();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg, function(){
							//this.mainPanel.enable();
						});
					}.createDelegate(this)
				});
			}
		};
		
		var baseField = [
			{
				xtype: "fieldset",
				title: "添加案卷",
				autoHeight: true,
				defaults : {
					border : false,
					style : "margin-bottom : 5px"
				},
				items: [
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "案卷题名",
										width: 150,
										name : "title",
										allowBlank : false
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype : "textfield",
										fieldLabel : "盒号",
										width : 150,
										name : "hehao",
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										fieldLabel: "年度",
										name: 'anjuandate',
										allowBlank : false,
										store: new Ext.data.SimpleStore({
											fields: ['value', 'anjuandate'],
											data: (function(){
												var Y = new Date().getFullYear()+1;
												var arr	= [];
												for(var i=0; i<20;i++){
													arr[i]	= [Y, Y];
													Y--;
												}
												return arr;
											})()
										}),
										width: 150,
										hiddenName: 'anjuandate',
										valueField: 'value',
										displayField: 'anjuandate',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "全宗号",
										name : "quanzonghao",
										width: 150,
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'savetime',
										store: _this.savetimeListStore,
										allowBlank : false,
										width: 150,
										fieldLabel : "保管期限",
										hiddenName: 'savetime',
										valueField: 'tid',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype : "textfield",
										fieldLabel : "档案室代号",
										allowBlank : false,
										name : "danganshidaihao",
										width : 150
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'danganshi',
										store: _this.roomListStore,
										width: 150,
										fieldLabel : "档案室",
										allowBlank : false,
										hiddenName: 'danganshi',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "责任者",
										width: 150,
										name : "respon",
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'type',
										store: _this.typeListStore,
										allowBlank : false,
										width: 150,
										fieldLabel : "内目",
										hiddenName: 'type',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "页数",
										width: 150,
										name : "page",
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'level',
										store: _this.levelListStore,
										width: 150,
										allowBlank : false,
										fieldLabel : "密级",
										hiddenName: 'level',
										valueField: 'tid',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							}
						]
					},{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "datefield",
										fieldLabel: "卷类文件起始时间",
										name : "stime",
										format : "Y-m-d",
										width: 150,
										allowBlank : false
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "datefield",
										fieldLabel: "卷类文件终止时间",
										name : "etime",
										format : "Y-m-d",
										width: 150,
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "textarea",
						fieldLabel : "备注",
						name : "note",
						width : 425,
						height : 50
					}
				]
			}
		];
		
		var form = new Ext.form.FormPanel({
			border: false,
			labelWidth: 120,
			labelAlign: 'right',
			region : "center",
			layout : "fit",
			waitMsgTarget: true,
			items:[
				{
					xtype: "panel",
					border: false,
					bodyStyle: "padding:10px",
					layout: "form",
					region: "center",
					autoScroll: true,
					items: baseField
				}
			]
		});
		
		var win = new Ext.Window({
			title : "添加案卷窗口",
			layout : "border",
			width : 620,
			height : makeWindowHeight(420),
			resizable : false,
			modal : true,
			items : [form],
			buttons : [
				{
					text : "提交",
					handler : function(){
						submit(from, id);
					}
				},
				{
					text : "取消",
					handler : function(){
						win.close();
					}
				}
			]
		}).show();
		
		if(from == "edit"){
			loadFormData(id);
		}	
	},
	
	deleteData : function(ids){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + '&task=delete',
			params: {ids : ids},
			method: "POST",
			success: function(r, opts) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.store.reload();
				}else{
					CNOA.msg.alert(result.msg, function(){
						_this.store.reload();
					});
				}
			},
			failure: function(response, opts) {
				CNOA.msg.alert(result.msg, function(){
					_this.store.reload();
				});
			}
		});
	}
}

