<?php 
class odocFilesSetting extends model{
	private $t_dangan_room = "odoc_files_dangan_room";
	private $t_dangan_type = "odoc_files_dangan_type";
	private $t_dangan_wenzhong	= "odoc_files_dangan_wenzhong";
	private $t_dangan_savetime	= "odoc_files_dangan_savetime";
	private $t_level_list	= "odoc_setting_word_level";
									
	/**
	 * 构造函数
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * 析构函数
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "add" :
				$this->_add();
				break;
			case "delete" :
				$this->_delete();
				break;
		}
	}
	
	private function _loadpage(){
		
	}
	
	private function _add(){
		global $CNOA_DB, $CNOA_SESSION;
		$id = getPar($_POST, "id", 0);
		$from = getPar($_POST, "from", "room");
		switch ($from) {
			case "room" :
				$table = $this->t_dangan_room;
				$extra = '档案室';
				break;
			case "type" :
				$table = $this->t_dangan_type;
				$extra = '内目';
				break;
			case "wenzhong" :
				$table = $this->t_dangan_wenzhong;
				$extra = '文种';
				break;
			case "savetime" :
				$table = $this->t_dangan_savetime;
				$extra = '保管期限';
				break;
		}
		$data['title']	= getPar($_POST, "title", "");
		$data['order']	= getPar($_POST, "order", 0);
		$data['postuid']= $CNOA_SESSION->get("UID");
		$num = $CNOA_DB->db_getcount($table, "WHERE `id` != '{$id}' AND `title` = '{$data['title']}'");
		if($num > 0){
			msg::callBack(false, "已存在此名称");
		}
		if(!empty($id)){
			$CNOA_DB->db_update($data, $table, "WHERE `id` = '{$id}' ");
		}else{
			$CNOA_DB->db_insert($data, $table);
		}
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('add', 3206, $data['title'], $extra);
		msg::callBack(true, "操作成功");
	}
	
	private function _getJsonData(){
		global $CNOA_DB;
		$from = getPar($_POST, "from", "room");
		switch ($from) {
			case "room" :
				$table = $this->t_dangan_room;
				break;
			case "type" :
				$table = $this->t_dangan_type;
				break;
			case "wenzhong" :
				$table = $this->t_dangan_wenzhong;
				break;
			case "savetime" :
				$table = $this->t_dangan_savetime;
				break;
		}
		$dblist = $CNOA_DB->db_select("*", $table, "ORDER BY `order` ASC");
		!is_array($dblist) && $dblist = array();
		$uidArr = array();
		foreach ($dblist as $k=>$v) {
			$uidArr[] = $v['postuid'];
		}
		$truenameArr = app::loadApp("main", "user")->api_getUserNamesByUids($uidArr);
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['postname'] = $truenameArr[$v['postuid']]['truename'];
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _delete(){
		global $CNOA_DB;
		$from = getPar($_POST, "from", "room");
		switch ($from) {
			case "room" :
				$table = $this->t_dangan_room;
				$extra = '档案室';
				break;
			case "type" :
				$table = $this->t_dangan_type;
				$extra = '内目';
				break;
			case "wenzhong" :
				$table = $this->t_dangan_wenzhong;
				$extra = '文种';
				break;
			case "savetime" :
				$table = $this->t_dangan_savetime;
				$extra = '文种';
				break;
		}
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		$DB = $CNOA_DB->db_select(array('id', 'title'), $table, "WHERE `id`	IN ({$ids})");
		foreach($DB as $v){
		    $title[$v['id']] = $v['title'];
		}
		foreach ($idArr as $v) {
			$CNOA_DB->db_delete($table, "WHERE `id` = '{$v}'");
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('del', 3206, $title[$v], $extra);
		}
		msg::callBack(true, "操作成功");
	}
	
	public function api_getRoomData(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_room, "ORDER BY `order` ASC");
		!is_array($dblist) && $dblist = array();
		$data = array();
		foreach ($dblist as $k=>$v) {
			$data[$v['id']] = $v;
		}
		return $data;
	}
	
	public function api_getTypeData(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_type, "ORDER BY `order` ASC");
		!is_array($dblist) && $dblist = array();
		$data = array();
		foreach ($dblist as $k=>$v) {
			$data[$v['id']] = $v;
		}
		return $data;
	}
	
	public function api_getWenzhongData(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_wenzhong, "ORDER BY `order` ASC");
		!is_array($dblist) && $dblist = array();
		$data = array();
		foreach ($dblist as $k=>$v) {
			$data[$v['id']] = $v;
		}
		return $data;
	}
	
	public function api_getRoomList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_room, "ORDER BY `order` ASC");
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_getTypeList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_type, "ORDER BY `order` ASC");
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_getWenzhongList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_wenzhong, "ORDER BY `order` ASC");
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_getSavetimeList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_savetime, "ORDER BY `order` ASC");
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}

	public function api_getLevelList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("tid", "title"), $this->t_level_list, "ORDER BY `order` ASC ");
		!is_array($dblist) && $dblist = array();
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
}
?>