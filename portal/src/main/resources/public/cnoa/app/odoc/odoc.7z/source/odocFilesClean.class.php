<?php 
class odocFilesClean extends model{
	private $t_odoc_view_fieldset="odoc_view_fieldset";
	private $t_odoc_view_field	="odoc_view_field";
	private $t_odoc_data		="odoc_data";
	private $t_odoc_view_field_list ="odoc_view_field_list";
	private $t_odoc_bind_flow_kj	= "odoc_bind_flow_kj";
	private $t_odoc_fenfa		= "odoc_fenfa";
	
	private $t_s_flow_other_app_data= 'wf_s_flow_other_app_data';
	
	private $t_step			= "odoc_step";
	private $t_send_list	= "odoc_send_list";
	private $t_receive_list	= "odoc_receive_list";
	private $t_files_dangan	= "odoc_files_dangan";
	
	private $rows = 15;
									
	/**
	 * 构造函数
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * 析构函数
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage":
				$this->_loadpage();
				break;
			case "loadColumn":
				$this->_loadColumn();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getTypeList" :
				app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "settingWord")->api_getLevelList();
				break;
			case "getRoomList" :
				app::loadApp("odoc", "filesSetting")->api_getRoomList();
				break;
			case "getAnjuanList" :
				app::loadApp("odoc", "filesAnjuanmgr")->api_anjuanList();
				break;
			case "getWenzhongList" :
				app::loadApp("odoc", "filesSetting")->api_getWenzhongList();
				break;
			case "loadFormData" :
				$this->_loadFormData();
				break;
			case 'add' :
				$this->_add();
				break;
			case "loadFileFormData":
				$this->_loadFileFormData();
				break;
			case 'collect' :
				$this->_collect();
				break;
			#查看
			case 'view':
				$fromType = getPar($_GET, "fromType");
				app::loadApp("odoc", "commonView")->run($fromType);
				break;
			//删除
			case 'delete':		
				$this->_delete();
				break;
		}
	}
	
	private function _loadColumn(){
		global $CNOA_DB;
		$from = getPar($_POST, 'from', 'send');
		$dblist = $CNOA_DB->db_select("*", $this->t_odoc_view_field_list, "WHERE 1 ");
		!is_array($dblist) && $dblist = array();
		$field = array();
		foreach ($dblist as $k=>$v){
			if($v['from'] == 'send'){
				$fieldSend[] = 'field_'.$v['field'];
				$dblistSend[]= $v;
			}else{
				$fieldReceive[] = 'field_'.$v['field'];
				$dblistReceive[]= $v;
			}
		}
	
		$result = array(
				'success'=>true,
				'field'=>array('send'=>$fieldSend, 'receive'=>$fieldReceive),
				'column'=>array('send'=>$dblistSend, 'receive'=>$dblistReceive)
		);
		echo json_encode($result);exit();
	}
	
	/**
	 * 删除档案
	 * Enter description here ...
	 */
	private function _delete(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$ids	= getPar($_POST, 'ids');
		$ids	= substr($ids, 0, -1);
		$from	= getPar($_POST, 'fromType');
		
		
		//到cnoa_odoc_receive_list删除ids的数据，再到step删除，删除步骤文件
		/*
		private $t_step			= "odoc_step";
		private $t_send_list	= "odoc_send_list";
		private $t_receive_list	= "odoc_receive_list";
		*/
		
		//默认是发文的
		$table		= $this->t_send_list;
		$fromType	= 1;
		$folder		= 'send';
		$extra		= '发文';
		
		//如果是收文的
		if($from == 'receive'){
			$table		= $this->t_receive_list;
			$fromType	= 2;
			$folder		= 'receive';
			$extra		= '收文';
		}
		
		//删除
		$where	= "WHERE 1";
		$where	.= " AND `id` IN ({$ids})";
		
		$DB = $CNOA_DB->db_select(array('title'), $table, $where);
		
		$CNOA_DB->db_delete($table, $where);
		
		//系统操作日志
		foreach ($DB as $v){
			app::loadApp('main', 'systemLogs')->api_addLogs('del', 3204, $v['title'], $extra."档案");
		}
		
		//删除步骤文件
		$argId = explode(',', $ids);
		foreach ($argId as $fid){
			$where	= "WHERE `fromId`={$fid} AND `fromType`={$fromType}";
			$dblist	= $CNOA_DB->db_select('*', $this->t_step, $where);
			!is_array($dblist) && $dblist = array();
			
			foreach ($dblist as $dbinfo){
				$step_id = $dbinfo['id'];
				$path = CNOA_PATH_FILE. "/common/odoc/{$folder}/". $fid ."/";
				@unlink($path . 'form.history.'.$step_id.'.php');
				@unlink($path . 'doc.history.'.$step_id.'.php');
			}
		}
				
		//删除步骤
		$where	= "WHERE 1";
		$where	.= " AND `fromId` IN ({$fid}) AND `fromType`={$fromType}";
		$CNOA_DB->db_delete($this->t_step, $where);
		
		msg::callBack(true, "删除操作成功.");
	}
	
	private function _loadpage(){
		global $CNOA_SESSION, $CNOA_CONTROLLER, $CNOA_DB;
		$from = getPar($_GET, "from", "");
		
		switch($from){
			case 'viewflow'	:
				//查看流程
				$GLOBALS['app']['uFlowId'] 			= getPar($_GET, "uFlowId", 0);
				$GLOBALS['app']['step']				= getPar($_GET, "step", 0);
		
				$GLOBALS['app']['wf']['type']		= "done";//已办流程， 用于查看页面显示召回和撤销按钮
				$DB									= $CNOA_DB->db_getone(array("status", "flowId"), "wf_u_flow", "WHERE `uFlowId`='{$GLOBALS['app']['uFlowId']}'");
				$GLOBALS['app']['flowId']			= $DB['flowId'];
				$flow								= $CNOA_DB->db_getone(array("tplSort", "flowType"), "wf_s_flow", "WHERE `flowId` = {$DB['flowId']} ");
				$GLOBALS['app']['wf']['allowCallback']	= 0;
				$GLOBALS['app']['wf']['allowCancel']	= 0;
				$GLOBALS['app']['allowPrint']			='false';
				$GLOBALS['app']['allowFenfa']			='false';
				$GLOBALS['app']['allowExport']			='false';
				$GLOBALS['app']['status']				= 1;
				$GLOBALS['app']['wf']['tplSort']		= $flow["tplSort"];
				$GLOBALS['app']['wf']['flowType']		= $flow["flowType"];
				$GLOBALS['app']['wf']['owner']			= 0;//getpar($_GET, "owner", 0);
				$tplPath = CNOA_PATH . '/app/wf/tpl/default/flow/use/showflow.htm';
				$CNOA_CONTROLLER->loadExtraTpl($tplPath);exit;
		}
	}
	
	private function _getJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid = $CNOA_SESSION->get('UID');
		
		$storeType = getPar($_GET, 'from', 'send');
		$WHERE = "WHERE `from` = '{$storeType}' ";
		
		$start = getPar($_POST, 'start', 0);
		
		$dblist = $CNOA_DB->db_select("*", $this->t_odoc_data, $WHERE."AND `uid` = {$uid} AND `collect` = 0 ORDER BY `id` DESC LIMIT {$start}, {$this->rows} ");
	
		!is_array($dblist) && $dblist = array();

		foreach ($dblist as $k=>$v){
			$dblist[$k]['posttime'] = date("Y-m-d", $v['posttime']);
		}
	
		$ds = new dataStore();
		$ds->data = $dblist;
		echo $ds->makeJsonData();exit();
	}
	
	private function _loadFormData(){
		global $CNOA_DB;
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		$num = count($idArr);
		$storeType = getPar($_POST, "storeType", "send");
		switch ($storeType){
			case "send" :
				$table = $this->t_send_list;
				break;
			case "receive" :
				$table = $this->t_receive_list;
				break;
		}
		if($num == 1){
			$this->__getLoadFormDataSingle($table, $idArr);
		}else{
			$this->__getLoadFormDataMult($table, $idArr);
		}
	}
	
	private function __getLoadFormDataSingle($table, $idArr){
		global $CNOA_DB;
		$data		= $CNOA_DB->db_getone("*", $table, "WHERE `id` = '{$idArr[0]}'");
		$typeArr	= app::loadApp("odoc", "settingWord")->api_getTypeAllArr();
		$data['type']			= $typeArr[$data['type']]['title'];
		$data['guidangdate']	= formatDate($GLOBALS['CNOA_TIMESTAMP']);
		$data['senddate']		= formatDate($data['createtime']);
		$dataStore = new dataStore();
		$dataStore->data = $data;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function __getLoadFormDataMult($table, $idArr){
		global $CNOA_DB;
		$dblist['guidangdate'] = formatDate($GLOBALS['CNOA_TIMESTAMP']);
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _add(){
		global $CNOA_DB;
		$data['title']			= getPar($_POST, "title", "");
		$data['level']			= getPar($_POST, "level", 0);
		$data['filesnum']		= getPar($_POST, "filesnum", "");
		$data['number']			= getPar($_POST, "number", "");
		$data['senddate']		= strtotime(getPar($_POST, "senddate", ""));
		$data['respon']			= getPar($_POST, "respon", "");
		$data['page']			= getPar($_POST, "page", "");
		$data['collectdate']	= strtotime(getPar($_POST, "collectdate", ""));
		$data['wenzhong']		= getPar($_POST, "wenzhong", "");
		$data['anjuan']			= getPar($_POST, "anjuan", "");
		$data['note']			= getPar($_POST, "note", "");
		$data['danganshi']		= getPar($_POST, "room", "");
		$data['from']			= 3;
		
		$id	= getPar($_POST, "id", 0);
		
		$fs = new fs();
		$filesUpload = getPar($_POST, "filesUpload", array());
		$attch = $fs->add($filesUpload, 17);
		$data['attach'] = json_encode($attch);
		
		if($id == 0){
			//获取上传文档的ID
			$CNOA_DB->db_insert($data, $this->t_files_dangan);
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('add', 3203, $data['title'], '档案');
		}else{
			$CNOA_DB->db_update($data, $this->t_files_dangan, "WHERE `id`='{$id}'");
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('update', 3203, $data['title'], '档案');
		}
		
		msg::callBack(true, "操作成功");
	}
	
	private function _loadFileFormData(){
		global $CNOA_DB;
		$id = getPar($_POST, "id", 0);
	
		$dblist = $CNOA_DB->db_getone("*", $this->t_files_dangan, "WHERE `id` = '{$id}' ");
		
		$dblist['senddate'] = formatDate($dblist['senddate']);
		$dblist['collectdate'] = formatDate($dblist['collectdate']);
		$dblist['room']	= $dblist['danganshi'];
		$dblist['year'] = $CNOA_DB->db_getfield("anjuandate", "odoc_files_anjuan_list", "WHERE `id`='{$dblist['anjuan']}'");
		
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _collect(){
		global $CNOA_DB;
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		$storeType = getPar($_POST, "storeType", "send");
		
		$title		= getPar($_POST, 'title', '');
		$guidangdate= strtotime(getPar($_POST, 'guidangdate', ''));
		$type		= getPar($_POST, 'type', '');
		$level		= getPar($_POST, 'level', 0);
		$number		= getPar($_POST, 'number', '');
		
		$respon		= getPar($_POST, "respon", "");
		$filesnum	= getPar($_POST, "filesnum", "");
		$wenzhong	= getPar($_POST, "wenzhong", 0);
		$anjuan		= getPar($_POST, "anjuan", 0);
		$danganshi	= getPar($_POST, "room", 0);
		
		$WHERE = 'WHERE 1 ';
		
		switch ($storeType) {
			case "send" :
				$from = 1;
				break;
			case "receive" :
				$from = 2;
				break;
		}
		foreach ($idArr as $v) {
			$data['title']		= $title;
			$data['number']		= $number;
			$data['type']		= $type;
			$data['level']		= $number;
			
			$data['from']		= $from;
			$data['fromid']		= $v;
			$data['respon']		= $respon;
			$data['filesnum']	= $filesnum;
			$data['wenzhong']	= $wenzhong;
			$data['anjuan']		= $anjuan;
			$data['danganshi']	= $danganshi;
			$data['collectdate']= $GLOBALS['CNOA_TIMESTAMP'];
			$data['senddate']	= $guidangdate;
			unset($data['createtime']);
			$data['page']		= getPar($_POST, "page", "");
			$CNOA_DB->db_insert($data, $this->t_files_dangan);
			if($storeType == 'receive'){
			 	$pid = $CNOA_DB->db_getfield("pid", $this->t_odoc_data, "WHERE `id` = '{$v}' ");
			 	$CNOA_DB->db_update(array("collect"=>1), $this->t_odoc_data, "WHERE `pid` = {$pid} ");
			}else{
				$CNOA_DB->db_update(array("collect"=>1), $this->t_odoc_data, "WHERE `id` = '{$v}' ");
			}
		}
		/*
		//系统操作日志
		$DB = $CNOA_DB->db_select(array('title'), $table, "WHERE `id` IN ({$ids})");
		$titles = '';
		foreach($DB as $v){
		    $titles .= "{$v['title']}, ";
		}
		$titles = substr($titles, 0, -2);
		app::loadApp('main', 'systemLogs')->api_addLogs('', 3204, $titles, "归档{$extra}文件");
		*/
		msg::callBack(true, "操作成功");
	}
}
?>