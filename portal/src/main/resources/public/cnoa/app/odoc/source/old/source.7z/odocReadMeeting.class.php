<?php 
class odocReadMeeting extends model{
	private $t_meeting_fenfa_check		= "meeting_mgr_fenfa_check";
	private $t_meeting_fenfa_reader		= "meeting_mgr_fenfa_reader";
	
	private $rows						= 15;
	
	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			//更新阅读情况
			case "readed" :
				$this->_readed();
				break;
			//阅读情况
			case "getReaderList" :
				$this->_getReaderList();
				break;
			//查看会议
			case "viewMeetingRoomApplyDetails" :
				app::loadApp("meeting", "mgrList")->api_viewMeetingRoomApplyDetails();
				break;
		}
	}
	
	private function _loadpage(){
		
	}
	
	private function _getJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		$storeType	= getPar($_POST, "storeType", "waiting");
		$start		= getPar($_POST, "start", 0);
		$WHERE = "WHERE 1 ";
		if($storeType == "waiting"){
			$WHERE .= "AND `status` = 0 ";
		}elseif ($storeType == "readed"){
			$WHERE .= "AND `status` = 1 ";
		}
		
		$s_name	 = getPar($_POST, "name", "");
		$s_title = getPar($_POST, "title", "");
		$s_stime = getPar($_POST, "stime", 0);
		$s_etime = getPar($_POST, "etime", 0);
		if(!empty($s_name)){
			$WHERE .= "AND `name` LIKE '%{$s_name}%' ";
		}
		if(!empty($s_title)){
			$WHERE .= "AND `title` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_stime)){
			$s_stime = strtotime($s_stime . " 00:00:00");
			$WHERE .= "AND `stime` >= '{$s_stime}' ";
		}
		if(!empty($s_etime)){
			$s_etime = strtotime($s_etime . " 23:59:59");
			$WHERE .= "AND `etime` <= '{$s_etime}' ";
		}
		$uid = $CNOA_SESSION->get("UID");
		$dblist = $CNOA_DB->db_select("*", $this->t_meeting_fenfa_reader, $WHERE . " AND `uid` = '{$uid}' ORDER BY `rid` DESC LIMIT {$start}, {$this->rows} ");
		!is_array($dblist) && $dblist = array();
		$appUidArr = array(0);
		$markUidArr = array(0);
		foreach ($dblist as $k=>$v) {
			$appUidArr[] = $v['appuid'];
			$markUidArr[] = $v['markuid'];
		}
		$uidArr = array_merge($appUidArr, $markUidArr);
		$truenameDB = app::loadApp("main", "user")->api_getUserNamesByUids($uidArr);
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['stime']	= formatDate($v['stime']);
			$dblist[$k]['etime']	= formatDate($v['etime']);
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _readed(){
		global $CNOA_DB;
		$rid = getPar($_POST, "rid", 0);
		$data['readtime'] = $GLOBALS['CNOA_TIMESTAMP'];
		$data['status']		= 1;
		$CNOA_DB->db_update($data, $this->t_meeting_fenfa_reader, "WHERE `rid` = '{$rid}'");
		msg::callBack(true, "操作成功");
	}
	
	private function _getReaderList(){
		global $CNOA_DB;
		$aid = getPar($_GET, "aid", 0);
		$dblist = $CNOA_DB->db_select(array("status", "uid", "readtime"), $this->t_meeting_fenfa_reader, "WHERE `aid` = '{$aid}' AND (`status` = 0 OR `status` = 1) ORDER BY `status` DESC");
		!is_array($dblist) && $dblist = array();
		$uidArr = array(0);
		foreach ($dblist as $k=>$v) {
			$uidArr[] = $v['uid'];
		}
		$truenameArr = app::loadApp("main", "user")->api_getUserNamesByUids($uidArr);
		!is_array($truenameArr) && $truenameArr = array();
		$deptIdArr = array(0);
		foreach ($truenameArr as $k=>$v) {
			$deptIdArr[] = $v['deptId'];
		}
		$deptNameArr = app::loadApp("main", "struct")->api_getNamesByIds($deptIdArr);
		
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['deptname']	= $deptNameArr[$truenameArr[$v['uid']]['deptId']];
			if($v['status'] == 1){
				$dblist[$k]['name']	=  "<span class='cnoa_color_red'>" . $truenameArr[$v['uid']]['truename'] . "</span>";
			}else{
				$dblist[$k]['name']	= $truenameArr[$v['uid']]['truename'];
			}
			$dblist[$k]['readtime']	= formatDate($v['readtime'], "Y-m-d H:i");
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
}
?>