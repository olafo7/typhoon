/**
 * 全局变量
 */
var CNOA_odoc_read_receive, CNOA_odoc_read_receiveClass;
CNOA_odoc_read_receiveClass = CNOA.Class.create();
CNOA_odoc_read_receiveClass.prototype = {
	init : function(){
		var _this = this;
		
		this.baseUrl = "index.php?app=odoc&func=read&action=receive";
		
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=loadColumn",
			method: 'POST',
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.layoutPanel(result);
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	layoutPanel:function(result){
		var _this = this;
			
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:true
		});
		
		this.cm = [new Ext.grid.RowNumberer(), this.sm,
			{header:lang('opt'),sortable:true,dataIndex:'id',width:50,menuDisabled:true,renderer:function(v, c, record){
				var rd = record.data;
					l = '<a href="javascript:void(0)" onclick="CNOA_odoc_read_receive.viewAttach('+v+')">查看</a>';
				return l;
			}},
			{header:'添加时间',sortable:true,dataIndex:'posttime',width:110,menuDisabled:true},
			{header:'来文机关',sortable:true,dataIndex:'deptment',width:100,menuDisabled:true},
			{header:'来文标题',sortable:true,dataIndex:'title',width:100,menuDisabled:true}
		];
		
		var fields = [{name:'id'},{name:'posttime'},{name:'status'},{name:'uFlowId'},{name:'deptment'},{name:'title'}];
		Ext.each(result.column, function(v,i){
			fields.push({name:'field_'+v.field});
			_this.cm.push({
				header			:v.title,
				sortable		:true,
				dataIndex		:'field_'+v.field,
				width			:v.width,
				menuDisabled	:true
			});
		});
		
		this.store = new Ext.data.Store({
			autoLoad: true,
			proxy: new Ext.data.HttpProxy({
				url: this.baseUrl + '&task=getJsonList'
			}),
			reader: new Ext.data.JsonReader({
				totalProperty: "total",
				root: "data",
				fields:fields
			})
		});
		
		this.grid = new Ext.grid.GridPanel({
			store:this.store,
			width:600,
			plain:false,
       		stripeRows:true,
			loadMask:{msg: lang('waiting')},
			region:"center",
			border:false,
			autoScroll:true,
			sm:this.sm,
			columns:this.cm,
			tbar:[
				{
					handler:function(button, event) {
						_this.store.reload();
					}.createDelegate(this),
					iconCls:'icon-system-refresh',
					text:lang('refresh')
				},'-',
				"<span class='cnoa_color_gray'>双击可修改记录,按住Ctrl或Shift键可以一次选择多条记录</span>"
			],
			bbar: new Ext.PagingToolbar({
				displayInfo:true,
				
				   
				store: this.store,
				pageSize:30,
				listeners: {
					"beforechange" : function(th, params){
						//Ext.apply(params, _this.search);
					}
				}
			})
		});
		
		this.treeStore = new Ext.data.Store({
			autoLoad:true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getSearchList", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:[{name:'field'},{name:'title'}]})
		});
		
		this.searchPanel = new Ext.form.FormPanel({
			region:'north',
			height:100,
			border:false,
			hidden:true,
			defaults:{
				border:false
			},
			padding:5,
			items:[
				{
					xtype:'panel',
					defaults:{
						border:false
					},
					items:[
						{
							xtype:'hidden',
							name:'id'
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:6
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong1',
									hiddenName: 'kong1',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition1',
									hiddenName:'condition1',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									name:'value1'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong1').setValue('');
										searchForm.findField('condition1').setValue('equal');
										searchForm.findField('value1').setValue('');
									}
								}
							]
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:4
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong2',
									hiddenName: 'kong2',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition2',
									hiddenName:'condition2',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									//emptyText:'查询条件',
									name:'value2'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong2').setValue('');
										searchForm.findField('condition2').setValue('equal');
										searchForm.findField('value2').setValue('');
									}
								}
							]
						},
						{
							xtype:'panel',
							layout:'table',
							layoutConfig:{
								columns:4
							},
							defaults:{
								style:'margin-left:5px;'
							},
							height:30,
							items:[								
								new Ext.form.ComboBox({
									store: _this.treeStore,
									name: 'kong3',
									hiddenName: 'kong3',
									valueField: 'field',
									displayField:'title',
									mode: 'local',
									width: 150,
									triggerAction:'all',
									forceSelection: true,
									editable: false,
									listeners:{
										select:function(th, record, oldValue){
										}
									}
								}),
								new Ext.form.ComboBox({
									store:new Ext.data.SimpleStore({
										fields:['value', 'name'],
										data:[['equal', "等于"], ['noEqual', "不等于"], ['contain', "包含"], ['dayu', "大于"], ['xiaoyu', "小于"], ['dayuEqual', "大于或等于"], ['xiaoyuEqual', "小于或等于"]]
									}),
									width:100,
									value:'equal',
									valueField:'value',
									displayField:'name',
									name:'condition3',
									hiddenName:'condition3',
									mode:'local',
									triggerAction:'all',
									forceSelection:true,
									editable:false
								}),
								{
									xtype:'textfield',
									width:200,
									//emptyText:'查询条件',
									name:'value3'
								},
								{
									xtype:'button',
									text:'重置',
									handler:function(){
										searchForm.findField('kong3').setValue('');
										searchForm.findField('condition3').setValue('equal');
										searchForm.findField('value3').setValue('');
									}
								}
							]
						}
					]
				}
			]
		});
		
		var searchForm = _this.searchPanel.getForm();
		
		this.mainPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			layout:'border',
			autoScroll:false,
			items:[this.searchPanel,this.grid]/*,
			tbar:[
				{
					text:'展开查询',
					id:'EXPAND_SEARCH_PANEL',
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						if(_this.searchExpandBtn == 'close'){
							//如果要打开
							_this.searchPanel.show();
							_this.searchExpandBtn = 'open';
							Ext.getCmp('EXPAND_SEARCH_PANEL').setText('折叠查询');
							Ext.getCmp('ID_BTN_SEARCH').show();
						}else{
							//如果要关闭
							_this.searchPanel.hide();
							_this.searchExpandBtn = 'close';
							Ext.getCmp('EXPAND_SEARCH_PANEL').setText('展开查询');
							Ext.getCmp('ID_BTN_SEARCH').hide();
						}
						_this.mainPanel.doLayout();
					}
				},
				{
					text:lang('search'),
					style: "margin-left:5px",
					id:'ID_BTN_SEARCH',
					iconCls: "icon-search",
					hidden:true,
					cls: "x-btn-over",
					enableToggle:false,
		    		//allowDepress:false,
		   	 		toggleGroup:"search_definde_btn_group",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						_this.searchDatas = searchForm.getValues();
						_this.searchDatas.search = 'now';
						_this.store.load({params:_this.searchDatas});
					}
				},
				{
					text:lang('clear'),
					style: "margin-left:5px",
					cls: "x-btn-over",
		   	 		toggleGroup:"search_definde_btn_group",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						_this.store.load();
						searchForm.reset();
						_this.searchDatas = {};
					}
				}
			]*/
		});
		
		Ext.getCmp(CNOA.odoc.read.receive.parentID).add(this.mainPanel);
		Ext.getCmp(CNOA.odoc.read.receive.parentID).doLayout();
	},
	
	viewAttach : function(id){
		var _this = this;
		
		var ID_fieldSet_Word = Ext.id();
		var ID_fieldSet_Attach = Ext.id();
		var ID_fieldSet_Form = Ext.id();
		
		var loadAttachList = function(){
			Ext.Ajax.request({
				url: _this.baseUrl + "&task=loadAttachList",
				method: 'POST',
				params:{id:id},
				success: function(r) {
					var result = Ext.decode(r.responseText);
					if(result.success === true){
						if(result.data.word){
							Ext.getCmp(ID_fieldSet_Word).show();
							Ext.getCmp(ID_fieldSet_Word).body.update(result.data.word);
						}
						if(result.data.attach){
							Ext.getCmp(ID_fieldSet_Attach).show();
							Ext.getCmp(ID_fieldSet_Attach).body.update(result.data.attach);
						}
						if(result.data.form){
							Ext.getCmp(ID_fieldSet_Form).show();
							Ext.getCmp(ID_fieldSet_Form).body.update(result.data.form);
						}
						
					}else{
						//CNOA.msg.alert(result.msg, function(){});
					}
				}
			});
		};
		
		var win = new Ext.Window({
			title:'查看发文内容',
			width:800,
			height:makeWindowHeight(Ext.getBody().getBox().height-40),
			modal:true,
			bodyStyle: 'background-color:#FFF;padding:10px;',
			autoScroll: true,
			maximizable: true,
			border:false,
			items: [
				{
					xtype: 'fieldset',
					title: '文件查看',
					hidden: true,
					id: ID_fieldSet_Word
				},
				{
					xtype: 'fieldset',
					title: '表单查看',
					hidden: true,
					id: ID_fieldSet_Form
				},
				{
					xtype: 'fieldset',
					title: '附件查看',
					hidden: true,
					id: ID_fieldSet_Attach
				}
			],
			listeners: {
				afterrender : function(){
					loadAttachList();
				}
			},
			buttons:[
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
	}
}
