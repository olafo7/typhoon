<?php 
class odocReceiveApply extends model{
	private $t_receive_list = "odoc_receive_list";
	private $t_flow			= "odoc_setting_flow";
	private $t_flow_step	= "odoc_step";
	private $t_tpl_list		= "odoc_setting_template_list";
	
	private $rows			= 15;
	
	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getTypeList" :
				app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "settingWord")->api_getLevelList();
				break;
			case "getHurryList" :
				app::loadApp("odoc", "settingWord")->api_getHurryList();
				break;
			case "getSecretList" :
				app::loadApp("odoc", "settingWord")->api_getSecretList();
				break;
			case "editOdocTemplate" :
				global $CNOA_DB, $CNOA_CONTROLLER, $CNOA_SESSION;
				$GLOBALS['receive']['title']	= getPar($_GET, "title", "");
				$GLOBALS['receive']['id']		= getPar($_GET, "id", 0);
				
				$GLOBALS['CNOA_SYSTEM_NAME']	= "收文登记";
				$GLOBALS['CNOA_USERNAME']		= $CNOA_SESSION->get("TRUENAME");
				$CNOA_CONTROLLER->loadViewCustom($CNOA_CONTROLLER->appPath . "/tpl/default/receive/editOdocTemplate.htm", true, true);
				exit;
			case "getTemplateList" :
				$typeId = getPar($_POST, "id", 0);
				app::loadApp("odoc", "settingTemplate")->api_getTemplateList($typeId, 2);
				break;
			case "newOdoc" :
				$this->_newOdoc();
				break;
			//插入登记
			case "insideOdoc" :
				$this->_insideOdoc();
				break;
			case "loadFormData" :
				$this->_loadFormData();
				break;
			case "createodoc" :
				//$this->_createodoc();
				break;
			case "delete" :
				$this->_delete();
				break;
			case "sign" :
				$this->_sign();
				break;
			case "sign2" :
				$this->_sign2();
				break;
			#转下一步，加载所有要绑定的流程列表
			case "getFlowList" :
				app::loadApp("odoc", "sendApply")->api_getFlowList("receive");
				break;
			#拟稿时，转下一步，加载指定的流程的信息及步骤列表
			case "getStepInfo" :
				app::loadApp("odoc", "sendApply")->api_getStepInfo();
				break;
			#加载指定的流程的步骤信息列表
			case "getFixedJsonData" :
				app::loadApp("odoc", "sendApply")->api_getFixedJsonData();
				break;
			case "getAllUserListsInPermitDeptTree" :
				$GLOBALS['user']['permitArea']['area'] = "all";
				$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
				echo json_encode($userList);
				exit;
				break;
			case "addDefinedFlow" :
				app::loadApp("odoc", "sendApply")->api_addDefinedFlow("receive");
				break;
			case "getDefinedJsonData" :
				app::loadApp("odoc", "sendApply")->api_getDefinedJsonData("receive");
				break;
			case "deleteDefinedData" :
				app::loadApp("odoc", "sendApply")->api_deleteDefinedData();
				break;
			case "moveDefinedData" :
				$this->_moveDefinedData();
				break;
			case "getOdocFawenForm" :
				$this->_getOdocFawenForm();
				break;
			case "loadTemplateFile" :
				$this->_loadTemplateFile();
				break;
			case "submitFormData" :
				$this->_submitFormData();
				break;
			//保存正文
			case "submitFileData" :
				$this->_submitFileData();
				break;
			#查看发文
			case 'view':
				app::loadApp("odoc", "commonView")->run("receive");
				break;
			//内部收文登记
			case "insideOdocTemplate" :
				$this->_insideOdocTemplate();
				break;
		}
	}
	
	private function _loadpage(){
		global $CNOA_CONTROLLER;
		$from = getPar($_GET, "from", "");
		$GLOBALS['receive']['from'] = $from;
		$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/receive/apply.htm';
		$CNOA_CONTROLLER->loadExtraTpl($tplPath);
		exit;
	}
	
	private function _getJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$cuid	= $CNOA_SESSION->get('UID');
		
		$WHERE = "WHERE 1 ";
		
		$start	= getPar($_POST, "start", 0);
		
		$s_title	= getPar($_POST, "title", "");
		$s_number	= getPar($_POST, "number", "");
		$s_type		= getPar($_POST, "type", 0);
		$s_level	= getPar($_POST, "level", 0);
		$s_hurry	= getPar($_POST, "hurry", 0);
		
		$storeType	= getPar($_POST, "storeType", "waiting");
		if($storeType == "waiting"){
			$WHERE .= "AND `status` = '0' ";
		}elseif($storeType == "working"){
			$WHERE .= "AND `status` = '1' ";
		}elseif($storeType == "end"){
			$WHERE .= "AND `status` = '2' ";
		}
		
		if(!empty($s_title)){
			$WHERE .= "AND `title` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_number)){
			$WHERE .= "AND `number` LIKE '%{$s_number}%' ";
		}
		if(!empty($s_type)){
			$WHERE .= "AND `type` = '{$s_type}' ";
		}
		if(!empty($s_level)){
			$WHERE .= "AND `level` = '{$s_level}' ";
		}
		if(!empty($s_hurry)){
			$WHERE .= "AND `hurry` = '{$s_hurry}' ";
		}
		
		$WHERE .= " AND `createuid`={$cuid} ";
		
		$dblist = $CNOA_DB->db_select("*", $this->t_receive_list, $WHERE . "ORDER BY `id` DESC LIMIT {$start}, {$this->rows}");
		!is_array($dblist) && $dblist = array();
		$typeArr	= app::loadApp("odoc", "settingWord")->api_getTypeAllArr();
		$levelArr	= app::loadApp("odoc", "settingWord")->api_getLevelAllArr();
		$hurryArr	= app::loadApp("odoc", "settingWord")->api_getHurryAllArr();
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['type']			= $typeArr[$v['type']]['title'];
			$dblist[$k]['level']		= $levelArr[$v['level']]['title'];
			$dblist[$k]['hurry']		= $hurryArr[$v['hurry']]['title'];
			$dblist[$k]['createtime']	= formatDate($v['createtime'], "Y-m-d H:i");
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		$dataStore->total = $CNOA_DB->db_getcount($this->t_receive_list, $WHERE);
		
		
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _newOdoc(){
		global $CNOA_DB, $CNOA_SESSION;
		$data['createuid']	= $CNOA_SESSION->get("UID");
		$data['createtime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['title']		= getPar($_POST, "title", "");
		$data['tempid']		= getPar($_POST, "template", 0);
		$data['type']		= getPar($_POST, "type", "");
		$data['from']		= 2;
		$data['stepid']		= 1;
		$id = $CNOA_DB->db_insert($data, $this->t_receive_list);
		$flow['fromId']		= $id;
		$flow['fromType']	= 2;
		$flow['stepid']		= 1;
		$flow['stepname']	= "收文登记";
		$flow['stepType']	= 1;
		$temp = app::loadApp("main", "struct")->api_getDeptByUid($data['createuid']);
		$flow['detpId']		= $temp['id'];
		$flow['deptName']	= $temp['name'];
		$flow['uname']		= $CNOA_SESSION->get('TRUENAME');;
		$flow['uid']		= $data['createuid'];
		$flow['status']		= 1;
		$flow['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
		$flow['etime']		= $flow['stime'];
		$CNOA_DB->db_insert($flow, $this->t_flow_step);
		echo "{success:true, msg:'操作成功', id : {$id}}";
		exit();
	}
	
	private function _insideOdoc(){
		global $CNOA_DB;
		$id = getPar($_GET, "id", 0);
		$data['tempid']		= getPar($_POST, "template", 0);
		$data['type']		= getPar($_POST, "type", "");
		$CNOA_DB->db_update($data, $this->t_receive_list, "WHERE `id` = '{$id}'");
		echo "{success:true, msg:'操作成功', id : {$id}}";
		exit();
	}
	
	private function _loadFormData(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid = $CNOA_SESSION->get("UID");
		$id = getPar($_POST, "id", 0);
		$data = $CNOA_DB->db_getone("*", $this->t_receive_list, "WHERE `id` = '{$id}'");
		$userInfo = app::loadApp("main", "user")->api_getUserDataByUid($uid);
		$deptmentInfo = app::loadApp("main", "struct")->api_getInfoById($userInfo['deptId']);
		$data['createpeople']	= $userInfo['truename'];
		$data['createdept']		= $deptmentInfo['name'];
		$data['receivedate']	= formatDate($data['receivedate']);
		//获取附件信息
		$fs = new fs();
		$data['attach']			 = $fs->getEditList(json_decode($data['attach'], true));
		
		$dataStore = new dataStore();
		$dataStore->data = $data;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _createodoc(){
		global $CNOA_DB;
		$id = getPar($_POST, "id", 0);
		
		$data['title']	= getPar($_POST, "title", "");
		$data['number']	= getPar($_POST, "number", "");
		
		$num = $CNOA_DB->db_getcount($this->t_receive_list, "WHERE `id` != '{$id}' AND `title` = '{$data['title']}' ");
		if($num > 0){
			msg::callBack(false, "已存在该名称");
		}
		
		$data['fromdept'] 		= getPar($_POST, "fromdept", "");
		$data['receivedept']	= getPar($_POST, "receivedept", "");
		$data['receivedate']	= strtotime(getPar($_POST, "receivedate", 0));
		$data['level']			= getPar($_POST, "level", 0);
		$data['secret']			= getPar($_POST, "secret", 0);
		$data['hurry']			= getPar($_POST, "hurry", 0);
		$data['many']			= getPar($_POST, "many", 0);
		$data['summary']		= getPar($_POST, "summary", "");
		
		$attach = $CNOA_DB->db_getfield("attach", $this->t_receive_list, "WHERE `id` = '{$id}'");
		
		$fs = new fs();
		$filesUpload = getPar($_POST, "filesUpload", array());
		$attach = $fs->edit($filesUpload, json_decode($attach, false), 17);
		$data['attach'] = json_encode($attach);
		
		$CNOA_DB->db_update($data, $this->t_receive_list, "WHERE `id` = '{$id}'");
		msg::callBack(true, "操作成功");
	}
	
	private function _delete(){
		global $CNOA_DB;
		$id = getPar($_POST, "id", 0);
		$CNOA_DB->db_delete($this->t_receive_list, "WHERE `id`='{$id}'");
		msg::callBack(true, "操作成功");
	}
	
	private function _sign(){
		global $CNOA_DB;
		$ids = getPar($_POST, "ids", 0);
		$data['status'] = 1;
		$CNOA_DB->db_update($data, $this->t_receive_list, "WHERE `id` = '{$id}' ");
		msg::callBack(true, "操作成功");
	}
	
	private function _sign2(){
		global $CNOA_DB;
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		$data['status'] = 2;
		foreach ($idArr as $v) {
			$CNOA_DB->db_update($data, $this->t_receive_list, "WHERE `id` = '{$v}' ");
		}
		msg::callBack(true, "操作成功");
	}
	
	private function _moveDefinedData(){
		global $CNOA_DB;
		$fid = getPar($_POST, "fid", 0);
		$CNOA_DB->db_update(array("status"=>1), $this->t_receive_list, "WHERE `id` = '{$fid}'");
		
		app::loadApp("odoc", "sendApply")->api_moveDefinedData("receive");
	}
	
	private function _getFlowList(){
		global $CNOA_DB;
		
		$WHERE = "WHERE `which`=1 AND `active`=1";
		
		$dblist = $CNOA_DB->db_select(array("id", "flowname"), $this->t_flow, $WHERE . " ORDER BY `id` DESC");
		!is_array($dblist) && $dblist = array();
		
		$data = array();
		foreach ($dblist as $k=>$v) {
			$data[] = array("id"=>$v['id'], "name"=>$v['flowname']);
		}
		$dataStore = new dataStore();
		$dataStore->data = $data;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _getOdocFawenForm(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$id		= intval(getPar($_GET, "id", ""));
		$from	= getPar($_GET, 'OdocFawenForm_from');
		
		$info = $CNOA_DB->db_getone("*", $this->t_receive_list, "WHERE `id`='{$id}'");

		if(empty($info['form'])){
			#如果未打开过表单，则从模板转换过来
			$form = app::loadApp("odoc", "common")->getFormFromTplById($info['tempid']);
			$CNOA_DB->db_update(array("form"=>addslashes($form)), $this->t_receive_list, "WHERE `id`='{$id}'");
		}else{
			#如果打开过表单，则直接显示
			$form = $info['form'];
		}
		
		if(!empty($info['formdata'])){
			$form = app::loadApp("odoc", "common")->getFormWithValue($form, json_decode($info['formdata'], true));
		}
		
		//去掉双引号及换行符号
		$form = str_replace(
			array("\r\n", "\n", "\""),
			array("&#13;", "&#13;", "'"),
			$form
		);
		
		if($from == 'check'){
			$js = file_get_contents(CNOA_PATH . "/app/odoc/scripts/receive_checkOdocTemplate.js");
		}else{
			$js = file_get_contents(CNOA_PATH . "/app/odoc/scripts/receive_editOdocTemplate.js");
		}
		$js = str_replace("{FAWENFORM}", $form, $js);
		header('Content-type: text/javascript');
		echo $js;
		exit();
	}
	
	private function _loadTemplateFile(){
		global $CNOA_DB;

		$id = intval(getPar($_GET, "id", 0));
		$filePath = CNOA_PATH_FILE . "/common/odoc/receive/{$id}/doc.history.0.php";
		
		if(file_exists($filePath)){
			$file = @file_get_contents($filePath);
		}else{
			$tempId = $CNOA_DB->db_getfield("tempid", $this->t_receive_list, "WHERE `id`='{$id}'");
			$template = $CNOA_DB->db_getfield("template", $this->t_tpl_list, "WHERE `id`='{$tempId}'");
			$tplFile = CNOA_PATH_FILE . "/common/odoc/template/{$tempId}/{$template}.php";

			if(file_exists($tplFile)){
				$file = @file_get_contents($tplFile);
				mkdirs(dirname($filePath));
				file_put_contents($filePath, $file);
			}else{
				$file = " ";
			}
		}
		
		/*
		if(($docfile !== false) && empty($docfile['docfile'])){
			$tplFile = $CNOA_DB->db_getfield("template", $this->t_tpl_list, "WHERE `id`='{$docfile['tempid']}'");
			if(!$tplFile){
				$file = "";
			}else{
				$file = @file_get_contents(CNOA_PATH_FILE . "/common/odoc/template/{$docfile['tempid']}/{$tplFile}.php");
				$filePath = CNOA_PATH_FILE . "/common/odoc/send/{$id}/doc.history.0.php";
				mkdirs(dirname($filePath));
				
				file_put_contents($filePath, $file);
			}
		}else{
			$file = " ";
		}
		*/
		
		echo $file;
		exit;
	}
	
	private function _submitFormData(){
		global $CNOA_DB, $CNOA_SESSION;

		$id = getPar($_POST, "id", 0);
		
		$info = $CNOA_DB->db_getone("*", $this->t_receive_list, "WHERE `id`='{$id}'");
		
		#保存进暂存字段
		$formdata = addslashes(json_encode($_POST));
		
		#处理表单数据
		$data = array();
		$data['formdata']	= $formdata;
		$data['createuid']	= $CNOA_SESSION->get("UID");
		$data['createtime']	= $GLOBALS['CNOA_TIMESTAMP'];
		
		foreach($_POST AS $k=>$v){
			$name = preg_replace("/id_[0-9]{1,}__(.*)/is", "\\1", $k);
			$in_array = array("number", "title", "sign", "createdept", "createname_receive", "level", "hurry", "page", "many", "range", "senddate");
			if(in_array($name, $in_array)){
				if($name == "createname_receive"){
					$name = "createname";
				}
				$data[$name] = $v;
			}
		}
		
		$attach = $CNOA_DB->db_getfield("attach", $this->t_receive_list, "WHERE `id` = '{$id}'");

		$fs = new fs();
		$filesUpload = getPar($_POST, "filesUpload", array());
		$attach = $fs->edit($filesUpload, json_decode($attach, false), 17);
		$data['attach'] = json_encode($attach);
		
		$CNOA_DB->db_update($data, $this->t_receive_list, "WHERE `id`='{$id}'");
		
		#保存历史页面进缓存文件
		$formHtml = app::loadApp("odoc", "common")->getHtmlWithValue($info['form'], $_POST);
		app::loadApp("odoc", "common")->saveHistory($id, $formHtml, 0, "receive");
		
		msg::callBack(true, "操作成功");
		exit();
	}
	
	public function _submitFileData(){
		global $CNOA_DB;
		$id = intval(getPar($_POST, "id", 0));

		$uploadfile = CNOA_PATH_FILE . "/common/odoc/receive/{$id}/doc.history.0.php";
		mkdirs(dirname($uploadfile));
		
		if(!move_uploaded_file($_FILES['docFile']['tmp_name'], $uploadfile)){
			echo '0';exit;
		}

		echo '1';
		exit;
	}
	
	public function api_getAllData($idArr){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select("*", $this->t_receive_list, "WHERE `id` IN (" . implode(",", $idArr) . ")");
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v) {
			$data[$v['id']] = $v;
		}
		return $data;
	}
	
	
	
	//private function __addRecvDoc($uid, $title, $tempid, $type, $number = '', $fromdept = '', $recvdept = '', $recvdate = '', $many = '', $form = '', $formdata = '', $attach = ''){
	private function __addRecvDoc($arg){
		global $CNOA_DB, $CNOA_SESSION;
		
		//$arg = array();
		$uid		= $arg['uid'];
		$title		= $arg['title'];
		$tempid		= $arg['tempid'];
		$type		= $arg['type'];
		$number		= $arg['number'];
		$fromdept	= $arg['fromdept'];
		$recvdept	= $arg['recvdept'];
		$recvdate	= $arg['recvdate'];
		$many		= $arg['many'];
		$form		= $arg['form'];
		$formdata	= $arg['formdata'];
		$attach		= $arg['attach'];
		$level		= $arg['level'];
		$hurry		= $arg['hurry'];
		
		$data['createuid']	= $uid;
		$data['createtime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['title']		= $title;
		$data['tempid']		= $tempid;
		$data['type']		= $type;
		$data['from']		= 1;
		$data['stepid']		= 1;
		
		//title 名称	number 文号	fromdept 来文机关	receivedept 收文单位	receivedate 收文日期(自己填的)
		//
		$data['number']			= $number;
		$data['fromdept']		= $fromdept;
		$data['receivedept']	= $recvdept;
		$data['receivedate']	= $recvdate;
		$data['many']			= $many;
		$data['form']			= addslashes($form);
		$data['formdata']		= addslashes($formdata);
		$data['level']			= $level;
		$data['hurry']			= $hurry;
		
		//debug::xprint($data); return;		
		$id = $CNOA_DB->db_insert($data, $this->t_receive_list);
		
		
		$flow['fromId']		= $id;
		$flow['fromType']	= 2;
		$flow['stepid']		= 1;
		$flow['stepname']	= "收文登记";
		$flow['stepType']	= 1;
		$temp = app::loadApp("main", "struct")->api_getDeptByUid($data['createuid']);
		$flow['detpId']		= $temp['id'];
		$flow['deptName']	= $temp['name'];
		$flow['uname']		= $CNOA_SESSION->get('TRUENAME');;
		$flow['uid']		= $data['createuid'];
		$flow['status']		= 1;
		$flow['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
		$flow['etime']		= $flow['stime'];
		$CNOA_DB->db_insert($flow, $this->t_flow_step);
		//echo "{success:true, msg:'操作成功', id : {$id}}";
		//exit();
		return $id;
	}
	
	
	
	//public function api_addRecvDoc($uid, $title, $tempid, $type, $number = '', $fromdept = '', $recvdept = '', $recvdate = '', $many = '', $form = '', $formdata = '', $attach = ''){
	//	return $this->__addRecvDoc($uid, $title, $tempid, $type, $number, $fromdept, $recvdept, $recvdate, $many, $form, $formdata, $attach);
	public function api_addRecvDoc($arg){
		return $this->__addRecvDoc($arg);
	}
}
?>