/**
 * 全局变量
 */

var CNOA_odoc_files_brwchk, CNOA_odoc_files_brwchkClass;
CNOA_odoc_files_brwchkClass = CNOA.Class.create();
CNOA_odoc_files_brwchkClass.prototype = {
	init : function(){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NUMBER	= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_HURRY		= Ext.id();
		var ID_BTN_AGREE		= Ext.id();
		var ID_BTN_DISAGREE		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=files&action=brwchk";
		
		this.storeBar = {
			storeType : "waiting",
			title : "",
			number : "",
			type : "",
			level : "",
			hurry : ""
		};
		
		this.fields = [
			{name:"id"},
			{name:"fileid"},
			{name:"title"},
			{name:"status"},
			{name:"number"},
			{name:"type"},
			{name:"type1"},
			{name:"level"},
			{name:"wenzhong"},
			{name:"danganshi"},
			{name:"anjuan"},
			{name:"anjuandate"},
			{name:"filesnum"},
			{name:"page"},
			{name:"reader"},
			{name:"stime"},
			{name:"etime"},
			{name:"deptment"},
			{name:"posttime"},
			{name:'senddate'},
			{name:'reason'}
		];
		
		this.store = new Ext.data.Store({
			autoLoad : true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				}
			}
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: false
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "id", dataIndex: 'id', hidden: true},
			{header: '操作', dataIndex: 'fileid', width: 80, sortable: true, menuDisabled :true, renderer : this.operate.createDelegate(this)},
			//{header: '状态', dataIndex: 'status', width: 80, sortable: true, menuDisabled :true},
			{header: '类型', dataIndex: 'type', width: 80, sortable: true, menuDisabled :true},
			{header: '密级', dataIndex: 'level', width: 80, sortable: true, menuDisabled :true},
			{header: '文件提名', dataIndex: 'title', width: 120, sortable: true, menuDisabled :true},
			{header: '借阅人部门', dataIndex: 'deptment', width: 140, sortable: true, menuDisabled :true},
			{header: '借阅人', dataIndex: 'reader', width: 80, sortable: true, menuDisabled :true},
			{header: '提交时间', dataIndex: 'posttime', width: 100, sortable: true, menuDisabled :true},
			{header: '成文日期', dataIndex: 'senddate', width: 100, sortable: true, menuDisabled :true},
			{header: '借阅开始时间', dataIndex: 'stime', width: 100, sortable: true, menuDisabled :true},
			{header: '借阅结束时间', dataIndex: 'etime', width: 100, sortable: true, menuDisabled :true},
			{header: '档案室', dataIndex: 'danganshi', width: 100, sortable: true, menuDisabled :true},
			{header: '类目', dataIndex: 'type1', width: 100, sortable: true, menuDisabled :true},
			{header: '案卷', dataIndex: 'anjuan', width: 80, sortable: true, menuDisabled :true},
			{header: '文种', dataIndex: 'wenzhong', width: 80, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		/**
		 * 
			layout:"fit",
			border : false,
	        store: this.store,
	        trackMouseOver:false,
	        disableSelection:true,
	        loadMask: true,
			autoScroll : true,
		 */
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			layout:"fit",
			border:false,
			trackMouseOver:false,
	        disableSelection:true,
			autoScroll : true,
			store:this.store,
			loadMask : {msg: lang('loading')},
			cm: this.colModel,
			sm: this.sm,
			hideBorders: true,
	        viewConfig: {
	            forceFit:true,
	            enableRowBody:true,
	            showPreview:true,
	            getRowClass : function(record, rowIndex, p, store){
	                if(this.showPreview){
	                    p.body = '<div style="padding-left:45px;" class="cnoa_color_gray"><div style=" width:60px; float:left">借阅原因: </div><div style="width:700px; float:left;">'+record.data.reason+'</div></div>';
	                }
	            }
	        },
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "waiting";
						_this.store.load({params: _this.storeBar});
						Ext.getCmp(ID_BTN_AGREE).show();
						Ext.getCmp(ID_BTN_DISAGREE).show();
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					pressed: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示待审批的公文列表",
					text : '待审批'
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "pass";
						_this.store.load({params: _this.storeBar});
						Ext.getCmp(ID_BTN_AGREE).hide();
						Ext.getCmp(ID_BTN_DISAGREE).hide();
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示已审批的公文列表",
					text : '已审批'
				},"-",
				{
					handler : function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, "您还没有选择信息");
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要同意该借阅吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.submit(ids, "agree");
								}
							});
						}
					}.createDelegate(this),
					id : ID_BTN_AGREE,
					iconCls: 'icon-dialog-ok-apply',
					text : "同意"
				},"-",
				{
					handler : function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, "您还没有选择信息");
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要不同意该借阅吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.submit(ids, "disagree");
								}
							});
						}
					}.createDelegate(this),
					id : ID_BTN_DISAGREE,
					iconCls: 'icon-order-s-close',
					text : "不同意"
				},
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid]//,
			/*tbar : [
				"标题: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TITLE
				},
				"文号: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_NUMBER
				},"类型: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.typeListStore,
					width: 100,
					id : ID_SEARCH_TYPE,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"密级: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.levelListStore,
					width: 100,
					id : ID_SEARCH_LEVEL,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"缓急: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.hurryListStore,
					width: 100,
					id : ID_SEARCH_HURRY,
					hiddenName: 'tid',
					valueField: 'tid',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				{
					xtype: "button",
					text: "查询",
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.number 		= Ext.getCmp(ID_SEARCH_NUMBER).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						_this.storeBar.level 		= Ext.getCmp(ID_SEARCH_LEVEL).getValue();
						_this.storeBar.hurry 		= Ext.getCmp(ID_SEARCH_HURRY).getValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:"清空",
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NUMBER).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
						Ext.getCmp(ID_SEARCH_HURRY).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.number 		= "";
						_this.storeBar.type 		= "";
						_this.storeBar.level 		= "";
						_this.storeBar.hurry 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]*/
		});
	},
	
	submit : function(ids, type){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + '&task=submit',
			params: {ids : ids, from : type},
			method: "POST",
			success: function(r, opts) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.store.reload();
				}else{
					CNOA.msg.alert(result.msg, function(){
						_this.store.reload();
					});
				}
			},
			failure: function(response, opts) {
				CNOA.msg.alert(result.msg, function(){
					_this.store.reload();
				});
			}
		});
	},
	
	operate : function(value) {
		var _this	= this;
		var sUrl	= _this.baseUrl;
		
		var x = (screen.availWidth - 850);
		var y = (screen.availHeight - 600);
		var sWin	= 'window.open("' + sUrl + '&task=view&act=getHtml&id=' + value + '", "", "width=890,height=500,left=' + x +',top=' + y + ',scrollbars=yes,resizable=yes,status=no");';
		
		return "<a href='javascript:void(0)' onclick='" + sWin + "'>查看档案</a>";
	}
}
