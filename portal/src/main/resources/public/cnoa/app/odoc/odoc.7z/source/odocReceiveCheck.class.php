<?php 
class odocReceiveCheck extends model{
	private $t_step_list	= "odoc_step";
	private $t_receive_list	= "odoc_receive_list";
	private $t_tpl_list		= "odoc_setting_template_list";
	
	private $rows			= 15;
									
	/**
	 * 构造函数
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * 析构函数
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getTypeList" :
				app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "settingWord")->api_getLevelList();
				break;
			case "getHurryList" :
				app::loadApp("odoc", "settingWord")->api_getHurryList();
				break;
			case "submit" :
				$from = getPar($_POST, "from", "agree");
				if($from == "agree") {
					$this->_agree();
				}elseif ($from == "disagree") {
					$this->_disagree();
				}
				break;
			case "checkOdocTemplate" :
				global $CNOA_DB, $CNOA_CONTROLLER, $CNOA_SESSION;
				$GLOBALS['title']	= getPar($_GET, "title", "");
				$id					= getPar($_GET, "id", 0);
				$GLOBALS['id']		= $CNOA_DB->db_getfield("fromId", $this->t_step_list, "WHERE `id` = '{$id}'");
				$GLOBALS['stepId']	= $id;
				$GLOBALS['CNOA_SYSTEM_NAME']	= "收文办理";
				$GLOBALS['CNOA_USERNAME']		= $CNOA_SESSION->get("TRUENAME");
				$CNOA_CONTROLLER->loadViewCustom($CNOA_CONTROLLER->appPath . "/tpl/default/receive/checkOdocTemplate.htm", true, true);
				exit;
			//获取模板
			case "loadTemplateFile" :
				$this->_loadTemplateFile();
				break;
			//获取表单
			case "getOdocFawenForm" :
				$this->_getOdocFawenForm();
				break;
			//保存表单
			case "submitFormData" :
				$this->_submitFormData();
				break;
			//保存正文
			case "submitFileData" :
				$this->_submitFileData();
				break;
			//下一步骤
			case "nextstep" :
				$this->_nextstep();
				break;
			case "loadFormData" :
				$this->_loadFormData();
				break;
			//获取流程列表
			case "getStepList" :
				$this->_getStepList();
				break;
		}
	}
	
	private function _loadpage(){
		
	}
	
	private function _getJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid = $CNOA_SESSION->get("UID");
		$WHERE		= "WHERE 1 ";
		$start		= getPar($_POST, "start", 0);
		
		$storeType = getPar($_POST, "storeType", "waiting");
		
		if($storeType == "waiting"){
			$WHERE .= "AND `status` = '1' ";
		}elseif ($storeType == "check"){
			$WHERE .= "AND `status` = '2' ";
		}
		
		$search = $this->__searchForJson();
		$WHERE .= "AND `fromId` IN (" . implode(",", $search) . ") ";
	
		$dblist = $CNOA_DB->db_select("*", $this->t_step_list, $WHERE . "AND `uid` = '{$uid}' AND `fromType` = '2' AND `stepid` != 1 ORDER BY `id` DESC LIMIT {$start}, {$this->rows}");
		!is_array($dblist) && $dblist = array();
		$idArr = array(0);
		foreach ($dblist as $k=>$v) {
			$idArr[] = $v['fromId'];
			
		}
		$receiveArr = app::loadApp("odoc", "receiveApply")->api_getAllData($idArr);
		$typeArr	= app::loadApp("odoc", "settingWord")->api_getTypeAllArr();
		$levelArr	= app::loadApp("odoc", "settingWord")->api_getLevelAllArr();
		$hurryArr	= app::loadApp("odoc", "settingWord")->api_getHurryAllArr();
	
		foreach ($dblist as $k=>$v) {
			//$dblist[$k]['steptitle']= $v['title'];
			$dblist[$k]['title']	= $receiveArr[$v['fromId']]['title'];
			$dblist[$k]['number']	= $receiveArr[$v['fromId']]['number'];
			$dblist[$k]['type']		= $typeArr[$receiveArr[$v['fromId']]['type']]['title'];
			$dblist[$k]['level']	= $levelArr[$receiveArr[$v['fromId']]['level']]['title'];
			$dblist[$k]['hurry']	= $hurryArr[$receiveArr[$v['fromId']]['hurry']]['title'];
			$dblist[$k]['createtime']	= formatDate($receiveArr[$v['fromId']]['createtime'], "Y-m-d H:i");
		}
		
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function __searchForJson(){
		global $CNOA_DB;
		
		$s_title	= getPar($_POST, "title", "");
		$s_number	= getPar($_POST, "number", "");
		$s_type		= getPar($_POST, "type", 0);
		$s_level	= getPar($_POST, "level", 0);
		$s_hurry	= getPar($_POST, "hurry", 0);
		
		$WHERE = "WHERE 1 ";
		
		if(!empty($s_title)){
			$WHERE .= "AND `title` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_number)){
			$WHERE .= "AND `number` LIKE '%{$s_number}%' ";
		}
		if(!empty($s_type)){
			$WHERE .= "AND `type` = '{$s_type}' ";
		}
		if(!empty($s_level)){
			$WHERE .= "AND `level` = '{$s_level}' ";
		}
		if(!empty($s_hurry)){
			$WHERE .= "AND `hurry` = '{$s_hurry}' ";
		}
		
		$dblist = $CNOA_DB->db_select(array("id"), $this->t_receive_list, $WHERE);
		!is_array($dblist) && $dblist = array();
		$data = array(0);
		foreach ($dblist as $k=>$v) {
			$data[] = $v['id'];
		}
		return $data;
	}
	
	private function _loadTemplateFile(){
		global $CNOA_DB;

		$id = intval(getPar($_GET, "id", 0));
		
		
		$info = $CNOA_DB->db_getone("*", $this->t_receive_list, "WHERE `id`='{$id}'");
		
		#找出当前最后一个正在办理的步骤
		$maxid = $CNOA_DB->db_getmax("id", $this->t_step_list, "WHERE `fromType`=2 AND `fromId`='{$id}' AND `status`=2");
		
		$formPath = CNOA_PATH_FILE. "/common/odoc/receive/{$id}/doc.history.{$maxid}.php";
		
		if (file_exists($formPath)){
			$form = file_get_contents($formPath);
		}else{
			$form = "无正文内容";
		}
		echo $form;	
		exit();
	}
	
	private function _getOdocFawenForm(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$id		= intval(getPar($_GET, "id", ""));
		$from	= getPar($_GET, 'OdocFawenForm_from');
		
		$info = $CNOA_DB->db_getone("*", $this->t_receive_list, "WHERE `id`='{$id}'");

		if(empty($info['form'])){
			#如果未打开过表单，则从模板转换过来
			$form = app::loadApp("odoc", "common")->getFormFromTplById($info['tempid']);
			$CNOA_DB->db_update(array("form"=>addslashes($form)), $this->t_receive_list, "WHERE `id`='{$id}'");
		}else{
			#如果打开过表单，则直接显示
			$form = $info['form'];
		}
		
		if(!empty($info['formdata'])){
			$form = app::loadApp("odoc", "common")->getFormWithValue($form, json_decode($info['formdata'], true));
		}
		
		//去掉双引号及换行符号
		$form = str_replace(
			array("\r\n", "\n", "\""),
			array("&#13;", "&#13;", "'"),
			$form
		);
		
		$js = file_get_contents(CNOA_PATH . "/app/odoc/scripts/receive_checkOdocTemplate.js");
		$js = str_replace("{FAWENFORM}", $form, $js);
		header('Content-type: text/javascript');
		echo $js;
		exit();
	}
	
	private function _submitFormData(){
		global $CNOA_DB, $CNOA_SESSION;

		$id = getPar($_POST, "id", 0);
		
		$info = $CNOA_DB->db_getone("*", $this->t_receive_list, "WHERE `id`='{$id}'");
		
		#保存进暂存字段
		$formdata = addslashes(json_encode($_POST));
		
		#处理表单数据
		$data = array();
		$data['formdata']	= $formdata;
		
		foreach($_POST AS $k=>$v){
			$name = preg_replace("/id_[0-9]{1,}__(.*)/is", "\\1", $k);
			$in_array = array("number", "title", "sign", "createdept", "createname_receive", "level", "hurry", "page", "many", "range", "senddate");
			if(in_array($name, $in_array)){
				if($name == "createname_receive"){
					$name = "createname";
				}
				$data[$name] = $v;
			}
		}
		/*
		$attach = $CNOA_DB->db_getfield("attach", $this->t_receive_list, "WHERE `id` = '{$id}'");

		$fs = new fs();
		$filesUpload = getPar($_POST, "filesUpload", array());
		$attach = $fs->edit($filesUpload, json_decode($attach, false), 17);
		$data['attach'] = json_encode($attach);
		*/
		$CNOA_DB->db_update($data, $this->t_receive_list, "WHERE `id`='{$id}'");
		#保存历史页面进缓存文件
		$formHtml = app::loadApp("odoc", "common")->getHtmlWithValue($info['form'], $_POST);
		app::loadApp("odoc", "common")->saveHistory($id, $formHtml, 0, "receive");
		
		msg::callBack(true, lang('successopt'));
		exit();
	}
	
	public function _submitFileData(){
		global $CNOA_DB;
		$id = intval(getPar($_POST, "id", 0));
		//$CNOA_DB->db_getfield("", $this->t_step_list, "WHERE `fromType` = 2 AND `fromId` = '{$id}' AND  ");
		$uploadfile = CNOA_PATH_FILE . "/common/odoc/receive/{$id}/doc.history.0.php";
		mkdirs(dirname($uploadfile));
		
		if(!move_uploaded_file($_FILES['msOffice']['tmp_name'], $uploadfile)){
			echo '0';exit;
		}

		echo '1';
		exit;
	}
	
	private function _agree(){
		global $CNOA_DB, $CNOA_SESSION;
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		$uid = $CNOA_SESSION->get("UID");
				
		foreach ($idArr as $k=>$v) {
			$temp = $CNOA_DB->db_getone(array("id", "fromId", "title"), $this->t_step_list, "WHERE `id` > '{$v}' ORDER BY `id` ASC ");
			if($temp['id'] == ""){
				$update['checked'] = 1;
			}else{
				$CNOA_DB->db_update(array("status"=>1, "stime"=>$GLOBALS['CNOA_TIMESTAMP']), $this->t_step_list, "WHERE `id` = '{$temp['id']}'");
			}
			$CNOA_DB->db_update($update, $this->t_receive_list, "WHERE `id` = '{$temp['fromId']}'");
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('', 3103, '同意', "审核收文（{$temp['title']}）");
		}	
		msg::callBack(true, lang('successopt'));
	}
	
	private function _disagree(){
		global $CNOA_DB, $CNOA_SESSION;
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		$uid = $CNOA_SESSION->get("UID");
		$CNOA_DB->db_update(array("etime"=>$GLOBALS['CNOA_TIMESTAMP'], "status"=>2), $this->t_step_list, "WHERE `id` IN ({$ids}) AND `status` = '1' AND `uid` = '{$uid}' ");

		foreach ($idArr as $k=>$v) {
			$temp = $CNOA_DB->db_getone(array("id", "fromId"), $this->t_step_list, "WHERE `id` > '{$v}' ORDER BY `id` ASC ");
			if($temp['id'] == ""){
				$update['checked'] = 2;
			}else{
				$CNOA_DB->db_update(array("status"=>1, "stime"=>$GLOBALS['CNOA_TIMESTAMP']), $this->t_step_list, "WHERE `id` = '{$temp['id']}'");
			}
			$CNOA_DB->db_update($update, $this->t_receive_list, "WHERE `id` = '{$temp['fromId']}'");
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('', 3103, '不同意', "审核收文（{$temp['title']}）");
		}
		msg::callBack(true, lang('successopt'));
	}
	
	private function _nextstep(){
		global $CNOA_DB, $CNOA_SESSION;
		$id		= getPar($_POST, "id", 0);
		$say	= getPar($_POST, "say", "");
		$temp	= $CNOA_DB->db_getone(array("fromType", "stepid", "fromId", "noticeid_c", "todoid_c"), $this->t_step_list, "WHERE `id` = '{$id}' ");
		//notice::doneN($temp['noticeid_c']);
		//notice::doneT($temp['todoid_c']);
		
		$stepid = $temp['stepid'] + 1;
		$next	= $CNOA_DB->db_getone(array("id", "uid", "fromId"), $this->t_step_list, "WHERE `fromId` = '{$temp['fromId']}' AND `stepid` = '{$stepid}' AND `fromType` = '2' ");
		$CNOA_DB->db_update(array("status"=>2, "say"=>$say, "etime"=>$GLOBALS['CNOA_TIMESTAMP']), $this->t_step_list, "WHERE `id` = '{$id}' ");
		$fid	= $temp['fromId'];
		
		//修改快照文件名称
		$path = CNOA_PATH_FILE. '/common/odoc/receive/'. $fid .'/';
		@rename($path . 'form.history.0.php', $path . 'form.history.'.$id.'.php');
		@rename($path . 'doc.history.0.php', $path . 'doc.history.'.$id.'.php');
		$info = $CNOA_DB->db_getone(array("title", "number", "createuid"), $this->t_receive_list, "WHERE `id` = '{$temp['fromId']}'");
		
		if(!empty($next['id'])){
			
			$noticeT = "公文管理";
			$noticeC = lang('title')."[" . $info['title'] . "]需要您审批";
			$noticeH	= "index.php?app=odoc&func=receive&action=check";
			$noticeid_c = notice::add($next['uid'], $noticeT, $noticeC, $noticeH, 0, 18, $CNOA_SESSION->get('UID'));
			/*
			$notice['touid']	= $next['uid'];
			$notice['from']		= 18;
			$notice['fromid']	= $temp['fromId'];
			$notice['href']		= $noticeH;
			$notice['title']	= $noticeC;
			$notice['funname']	= "公文收文管理";
			$notice['move']		= "审批";
			$todoid_c = notice::add2($notice);
			*/
			$CNOA_DB->db_update(array("status"=>1, "stime"=>$GLOBALS['CNOA_TIMESTAMP']), $this->t_step_list, "WHERE `id` = '{$next['id']}'");
			
			msg::callBack(true, "操作成功，流程已经到下一步了");
		}else{
			$noticeT = "公文管理";
			$noticeC = lang('title')."[" . $info['title'] . "]流程已经完成";
			$noticeH	= "index.php?app=odoc&func=receive&action=apply&from=done";
			
			notice::add($info['createuid'], $noticeT, $noticeC, $noticeH, 0, 18, $CNOA_SESSION->get('UID'));
			
			$CNOA_DB->db_update(array("status"=>2, "senddate"=>$GLOBALS['CNOA_TIMESTAMP']), $this->t_receive_list, "WHERE `id` = '{$temp['fromId']}'");
			msg::callBack(true, "您已经是最后一步了，流程已全部走完");
		}
	}
	
	private function _loadFormData(){
		global $CNOA_DB;
		$id = getPar($_POST, "id", 0);
		$dblist = $CNOA_DB->db_getone("*", $this->t_receive_list, "WHERE `id` = '{$id}' ");
		!is_array($dblist) && $dblist = array();
		
		//附件
		$fs = new fs();
		$dblist['attach']		 	= json_decode($dblist['attach'], true);
		$dblist['attachCount']		= !$dblist['attach'] ? 0 : count($dblist['attach']);
		$dblist['attach']			= $fs->getDownLoadItems4normal($dblist['attach'], true);
		//$dblist['attach']   = $fs->getXXXXDownLoadFileListByIds(json_decode($dblist['attach']));
		//$dblist['attachCount'] = !$dblist['attach'] ? 0 : count($dblist['attach']);
		
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _getStepList(){
		global $CNOA_DB;
		
		$where = "WHERE 1";
		
		$fid	= getPar($_POST, 'fid');
		$where	.= " AND `fromId`={$fid}";
		
		//如果是“退上一步”时，则只显示当前步骤的前步骤
		$prev	= getPar($_POST, 'prev');
		if(!empty($prev)){
			//$stepid	= getPar($_POST, 'stepid');
			$stepInfo	= $CNOA_DB->db_getone(array('stepid'), $this->t_step_list, "WHERE `fromId`={$fid} AND `status`=1 AND `stepType`=1");
			$stepid		= $stepInfo['stepid'];
			$where		.= " AND < `stepid`={$stepid}";
		}

		//发文
		$where .= " AND `fromType`=2";
		
		//上级为2的时候，下级为1，下下级为0
		$dblist = $CNOA_DB->db_select('*', $this->t_step_list, $where ." ORDER BY `stepid` ASC");
		!is_array($dblist) && $dblist = array();
		
		$data = array();
		foreach ($dblist as $info){
			$db = &$data[];
			$db	= $info;
			
			$db['status']	= app::loadApp('odoc', 'sendApply')->api_getStepStatus($db['status']);
			$db['from']		= $db['deptName'] .' / '. $db['uname'];
			$db['stime']	= formatDate($db['stime'], 'Y-m-d H:i');
			$db['etime']	= formatDate($db['etime'], 'Y-m-d H:i');
			$db['say']		= nl2br($db['say']);
		}
		$ds = new dataStore();
		$ds->data = $data;
		$js = $ds->makeJsonData();
		echo $js;
		exit;
	}

	public function api_getStepList(){
		$this->_getStepList();
	}
}
?>