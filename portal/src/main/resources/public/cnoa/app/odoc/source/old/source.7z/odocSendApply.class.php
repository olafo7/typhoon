<?php 
class odocSendApply extends model{
	private $t_send_list	= "odoc_send_list";
	private $t_receive_list	= "odoc_receive_list";
	private $t_tpl_list		= "odoc_setting_template_list";
	private $t_setting_word_level		= "odoc_setting_word_level";//"odoc_setting_send_level"; 
	private $t_setting_word_hurry		= "odoc_setting_word_hurry";
	private $t_flow			= "odoc_setting_flow";
	private $t_flow_step	= "odoc_setting_flow_step";
	private $t_step			= "odoc_step";
	private $t_step_temp	= "odoc_step_temp";
	
	private $arrSendStatus	= array(0=>'拟稿中', 1=>'办理中', 2=>'已办理');
	private $arrStepStatus	= array(0=>'未开始', 1=>'办理中', 2=>'已办理', 3=>'退件');
	
	private $rows			= 15;
	
	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getTemplateList" :
				$typeId = getPar($_POST, "id", 0);
				app::loadApp("odoc", "settingTemplate")->api_getTemplateList($typeId, 1);
				break;
			case "getTypeList" :
				app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "settingWord")->api_getLevelList();
				break;
			case "getHurryList" :
				app::loadApp("odoc", "settingWord")->api_getHurryList();
				break;
			case "newOdoc" :
				$this->_newOdoc();
				break;
			case "editOdocTemplate" :
				global $CNOA_DB, $CNOA_CONTROLLER, $CNOA_SESSION;
				$id = getPar($_GET, "id", "");
				
				//如果办理过了的，则提示并关闭窗口
				$where = "WHERE 1";
				$where .= " AND `fromId`={$id} AND `fromType`=1 AND `status`=2"; 
				//debug::xprint($where);
				$iExist	= $CNOA_DB->db_getcount($this->t_step, $where);
				if(intval($iExist) > 0){
					//已办理
					//msg::callBack(false, "您已经办理过，请不要重复办理.");
					echo '<script type="text/javascript">alert("您已经办理过，请不要重复办理"); window.close();</script>';
					exit;
				}
				
				$GLOBALS['id']				= $id;
				$GLOBALS['CNOA_SYSTEM_NAME']= "发文拟稿";
				$GLOBALS['CNOA_USERNAME']	= $CNOA_SESSION->get("TRUENAME");
				$CNOA_CONTROLLER->loadViewCustom($CNOA_CONTROLLER->appPath . "/tpl/default/send/editOdocTemplate.htm", true, true);
				exit;
			case "loadFormData" :
				$this->_loadFormData();
				break;
			case "delete" :
				$this->_delete();
				break;
			case "submitFormData" :
				$this->_submitFormData();
				break;
			case "submitFileData" :
				$this->_submitFileData();
				break;
			#获取拟稿页面的JS文件
			case "getOdocFawenForm" :
				$this->_getOdocFawenForm();
				break;
			#获取红头文件供前端显示&编辑
			case "loadTemplateFile" :
				$this->_loadTemplateFile();
				break;
			#拟稿时，转下一步，加载所有要绑定的流程列表
			case "getFlowList" :
				$this->_getFlowList();
				break;
			#拟稿时，转下一步，加载指定的流程的信息及步骤列表
			case "getStepInfo" :
				$this->_getStepInfo();
				break;
			#拟稿，加载指定的流程的步骤信息列表
			case "getFixedJsonData" :
				$this->_getFixedJsonData();
				break;
			case "getAllUserListsInPermitDeptTree" :
				$GLOBALS['user']['permitArea']['area'] = "all";
				$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
				echo json_encode($userList);
				exit;
				break;
			case "addDefinedFlow" :
				$this->_addDefinedFlow();
				break;
			case "getDefinedJsonData" :
				$this->_getDefinedJsonData();
				break;
			case "deleteDefinedData" :
				$this->_deleteDefinedData();
				break;
			case "moveDefinedData" :
				$this->_moveDefinedData();
				break;
			#查看发文
			case 'view':
				$_POST['func']	= 'send';
				app::loadApp("odoc", "commonView")->run("send");
				break;
		}
	}
	
	private function _loadpage(){
		
	}
	
	private function __getJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		$start	= getPar($_POST, "start", 0);
		$status	= getPar($_POST, 'status', 0);
		
		$WHERE = "WHERE 1 ";
				
		$s_title	= getPar($_POST, "title", "");
		$s_number	= getPar($_POST, "number", "");
		$s_type		= getPar($_POST, "type", 0);
		$s_level	= getPar($_POST, "level", 0);
		$s_hurry	= getPar($_POST, "hurry", 0);
		
		if(!empty($s_title)){
			$WHERE .= "AND `title` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_number)){
			$WHERE .= "AND `number` LIKE '%{$s_number}%' ";
		}
		if(!empty($s_type)){
			$WHERE .= "AND `type` = '{$s_type}' ";
		}
		if(!empty($s_level)){
			$WHERE .= "AND `level` = '{$s_level}' ";
		}
		if(!empty($s_hurry)){
			$WHERE .= "AND `hurry` = '{$s_hurry}' ";
		}
		
		$stepWhere = "";
		$stepStatus = 0;
		$sendStatus	= "AND `status`= 0";
		switch (intval($status)){
			case 1:		//发文审批
				$sendStatus = "AND `status`= 1";
				$stepStatus	= 1;
				
				//$stepWhere .= " OR `status`=3"; //退件处理
				break;
				
			case 111:	//拟稿历史
				$sendStatus = "AND `status`= 1";;
				$stepStatus	= 2;
				
				$stepWhere .= " AND `stepid`=1";
				break;
				
			case 2:		//已审批
				$sendStatus = "";;
				$stepStatus = 2;
				$stepWhere .= ' AND `stepid` > 1';
				break;
							
			default:	//拟稿中
				$sendStatus = "AND `status`= 0";;
				//$stepStatus	= 1;
				$stepStatus	= '1, 3';
				break;
		}
		$WHERE .= " AND `id` IN (SELECT `fromId` FROM ".CNOA_DB_PRE."odoc_step WHERE `uid`={$uid} AND `fromType`=1 AND `status` IN ({$stepStatus}) {$stepWhere}) {$sendStatus}";
		//debug::xprint($status .' ## '. $WHERE);
		
		
		$field = array(
			'id', 
			'title', 
			'number', 
			'type', 
			'level', 
			'hurry', 
			'status', 
			'createtime', 
			'createname',
			'createdept',
			'sign',
			'regdate',
			'senddate',
			'many'
		);
		$dblist = $CNOA_DB->db_select($field, $this->t_send_list, $WHERE . " ORDER BY `id` DESC LIMIT {$start}, {$this->rows}");
		!is_array($dblist) && $dblist = array();
				
		$typeArr	= app::loadApp("odoc", "settingWord")->api_getTypeAllArr();
		$levelArr	= app::loadApp("odoc", "settingWord")->api_getLevelAllArr();
		$hurryArr	= app::loadApp("odoc", "settingWord")->api_getHurryAllArr();
		foreach ($dblist as $k=>$v) {
			$db = &$dblist[$k];
			$db['type']			= $typeArr[$v['type']]['title'];
			$db['level']		= $levelArr[$v['level']]['title'];
			$db['hurry']		= $hurryArr[$v['hurry']]['title'];
			$db['createtime']	= formatDate($v['createtime'], "Y-m-d H:i");			
			$db['status']		= $this->arrSendStatus[$db['status']];
			//$dblist[$k]['stepData']		= $stepInfo;
			
			
			//发文审批
			if(intval($status) == 1){
				//步骤名称				
				$stepname = $CNOA_DB->db_getfield('stepname', $this->t_step, "WHERE `fromId`={$db['id']} AND `uid`={$uid} AND `fromType`=1 AND `status`=1");
				$db['stepname']	= $stepname;
			}
		}
		
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		$dataStore->total = $CNOA_DB->db_getcount($this->t_send_list, $WHERE);
		return $dataStore->makeJsonData();
	}
	
	private function _getJsonData(){
		echo $this->__getJsonData();
		exit();
	}
	
	private function _newOdoc(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");		
		$uname	= $CNOA_SESSION->get('TRUENAME');
		
		$data['createuid']	= $uid;
		$data['createtime']	= $GLOBALS['CNOA_TIMESTAMP'];
		//$data['title']		= getPar($_POST, "title", "");
		$data['tempid']		= getPar($_POST, "template", 0);
		$data['type']		= getPar($_POST, "type", "");
		$fid = $CNOA_DB->db_insert($data, $this->t_send_list);
		
		
		//先插入第一个步骤
		$data = array();
		$data['stepid']		= 1;
		$data['stepname']	= '拟稿';		
		$data['fromId']		= $fid;
		$data['fromType']	= 1;
		$data['stepType']	= 1;
		$temp = app::loadApp("main", "struct")->api_getDeptByUid($uid);
		$data['detpId']		= $temp['id'];
		$data['deptName']	= $temp['name'];
		$data['uname']		= $uname;
		$data['uid']		= $uid;
		$data['status']		= 1;
		$data['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
		$data['etime']		= $data['stime'];
		$id = $CNOA_DB->db_insert($data, $this->t_step);
				
		echo "{success:true, msg:'操作成功', id : {$fid}}";
		exit();
	}
	
	private function _loadFormData(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid = $CNOA_SESSION->get("UID");
		$id = getPar($_POST, "id", 0);
		
		$data = $CNOA_DB->db_getone("*", $this->t_send_list, "WHERE `id` = '{$id}'");
		$userInfo = app::loadApp("main", "user")->api_getUserDataByUid($uid);
		$deptmentInfo = app::loadApp("main", "struct")->api_getInfoById($userInfo['deptId']);
		$data['createpeople']	= $userInfo['truename'];
		$data['createdept']		= $deptmentInfo['name'];
		
		#eval("\$data = \$data['formdata'];");
		
		//获取附件信息
		$fs = new fs();
		$data['attach']			 = $fs->getEditList(json_decode($data['attach'], true));
		
		//debug::xprint($data['attach']);
		
		
		//当前的步骤
		$stepInfo	= $CNOA_DB->db_getone('*', $this->t_step, "WHERE `fromId`={$id} AND `status`=1 AND `uid`={$uid}");
		$data['stepData']	= $stepInfo;
		
		$dataStore = new dataStore();
		$dataStore->data = $data;
		echo $dataStore->makeJsonData();
		exit();
	}

	private function _submitFormData(){
		global $CNOA_DB, $CNOA_SESSION;

		$id = getPar($_POST, "id", 0);
		
		$info = $CNOA_DB->db_getone("*", $this->t_send_list, "WHERE `id`='{$id}'");
		
		#保存进暂存字段
		$formdata = addslashes(json_encode($_POST));
		
		#处理表单数据
		$data = array();
		$data['formdata']	= $formdata;
		$data['createuid']	= $CNOA_SESSION->get("UID");
		$data['createtime']	= $GLOBALS['CNOA_TIMESTAMP'];
		
		foreach($_POST AS $k=>$v){
			$name = preg_replace("/id_[0-9]{1,}__(.*)/is", "\\1", $k);
			$in_array = array("number", "title", "sign", "createdept", "createname_send", "level", "hurry", "page", "many", "range", "regdate", "senddate");
			if(in_array($name, $in_array)){
				if($name == "createname_send"){
					$name = "createname";
				}
				$data[$name] = $v;
			}
		}
		
		$attach = $CNOA_DB->db_getfield("attach", $this->t_send_list, "WHERE `id` = '{$id}'");

		$fs = new fs();
		$filesUpload = getPar($_POST, "filesUpload", array());
		$attach = $fs->edit($filesUpload, json_decode($attach, false), 17);
		$data['attach'] = json_encode($attach);
		
		$CNOA_DB->db_update($data, $this->t_send_list, "WHERE `id`='{$id}'");
		
		#保存历史页面进缓存文件
		$formHtml = app::loadApp("odoc", "common")->getHtmlWithValue($info['form'], $_POST);
		app::loadApp("odoc", "common")->saveHistory($id, $formHtml, 0, "send");
		
		msg::callBack(true, "操作成功");
		exit();
	}
	
	public function _submitFileData(){
		global $CNOA_DB;
		
		$id = intval(getPar($_POST, "id", 0));

		$uploadfile = CNOA_PATH_FILE . "/common/odoc/send/{$id}/doc.history.0.php";
		mkdirs(dirname($uploadfile));
		
		if(!move_uploaded_file($_FILES['docFile']['tmp_name'], $uploadfile)){
			echo '0';exit;
		}

		echo '1';
		exit;
	}
	
	private function _getOdocFawenForm(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$id		= intval(getPar($_GET, "id", ""));
		$from	= getPar($_GET, 'OdocFawenForm_from');
		
		$info = $CNOA_DB->db_getone("*", $this->t_send_list, "WHERE `id`='{$id}'");

		if(empty($info['form'])){
			#如果未打开过表单，则从模板转换过来
			$form = app::loadApp("odoc", "common")->getFormFromTplById($info['tempid']);
			$CNOA_DB->db_update(array("form"=>addslashes($form)), $this->t_send_list, "WHERE `id`='{$id}'");
		}else{
			#如果打开过表单，则直接显示
			$form = $info['form'];
		}
		
		if(!empty($info['formdata'])){
			$form = app::loadApp("odoc", "common")->getFormWithValue($form, json_decode($info['formdata'], true));
		}
		
		//去掉双引号及换行符号
		$form = str_replace(
			array("\r\n", "\n", "\""),
			array("&#13;", "&#13;", "'"),
			$form
		);
		
		if($from == 'check'){
			$js = file_get_contents(CNOA_PATH . "/app/odoc/scripts/send_checkOdocTemplate.js");
		}else{
			$js = file_get_contents(CNOA_PATH . "/app/odoc/scripts/send_editOdocTemplate.js");
		}
		$js = str_replace("{FAWENFORM}", $form, $js);
		header('Content-type: text/javascript');
		echo $js;
		exit();
	}
	
	private function _delete(){
		global $CNOA_DB;
		$id = getPar($_POST, "id", 0);
		$CNOA_DB->db_delete($this->t_send_list, "WHERE `id`='{$id}'");
		msg::callBack(true, "操作成功");
	}
	
	private function _loadTemplateFile(){
		global $CNOA_DB;

		$id = intval(getPar($_GET, "id", 0));
		$filePath = CNOA_PATH_FILE . "/common/odoc/send/{$id}/doc.history.0.php";
		
		if(file_exists($filePath)){
			$file = @file_get_contents($filePath);
		}else{
			$tempId = $CNOA_DB->db_getfield("tempid", $this->t_send_list, "WHERE `id`='{$id}'");
			$template = $CNOA_DB->db_getfield("template", $this->t_tpl_list, "WHERE `id`='{$tempId}'");
			$tplFile = CNOA_PATH_FILE . "/common/odoc/template/{$tempId}/{$template}.php";

			if(file_exists($tplFile)){
				$file = @file_get_contents($tplFile);
				mkdirs(dirname($filePath));
				file_put_contents($filePath, $file);
			}else{
				$file = " ";
			}
		}
		
		/*
		if(($docfile !== false) && empty($docfile['docfile'])){
			$tplFile = $CNOA_DB->db_getfield("template", $this->t_tpl_list, "WHERE `id`='{$docfile['tempid']}'");
			if(!$tplFile){
				$file = "";
			}else{
				$file = @file_get_contents(CNOA_PATH_FILE . "/common/odoc/template/{$docfile['tempid']}/{$tplFile}.php");
				$filePath = CNOA_PATH_FILE . "/common/odoc/send/{$id}/doc.history.0.php";
				mkdirs(dirname($filePath));
				
				file_put_contents($filePath, $file);
			}
		}else{
			$file = " ";
		}
		*/
		
		echo $file;
		exit;
	}
	
	private function _getFlowList($fromType = "send"){
		global $CNOA_DB;
		
		$WHERE = "WHERE `active`=1";
		
		if($fromType == "receive"){
			$WHERE .= " AND `which`=2";
		}elseif($fromType == "send"){
			$WHERE .= " AND `which`=1";
		}

		$dblist = $CNOA_DB->db_select(array("id", "flowname"), $this->t_flow, $WHERE . " ORDER BY `id` DESC");
		!is_array($dblist) && $dblist = array();
		
		$data = array();
		foreach ($dblist as $k=>$v) {
			$data[] = array("id"=>$v['id'], "name"=>$v['flowname']);
		}
		$dataStore = new dataStore();
		$dataStore->data = $data;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _getStepInfo(){
		global $CNOA_DB;
		
		$flowid = getPar($_POST, "flowid", 0);
		
		#获取流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->t_flow, "WHERE `which`=1 AND `active`=1 AND `id`='{$flowid}'");
		!is_array($flowInfo) && $flowInfo = array();
		
		$flowInfo['stepList'] = $CNOA_DB->db_select("*", $this->t_flow_step, "WHERE `fid`='{$flowid}'");
		
		$dataStore = new dataStore();
		$dataStore->data = $flowInfo;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _getFixedJsonData(){
		global $CNOA_DB;
		$id = getPar($_POST, "id", 0);
		$dblist = $CNOA_DB->db_select("*", $this->t_flow_step, "WHERE `fid` = '{$id}' ORDER BY `id` ASC");
		!is_array($dblist) && $dblist = array();
		
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _addDefinedFlow($from = "send"){
		global $CNOA_DB;
		$fid= getPar($_POST, "fid", 0);
		$id = getPar($_POST, "id", 0);
		if($from == "send"){
			$data['fromType'] = 1;
		}elseif ($from == "receive"){
			$data['fromType'] = 2;
		}
		$data['fromId']		= $fid;
		$data['stepname']	= getPar($_POST, "stepname", "");
		$data['uid']		= getPar($_POST, "uid", 0);
		$data['uname']		= getPar($_POST, "uname", "");
		$temp = app::loadApp("main", "struct")->api_getDeptByUid($data['uid']);
		$data['detpId']		= $temp['id'];
		$data['deptName']	= $temp['name'];				
		//$data['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
		//$data['etime']		= $data['stime'];
	
		if(!empty($id)){
			$CNOA_DB->db_update($data, $this->t_step_temp, "WHERE `id` = '{$id}'");
		}else{
			$CNOA_DB->db_insert($data, $this->t_step_temp);
		}
		msg::callBack(true, "操作成功");
	}
	
	private function _getDefinedJsonData($from = "send"){
		global $CNOA_DB;
		$fid = getPar($_POST, "fid", 0);
		$WHERE = "WHERE 1 ";
		if($from == "send"){
			$WHERE .= "AND `fromType` = 1 ";
		}elseif ($from == "receive"){
			$WHERE .= "AND `fromType` = 2 ";
		}
		$dblist = $CNOA_DB->db_select("*",$this->t_step_temp, $WHERE . "AND `fromId` = '{$fid}' ORDER BY `id` ASC");
		!is_array($dblist) && $dblist = array();

		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _deleteDefinedData(){
		global $CNOA_DB;
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		foreach ($idArr as $k=>$v) {
			$CNOA_DB->db_delete($this->t_step_temp, "WHERE `id` = '{$v}'");
		}
		msg::callBack(true, "操作成功");
	}
	
	private function _moveDefinedData($from = "send"){
		global $CNOA_DB, $CNOA_SESSION;
		$fid	= getPar($_POST, "fid", 0);
		$type	= getPar($_POST, "from", "fixed");
		
		$uid	= $CNOA_SESSION->get('UID');
		$uname	= $CNOA_SESSION->get('TRUENAME');
		
		$i		= 2;
		
		if($from == "send"){
			$typeId = 1;
			$table = $this->t_send_list;
		}elseif ($from == "receive") {
			$typeId = 2;
			$table = $this->t_receive_list;
		}
		
		
		$send_info	= $CNOA_DB->db_getone(array("title", "number"), $table, "WHERE `id` = '{$fid}'");
		$send_title	= $send_info['title'];
		$send_num	= $send_info['number'];	
		
		
		//先清除原有的数据
		$CNOA_DB->db_delete($this->t_step, "WHERE `fromType` = '{$typeId}' AND `fromId` = '{$fid}' AND `stepid` != 1");
		
		if($type == "fixed"){
		//绑定已有流程
			$choice = getPar($_POST, "choice", 0);
			$dblist = $CNOA_DB->db_select("*", $this->t_flow_step, "WHERE `fid` = '{$choice}' ORDER BY `id` ASC");
			!is_array($dblist) && $dblist = array();
			foreach ($dblist as $k=>$v) {
				$data = array();
				$data['fromId']		= $fid;
				if($from == "send"){
					$data['fromType']	= 1;
				}elseif ($from == "receive"){
					$data['fromType']	= 2;
				}
				$data['stepid']		= $i;
				$data['stepType']	= 1;
				$temp = app::loadApp("main", "struct")->api_getDeptByUid($v['uid']);
				$data['detpId']		= $temp['id'];
				$data['deptName']	= $temp['name'];
				$data['uname']		= $v['uname'];
				$data['stepname']	= $v['stepName'];
				$data['uid']		= $v['uid'];
				
				if($i == 2){
					$data['status']		= 1;
					$data['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
					//发送提醒
					$this->__sendNotice($data['uid'], $send_title, $typeId);
				}else{
					$data['status']		= 0;
				}
				
				//debug::xprint($data);
				$CNOA_DB->db_insert($data, $this->t_step);
				$i++;
				
			}
		}elseif($type == "defined"){
		//自定义流程
			$temp = $CNOA_DB->db_select("*", $this->t_step_temp, "WHERE `fromId` = '{$fid}' ORDER BY `id` ASC ");
			//$send_info	= $CNOA_DB->db_getone(array("title", "number"), $table, "WHERE `id` = '{$fid}'");
			//$send_title	= $send_info['title'];
			//$send_num	= $send_info['number'];			
			!is_array($temp) && $temp = array();
			
			foreach ($temp as $k=>$v) {
				$data				= $v;
				$data['stepid']		= $i;
				$data['stepType']	= 1;
				if($i == 2){
					$data['status']		= 1;
					$data['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
					//发送提醒
					$this->__sendNotice($data['uid'], $send_title, $typeId);
				}else{
					$data['status']		= 0;
				}
				unset($data['id']);
				$CNOA_DB->db_insert($data, $this->t_step);
				$i++;
			}
			$CNOA_DB->db_delete($this->t_step_temp, "WHERE `fromId`='{$fid}'");
		}
				
		if($from == "send") {
			//修改状态为：办理中
			$data = array();
			$data['status']		= 1;
			//$data['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
			$CNOA_DB->db_update($data, $this->t_send_list, "WHERE `id`='{$fid}'");
			
			
			//修改第一步骤的“拟稿”状态为已办理
			$where = "WHERE `fromId`='{$fid}' AND `fromType`=1 AND `stepid`=1";
			$data = array();
			$data['status']	= 2;
			$CNOA_DB->db_update($data, $this->t_step, $where);
			
			
			//当前步骤
			$id = $CNOA_DB->db_getfield('id', $this->t_step, $where);				
			
			//修改快照文件名称
			$path = CNOA_PATH_FILE. '/common/odoc/send/'. $fid .'/';
			@rename($path . 'form.history.0.php', $path . 'form.history.'.$id.'.php');
			@rename($path . 'doc.history.0.php', $path . 'doc.history.'.$id.'.php');
		}elseif($from == "receive"){
			//修改状态为：办理中
					
			//修改第一步骤的“拟稿”状态为已办理
			$where = "WHERE `fromId`='{$fid}' AND `fromType`=2 AND `stepid`=1";
			$data = array();
			$data['status']	= 2;
			//$data['say']	= "同意";
			$CNOA_DB->db_update($data, $this->t_step, $where);
			
			//当前步骤
			$id = $CNOA_DB->db_getfield('id', $this->t_step, $where);				
			
			//修改快照文件名称
			$path = CNOA_PATH_FILE. '/common/odoc/receive/'. $fid .'/';
			@rename($path . 'form.history.0.php', $path . 'form.history.'.$id.'.php');
			@rename($path . 'doc.history.0.php', $path . 'doc.history.'.$id.'.php');
		}
		
		msg::callBack(true, "操作成功");
	}
	
	/**
	 * 发送提醒
	 * Enter description here ...
	 * @param unknown_type $uid
	 */
	private function __sendNotice($uid, $title = '', $type=1, $to=1){
		app::loadApp('odoc', 'sendCheck')->api_sendNotice($uid, $title, $type, $to);
	}
	
	
	/**
	 * 提交文件数据
	 */
	public function api_submitFileData(){
		return $this->_submitFileData();
	}
	
	
	/**
	 * 发文状态
	 * Enter description here ...
	 * @param unknown_type $status
	 */
	public function api_getSendStatus($status){
		return $this->arrSendStatus[intval($status)];
	}
	
	/**
	 * 发文步骤状态
	 */
	public function api_getStepStatus($status){
		return $this->arrStepStatus[intval($status)];
	}
	
	
	/**
	 * 读取表单数据
	 * Enter description here ...
	 */
	public function api_loadFormData(){
		return $this->_loadFormData();
	}
	
	/**
	 * 读取模板文件
	 * Enter description here ...
	 */
	public function api_loadTemplateFile(){
		return $this->_loadTemplateFile();
	}
	
	
	
	/**
	 * 发文表单
	 * Enter description here ...
	 */
	public function api_getOdocFawenForm(){
		return $this->_getOdocFawenForm();
	}
	
	
	
	/**
	 * 
	 */
	public function api_submitFormData(){
		return $this->_submitFormData();
	}
	
	
	/**
	 * 发文列表
	 * Enter description here ...
	 */
	public function api_getSendList(){
		return $this->__getJsonData();
	}
	
	public function api_getFlowList($fromType){
		$this->_getFlowList($fromType);
	}
	
	public function api_getStepInfo(){
		$this->_getStepInfo();
	}
	
	public function api_getFixedJsonData(){
		$this->_getFixedJsonData();
	}
	
	public function api_addDefinedFlow($from){
		$this->_addDefinedFlow($from);
	}
	
	public function api_getDefinedJsonData($from){
		$this->_getDefinedJsonData($from);
	}
	
	public function api_deleteDefinedData(){
		$this->_deleteDefinedData();
	}
	
	public function api_moveDefinedData($from){
		$this->_moveDefinedData($from);
	}
	
	
	
	
	
	
	public function api_getData($idArr){
		global $CNOA_DB;
		
		$dblist = $CNOA_DB->db_select("*", $this->t_send_list, "WHERE `id` IN (" . implode(",", $idArr) . ") ");
		!is_array($dblist) && $dblist = array();
		$data = array(0);
		foreach ($dblist as $k=>$v) {
			$data[$v['id']] = $v;
		}
		return $data;
	}
	
}
?>