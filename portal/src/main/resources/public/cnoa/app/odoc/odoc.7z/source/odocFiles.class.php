<?php 
class odocFiles extends model{
									
	/**
	 * ���캯��
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * ��������
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function actionBorrow(){
		app::loadApp("odoc", "filesBorrow")->run();
	}
	
	public function actionDananmgr(){
		app::loadApp("odoc", "filesDananmgr")->run();
	}
	
	public function actionClean(){
		app::loadApp("odoc", "filesClean")->run();
	}
	
	public function actionAnjuanmgr(){
		app::loadApp("odoc", "filesAnjuanmgr")->run();
	}
	
	public function actionSetting(){
		app::loadApp("odoc", "filesSetting")->run();
	}
	
	public function actionSearch(){
		app::loadApp("odoc", "filesSearch")->run();
	}
	
	public function actionBrwchk(){
		app::loadApp("odoc", "filesBrwchk")->run();
	}
}
?>