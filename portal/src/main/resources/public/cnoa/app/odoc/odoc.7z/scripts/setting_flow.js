var CNOA_odoc_setting_flowClass, CNOA_odoc_setting_flow;
var CNOA_odoc_setting_setAddWin1,CNOA_odoc_setting_setAddWin2, CNOA_odoc_setting_setAddWinClass;
var CNOA_odoc_setting_setWinList1,CNOA_odoc_setting_setWinList2, CNOA_odoc_setting_setWinListClass;
var CNOA_odoc_setting_setBindFlowClass;

CNOA_odoc_setting_setAddWinClass = function(from){
	var _this = this;

	this.baseUrl = "index.php?app=odoc&func=setting&action=flow";
		
	var baseField = [
		{
			xtype:'panel',
			border:false,
			layout:"form",
			defaults:{},
			id:'ID_DEFINDE_FIELDS'
		}
	];
	
	this.form = new Ext.form.FormPanel({
		border:false,
		labelWidth:60,
		labelAlign:'left',
		autoWidth:true,
		waitMsgTarget:true,
		bodyStyle:"padding:5px 10px 10px 10px;",
		items:baseField,
		autoScroll:true,
		hideLabel:true,
		listeners:{
			"render":function(form){}
		}
	});
	
	this.fieldStore = new Ext.data.SimpleStore({
		fields:['value', 'name'],
		data:[]
	});
	
	this.superField = Ext.getCmp('ID_DEFINDE_FIELDS');
	
	//fieldset的id
	this.fieldsetid = 1;
	this.fieldStoreData = [];
	
	this.childFieldid = 1;
	
	this.childFieldArr = [];
	
	var win = new Ext.Panel({
		layout:'fit',
		id: 'odoc_view_' + from,
		items:this.form,
		tbar:[
			{
				text:'添加分类',
				handler:function(btn){
					Ext.MessageBox.prompt("", "添加您需要的类别名称", function(btn, msg){
						if(btn == 'ok'){
							if(msg != ''){
								_this.addFieldSet(msg, _this.fieldsetid);
								_this.fieldsetid++;
							}else{
								CNOA.msg.alert('您还没有添加名称');
							}
						}
					});
					
				}
			},'-',
			{
				text:'添加输入框',
				handler:function(btn){
					_this.addChildField('add', '', '', '', '');
				}
			},'-',
			{
				text:lang('save'),
				iconCls: 'icon-btn-save',
				handler:function(btn){
					var	temp = [];
					Ext.each(_this.fieldStore.data.items,function(v, i){
						temp.push(v.data);
					});
					var tempStoreData = Ext.encode(temp);
					_this.form.getForm().submit({
						url: _this.baseUrl+"&task=submitAddWinLayout",
						method: 'POST',
						waitMsg: lang('waiting'),
						params: {tempStoreData:tempStoreData,from:from},
						success: function(form, action) {
							CNOA.msg.alert(lang('successopt'), function(){
							});
						}.createDelegate(this),
						failure: function(form, action) {
							CNOA.msg.alert(action.result.msg, function(){
								
							}.createDelegate(this));
						}.createDelegate(this)
					});
				}
			},'-',
			('<span class="cnoa_color_gray">添加'+(from == 'send'?'发':'收')+'文的窗口设置</span>')
		]
	});
	
	this.addChildField = function(from, editFirstField, editSecondField, sortFrom, typeFrom){
		var _this = this;
		
		var addToFieldset = function(){
			var values = form.getForm().getValues();
			var sortFrom = values.sortFrom;
			var typeFrom = values.typeFrom;
			if(sortFrom == 0){
				_this.superField.add(_this.childFormat(from, values, _this.superField, sortFrom, typeFrom));
				_this.superField.doLayout();
			}else{
				var childField = Ext.getCmp('ID_FIELD_SET_' + sortFrom);
				childField.add(_this.childFormat(from, values, childField, sortFrom, typeFrom));
				childField.doLayout();
			}
		};
		
		var baseField = [
			{
				xtype:'combo',
				fieldLabel:"类型",
				name:'typeFrom',
				hiddenName:'typeFrom',
				store:new Ext.data.SimpleStore({
					fields:['value', 'name'],
					data:[['text', '单行文本'], ['textarea', '多行文本']]
				}),
				valueField:'value',
				displayField:'name',
				mode:'local',
				triggerAction:'all',
				forceSelection:true,
				editable:false,
				width:200,
				value:'text',
				listeners:{
					'change':function(th, newValue, oldValue){
						if(newValue == 'textarea' || newValue == 'type' || newValue == 'sort'){
							form.getForm().findField('secname').setValue('');
							form.getForm().findField('secname').hide();
						}else{
							form.getForm().findField('secname').show();
						};
					}
				}
			},
			{
				xtype:'combo',
				fieldLabel:"分类列表",
				name:'sortFrom',
				hiddenName:'sortFrom',
				store:this.fieldStore,
				valueField:'value',
				displayField:'name',
				mode:'local',
				triggerAction:'all',
				forceSelection:true,
				editable:false,
				width:200,
				allowBlank:false,
				listeners:{
					'select':function(th, record, index){}
				}
			},
			{
				xtype:'textfield',
				name:'fstname',
				width:200,
				fieldLabel:'第一个名称'
			},
			{
				xtype:'textfield',
				name:'secname',
				width:200,
				fieldLabel:'第二个名称'
			}
		];
		
		var form = new Ext.form.FormPanel({
			border: false,
			labelWidth: 90,
			labelAlign: 'right',
			autoWidth: true,
			waitMsgTarget: true,
			bodyStyle: "padding:5px 10px 10px 10px;",
			items:baseField,
			autoScroll:true,
			listeners: {
				"render" : function(form){}
			}
		});
		
		var win = new Ext.Window({
			title:lang('add'),
			modal:true,
			resizable:false,
			width:400,
			height:200,
			layout:'fit',
			items:form,
			buttons:[
				{
					text:lang('ok'),
					hidden:from == 'add'?false:true,
					handler:function(btn){
						if(!form.getForm().isValid()){
							CNOA.msg.alert('您还没有设置分类.');
							return false;
						}
						var values = form.getForm().getValues();
//						if(!_this.checkChildField(values, _this.childFieldArr)){
//							return false;
//						}
						_this.childFieldArr.push(values.fstname);
						_this.childFieldArr.push(values.secname);
						addToFieldset();
						win.close();
					}
				},
				{
					text:lang('modify'),
					hidden:from == 'edit'?false:true,
					handler:function(btn){
						if(!form.getForm().isValid()){
							CNOA.msg.alert('您还没有设置分类.');
							return false;
						}
						
						var childFieldArr = [];
						Ext.each(_this.childFieldArr, function(v,i){
							if(v != editFirstField.hideValue && v != editSecondField.hideValue){
								childFieldArr.push(v);
							}
						});
						
						var values = form.getForm().getValues();
//						if(!_this.checkChildField(values, childFieldArr)){
//							return false;
//						}
						
						editFirstField.hideValue = values.fstname;
						editSecondField.hideValue = values.secname;
						
						var note = _this.formatNote(typeFrom);
						
						editFirstField.setValue(note.note_one+values.fstname);
						editSecondField.setValue(note.note_two+values.secname);
						
						_this.childFieldArr = childFieldArr;
						
						_this.childFieldArr.push(values.fstname);
						_this.childFieldArr.push(values.secname);
						win.close();
					}
				},
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
		
		if(from == 'edit'){
			var record = {};
			var fstname = '';
			var secname = '';
				record.data = {'typeFrom':typeFrom, 'sortFrom':sortFrom, 'fstname':editFirstField.hideValue, 'secname':editSecondField.hideValue};
			form.getForm().loadRecord(record);
			form.getForm().findField('sortFrom').setDisabled(true);
			form.getForm().findField('typeFrom').setDisabled(true);
			if(typeFrom == 'textarea'){
				form.getForm().findField('secname').hide();
			}
		}
	};
	
	this.formatNote = function(from){
		var result = {};
		switch(from){
			case 'text':
				result.note_one = '{[单行文本]}';
				result.note_two = '{[单行文本]}';
			break;
			case 'textarea':
				result.note_one = '{[多行文本]}';
				result.note_two = '{[多行文本]}';
			break;
			case 'type':
				result.note_one = '{[自定义类别]}';
				result.note_two = '';
			break;
			case 'sort':
				result.note_one = '{[行业信息]}';
				result.note_two = '';
			break;
			case 'region':
				result.note_one = '{[地区]}';
				result.note_two = '{[二级地区]}';
			break;
			case 'account':
				result.note_one = '{[登陆账号]}';
				result.note_two = '{[真实姓名]}';
			break;
		}
		return result;
	};
	
	this.childFormat = function(from, values, fieldset, sortFrom, typeFrom){
		var _this = this;

		var firstId		= this.childFieldid++;
		var secondId	= this.childFieldid++;
		
		var note = this.formatNote(typeFrom);
		if(typeFrom == 'textarea'){
			var items = [
					{
						xtype:'textarea',
						width:378,
						readOnly:true,
						name:'field_'+firstId+'_'+sortFrom+'_'+typeFrom,
						hideValue:values.fstname,
						value:note.note_one+values.fstname
					},
					{
						xtype:'hidden',
						readOnly:true,
						name:'field_'+secondId+'_'+sortFrom+'_'+typeFrom+'_hide',
						hideValue:values.secname,
						value:note.note_two+values.secname
					}
				];
		}else if(typeFrom == 'sort'){
			var items = [
				{
					xtype:'textfield',
					width:180,
					readOnly:true,
					name:'field_'+firstId+'_'+sortFrom+'_'+typeFrom,
					hideValue:values.fstname,
					value:note.note_one+values.fstname
				},
				{
					xtype:'hidden',
					width:180,
					readOnly:true,
					name:'field_'+secondId+'_'+sortFrom+'_'+typeFrom+'_hide',
					style:'margin-left:20px',
					hideValue:values.secname,
					value:note.note_two+values.secname
				}
			];
		}else if(typeFrom == 'type'){
			var items = [
				{
					xtype:'textfield',
					width:180,
					readOnly:true,
					name:'field_'+firstId+'_'+sortFrom+'_'+typeFrom,
					hideValue:values.fstname,
					value:note.note_one+values.fstname
				},
				{
					xtype:'hidden',
					width:180,
					readOnly:true,
					name:'field_'+secondId+'_'+sortFrom+'_'+typeFrom+'_hide',
					style:'margin-left:20px',
					hideValue:values.secname,
					value:note.note_two+values.secname
				}
			];
		}else{
			var displayF = '';
			var displayS = '';
			if(values.fstname == ''){
				displayF = '_hide';
			}
			if(values.secname == ''){
				displayS = '_hide';
				values.secname = 'aa';
			}
			var items = [
				{
					xtype:'textfield',
					width:180,
					readOnly:true,
					name:'field_'+firstId+'_'+sortFrom+'_'+typeFrom+displayF,
					hideValue:values.fstname,
					value:note.note_one+values.fstname
				},
				{
					xtype:'textfield',
					width:180,
					readOnly:true,
					name:'field_'+secondId+'_'+sortFrom+'_'+typeFrom+displayS,
					style:'margin-left:20px',
					hideValue:values.secname,
					value:note.note_two+values.secname
				}
			];
		}
		
		items.push(
			{
				xtype:'button',
				text:'编辑',
				firstId:firstId,
				secondId:secondId,
				sortFrom:sortFrom,
				typeFrom:typeFrom,
				handler:function(btn){
					var firstGroup = {};
					var secondGroup = {};
					try{
						firstGroup = _this.form.getForm().findField('field_'+btn.firstId+'_'+btn.sortFrom+'_'+btn.typeFrom);
					}catch(e){
						firstGroup = _this.form.getForm().findField('field_'+btn.firstId+'_'+btn.sortFrom+'_'+btn.typeFrom+'_hide');
					}
					try{
						secondGroup = _this.form.getForm().findField('field_'+btn.secondId+'_'+btn.sortFrom+'_'+btn.typeFrom);
					}catch(e){
						secondGroup = _this.form.getForm().findField('field_'+btn.secondId+'_'+btn.sortFrom+'_'+btn.typeFrom+'_hide');
					}
					_this.addChildField('edit', firstGroup,secondGroup, btn.sortFrom, btn.typeFrom);
				}
			},
			{
				xtype:'button',
				text:lang('del'),
				tableId:firstId,
				style:'margin-left:20px',
				handler:function(btn){
					fieldset.remove(Ext.getCmp('ID_GROUP_CHILD_FIELD' + btn.tableId));
				}
			}
		);
		
		var result = {
			xtype: 'panel',
			layout: 'table',
			layoutConfig: {
				columns: 5
			},
			style: 'margin-top:10px',
			border: false,
			id: 'ID_GROUP_CHILD_FIELD' + firstId,
			defaults: {
				border: false
			},
			items:items
		}
		
		return result;
	};
	
	this.addField = function(name, sortFrom, typeFrom, values){
		var _this = this;

		var childField = Ext.getCmp('ID_FIELD_SET_' + sortFrom);
		childField.add(_this.childFormat('add', values, childField, sortFrom, typeFrom));
		childField.doLayout();
	};
	
	this.addFieldSet = function(msg, fieldsetid){
		this.superField = Ext.getCmp('ID_DEFINDE_FIELDS');
		
		this.superField.add({
			xtype:'fieldset',
			title:msg,
			anchor: "99%",
			autoHeight: true,
			id:"ID_FIELD_SET_" + fieldsetid,
			items:[
				{
					xtype:'button',
					text:'删除分类',
					fieldsetid:fieldsetid,
					handler:function(botton){
						CNOA.msg.cf('删除该分类，也会删除分类里面的内容', function(btn){
							if(btn == 'yes'){
								_this.superField.remove(Ext.getCmp("ID_FIELD_SET_" + botton.fieldsetid));
								var fieldStoreData2 = [];
								Ext.each(_this.fieldStoreData,function(v,i){
									if(v[0] != botton.fieldsetid){
										fieldStoreData2.push(v);
									}
								});
								_this.fieldStore.loadData(fieldStoreData2);
							}
						})
					}
				}
			]
		});
		_this.superField.doLayout();
		_this.fieldStoreData.push([fieldsetid, msg]);
		_this.fieldStore.loadData(_this.fieldStoreData);
	};
	
	this.loadData = function(){
		Ext.Ajax.request({
			url:_this.baseUrl + "&task=loadFormData",
			method:'POST',
			params:{from:from},
			success:function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					Ext.each(result.fieldset, function(v, i){
						_this.addFieldSet(v.name, v.fieldset);
					});
					Ext.each(result.field, function(v,i){
						var values = {};
						values.fstname = v.fstname;
						values.secname = v.secname;
						
						_this.childFieldArr.push(v.fstname);
						_this.childFieldArr.push(v.secname);
						
						_this.addField(v.name, v.fieldset, v.type, values);
						_this.fieldsetid++;
					});
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	};
	
	this.loadData();

	return win;
};


CNOA_odoc_setting_setWinListClass = function(from){
	var _this = this;
	
	this.baseUrl = "index.php?app=odoc&func=setting&action=flow";
		
	var wordFields = [
		'field',
		'name',
		'title',
		'width'
	];
	
	var wordStore = new Ext.data.Store({
		proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getFieldList", disableCaching: true}),   
		reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:wordFields}),
		listeners:{
			load:function(th, records, options){}
		}
	});
	
	wordStore.load({params:{from:from}});
	
	var wordColModel = new Ext.grid.ColumnModel([
        {id:'name',header: "输入框名称", sortable: true, dataIndex: 'name', menuDisabled: true}
    ]);
	
	var leftGrid = new Ext.grid.GridPanel({
		region:'west',
		width:240,
		ddGroup:'wordDDGroup',
		layout:'fit',
		bodyStyle: 'border-right-width:1px;',
		enableDragDrop:true,
        store:wordStore,
        cm:wordColModel,
		autoExpandColumn:'name',
        sm:new Ext.grid.RowSelectionModel({
            singleSelect: true
        }),
		dropConfig:{
			appendOnly:true
		},
        border: false,
		listeners:{
			afterrender: function(th){
				setTimeout(function(){
					new Ext.dd.DropTarget(rightGrid.getView().scroller.dom, {
						ddGroup:'wordDDGroup',
						notifyDrop  : function(ddSource, e, data){
							var records =  ddSource.dragData.selections;
							Ext.each(records, ddSource.grid.store.remove, ddSource.grid.store);
							
							var index = ddSource.getDragData(e).rowIndex;
							if (typeof(index) == "undefined") {
								rightGrid.store.add(records);
							}else{
								templeStore.insert(index, records);
							}
						}
					});
				}, 1000);
			}
		}
	});
	
	var templeStore = new Ext.data.Store({
		proxy:new Ext.data.HttpProxy({url:this.baseUrl+"&task=getWordList", disableCaching: true}),   
		reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:wordFields})
	});
	
	templeStore.load({params:{from:from}});
	
	var templeColModel = new Ext.grid.ColumnModel([
        {header:"", hidden:true, dataIndex:'fieldid'},
        {header:"输入框名称", width:150, sortable:true, dataIndex:'name', menuDisabled:true},
        {id:'title', header:"自定义名称", sortable:true, dataIndex:'title', menuDisabled:true,
			editor:{
				xtype:'textfield',
				allowBlank:true
			}},
        {header:"宽度", width:80, sortable:true, dataIndex:'width', menuDisabled:true,
			editor:{
				xtype:'textfield',
				allowBlank:true
			}}
	]);
	
	var rightGrid = new Ext.grid.EditorGridPanel({
		region:'center',
		border: false,
		ddGroup:'wordDDGroup',
		layout:'fit',
		enableDragDrop:true,
        store:templeStore,
        cm:templeColModel,
		autoExpandColumn:'title',
        sm:new Ext.grid.RowSelectionModel({
            singleSelect: true
        }),
		clicksToEdit: 1,
		listeners:{
			afterrender:function(th){
				setTimeout(function(){
					new Ext.dd.DropTarget(leftGrid.getView().scroller.dom, {
						ddGroup:'wordDDGroup',
						notifyEnter : function(ddSource, e, data) {},
						notifyDrop  : function(ddSource, e, data){
							var records =  ddSource.dragData.selections;
							Ext.each(records, ddSource.grid.store.remove, ddSource.grid.store);
							
							var index = ddSource.getDragData(e).rowIndex;
							if (typeof(index) == "undefined") {
								leftGrid.store.add(records);
							}else{
								wordStore.insert(index, records);
							}
						}
					});
				}, 1000);
			}
		}
	});
	

	var win = new Ext.Panel({
		resizable:false,
		modal:true,
		layout:'border',
		items:[leftGrid, rightGrid],
		id: 'odoc_list_' + from,
		tbar:[
			{
				text:lang('save'),
				iconCls: 'icon-btn-save',
				handler:function(btn){
					var data = [];
					Ext.each(templeStore.data.items, function(v, i){
						data.push(v.data);
					});
					Ext.Ajax.request({
						url: _this.baseUrl + "&task=submitList",
						method: 'POST',
						params:{data:Ext.encode(data),from: from},
						success: function(r) {
							var result = Ext.decode(r.responseText);
							if(result.success === true){
								CNOA.msg.alert(result.msg,function(){
									
								})
							}else{
								CNOA.msg.alert(result.msg, function(){});
							}
						}
					});
				}
			},'-',
			('<span class="cnoa_color_gray">设置'+(from == 'send'?'发':'收')+'文的列表显示</span>'),'-',
			'<span class="cnoa_color_gray">可以拖动左边的输入框到右边栏目里添加列，双击“自定义名称”/“宽度”可以修改相应内容。</span>'
		]
	});

	return win;
};

CNOA_odoc_setting_setBindFlowClass = CNOA.Class.create();
CNOA_odoc_setting_setBindFlowClass.prototype = {
	init : function(from){
		var _this = this;
		
		this.from = from;
		
		this.baseUrl = "index.php?app=odoc&func=setting&action=flow";
			
		var fields = [
			{name:"id"},
			{name:"name"},
			{name:"flowId"},
			{name:"flowName"},
			{name:"status"},
			{name:"bindKJ"}
		];
		
		this.store = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getFlowJsonData&from="+this.from, disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: fields})
		});
		
		var sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:true
		});
		
		this.store.load();
	
		var colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			{header: "id", dataIndex: 'id', hidden: true},
			{header: lang('flowName'), dataIndex: 'name',width: 180, sortable: true, menuDisabled :true},
			{header: '绑定工作流', dataIndex: 'flowName',width: 180, sortable: true, menuDisabled :true},
			{header: "状态", dataIndex: 'status', width: 60, sortable: false,menuDisabled :true, renderer:function(value, c, r){
				var _this = this;
				if (value==1){
					return '<span class=cnoa_color_green>启用</span>';
				}else{
					return '<span class=cnoa_color_red>停用</span>';
				}
			}},
			{header: "绑定控件", dataIndex: 'bindKJ', id: 'bindKJ', width: 140, sortable: false,menuDisabled :true},
			{header: lang('opt'), dataIndex: 'id', width: 160, sortable: false,menuDisabled :true, renderer:function(value, c, r){
				var rd = r.data, sText='';
				if(rd.status == 1){
					sText = '停用';
				}else{
					sText = '启用';
				}
				var h  = "<a href='javascript:void(0);' onclick='CNOA_odoc_setting_setBindFlow.setStatus("+value+", "+rd.status+")'>"+sText+"</a>&nbsp;&nbsp;";
					h += "<a href='javascript:void(0);' onclick='CNOA_odoc_setting_setBindFlow.addFlow(\"edit\", "+value+")'>修改</a>&nbsp;&nbsp;";
					h += "<a href='javascript:void(0);' onclick='CNOA_odoc_setting_setBindFlow.bindKongJian("+value+")'>绑定控件</a>&nbsp;&nbsp;";
					h += "<a href='javascript:void(0);' onclick='CNOA_odoc_setting_setBindFlow.deleteFlow("+value+")'>删除</a>";
				return h;
			}},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
				
		this.right = new Ext.grid.GridPanel({
			store: this.store,
			loadMask:{msg: lang('waiting')},
			cm:colModel,
			hideBorders:true,
			border:false,
			region:"center",
			layout:'fit',
			autoExpandColumn:'bindKJ',
			stripeRows:true,
			tbar: new Ext.Toolbar({
				items: [
					{
						text:lang('refresh'),
						iconCls: 'icon-system-refresh',
						handler:function(btn){
							_this.store.reload();
						}
					},'-',{
						text:lang('add'),
						iconCls: 'icon-utils-s-add',
						handler:function(btn){
							_this.addFlow("add");
						}
					},'-',
					(function(){
						var h = '<span class="cnoa_color_gray">';
						switch(this.from){
							case 'send':
								h += '绑定发文流程';
								break;
							case 'receive':
								h += '绑定收文流程';
								break;
							case 'borrow':
								h += '绑定借阅流程';
								break;
							return 
						}
						h += '</span>';
						return h;
					})()
				]
			})
		});
		
		this.mainPanel = new Ext.Panel({
			layout:'border',
			id: 'odoc_bind_' + this.from,
			items:[this.right]
		});
	},
	
	setStatus : function(id, status){
		var _this = this;
		
		CNOA.msg.cf("确定要"+(status == 0 ? "启用" : "停用")+"此条公文流程吗？", function(btn){
			if(btn == 'yes'){
				Ext.Ajax.request({
					url: _this.baseUrl + "&task=setStatus",
					method: 'POST',
					params:{id:id},
					success: function(r){
						var result = Ext.decode(r.responseText);
						if(result.success === true){
							CNOA.msg.alert(result.msg,function(){
								_this.store.load();
							});
						}else{
							CNOA.msg.alert(result.msg, function(){});
						}
					}
				});
			}
		});
	},
	
	deleteFlow: function(id){
		var _this = this;
		
		CNOA.msg.cf("确定要删除此条公文流程吗？", function(btn){
			if(btn == 'yes'){
				Ext.Ajax.request({
					url: _this.baseUrl + "&task=deleteFlow",
					method: 'POST',
					params:{id:id},
					success: function(r){
						var result = Ext.decode(r.responseText);
						if(result.success === true){
							CNOA.msg.alert(result.msg,function(){
								_this.store.load();
							});
						}else{
							CNOA.msg.alert(result.msg, function(){});
						}
					}
				});
			}
		});
	},
	
	addFlow : function(tp, id){
		var _this = this;
		var form, flowStore, win;
		
		var loadForm = function(){
			form.getForm().load({
				url: _this.baseUrl + "&task=editLoadBindFlowData",
				params: {id: id},
				method:'POST',
				waitMsg: lang('waiting'),
				success: function(form, action){
					
				}.createDelegate(this),
				failure: function(form, action) {
					CNOA.msg.alert(action.result.msg, function(){
						win.close();
					});
				}.createDelegate(this)
			});
		};
		
		flowStore = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({
				url: this.baseUrl + "&task=getFlowList",
				method:'POST'
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields:[{
					name:'flowId'
				}, {
					name:'name'
				}]
			}),
			listeners:{
				load:function(th, record, opt){
					
				}
			}
		});
		flowStore.load();
		form = new Ext.form.FormPanel({
			border:false,
			labelWidth:60,
			labelAlign:'left',
			autoWidth:true,
			waitMsgTarget:true,
			bodyStyle:"padding:5px",
			items: [
				{
					xtype: 'textfield',
					fieldLabel: lang('flowName'),
					name: 'name',
					width:400
				},
				{
					xtype:'combo',
					fieldLabel:"绑定流程",
					name:'bindFlow',
					hiddenName: 'bindFlow',
					store: flowStore,
					valueField:'flowId',
					displayField:'name',
					mode:'local',
					triggerAction:'all',
					forceSelection:true,
					editable:false,
					width:400
				}
			],
			listeners:{
				"render":function(form){
					if(tp){
						loadForm();
					}
				}
			}
		});
		
		win = new Ext.Window({
			title: (tp == "edit" ? lang('modify') : lang('add')) + (this.from == 'send'?'发文流程':'收文流程') + "绑定",
			width:492,
			height:150,
			modal:true,
			resizable:false,
			layout:'fit',
			items: form,
			buttons:[
				{
					text:lang('save'),
					handler:function(btn){
						
						form.getForm().submit({
					        url: _this.baseUrl+"&task=submitBindFlow",
					        method: 'POST',
					        waitMsg: lang('waiting'),
					        params: {from: _this.from, tp: tp, id: id},
					        success: function(form, action) {
								CNOA.msg.alert(lang('successopt'), function(){
									win.close();
									_this.store.load();
								});
					        }.createDelegate(this),
					        failure: function(form, action) {
					            CNOA.msg.alert(action.result.msg, function(){
					                
					            }.createDelegate(this));
					        }.createDelegate(this)
						});
					}
				},
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
	},
	
	bindKongJian : function(id){
		var _this = this;
				
		var fields = [
			{name:'field'},
			{name:'kongjian'},
			{name:'name'}
		];
		
		var bingFlowStore = new Ext.data.GroupingStore({
			proxy:new Ext.data.HttpProxy({
				url:this.baseUrl + '&task=getBindFieldList'
			}),
			reader:new Ext.data.JsonReader({
				totalProperty:"total",
				root:"data",
				fields:fields
			}),
			listeners:{
				load:function(th, record, opt){}
			}
		});
		
		var flowFieldStore = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({
				url:this.baseUrl + "&task=getFlowFieldList",
				method:'POST'
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields:[{
					name:'id'
				}, {
					name:'name'
				}]
			}),
			listeners:{
				load:function(th, record, opt){
					bingFlowStore.load({params:{from:_this.from, id: id}});
					//if(record.length == 0){
					//	_this.setBindFlow();
					//}
				}
			}
		});
		
		flowFieldStore.load({params:{from:_this.from, id: id}});
		
		var editor = new Ext.ux.grid.RowEditor({
			cancelText: lang('cancel'),
			saveText: lang('update'),
			errorSummary: false
		});
		
		var sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:true
		});
		
		var sortCombo = new Ext.form.ComboBox({
			width:150,
			autoLoad:true,
			triggerAction:'all',
			selectOnFocus:true,
			editable:false,
			store: flowFieldStore,
			valueField:'id',
			displayField:'name',
			mode:'local',
			forceSelection:true
		});
		
		var cm = [new Ext.grid.RowNumberer(),
			{header:'', hidden:true, dataIndex:'field'},
			{header:"输入框",sortable:true,dataIndex:'name',width:200,menuDisabled:true},
			{header:"流程控件",sortable:true,dataIndex:'kongjian',width:200,menuDisabled:true,
				editor: sortCombo,
	            renderer: function(v){
	                var recor;
	                flowFieldStore.each(function(r){
	                    if(r.get('id')==v){
	                        recor=r;
	                        return;
	                    };
	                });
	                return recor==null?"":recor.get("name");
	            }}
		];
		
		var grid = new Ext.grid.GridPanel({
			store:bingFlowStore,
			plain:false,
       		stripeRows:true,
			loadMask:{msg:lang('waiting')},
			region:"center",
			layout:'fit',
			border:false,
			autoScroll:true,
			columns:cm,
			plugins:editor,
			view:new Ext.grid.GroupingView({
				markDirty: false
			})
		});
		
		var win = new Ext.Window({
			title:'绑定流程控件',
			width: 700,
			height: 550,
			resizable: false,
			modal: true,
			layout: 'fit',
			items:grid,
			buttons:[
				{
					text:lang('save'),
					handler:function(btn){
						var data = [];
						Ext.each(bingFlowStore.data.items,function(v, i){
							data.push(v.data);
						});

						Ext.Ajax.request({
							url: _this.baseUrl + "&task=submitBindFlowField",
							method: 'POST',
							params:{data:Ext.encode(data),from:_this.from},
							success: function(r){
								var result = Ext.decode(r.responseText);
								if(result.success === true){
									CNOA.msg.alert(result.msg,function(){
										win.close();
									});
								}else{
									CNOA.msg.alert(result.msg, function(){});
								}
							}
						});
					}
				},
				{
					text:lang('close'),
					handler:function(){
						win.close();
					}
				}
			]
		}).show();
	}
};



CNOA_odoc_setting_flowClass = CNOA.Class.create();
CNOA_odoc_setting_flowClass.prototype = {
	init : function(){
		var _this = this;
		this.from = '';
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_HURRY		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=setting&action=flow";
		
		this.mainPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			region: 'center',
			layout: 'fit',
			items: [
				new CNOA_odoc_setting_setAddWinClass('send')
			],
			tbar:[
				{
		            xtype: 'buttongroup',
		            title: '界面设置',
		            columns: 2,
		            defaults: {
		                scale: 'small',
		                allowDepress: false,
		                toggleGroup: 'odocSettings',
		                iconCls: 'icon-setting',
		                enableToggle: true
		            },
		            items: [
						{
							handler : function(button, event) {
								_this.getSetAddWin('send');
							}.createDelegate(this),
							pressed: true,
							text : "发文"
						},
						{
							handler : function(button, event) {
								_this.getSetAddWin('receive');
							}.createDelegate(this),
							text : "收文"
						}
					]
				},
				{
		            xtype: 'buttongroup',
		            title: '列表设置',
		            columns: 2,
		            defaults: {
		                scale: 'small',
		                allowDepress: false,
		                toggleGroup: 'odocSettings',
		                iconCls: 'icon-setting',
		                enableToggle: true
		            },
					items:[
						{
							handler:function(btn,event){
								_this.getSetWinList('send');
							},
							text:"发文"
						},
						{
							handler:function(btn,event){
								_this.getSetWinList('receive');
							},
							text:"收文"
						}
					]
				},
				{
		            xtype: 'buttongroup',
		            title: '绑定工作流',
		            columns: 3,
		            defaults: {
		                scale: 'small',
		                allowDepress: false,
		                toggleGroup: 'odocSettings',
		                iconCls: 'icon-setting',
		                enableToggle: true
		            },
					items:[
						{
							handler:function(btn,event){
								_this.getSetBindFlow('send');
							},
							text : "发文"
						},
						{
							handler:function(btn,event){
								_this.getSetBindFlow('receive')
							},
							text : "收文"
						},
						{
							handler:function(btn,event){
								CNOA.msg.alert("借阅流程需绑定一个字符型的单选框，来确定是否同意借阅，该控件包含[同意][不同意]", function(){
									_this.getSetBindFlow('borrow');
								})
							},
							text : "借阅"
						}
					]
				},
				"<span class='cnoa_color_red'>创建流程后，如没启用则无法显示</span>"
			]
		});
	},
	
	clearItems : function(){
		try{
			Ext.destroy(this.mainPanel.items.items);
		}catch(e){}
	},
	
	getSetAddWin :function(from){
		this.clearItems();
		this.mainPanel.add(new CNOA_odoc_setting_setAddWinClass(from));
		this.mainPanel.doLayout();
	},
	
	getSetWinList :function(from){
		this.clearItems();
		this.mainPanel.add(new CNOA_odoc_setting_setWinListClass(from));
		this.mainPanel.doLayout();
	},
	
	getSetBindFlow :function(from){
		CNOA_odoc_setting_setBindFlow = new CNOA_odoc_setting_setBindFlowClass(from);
		this.clearItems();
		this.mainPanel.add(CNOA_odoc_setting_setBindFlow.mainPanel);
		this.mainPanel.doLayout();
	}
};

