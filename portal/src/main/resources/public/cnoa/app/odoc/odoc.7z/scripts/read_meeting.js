/**
 * 全局变量
 */

var CNOA_odoc_read_meetingClass, CNOA_odoc_read_meeting;
CNOA_odoc_read_meetingClass = CNOA.Class.create();
CNOA_odoc_read_meetingClass.prototype = {
	init : function(){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NAME		= Ext.id();
		var ID_SEARCH_STIME		= Ext.id();
		var ID_SEARCH_ETIME		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=read&action=meeting";
			
		this.storeBar = {
			storeType : "waiting",
			title : "",
			name : "",
			stime : "",
			etime : ""
		};
		
		this.fields = [
			{name : "rid"},
			{name : "aid"},
			{name : "name"},
			{name : "markname"},
			{name : "title"},
			{name : "stime"},
			{name : "etime"},
			{name : "statusname"},
			{name : "appname"},
			{name : "checktime"},
			{name : "opinion"}
		];
		
		this.store = new Ext.data.Store({
			autoLoad : true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: false
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "rid", dataIndex: 'rid', hidden: true},
			{header: '会议名称', dataIndex: 'name', width: 100, sortable: true, menuDisabled :true, renderer : this.showDetails.createDelegate(this)},
			{header: '主题', dataIndex: 'title', width: 200, sortable: true, menuDisabled :true},
			{header: '会议开始时间', dataIndex: 'stime', width: 120, sortable: true, menuDisabled :true},
			{header: '会议结束时间', dataIndex: 'etime', width: 120, sortable: true, menuDisabled :true},
			{header: '分发意见', dataIndex: 'opinion', width: 200, sortable: true, menuDisabled :true, renderer : this.opinion.createDelegate(this)},
			{header: lang('opt'), dataIndex: 'aid', width: 120, sortable: true, menuDisabled :true, renderer : this.operate.createDelegate(this)},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			border:false,
			store:this.store,
			loadMask : {msg: lang('waiting')},
			cm: this.colModel,
			sm: this.sm,
			hideBorders: true,
			listeners:{
				"rowdblclick":function(button, event){
					
				}
			}, 
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "waiting";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					pressed: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示待阅读的公文列表",
					text : '待阅读'
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "readed";
						_this.store.load({params: _this.storeBar});
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示已阅读的公文列表",
					text : '已阅读'
				},
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid],
			tbar : [
				"会议名称: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_NAME
				},
				"主题: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TITLE
				},
				"会议开始时间: ",
				{
					xtype : "datefield",
					width : 150,
					format : "Y-m-d",
					id : ID_SEARCH_STIME
				},
				"会议结束时间: ",
				{
					xtype : "datefield",
					width : 150,
					format : "Y-m-d",
					id : ID_SEARCH_ETIME
				},
				{
					xtype: "button",
					text: lang('search'),
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.name 		= Ext.getCmp(ID_SEARCH_NAME).getValue();
						_this.storeBar.stime 		= Ext.getCmp(ID_SEARCH_STIME).getRawValue();
						_this.storeBar.etime 		= Ext.getCmp(ID_SEARCH_ETIME).getRawValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:lang('clear'),
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NAME).setValue("");
						Ext.getCmp(ID_SEARCH_STIME).setValue("");
						Ext.getCmp(ID_SEARCH_ETIME).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.name 		= "";
						_this.storeBar.stime 		= "";
						_this.storeBar.etime 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]
		});
	},
	
	showDetails : function(value, cellmeta, record, rowIndex, columnIndex, color_store){
		return "<a href='javascript:void(0)' onclick='CNOA_odoc_read_meeting.showDetailsWin("+record.data.rid+", "+record.data.aid+")'>"+value+"</a>";
	},
	
	showDetailsWin : function(rid, aid){
		var _this = this;
		
		if(_this.storeBar.storeType == "waiting"){
			Ext.Ajax.request({  
				url: this.baseUrl + "&task=readed",
				method: 'POST',
				params: {rid : rid},
				success: function(r) {
					var result = Ext.decode(r.responseText);
					if(result.success === true){
					
					}else{
						CNOA.msg.alert(result.msg);
					}
				}
			});
		}
		
		var src = _this.baseUrl+"&task=viewMeetingRoomApplyDetails&aid="+aid;
		var win = Ext.id();
		var panel = new Ext.Panel({
			border:false,
			html: '<div style="width:100%;height:570px;"><iframe scrolling=auto frameborder=0 width=100% height=100% id="'+win+'"></iframe></div>',
			listeners:{
				afterrender:function(){
					Ext.getDom(win).contentWindow.location.href = src;
				}
			}
		});
		
		var win = new Ext.Window({
			title : "查看会议详细信息",
			width:800,
			height:makeWindowHeight(600),
			resizable: false,
			modal: true,
			items : [panel],
			buttons : [
				{
					text : lang('close'),
					handler : function(btn, e){
						if (_this.storeBar.storeType == "waiting") {
							CNOA.msg.alert("您阅读的会议信息已经转移到已阅读列表中,可在已阅读列表中查看", function(){
								win.close();
							});
						}else{
							win.close();
						}
					}
				}
			],
			listeners : {
				"beforeclose" : function(th){
					if (_this.storeBar.storeType == "waiting") {
						_this.store.reload();
					}
				}
			}
		}).show();
	},
	
	operate : function(value, c, record){
		return "<a href='javascript:void(0)' onclick='CNOA_odoc_read_meeting.read("+record.data.aid+")'>阅读情况</a>";
	},
	
	opinion : function(value, c, record){
		var _this = this;
		return "<a href='javascript:void(0)' onclick='CNOA_odoc_read_meeting.viewopinion(\""+value+"\")'>"+value+"</a>";
	},
	
	viewopinion : function(value){
		var _this = this;
		
		CNOA.msg.alert(value);
	},
	
	read : function(aid){
		var _this = this;
		
		var fields = [
			{name:"deptname"},
			{name:"name"},
			{name:"readtime"}
		];
		
		var store = new Ext.data.Store({
			proxy:new Ext.data.HttpProxy({url: _this.baseUrl+"&task=getReaderList&aid="+aid, disableCaching: true}),
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: fields})
		});
		
		store.load();
		
		var sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:false
		});
		
		var colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			{header: "所属部门", dataIndex: 'deptname', width: 100, sortable: true, menuDisabled :true},
			{header: "名字", dataIndex: 'name', width: 100, sortable: false,menuDisabled :true},
			{header: "阅读日期", dataIndex: 'readtime', width: 150, sortable: true, menuDisabled :true},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		var Grid = new Ext.grid.GridPanel({
			stripeRows : true,
			store : store,
			region : "center",
			layout : "fit",
			loadMask : {msg: lang('waiting')},
			cm : colModel,
			sm : sm,
			hideBorders : true,
			border : false,
			viewConfig : {
				forceFit : true
			}
		});
		
		var win = new Ext.Window({
			title : "阅读情况",
			layout : "border",
			width : 600,
			height : makeWindowHeight(500),
			resizable : false,
			modal : true,
			items : [Grid],
			buttons : [
				{
					text : lang('close'),
					handler : function(){
						win.close();
					}
				}
			]
		}).show();
	}
};