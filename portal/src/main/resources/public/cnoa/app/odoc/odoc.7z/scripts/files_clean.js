/**
 * 全局变量
 */

var CNOA_odoc_files_clean, CNOA_odoc_files_cleanClass;
CNOA_odoc_files_cleanClass = CNOA.Class.create();
CNOA_odoc_files_cleanClass.prototype = {
	init:function(){
		var _this = this;
		
		this.ID_anJuan			= Ext.id();
				
		this.baseUrl = "index.php?app=odoc&func=files&action=clean";
		
		Ext.Ajax.request({
			url:_this.baseUrl + "&task=loadColumn",
			method:'POST',
			success:function(r){
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.layoutPanel(result);
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	layoutPanel:function(result){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NUMBER	= Ext.id();
		var ID_SEARCH_SORT		= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_STIME		= Ext.id();
		var ID_SEARCH_ETIME		= Ext.id();
		
		this.select = {
			room : "",
			year : ""
		};
		
		this.storeBar = {
			storeType : "send",
			title : "",
			number : "",
			type : "",
			level : "",
			stime : "",
			etime : ""
		};
		
		this.smSend = new Ext.grid.CheckboxSelectionModel({
			singleSelect:false
		});
		
		this.cmSend = [new Ext.grid.RowNumberer(), this.smSend,
			{header:'操作',sortable:true,dataIndex:'id',width:140,menuDisabled:true,renderer:function(v, c, record){
				var rd = record.data;
				var l = '';
				if(rd.status == 2){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_clean.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}else if(rd.status == 0){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_clean.operate('+v+')">发起审批</a>';
				}else if(rd.status == 1){
					l += '审批中';
				}
				return l;
			}},
			{header:'添加时间',sortable:true,dataIndex:'posttime',width:100,menuDisabled:true}
		];

		this.fieldSend = [{name:'id'},{name:'posttime'},{name:'status'},{name:'uFlowId'}];
		Ext.each(result.column.send, function(v,i){
			_this.fieldSend.push({name:'field_'+v.field});
			_this.cmSend.push({
				header			:v.title,
				sortable		:true,
				dataIndex		:'field_'+v.field,
				width			:v.width,
				menuDisabled	:true
			});
		});
		
		this.typeListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getTypeList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.typeListStore.load();
		
		this.levelListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getLevelList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "tid"},
					{name : "title"}
				]
			})
		});
		
		this.levelListStore.load();
		
		this.roomListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getRoomList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.roomListStore.load();
		
		this.anJuanListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getAnjuanList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			}),
			listeners : {
				"load" : function(){
					//Ext.getCmp(_this.ID_anJuan).setValue(_this.anjuanid);
				}
			}
		});
		
		this.wenzhongListStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=getWenzhongList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.wenzhongListStore.load();
		
		this.storeSend = new Ext.data.Store({
			autoLoad:true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData&from=send", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:this.fieldSend}),
			listeners:{
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		this.storeSend.load({params:{from:'send'}});
				
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.storeSend,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.gridSend = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			border:false,
			store:this.storeSend,
			loadMask : {msg: lang('loading')},
			columns: this.cmSend,
			sm: this.smSend,
			hideBorders: true,
			listeners:{
				"rowdblclick" : function(button, event){}
			},
			bbar: this.pagingBar
		});
		
		
		this.smReceive = new Ext.grid.CheckboxSelectionModel({
			singleSelect:false
		});
		
		this.cmReceive = [new Ext.grid.RowNumberer(), this.smReceive,
			{header:'操作',sortable:true,dataIndex:'id',width:140,menuDisabled:true,renderer:function(v, c, record){
				var rd = record.data;
				var l = '';
				if(rd.status == 2){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_clean.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}else if(rd.status == 0){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_files_clean.operate('+v+')">发起审批</a>';
				}else if(rd.status == 1){
					l += '审批中';
				}
				return l;
			}},
			{header:'添加时间',sortable:true,dataIndex:'posttime',width:100,menuDisabled:true},
			{header:'来文机关',sortable:true,dataIndex:'deptment',width:100,menuDisabled:true},
			{header:'来文标题',sortable:true,dataIndex:'title',width:100,menuDisabled:true},
			{header:'来文编号',sortable:true,dataIndex:'number',width:100,menuDisabled:true}
		];

		this.fieldSend = [{name:'id'},{name:'posttime'},{name:'status'},{name:'uFlowId'},{name:'deptment'},{name:'title'},{name:'number'}];
		Ext.each(result.column.receive, function(v,i){
			_this.fieldSend.push({name:'field_'+v.field});
			_this.cmReceive.push({
				header			:v.title,
				sortable		:true,
				dataIndex		:'field_'+v.field,
				width			:v.width,
				menuDisabled	:true
			});
		});
		
		this.storeReceive = new Ext.data.Store({
			autoLoad:true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData&from=receive", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:this.fieldSend}),
			listeners:{
				"load" : function(th, rd, op){
				}
			}
		});
		
		this.storeReceive.load({params:{from:'receive'}});
		
		this.gridReceive = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			border:false,
			store:this.storeReceive,
			loadMask : {msg: lang('loading')},
			columns: this.cmReceive,
			sm: this.smReceive,
			hideBorders: true,
			listeners:{
				"rowdblclick" : function(button, event){}
			},
			bbar: this.pagingBar
		});
		
		this.secondPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			region:'center',
			layout:'card',
			autoScroll:false,
			activeItem:0,
			items:[this.gridSend, this.gridReceive],
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.storeReceive.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.add("add", 0);
					}.createDelegate(this),
					iconCls: 'icon-folder--pencil',
					text : '著录'
				},"-",
				{
					handler : function(button, event) {
						if(_this.storeBar.storeType == "receive"){
							var rows = _this.gridReceive.getSelectionModel().getSelections();
						}else{
							var rows = _this.gridSend.getSelectionModel().getSelections();
						}
						if(rows.length == 0){
							CNOA.miniMsg.alertShowAt(button, "您还没有选择要归档的信息");
						}else{
							var ids = "";
							for(var i = 0; i < rows.length; i++){
								ids += rows[i].get("id") + ",";
							}
							_this.collect(ids);
						}
					}.createDelegate(this),
					iconCls: 'icon-folder--plus',
					text : '归档'
				},"-",
				{
					handler : function(button, event) {
						_this.deleteList(button, _this.storeBar.storeType);
					}.createDelegate(this),
					iconCls: 'icon-utils-s-delete',
					text : '删除'
				},"-",
				{
					handler:function(button, event){
						_this.storeBar.storeType = "send";
						_this.secondPanel.layout.setActiveItem(0);
					}.createDelegate(this),
					iconCls:'icon-roduction',
					pressed:true,
					enableToggle:true,
					allowDepress:false,
					toggleGroup:"meeting_room_check",
					tooltip:"显示发文的公文列表",
					text:'发文列表'
				},"-",
				{
					handler:function(button, event){
						_this.storeBar.storeType = "receive";
						_this.secondPanel.layout.setActiveItem(1);
					}.createDelegate(this),
					iconCls:'icon-roduction',
					enableToggle:true,
					allowDepress:false,
					toggleGroup:"meeting_room_check",
					tooltip:"显示收文的公文列表",
					text:'收文列表'
				}
			]			
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			layout:'border',
			autoScroll:false,
			items:[this.secondPanel],
			tbar:[
				"标题:",
				{
					xtype:"textfield",
					width:100,
					id:ID_SEARCH_TITLE
				},
				"文号:",
				{
					xtype:"textfield",
					width:100,
					id:ID_SEARCH_NUMBER
				},
				"类别:",
				new Ext.form.ComboBox({
					name:'title',
					store:_this.typeListStore,
					width:100,
					id:ID_SEARCH_TYPE,
					hiddenName:'tid',
					valueField:'tid',
					displayField:'title',
					mode:'local',
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}),
				"密级: ",
				new Ext.form.ComboBox({
					name:'title',
					store:_this.levelListStore,
					width:100,
					id:ID_SEARCH_LEVEL,
					hiddenName:'tid',
					valueField:'tid',
					displayField:'title',
					mode:'local',
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}),
				"起始日期",
				{
					xtype:"datefield",
					format:"Y-m-d",
					id:ID_SEARCH_STIME,
					width:100
				},
				"终止日期",
				{
					xtype:"datefield",
					format:"Y-m-d",
					id:ID_SEARCH_ETIME,
					width:100
				},
				{
					xtype:"button",
					text:"查询",
					style:"margin-left:5px",
					cls:"x-btn-over",
					listeners:{
						"mouseout":function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler:function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.number 		= Ext.getCmp(ID_SEARCH_NUMBER).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						_this.storeBar.level 		= Ext.getCmp(ID_SEARCH_LEVEL).getValue();
						_this.storeBar.stime 		= Ext.getCmp(ID_SEARCH_STIME).getRawValue();
						_this.storeBar.etime 		= Ext.getCmp(ID_SEARCH_ETIME).getRawValue();

						_this.storeSend.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:"清空",
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NUMBER).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
						Ext.getCmp(ID_SEARCH_STIME).setValue("");
						Ext.getCmp(ID_SEARCH_ETIME).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.number 		= "";
						_this.storeBar.type 		= "";
						_this.storeBar.level 		= "";
						_this.storeBar.stime 		= "";
						_this.storeBar.etime 		= "";
						
						_this.storeSend.load({params:_this.storeBar});
					}
				}
			]
		});

		Ext.getCmp(CNOA.odoc.files.clean.parentID).add(this.mainPanel);
		Ext.getCmp(CNOA.odoc.files.clean.parentID).doLayout();
	},
	
	//整理要删除的ID列表	
	deleteList:function(button, fromType){
		var _this = this;				
		var rows = _this.gridSend.getSelectionModel().getSelections(); // 返回值为 Record 数组 
		if (rows.length == 0) {
			CNOA.miniMsg.alertShowAt(button, lang('mustSelectOneRow'));

		} else {
			CNOA.msg.cf("您确定要删除?", function(btn) {
				if (btn == 'yes') {
					if (rows) {
						var ids = "";
						var row = '';
						for (var i = 0; i < rows.length; i++) {
							var row		= rows[i];
							var id		= parseInt(row.get("id"));
							ids += id + ",";							
						}
						_this.deleteData(ids, fromType);
					}
				}
			});
		}
	},
	
	//发送删除信息
	deleteData:function(ids, fromType){
	    var	_this = this;
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=delete",
			method: 'POST',
			params: { ids: ids, fromType:fromType },
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					CNOA.msg.notice(result.msg, "公文管理");
					_this.storeSend.reload();
					_this.storeReceive.reload();
				}else{
					CNOA.msg.alert(result.msg);
				}
			}
		});
	},
	
	operate : function(value,c,record) {
		var _this	= this;
		var rd = record.data;
		return '<a href="javascript:void(0)" onclick="CNOA_odoc_files_clean.viewFlow('+rd.uFlowId+')">查看流程</a>';
	},
	
	viewFlow:function(uFlowId){
		mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
		mainPanel.loadClass(this.baseUrl+"&task=loadpage&from=viewflow&uFlowId="+uFlowId, "CNOA_MENU_WF_USE_OPENFLOW", "查看工作流程", "icon-flow");
	},
	
	add : function(type, id){
		var _this = this;
		
		var loadFileFormData = function(){
			form.getForm().load({
				url: _this.baseUrl + "&task=loadFileFormData",
				params : {id : id},
				method:'POST',
				waitTitle: lang('waiting'),
				success: function(form, action){
					_this.anjuanid = action.result.data.anjuan;
					_this.anJuanListStore.load({params : action.result.data.year});
					//Ext.getCmp(_this.ID_anJuan).setValue(_this.anjuanid);
				},
				failure: function(form, action) {
					CNOA.msg.alert(action.result.msg, function(){
						
					});
				}
			})
		};
		
		var submit = function(){
			if (form.getForm().isValid()) {
				form.getForm().submit({
					url: _this.baseUrl + "&task=add",
					waitTitle: lang('waiting'),
					method: 'POST',
					params : {storeType : _this.storeBar.storeType, id:id},
					waitMsg: lang('loading'),
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						win.close();
						_this.storeSend.reload();
						_this.storeReceive.reload();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg, function(){});
					}.createDelegate(this)
				});
			}
		};
		
		var baseField = [
			{
				xtype: "fieldset",
				title: "著录信息",
				autoHeight: true,
				defaults : {
					border : false,
					style : "margin-bottom : 5px"
				},
				items: [
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype:"textfield",
										fieldLabel:"文件标题",
										width:150,
										name:"title",
										allowBlank : false
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										fieldLabel : "密级",
										name: 'level',
										store: _this.levelListStore,
										width: 150,
										allowBlank : false,
										hiddenName: 'level',
										valueField: 'tid',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false
									})
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "件号",
										width: 150,
										name : "filesnum",
										allowBlank : false
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "文件字号",
										name : "number",
										width: 150,
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "datefield",
										fieldLabel: "成文日期",
										name : "senddate",
										format : "Y-m-d",
										width: 150,
										allowBlank : false
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "责任者",
										width: 150,
										name : "respon",
										value : CNOA_USER_TRUENAME
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "页号",
										name : "page",
										width: 150
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "datefield",
										fieldLabel: "归档日期",
										name : "collectdate",
										format : "Y-m-d",
										width: 150,
										allowBlank : false
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'room',
										store: _this.roomListStore,
										width: 150,
										fieldLabel : "档案室",
										hiddenName: 'room',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false,
										listeners : {
											"select" : function(th, record, num){
												form.getForm().findField("anjuan").setValue("");
												_this.select.room = record.id;
												_this.anJuanListStore.load({params : _this.select.room});
											}
										}
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'wenzhong',
										store: _this.wenzhongListStore,
										width: 150,
										fieldLabel : "文种",
										hiddenName: 'wenzhong',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false
									})
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										fieldLabel: "年度",
										name: 'year',
										store: new Ext.data.SimpleStore({
											fields: ['value', 'year'],
											data: (function(){
												var Y = new Date().getFullYear()+1;
												var arr	= [];
												for(var i=0; i<20;i++){
													arr[i]	= [Y, Y];
													Y--;
												}
												return arr;
											})()
										}),
										width: 150,
										hiddenName: 'year',
										valueField: 'value',
										displayField: 'year',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										regex: /^\+?[1-9][0-9]*$/i,
										regexText: '必须设置为正整数',
										allowBlank : false,
										listeners : {
											"select" : function(th, record, num){
												form.getForm().findField("anjuan").setValue("");
												_this.select.year = record.data.value;
												_this.anJuanListStore.load({params : _this.select.year});
											}
										}
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										id: _this.ID_anJuan,
										name: 'anjuan',
										store: _this.anJuanListStore,
										width: 150,
										fieldLabel : "案卷",
										hiddenName: 'anjuan',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false
									})
								]
							}
						]
					},
					{
						xtype: "flashfile",
						fieldLabel: "添加附件",
						style: "margin-top:5px;",
						inputPre: "filesUpload",
						name : "attach"
					},
					{
						xtype : "textarea",
						fieldLabel : "备注",
						width : 385,
						height : 50,
						name: "note"
					}
				]
			}
		];
		
		var form = new Ext.form.FormPanel({
			border: false,
			labelWidth: 80,
			labelAlign: 'right',
			region : "center",
			layout : "fit",
			waitMsgTarget: true,
			items:[
				{
					xtype: "panel",
					border: false,
					bodyStyle: "padding:10px",
					layout: "form",
					region: "center",
					autoScroll: true,
					items: baseField
				}
			]
		});
		
		var win = new Ext.Window({
			title : "著录窗口",
			layout : "border",
			width : 550,
			height : makeWindowHeight(420),
			resizable : false,
			modal : true,
			items : [form],
			buttons : [
				{
					text : "提交",
					handler : function(){
						submit();
					}
				},
				{
					text : "取消",
					handler : function(){
						win.close();
					}
				}
			]
		}).show();
		if(type == "edit"){
			loadFileFormData();
		}
	},
	
	collect : function(ids){
		var _this = this;
		
		var submit = function(ids){
			if (form.getForm().isValid()) {
				form.getForm().submit({
					url: _this.baseUrl + "&task=collect",
					waitTitle: lang('waiting'),
					params : {ids : ids, storeType : _this.storeBar.storeType},
					method: 'POST',
					waitMsg: lang('loading'),
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						win.close();
						_this.storeSend.reload();
						_this.storeReceive.reload();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg, function(){

						});
					}.createDelegate(this)
				});
			}
		};
		
		var loadFormData = function(ids, type){
			form.getForm().load({
				url: _this.baseUrl + "&task=loadFormData",
				params : {ids : ids, storeType : type},
				method:'POST',
				waitTitle: lang('waiting'),
				success: function(form, action){
					
				},
				failure: function(form, action) {
					CNOA.msg.alert(action.result.msg, function(){
						
					});
				}
			})
		};
		
		var baseField = [
			{
				xtype: "fieldset",
				title: "归档信息",
				autoHeight: true,
				defaults : {
					border : false,
					style : "margin-bottom : 5px"
				},
				items: [
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "文件标题",
										width: 150,
										name : "title"
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										fieldLabel:"文件类型",
										store:new Ext.data.SimpleStore({
											fields:['value', 'text'],
											data:[['0', "其他"], ['1', "发文"], ['2', "收文"]]
										}),
										width:150,
										valueField:'value',
										displayField:'text',
										mode:'local',
										triggerAction:'all',
										forceSelection:true,
										editable:false,
										hiddenName:'type',
										name:'name',
										listeners:{
											select:function(th, record, index){
												var id = record.data.value;
												submit("gender", id);
											}
										}
									})
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "成文日期",
										name : "senddate",
										width: 150
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "文件字号",
										width: 150,
										name : "number"
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "归档日期",
										width: 150,
										name : "guidangdate"
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "责任者",
										width: 150,
										name : "respon",
										value : CNOA_USER_TRUENAME
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "页号",
										width: 150,
										name : "page"
									}
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									{
										xtype: "textfield",
										fieldLabel: "件号",
										name : "filesnum",
										width: 150
									}
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'room',
										store: _this.roomListStore,
										width: 150,
										fieldLabel : "档案室",
										hiddenName: 'room',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false,
										listeners : {
											"select" : function(th, record, num){
												form.getForm().findField("anjuan").setValue("");
												_this.select.room = record.id;
												_this.anJuanListStore.load({params : _this.select.room});
											}
										}
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'wenzhong',
										store: _this.wenzhongListStore,
										width: 150,
										fieldLabel : "文种",
										hiddenName: 'wenzhong',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false
									})
								]
							}
						]
					},
					{
						xtype : "panel",
						layout : "table",
						column : 2,
						defaults : {
							border : false
							//style : "margin-bottom : 5px"
						},
						items : [
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										fieldLabel: "年度",
										name: 'anjuandate',
										store: new Ext.data.SimpleStore({
											fields: ['value', 'anjuandate'],
											data: (function(){
												var Y = new Date().getFullYear()+1;
												var arr	= [];
												for(var i=0; i<20;i++){
													arr[i]	= [Y, Y];
													Y--;
												}
												return arr;
											})()
										}),
										width: 150,
										hiddenName: 'anjuandate',
										valueField: 'value',
										displayField: 'anjuandate',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false,
										listeners : {
											"select" : function(th, record, num){
												form.getForm().findField("anjuan").setValue("");
												_this.select.year = record.data.value;
												_this.anJuanListStore.load({params : _this.select});
											}
										}
									})
								]
							},
							{
								xtype: "panel",
								layout: "form",
								items: [
									new Ext.form.ComboBox({
										name: 'anjuan',
										store: _this.anJuanListStore,
										width: 150,
										fieldLabel : "案卷",
										hiddenName: 'anjuan',
										valueField: 'id',
										displayField: 'title',
										mode: 'local',
										triggerAction: 'all',
										forceSelection: true,
										editable: false,
										allowBlank : false
									})
								]
							}
						]
					},
					new Ext.BoxComponent({
						autoEl: {
							tag: 'div',
							style: "margin-left:80px;margin-top:5px;margin-bottom:5px;color:#676767;",
							html: '注意:案卷管理是通过档案室和年度筛选出来的,选择了档案室和年度才会显示出相应的案卷'
						}
					})
				]
			}
		];
		
		var form = new Ext.form.FormPanel({
			border: false,
			labelWidth: 80,
			labelAlign: 'right',
			region : "center",
			layout : "fit",
			waitMsgTarget: true,
			items:[
				{
					xtype: "panel",
					border: false,
					bodyStyle: "padding:10px",
					layout: "form",
					region: "center",
					autoScroll: true,
					items: baseField
				}
			]
		});
		
		var win = new Ext.Window({
			title:"归档窗口",
			layout:"border",
			width:550,
			height:360,
			resizable:false,
			modal:true,
			items:form,
			buttons:[
				{
					text:"确认",
					handler:function(){
						submit(ids);
					}
				},
				{
					text:"取消",
					handler:function(){
						win.close();
					}
				}
			]
		}).show();
		
		loadFormData(ids, _this.storeBar.storeType);
	},
	
	viewFlow:function(uFlowId){
		mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
		mainPanel.loadClass(this.baseUrl+"&task=loadpage&from=viewflow&uFlowId="+uFlowId, "CNOA_MENU_WF_USE_OPENFLOW", "查看工作流程", "icon-flow");
	}
}

