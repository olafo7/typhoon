<?php 
class odocFilesBorrow extends model{
	private $t_files_dangan			= "odoc_files_dangan";
	private $t_files_borrow_list	= "odoc_files_borrow_list";
	private $t_flow_step			= "odoc_setting_flow_step";
	private $t_flow_step_list		= "odoc_step";
	private $t_files_read			= "odoc_read_file";
	
	private $t_s_flow_other_app_data= 'wf_s_flow_other_app_data';
	
	private $t_odoc_view_fieldset	= "odoc_view_fieldset";
	private $t_odoc_view_field		= "odoc_view_field";
	private $t_odoc_data			= "odoc_data";
	private $t_odoc_view_field_list = "odoc_view_field_list";
	private $t_odoc_bind_flow_kj		= "odoc_bind_flow_kj";
	
	private $f_from			= array(3=>"其他", 1=>"发文", 2=>"收文");
	
	private $rows			= 15;
									
	/**
	 * 构造函数
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * 析构函数
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "getFaqiFlow":
				$this->_getFaqiFlow();
				break;
			case "getTypeList" :
				app::loadApp("odoc", "settingWord")->api_getTypeList();
				break;
			case "getLevelList" :
				app::loadApp("odoc", "settingWord")->api_getLevelList();
				break;
			case "getAllUserListsInPermitDeptTree" :
				$GLOBALS['user']['permitArea']['area'] = "all";
				$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
				echo json_encode($userList);
				exit;
			case "getStructTree" :
				$GLOBALS['user']['permitArea']['area'] = "all";
				echo app::loadApp("main", "struct")->api_getStructTree();
				exit;
			case "getStepJsonData" :
				$this->_getStepJsonData();
				break;
			case "getFlowList" :
				app::loadApp("odoc", "settingFlow")->api_getFlowList("borrow");
				break;
			case "getFlowDetails" :
				app::loadApp("odoc", "settingFlow")->api_getFlowDetails();
				break;
			case "nextStep" :
				$this->_nextStep();
				break;
		}
	}
	
	private function _loadpage(){
		global $CNOA_CONTROLLER,$CNOA_DB;
		$from = getPar($_GET, "from", "");
		
		switch($from){
			case 'viewflow'	:
				//查看流程
				$GLOBALS['app']['uFlowId'] 			= getPar($_GET, "uFlowId", 0);				
				$GLOBALS['app']['step']				= getPar($_GET, "step", 0);
		
				$GLOBALS['app']['wf']['type']		= "done";//已办流程， 用于查看页面显示召回和撤销按钮
				$DB									= $CNOA_DB->db_getone(array("status", "flowId"), "wf_u_flow", "WHERE `uFlowId`='{$GLOBALS['app']['uFlowId']}'");
				$GLOBALS['app']['flowId']			= $DB['flowId'];
				$flow								= $CNOA_DB->db_getone(array("tplSort", "flowType"), "wf_s_flow", "WHERE `flowId` = {$DB['flowId']} ");
				$GLOBALS['app']['wf']['allowCallback']	= 0;
				$GLOBALS['app']['wf']['allowCancel']	= 0;
				$GLOBALS['app']['allowPrint']			='false';
				$GLOBALS['app']['allowFenfa']			='false';
				$GLOBALS['app']['allowExport']			='false';
				$GLOBALS['app']['status']				= 1;
				$GLOBALS['app']['wf']['tplSort']		= $flow["tplSort"];
				$GLOBALS['app']['wf']['flowType']		= $flow["flowType"];
				$GLOBALS['app']['wf']['owner']			= 0;//getpar($_GET, "owner", 0);
				$tplPath = CNOA_PATH . '/app/wf/tpl/default/flow/use/showflow.htm';
				$CNOA_CONTROLLER->loadExtraTpl($tplPath);exit;
		}
		
		$GLOBALS['files']['from'] = $from;
		$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/files/borrow.htm';
		$CNOA_CONTROLLER->loadExtraTpl($tplPath);
		exit;
	}
	
	private function _getJsonData(){
		global $CNOA_DB;
		
		$this->_checkData();
		
		$start = getPar($_POST, "start", 0);
		$storeType = getPar($_POST, "storeType", "all");
		$WHERE = "WHERE 1 ";
		if($storeType == "all"){
			$this->__getJsonDataByALl();
		}elseif ($storeType == "waiting"){
			$WHERE .= "AND `status` = '1' ";
		}elseif ($storeType == "pass"){
			$WHERE .= "AND `status` = '2' ";
		}elseif ($storeType == "unpass"){
			$WHERE .= "AND `status` = '3' ";
		}elseif ($storeType == "return"){
			$WHERE .= "AND `status` = '4' ";
		}
		
		$s_sort		= getPar($_POST, "sort", 0);
		$s_title	= getPar($_POST, "title", "");
		$s_number	= getPar($_POST, "number", "");
		$s_type		= getPar($_POST, "type", 0);	
		$s_level	= getPar($_POST, "level", 0);
		$s_stime	= getPar($_POST, "stime", 0);
		$s_etime	= getPar($_POST, "etime", 0);
		
		$WHERE2 = "";
		if(!empty($s_sort)){
			$WHERE2 .= "AND `from` = '{$s_sort}' ";
		}
		if(!empty($s_title)){
			$WHERE2 .= "AND `title` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_number)){
			$WHERE2 .= "AND `number` LIKE '%{$s_number}%' ";
		}
		if(!empty($s_type)){
			$WHERE2 .= "AND `type` = '{$s_type}' ";
		}
		if(!empty($s_level)){
			$WHERE2 .= "AND `level` = '{$s_level}' ";
		}
		if(!empty($s_stime)){
			$s_stime = strtotime($s_stime);
			$WHERE2 .= "AND `collectdate` > '{$s_stime}' ";
		}
		if(!empty($s_etime)){
			$s_etime = strtotime($s_etime);
			$WHERE2 .= "AND `collectdate` < '{$s_etime}' ";
		}
		if(!empty($WHERE2)){
			$fileDB = $CNOA_DB->db_select(array("id"), $this->t_files_dangan, "WHERE 1 " . $WHERE2 . "AND `anjuanstatus` = '0' ");
			!is_array($fileDB) && $fileDB = arrat();
			$fileArr = array(0);
			foreach ($fileDB as $k=>$v) {
				$fileArr[] = $v['id'];
			}
			$WHERE = "AND `fileid` IN (" . implode(",", $fileArr) . ") ";
		}
		
		$dblist = $CNOA_DB->db_select(array("fileid", "status", "uFlowId"), $this->t_files_borrow_list, $WHERE . "ORDER BY `id` DESC LIMIT {$start}, {$this->rows}");

		!is_array($dblist) && $dblist = array();
		$idArr = array(0);
		foreach ($dblist as $k=>$v) {
			$idArr[] = $v['fileid'];
		}
		$danganArr = app::loadApp("odoc", "filesDananmgr")->api_getAllDanganArr($idArr);
		foreach ($dblist as $k=>$v) {
			$dblist[$k]				= $danganArr[$v['fileid']];
			$dblist[$k]['status']	= $v['status'];
			$dblist[$k]['uFlowId']	= $v['uFlowId'];
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		$dataStore->total = $CNOA_DB->db_getcount($this->t_files_borrow_list, $WHERE);
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _checkData(){
		global $CNOA_DB, $CNOA_SESSION;
	
		$dblist = $CNOA_DB->db_select(array("otherAppId"), $this->t_files_borrow_list, "WHERE `status` != 2 ");
		!is_array($dblist) && $dblist = array();
		$otherAppIDArr = array(0);
		foreach ($dblist as $k=>$v){
			$otherAppIDArr[] = $v['otherAppId'];
		}
		$dblist = $CNOA_DB->db_select(array("uFlowId", "id"), $this->t_s_flow_other_app_data, "WHERE `id` IN (".implode(",", $otherAppIDArr).") ");
		$uFlowIdArr = array(0);
		$tempArr = array();
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v){
			$uFlowIdArr[] = $v['uFlowId'];
			$tempArr[$v['uFlowId']] = $v['id'];
		}
	
		$bindData = $CNOA_DB->db_select("*", $this->t_odoc_bind_flow_kj, "WHERE `kongjian` > 0 AND `from` = 'borrow' ");
		!is_array($bindData) && $bindData = array();
		$statusDB = $CNOA_DB->db_select(array('status', 'uFlowId', 'flowId'), "wf_u_flow", "WHERE `uFlowId` IN (".implode(",", $uFlowIdArr).") ");
		!is_array($statusDB) && $statusDB = array();
		foreach ($statusDB as $k=>$v){
			if($v['status'] == 2){
				$data = $CNOA_DB->db_getone("*", "z_wf_t_".$v['flowId'], "WHERE `uFlowId` = {$v['uFlowId']} ");
				!is_array($data) && $data = array();
				foreach ($data as $key=>$val){
					$update['uFlowId'] = $v['uFlowId'];
					foreach ($bindData as $k2 => $v2){
						if($key == "T_".$v2['kongjian']){
							if($v2['type'] == 'stime' || $v2['type'] == 'etime'){
								$val = str_replace('年', '-', $val);
								$val = str_replace('月', '-', $val);
								$val = str_replace('日', '', $val);
								$val = strtotime($val);
								if($v2['type'] == 'stime'){
									$update['stime'] = $val;
								}else{
									$update['etime'] = $val;
								}
							}else if($v2['type'] == 'agree'){
								if($val == '同意'){
									$update['status'] = 2;
								}else if($val == '不同意'){
									$update['status'] = 3;
								}
							}else if($v2['type'] == 'reason'){
								$update['reason'] = $val;
							}
						}
					}
				}
				$CNOA_DB->db_update($update, $this->t_files_borrow_list, "WHERE `otherAppId` = {$tempArr[$v['uFlowId']]} ");
			}else{
				$CNOA_DB->db_update(array('status'=>1, 'uFlowId'=>$v['uFlowId']), $this->t_files_borrow_list, "WHERE `otherAppId` = {$tempArr[$v['uFlowId']]} ");
			}
		}
	}
	
	private function __getJsonDataByALl(){
		global $CNOA_DB;
		$WHERE = "WHERE 1 ";
		$start	= getPar($_POST, "start", 0);
		
		$s_sort		= getPar($_POST, "sort", 0);
		$s_title	= getPar($_POST, "title", "");
		$s_number	= getPar($_POST, "number", "");
		$s_type		= getPar($_POST, "type", 0);	
		$s_level	= getPar($_POST, "level", 0);
		$s_stime	= getPar($_POST, "stime", 0);
		$s_etime	= getPar($_POST, "etime", 0);
		
		if(!empty($s_sort)){
			$WHERE .= "AND `from` = '{$s_sort}' ";
		}
		if(!empty($s_title)){
			$WHERE .= "AND `title` LIKE '%{$s_title}%' ";
		}
		if(!empty($s_number)){
			$WHERE .= "AND `number` LIKE '%{$s_number}%' ";
		}
		if(!empty($s_type)){
			$WHERE .= "AND `type` = '{$s_type}' ";
		}
		if(!empty($s_level)){
			$WHERE .= "AND `level` = '{$s_level}' ";
		}
		if(!empty($s_stime)){
			$s_stime = strtotime($s_stime);
			$WHERE .= "AND `collectdate` > '{$s_stime}' ";
		}
		if(!empty($s_etime)){
			$s_etime = strtotime($s_etime);
			$WHERE .= "AND `collectdate` < '{$s_etime}' ";
		}
		
		$dblist = $CNOA_DB->db_select("*", $this->t_files_dangan, $WHERE . "AND `anjuanstatus` = '0' ORDER BY `id` DESC LIMIT {$start}, {$this->rows}");
	
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['from']		= $this->f_from[$v['from']];
			$dblist[$k]['senddate']	= formatDate($v['senddate']);
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		$dataStore->total = $CNOA_DB->db_getcount($this->t_files_dangan, "WHERE 1");
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _nextStep(){
		global $CNOA_DB, $CNOA_SESSION;
		$data['fileid'] = getPar($_POST, "id", 0);
		$data['stime']	= strtotime(getPar($_POST, "stime", "") . " 00:00");
		$data['etime']	= strtotime(getPar($_POST, "etime", "") . " 23:59");
		$data['reason']	= getPar($_POST, "reason", "");
		$data['fid']	= getPar($_POST, "flowid", 0);
		$data['postuid']	= $CNOA_SESSION->get("UID");
		$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['status']	= 0;
		$dangan = $CNOA_DB->db_getone(array('title', 'number'), $this->t_files_dangan, "WHERE `id`='{$data['fileid']}'");
		$data['title'] = $dangan['title'];
		$data['number']= $dangan['number'];
		$id = $CNOA_DB->db_insert($data, $this->t_files_borrow_list);
		//系统操作日志
		$title = $dangan['title'];
		app::loadApp('main', 'systemLogs')->api_addLogs('', 3202, $title, '借阅档案');
		$this->_addFlowStep("借阅开始", $id, 3, $data['fid'], getPar($_POST, "id", 0));
		msg::callBack(true, "操作成功");
	}	
	
	private function _addFlowStep($firstStep, $id, $fromType, $fid, $danganId){
		global $CNOA_DB, $CNOA_SESSION;
		$uid				= $CNOA_SESSION->get("UID");
		$deptInfo = app::loadApp("main", "struct")->api_getDeptByUid($uid);
		$first['fromId']	= $id;
		$first['fromType']	= $fromType;
		$first['stepid']	= 1;
		$first['stepname']	= $firstStep;
		$first['stepType']	= 1;
		$first['status']	= 2;
		$first['detpId']	= $deptInfo['id'];
		$first['deptName']	= $deptInfo['name'];
		$first['uid']		= $uid;
		$first['uname']		= $CNOA_SESSION->get("TRUENAME");
		$first['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
		$first['etime']		= $GLOBALS['CNOA_TIMESTAMP'];
		$CNOA_DB->db_insert($first, $this->t_flow_step_list);
		
		$dblist = $CNOA_DB->db_select("*", $this->t_flow_step, "WHERE `fid` = '{$fid}' ORDER BY `id` ASC");
		!is_array($dblist) && $dblist = array();
		$i = 1;
		foreach ($dblist as $k=>$v) {
			$data['fromId']		= $id;
			$data['fromType']	= $fromType;
			$data['stepid']		= $i+1;
			$data['stepType']	= 1;
			if($i == 1){
				$data['stime']		= $GLOBALS['CNOA_TIMESTAMP'];
				$data['status']		= 1;
				$info = $CNOA_DB->db_getone(array("title", "number"), $this->t_files_dangan, "WHERE `id` = '{$danganId}' ");
				$noticeT = "公文借阅管理";
				$noticeC = "文号:" . $info['number'] . "标题[" . $info['title'] . "]需要您审批";
				$noticeH	= "index.php?app=odoc&func=files&action=brwchk";
				$data['noticeid_c'] = notice::add($v['uid'], $noticeT, $noticeC, $noticeH, 0, 17, $CNOA_SESSION->get('UID'));
				/*
				$notice['touid']	= $v['uid'];
				$notice['from']		= 17;
				$notice['fromid']	= 0;
				$notice['href']		= $noticeH;
				$notice['title']	= $noticeC;
				$notice['content']	= "";
				$notice['funname']	= "公文借阅管理";
				$notice['move']		= "审批";
				$data['todoid_c']	= notice::add2($notice);
				*/
			}else{
				$data['status']		= 0;
			}
			$data['stepname']	= $v['stepName'];
			$data['uid']		= $v['uid'];
			$data['uname']		= $v['uname'];
			$deptInfo = app::loadApp("main", "struct")->api_getDeptByUid($data['uid']);
			$data['detpId']	= $deptInfo['id'];
			$data['deptName']	= $deptInfo['name'];
			$CNOA_DB->db_insert($data, $this->t_flow_step_list);
			$i++;
		}
	}
	
	private function _getFaqiFlow(){
		global $CNOA_DB,$CNOA_SESSION;
		$bindData = $CNOA_DB->db_select("*", $this->t_odoc_bind_flow_kj, "WHERE `from` = 'borrow' ");
		if(empty($bindData[0]['flowId'])){
			msg::callBack(false,'您还没有绑定流程，到渠道设置绑定');
		}
		$flowDB = $CNOA_DB->db_getone(array("nameRule", "tplSort", "flowType","flowId"), "wf_s_flow", "WHERE `flowId` = {$bindData[0]['flowId']} ");
	
		$id = getPar($_POST, 'id', 0);
		//删除上次点击发起没审批的数据
		$CNOA_DB->db_delete($this->t_files_borrow_list, "WHERE `fileid` = {$id} AND `status` = 0 ");
		$data = $CNOA_DB->db_getone("*", $this->t_files_dangan, "WHERE `id` = {$id} ");
	
		!is_array($bindData) && $bindData = array();
		$source = array();
		foreach ($bindData as $k=>$v){
			$val = '';
			if($v['type'] == 'title'){
				$val = $data['title'];
			}else if($v['type'] == 'number'){
				$val = $data['number'];
			}
			if(!empty($v['kongjian'])){
				$source[$v['kongjian']] = $val;
			}
		}
		$source = addslashes(json_encode($source));
		$otherAppId = $CNOA_DB->db_insert(array('posttime'=>$GLOBALS['CNOA_TIMESTAMP'], 'data'=>$source), $this->t_s_flow_other_app_data);
		$result = array(
			'success'=>true,
			'flowId'=>$flowDB['flowId'],
			'nameRule'=>$flowDB['nameRule'],
			'tplSort'=>$flowDB['tplSort'],
			'flowType'=>$flowDB['flowType'],
			'otherApp'=>$otherAppId
		);
		
		$data = array();
		$data['otherAppId'] = $otherAppId;
		
		$data['fileid'] = $id;
		$data['postuid']= $CNOA_SESSION->get("UID");
		$data['posttime']= $GLOBALS['CNOA_TIMESTAMP'];
		$CNOA_DB->db_insert($data, $this->t_files_borrow_list);
		
		echo json_encode($result);exit();
	}
}
?>