/**
 * 全局变量
 */

var CNOA_odoc_files_setting, CNOA_odoc_files_settingClass;
CNOA_odoc_files_settingClass = CNOA.Class.create();
CNOA_odoc_files_settingClass.prototype = {	
	init : function(){
		var _this = this;
		
		var ID_BTN_SETTING_TYPE = Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=files&action=setting";
		
		this.storeBar = {
			from : "room"
		};
		
		this.dsc = Ext.data.Record.create([
		{
			name: 'title',
			type: 'string'
		}]);
		
		this.fields = [
			{name : "id"},
			{name : "title"},
			{name : "postname"},
			{name : "order"}
		];
		
		this.store = new Ext.data.GroupingStore({
			autoLoad: true,
			proxy: new Ext.data.HttpProxy({
				url: this.baseUrl + '&task=getJsonData'
			}),
			reader: new Ext.data.JsonReader({
				totalProperty: "total",
				root: "data",
				fields: this.fields
			}),
			listeners: {
				'update': function(thiz, record, operation) {
					var user = record.data;
					if (operation == Ext.data.Record.EDIT) {//判断update时间的操作类型是否为 edit 该事件还有其他操作类型比如 commit,reject 
						user.from = _this.storeBar.from;  
						_this.submit(user);
					}
				}
			}
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.editor = new Ext.ux.grid.RowEditor({
			cancelText: '取消',
			saveText: '更新',
			errorSummary: false
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			
		});
		
		this.cm = [new Ext.grid.RowNumberer(), this.sm,
		{
			header: '',
			dataIndex: 'id',
			hidden: true
		}, {
			header: '档案室名称',
			dataIndex: 'title',
			width: 300,
			sortable: false,
			editor: {
				xtype: 'textfield',
				allowBlank: false
			}
		}, {
			header : '排序',
			dataIndex : 'order',
			width : 100,
			sortable : false,
			editor: {
				xtype : 'textfield',
				allowBlank : true,
				regex: /^\+?[1-9][0-9]*$/i,
				regexText: '必须设置为正整数'
			}
		}, {
			header: '发布人',
			dataIndex: 'postname',
			width: 80,
			sortable: false
		}];
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			store: this.store,
			plain: false,
			loadMask : {msg: lang('loading')},
			region: "center",
			border: false,
			autoScroll: true,
			plugins: [this.editor],
			columns: this.cm,
			sm : this.sm,
			view: new Ext.grid.GroupingView({
				markDirty: false
			}),
			listeners:{
				cellclick:function(th, rowNum, columnNum, e){
					if(columnNum == 1){
						return false;
					}
				}
			},
			tbar: [
				{
					handler : function(button, event) {
						_this.store.reload();
					}.createDelegate(this),
					iconCls: 'icon-system-refresh',
					text : lang('refresh')
				},'-',
				{
					handler : function(button, event) {
						var e = new _this.dsc({
   							name: ''
   						});
   						_this.editor.stopEditing();
   						_this.store.insert(0, e);
   						_this.grid.getView().refresh();
   						_this.grid.getSelectionModel().selectRow(0);
   						_this.editor.startEditing(0);
					}.createDelegate(this),
					iconCls: 'icon-system-refresh',
					text : "添加"
				},'-',
				{
					text : "删除",
					iconCls: 'icon-utils-s-delete',
					handler : function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections(); // 返回值为 Record 数组 
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, lang('mustSelectOneRow'));
						} else {
							CNOA.miniMsg.cfShowAt(button, "确定要删该记录吗?", function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									_this.deleteData(ids);
								}
							});
						}
					}
				},
				"<span class='cnoa_color_gray'>双击可修改记录,按住Ctrl或Shift键可以一次选择多条记录</span>",
				'->',{xtype: 'cnoa_helpBtn', helpid:5002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid],
			tbar : [
				{
					text : "档案室列表",
					iconCls: 'icon-ui-combo-boxes',
					enableToggle: true,
					toggleGroup: "odoc_files_set_types",
					pressed:true,
					allowDepress:false,
					handler : function(){
						_this.storeBar.from = "room";
						_this.grid.getColumnModel().setColumnHeader(3, "档案室名称");
						_this.grid.getColumnModel().setColumnHeader(4, "排序");
						_this.store.load({params : _this.storeBar});
						//Ext.getCmp(ID_BTN_SETTING_TYPE).show();
					}
				},'-',
				{
					text : "内目",
					iconCls: 'icon-ui-combo-box',
					enableToggle: true,
					toggleGroup: "odoc_files_set_types",
					allowDepress:false,
					handler : function(){
						_this.storeBar.from = "type";
						_this.grid.getColumnModel().setColumnHeader(3, "内目名称");
						_this.grid.getColumnModel().setColumnHeader(4, "排序");
						_this.store.load({params : _this.storeBar});
						//Ext.getCmp(ID_BTN_SETTING_TYPE).hide();
					}
				},'-',
				{
					text : "文种",
					iconCls: 'icon-ui-combo-box-blue',
					enableToggle: true,
					toggleGroup: "odoc_files_set_types",
					allowDepress:false,
					handler : function(){
						_this.storeBar.from = "wenzhong";
						_this.grid.getColumnModel().setColumnHeader(3, "文种名称");
						_this.grid.getColumnModel().setColumnHeader(4, "排序");
						_this.store.load({params : _this.storeBar});
						//Ext.getCmp(ID_BTN_SETTING_TYPE).hide();
					}
				},'-',
				{
					text : "保管期限",
					iconCls: 'icon-ui-combo-boxes',
					enableToggle: true,
					toggleGroup: "odoc_files_set_types",
					allowDepress:false,
					handler : function(){
						_this.storeBar.from = "savetime";
						_this.grid.getColumnModel().setColumnHeader(3, "保管期限");
						_this.grid.getColumnModel().setColumnHeader(4, "排序");
						_this.store.load({params : _this.storeBar});
						//Ext.getCmp(ID_BTN_SETTING_TYPE).hide();
					}
				}
			]
		})
	},
	
	submit : function(user){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + '&task=add',
			params: user,
			method: "POST",
			success: function(r, opts) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.store.reload();
				}else{
					CNOA.msg.alert(result.msg, function(){
						_this.store.reload();
					});
				}
			},
			failure: function(response, opts) {
				CNOA.msg.alert(result.msg, function(){
					_this.store.reload();
				});
			}
		});
	},
	
	deleteData : function(ids){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + '&task=delete',
			params: {ids : ids, from : _this.storeBar.from},
			method: "POST",
			success: function(r, opts) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.store.reload();
				}else{
					CNOA.msg.alert(result.msg, function(){
						_this.store.reload();
					});
				}
			},
			failure: function(response, opts) {
				CNOA.msg.alert(result.msg, function(){
					_this.store.reload();
				});
			}
		});
	}
}

