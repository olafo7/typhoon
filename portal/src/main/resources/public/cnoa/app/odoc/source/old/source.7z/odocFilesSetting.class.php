<?php 
class odocFilesSetting extends model{
	private $t_dangan_room = "odoc_files_dangan_room";
	private $t_dangan_type = "odoc_files_dangan_type";
	private $t_dangan_wenzhong	= "odoc_files_dangan_wenzhong";
	
	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task) {
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "add" :
				$this->_add();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "delete" :
				$this->_delete();
				break;
		}
	}
	
	private function _loadpage(){
		
	}
	
	private function _add(){
		global $CNOA_DB, $CNOA_SESSION;
		$id = getPar($_POST, "id", 0);
		$from = getPar($_POST, "from", "room");
		switch ($from) {
			case "room" :
				$table = $this->t_dangan_room;
				break;
			case "type" :
				$table = $this->t_dangan_type;
				break;
			case "wenzhong" :
				$table = $this->t_dangan_wenzhong;
				break;
		}
		$data['title']	= getPar($_POST, "title", "");
		$data['order']	= getPar($_POST, "order", 0);
		$data['postuid']= $CNOA_SESSION->get("UID");
		$num = $CNOA_DB->db_getcount($table, "WHERE `id` != '{$id}' AND `title` = '{$data['title']}'");
		if($num > 0){
			msg::callBack(false, "已存在此名称");
		}
		if(!empty($id)){
			$CNOA_DB->db_update($data, $table, "WHERE `id` = '{$id}' ");
		}else{
			$CNOA_DB->db_insert($data, $table);
		}
		msg::callBack(true, "操作成功");
	}
	
	private function _getJsonData(){
		global $CNOA_DB;
		$from = getPar($_POST, "from", "room");
		switch ($from) {
			case "room" :
				$table = $this->t_dangan_room;
				break;
			case "type" :
				$table = $this->t_dangan_type;
				break;
			case "wenzhong" :
				$table = $this->t_dangan_wenzhong;
				break;
		}
		$dblist = $CNOA_DB->db_select("*", $table, "ORDER BY `order` ASC");
		!is_array($dblist) && $dblist = array();
		$uidArr = array();
		foreach ($dblist as $k=>$v) {
			$uidArr[] = $v['postuid'];
		}
		$truenameArr = app::loadApp("main", "user")->api_getUserNamesByUids($uidArr);
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['postname'] = $truenameArr[$v['postuid']]['truename'];
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _delete(){
		global $CNOA_DB;
		$from = getPar($_POST, "from", "room");
		switch ($from) {
			case "room" :
				$table = $this->t_dangan_room;
				break;
			case "type" :
				$table = $this->t_dangan_type;
				break;
			case "wenzhong" :
				$table = $this->t_dangan_wenzhong;
				break;
		}
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		foreach ($idArr as $v) {
			$CNOA_DB->db_delete($table, "WHERE `id` = '{$v}'");
		}
		msg::callBack(true, "操作成功");
	}
	
	public function api_getRoomData(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_room, "ORDER BY `order` ASC");
		!is_array($dblist) && $dblist = array();
		$data = array();
		foreach ($dblist as $k=>$v) {
			$data[$v['id']] = $v;
		}
		return $data;
	}
	
	public function api_getTypeData(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_type, "ORDER BY `order` ASC");
		!is_array($dblist) && $dblist = array();
		$data = array();
		foreach ($dblist as $k=>$v) {
			$data[$v['id']] = $v;
		}
		return $data;
	}
	
	public function api_getWenzhongData(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_wenzhong, "ORDER BY `order` ASC");
		!is_array($dblist) && $dblist = array();
		$data = array();
		foreach ($dblist as $k=>$v) {
			$data[$v['id']] = $v;
		}
		return $data;
	}
	
	public function api_getRoomList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_room, "ORDER BY `order` ASC");
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_getTypeList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_type, "ORDER BY `order` ASC");
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_getWenzhongList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("title", "id"), $this->t_dangan_wenzhong, "ORDER BY `order` ASC");
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
}
?>