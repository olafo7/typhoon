/**
 * 全局变量
 */

var CNOA_odoc_receive_apply, CNOA_odoc_receive_applyClass;

CNOA_odoc_receive_applyClass = CNOA.Class.create();
CNOA_odoc_receive_applyClass.prototype = {
	init : function(){
		var _this = this;
				
		this.baseUrl = "index.php?app=odoc&func=receive&action=apply";
		
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=loadColumn",
			method: 'POST',
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					_this.layoutPanel(result);
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	layoutPanel:function(result){
		var _this = this;
			
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect:true
		});
		
		this.cm = [new Ext.grid.RowNumberer(), this.sm,
			{header:lang('opt'),sortable:true,dataIndex:'id',width:120,menuDisabled:true,renderer:function(v, c, record){
				var rd = record.data;
				var l = '';
				if(rd.status == 2){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_receive_apply.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}else if(rd.status == 0){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_receive_apply.operate('+v+')">发起审批</a>';
				}else if(rd.status == 1){
					l += '<a href="javascript:void(0)" onclick="CNOA_odoc_receive_apply.viewFlow('+rd.uFlowId+')">查看流程</a>';
				}
				l += '&nbsp;&nbsp;<a href="javascript:void(0)" onclick="CNOA_odoc_receive_apply.viewAttach('+v+')">来文内容</a>';
				/*
				if(rd.puFlowId > 0){
					l += ' <a href="javascript:void(0)" onclick="CNOA_odoc_receive_apply.viewFlow('+rd.puFlowId+')">查看发文流程</a>';
				}
				*/
				return l;
			}},
			{header:'添加时间',sortable:true,dataIndex:'posttime',width:100,menuDisabled:true},
			{header:'状态',sortable:true,dataIndex:'status',width:100,menuDisabled:true,renderer:function(v){
				if(v == 1){
					return '<span style="color:green;">审批中</span>';
				}else if(v == 2){
					return '<span style="color:#333333;">审批结束</span>';
				}else{
					return '<span style="color:red;">未提交审批</span>';
				}
			}},
			{header:'来文机关',sortable:true,dataIndex:'deptment',width:100,menuDisabled:true},
			{header:'来文标题',sortable:true,dataIndex:'title',width:100,menuDisabled:true},
			{header:'来文编号',sortable:true,dataIndex:'number',width:100,menuDisabled:true},
			{header:'打印份数',sortable:true,dataIndex:'print',width:100,menuDisabled:true}
		];

		var fields = [{name:'id'},{name:'posttime'},{name:'status'},{name:'uFlowId'},{name:'deptment'},{name:'title'},{name:'number'},{name:'print'},{name:'puFlowId'}];
		Ext.each(result.column, function(v,i){
			fields.push({name:'field_'+v.field});
			_this.cm.push({
				header			:v.title,
				sortable		:true,
				dataIndex		:'field_'+v.field,
				width			:v.width,
				menuDisabled	:true
			});
		});

		this.store = new Ext.data.Store({
			autoLoad: true,
			proxy: new Ext.data.HttpProxy({
				url: this.baseUrl + '&task=getJsonList'
			}),
			reader: new Ext.data.JsonReader({
				totalProperty: "total",
				root: "data",
				fields:fields
			})
		});

		this.grid = new Ext.grid.GridPanel({
			store:this.store,
			width:600,
			plain:false,
       		stripeRows:true,
			loadMask:{msg: lang('waiting')},
			region:"center",
			border:false,
			autoScroll:true,
			sm:this.sm,
			columns:this.cm,
			tbar:[
				{
					handler:function(button, event) {
						_this.store.reload();
					}.createDelegate(this),
					iconCls:'icon-system-refresh',
					text:lang('refresh')
				},'-',
				{
					handler:function(button, event) {
						_this.addWin('new', 0);
					}.createDelegate(this),
					iconCls:'icon-utils-s-add',
					text:"添加收文"
				},'-',
				{
					handler:function(button, event){
						var rows = _this.grid.getSelectionModel().getSelections();
						if (rows.length == 0) {
							CNOA.miniMsg.alertShowAt(button, '您还没有选择要编辑的列');
						}else{
							var id = rows[0].get("id");
							var status = rows[0].get("status");
							
							if(status != 0){
								CNOA.msg.alert("流程已经启动或者已经结束，不能再编辑！");
							}else{
								_this.addWin('edit', id);
							}
						}
					},
					iconCls: 'icon-utils-s-edit',
					text:lang('modify')
				},'-',
				{
					text:lang('del'),
					iconCls:'icon-utils-s-delete',
					handler:function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections();
						if(rows.length == 0){
							CNOA.miniMsg.alertShowAt(button, lang('mustSelectOneRow'));
						}else{
							CNOA.miniMsg.cfShowAt(button, lang('confirmToDelete'), function(){
								if (rows) {
									var ids = "";
									for (var i = 0; i < rows.length; i++) {
										ids += rows[i].get("id") + ",";
									}
									Ext.Ajax.request({
										url: _this.baseUrl + "&task=deleteData",
										method: 'POST',
										params:{ids:ids},
										success: function(r) {
											var result = Ext.decode(r.responseText);
											if(result.success === true){
												_this.store.reload();
											}else{
												CNOA.msg.alert(result.msg, function(){});
											}
										}
									});
								}
							});
						}
					}
				},"-",
				{
					text: '分发', //所有人
					handler: function(){
						var rows = _this.grid.getSelectionModel().getSelections();

						if(rows.length <= 0){
							CNOA.msg.alert('您好，请至少选择一个发文进行操作.');
							return;
						}
						if(rows[0].json.status != 2){
							CNOA.msg.alert('该信息还没有审批通过。 审批通过才能签发。');
							return;
						}
						var slid = rows[0].json.id;
						
						_this.issueSend(slid);
					}.createDelegate(this),
					iconCls: 'icon-applications-stack',
					cls: 'x-btn-over',
					listeners: {
						'mouseout': function(btn){
							btn.addClass('x-btn-over');
						}
					}
				},
				"<span class='cnoa_color_gray'>双击可修改记录,按住Ctrl或Shift键可以一次选择多条记录</span>"
			],
			bbar: new Ext.PagingToolbar({
				displayInfo:true,
				
				   
				store: this.store,
				pageSize:30,
				listeners: {
					"beforechange" : function(th, params){
						//Ext.apply(params, _this.search);
					}
				}
			})
		});

		this.treeStore = new Ext.data.Store({
			autoLoad:true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getSearchList", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields:[{name:'field'},{name:'title'}]})
		});		
	
		
		this.mainPanel = new Ext.Panel({
			collapsible:false,
			hideBorders:true,
			border:false,
			layout:'border',
			autoScroll:false,
			items:[this.grid]
		});
		
		Ext.getCmp(CNOA.odoc.receive.apply.parentID).add(this.mainPanel);
		Ext.getCmp(CNOA.odoc.receive.apply.parentID).doLayout();
	},
	
	addWin:function(from, edit_id){
		var _this = this;
		
		var baseField = [
			{
				xtype:'fieldset',
				title: '请选择要发起的流程',
				layout:'column',
				//style:'margin-bottom:5px;',
				id:'CNOA_ODOC_NEW_FLOW_CT',
				hideLabel:true,
				width:660,
				autoHeight: true,
	            items: []
			},
			{
				xtype:'fieldset',
				title: '来文信息',
				hideLabel:true,
				width:660,
				layout:'column',
				autoHeight: true,
				defaults: {border: false},
	            items: [
	            	{
						xtype:'panel',
						layout:'form',
						items:[{
							xtype:'textfield',
							fieldLabel:'来文单位',
							name:'deptment',
							width:180,
							allowBlank:false
						},{
							xtype:'textfield',
							fieldLabel:'来文标题',
							name:'title',
							width:180,
							allowBlank:false
						}]
					},
					{
						xtype:'panel',
						layout:'form',
						items:[{
							xtype:'numberfield',
							fieldLabel:'打印份数',
							name:'print',
							width:180,
							allowBlank:false
						}]
					}
				]
			},
			{
				xtype:'panel',
				border:false,
				layout: "form",
				width:660,
				defaults:{
				},
				id:'ID_DEFINDE_FIELDS'
			}
		];
		
		this.addFormPanel = new Ext.form.FormPanel({
			border:false,
			labelWidth:90,
			width:640,
			labelAlign:'right',
			waitMsgTarget:true,
			bodyStyle:"padding-left:5px;",
			items:baseField,
			autoScroll:true,
			listeners:{
				"render" : function(form){}
			}
		});
		
		var checkSelectedFlow = function(){
			var msg = "请选择要发起哪条流程", v;
			try{
				v = _this.addFormPanel.getForm().findField("ococ_send_apply_flowList").getGroupValue();
			}catch(e){
				v = "";
				msg = "还没有可以发起的流程，请到公文设置功能里面添加公文与流程的绑定！";
			}
			if(Ext.isEmpty(v)){
				CNOA.msg.alert(msg);
				return false;
			}
			return true;
		};
		
		var submitData = function(){
			var f = _this.addFormPanel.getForm();
			if(f.isValid()) {
				f.submit({
			        url: _this.baseUrl+"&task=submitData",
			        method: 'POST',
			        waitMsg: lang('waiting'),
			        params: {id: edit_id},
			        success: function(form, action) {
						if(action.result.success == true){
							win.close();
							_this.store.reload();
							
							_this.operate(action.result.msg);
						}
			        }.createDelegate(this),
			        failure:function(form, action){}.createDelegate(this)
				});
			}
		};
		
		var win = new Ext.Window({
			title:'添加收文',
			width:700,
			height:makeWindowHeight(500),
			modal:true,
			layout:"fit",
			resizable:false,
			border:false,
			items:this.addFormPanel,
			buttons:[
				{
					text:'确定发起',
					handler:function(){
						if(checkSelectedFlow()){
							submitData(edit_id);
						}
					}
				},
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
		
		this.superField = Ext.getCmp('ID_DEFINDE_FIELDS');
		
		_this.loadLayout(from,edit_id);
	},
	
	viewFlow:function(uFlowId){
		mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
		mainPanel.loadClass(this.baseUrl+"&task=loadPage&from=viewflow&uFlowId="+uFlowId, "CNOA_MENU_WF_USE_OPENFLOW", "查看工作流程", "icon-flow");
	},
	
	operate:function(v){
		var _this = this;
		
		Ext.Ajax.request({
			url:_this.baseUrl + "&task=getFaqiFlow",
			method:'POST',
			params:{id:v},
			success:function(r) {
				var result = Ext.decode(r.responseText);
				
				if(result.success === true){
					_this.goNewFlow(result);
				}else{
					if(result.msg == 'no_bind_flow'){
						_this.addWin('edit', v);
					}else{
						CNOA.msg.alert(result.msg);
					}
				}
			}
		});
	},
	
	viewAttach : function(id){
		var _this = this;
		
		var ID_fieldSet = Ext.id();
		
		var loadAttachList = function(){
			Ext.Ajax.request({
				url: _this.baseUrl + "&task=loadAttachList",
				method: 'POST',
				params:{id:id},
				success: function(r) {
					var result = Ext.decode(r.responseText);
					if(result.success === true){
						Ext.getCmp(ID_fieldSet).body.update(result.data);
					}else{
						//CNOA.msg.alert(result.msg, function(){});
					}
				}
			});
		};
		
		var win = new Ext.Window({
			title:'查看发文内容',
			width:500,
			height:makeWindowHeight(500),
			modal:true,
			bodyStyle: 'background-color:#FFF;padding:10px;',
			resizable:false,
			autoScroll: true,
			border:false,
			items: [
				{
					xtype: 'fieldset',
					title: '文件查看',
					id: ID_fieldSet
				}
			],
			listeners: {
				afterrender : function(){
					loadAttachList();
				}
			},
			buttons:[
				{
					text:lang('close'),
					handler:function(btn){
						win.close();
					}
				}
			]
		}).show();
	},
	
	goNewFlow : function(result){
		var flowType = result.flowType;
		var flowId = result.flowId;
		var nameRuleId = result.nameRuleId;
		var tplSort = result.tplSort;
		var childId = 0;
		var otherApp = result.otherApp;
		
		if(flowType == 0){
			mainPanel.closeTab("CNOA_MENU_WF_USE_OPENFLOW");
			mainPanel.loadClass("index.php?app=wf&func=flow&action=use&modul=new&task=loadPage&from=newflow&flowId="+flowId+"&nameRuleId="+nameRuleId+"&flowType="+flowType+"&tplSort="+tplSort+"&childId="+childId+"&otherApp="+otherApp, "CNOA_MENU_WF_USE_OPENFLOW", "发起新的固定流程", "icon-flow-new");
		}else{
			mainPanel.closeTab("CNOA_USE_FLOW_NEWFREE_FLOWDESIGN");
			mainPanel.loadClass("index.php?app=wf&func=flow&action=use&modul=newfree&task=loadPage&from=flowdesign&flowId="+flowId+"&flowType="+flowType+"&tplSort="+tplSort+"&childId="+childId+"&otherApp="+otherApp, "CNOA_USE_FLOW_NEWFREE_FLOWDESIGN", "设计流程", "icon-flow-new");
		}
	},
	
	loadLayout:function(from,edit_id){
		var _this = this;
		
		Ext.Ajax.request({
			url: _this.baseUrl + "&task=loadLayout",
			method: 'POST',
			success: function(r) {
				var result = Ext.decode(r.responseText);
				if(result.success === true){
					Ext.each(result.fieldset, function(v, i){
						_this.addFieldSet(v.name, v.fieldset);
					});
					Ext.each(result.field, function(v,i){
						Ext.getCmp('ID_FIELD_SET_'+v.fieldset).add(_this.addField(v.fstfield, v.secfield, v.fstname, v.secname, v.type));
					});
					
					var flowListCt = Ext.getCmp("CNOA_ODOC_NEW_FLOW_CT");
					Ext.each(result.flowList, function(v,i){
						flowListCt.add({
							xtype: 'radio',
							name: 'ococ_send_apply_flowList',
							style: 'margin-left: 10px;',
							boxLabel: v.name,
							inputValue: v.id
						});
					});
					flowListCt.doLayout();
					
					_this.superField.doLayout();
					
					if(from == 'edit'){
						_this.addFormPanel.getForm().load({
						    url: _this.baseUrl + "&task=loadFormData",
						    method:'POST',
						    params : {id:edit_id},
						    success: function(form, action){
						        var rd = action.result.data;
						    },
						    failure: function(form, action) {
						        CNOA.msg.alert(action.result.msg, function(){
						            
						        });
						    }
						});
					}
				}else{
					CNOA.msg.alert(result.msg, function(){});
				}
			}
		});
	},
	
	addFieldSet:function(msg, fieldsetid){
		var _this = this;
		
		_this.superField.add({
			xtype:'fieldset',
			title:msg,
			width:660,
			autoHeight: true,
			id:"ID_FIELD_SET_"+fieldsetid
		});
	},
	
	addField:function(firstId, secondId, fstname, secname, typeFrom){
		var _this = this;
		
		if (typeFrom == 'textarea') {
			var items = {
					xtype: 'panel',
					layout: 'form',
					items: [{
						xtype: 'textarea',
						width: 464,
						fieldLabel: fstname,
						name: 'field_' + firstId
					}]
				}
		}else if(typeFrom == 'sort'){
			var items = {
				xtype:'panel',
				layout:'form',
				items:[{
					xtype:"combo",
					fieldLabel:fstname,
					name:'field_'+firstId,
					store: this.sortStore,
					hiddenName:'field_' + firstId,
					valueField:'iid',
					displayField:'sort',
					mode:'local',
					width:180,
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}]
			}
		}else if(typeFrom == 'type'){
			var items = {
				xtype:'panel',
				layout:'form',
				items:[{
					xtype:"combo",
					fieldLabel:fstname,
					name:'field_'+firstId,
					store:this.typeStore,
					hiddenName:'field_' + firstId,
					valueField:'id',
					displayField:'sid',
					mode:'local',
					width:180,
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}]
			}
		}else if(typeFrom == 'region'){
			var items = [{
				xtype:"panel",
				layout:"form",
				items:[{
					xtype:"combo",
					fieldLabel:fstname,
					name:'field_' + firstId,
					store:this.regionStore,
					name:'field_' + firstId,
					secondId:secondId,
					valueField:'rid',
					displayField:'name',
					mode:'local',
					width:180,
					triggerAction:'all',
					forceSelection:true,
					editable:false,
					listeners:{
						change:function(th, newValue, oldValue){
							_this.region2 = "";
							_this.addFormPanel.getForm().findField('field_' + th.secondId).setValue("");
							_this.regionStore2.load({params : {rid : newValue}});
						}
					}
				}]
			}, {
				xtype: "panel",
				layout: "form",
				items: [{
					xtype:"combo",
					fieldLabel:secname,
					name:'field_' + secondId,
					store:this.regionStore2,
					name:'field_' + secondId,
					valueField:'pid',
					displayField:'name',
					mode:'local',
					width:180,
					triggerAction:'all',
					forceSelection:true,
					editable:false
				}]
			}]
		}
		else {
			var items = [];
			
			if(fstname == '' || secname == ''){
				var fieldName = fstname == ''?secondId:firstId;
				items = [
					{
						xtype:'panel',
						layout:'form',
						items:[{
							xtype:'textfield',
							width:464,
							fieldLabel:fstname == ''?secname:fstname,
							name:'field_'+ fieldName
						}]
					}
				];
			}else{
				items = [
					{
						xtype:'panel',
						layout:'form',
						items:[{
							xtype:'textfield',
							width:180,
							fieldLabel:fstname,
							name:'field_'+firstId
						}]
					},{
						xtype: 'panel',
						layout: 'form',
						items: [{
							xtype:'textfield',
							width:180,
							fieldLabel:secname,
							name:'field_'+secondId
						}]
					}
				];
			}
		}
		
		var result = {
			xtype: 'panel',
			layout: 'table',
			layoutConfig: {
				columns: 2
			},
			style: 'margin-top:10px',
			border: false,labelWidth:90,
			defaults: {
				border: false
			},
			items:items
		}
		
		return result;
	},
	
	/**
	 * 分发
	 */
	issueSend : function(id){
		var _this = this;
		
		var rows = _this.grid.getSelectionModel().getSelections();
		//cdump(rows);return;
		if(rows.length <= 0){
			CNOA.msg.alert('您好，请至少选择一个发文进行操作.');
			return;
		}
		var slid = rows[0].json.id;

		var frm = new Ext.form.FormPanel({
			border: false,
			labelWidth: 60,
			labelAlign: 'right',
			bodyStyle:'padding: 10px',
			items: [
				{
					xtype: 'checkboxgroup',
					fieldLabel: '分发内容',
					columns: 3,
					allowBlank: false,
					items: [
						{boxLabel: '审批表单', name: "viewForm"},
						{boxLabel: '审批正文(Word)', name: "viewWord", checked: true},
						{boxLabel: '流程附件', name: "viewAttach", checked: true}//,
						//{boxLabel: '审批步骤', name: "viewConfig[step]"},
						//{boxLabel: '审批事件', name: "viewConfig[event]"},
						//{boxLabel: '允许打印', name: "viewConfig[print]"}
					]
				},
				{
					xtype:'textarea',
					fieldLabel:'查看人',
					name:'recvMan',
					width:333,
					height:150,
					readOnly:true,
					allowBlank:false
				},
				{
					xtype:"hidden",
					name:"recvUids",
					id:_this.ID_recvUids
				},
				{
					xtype:"btnForPoepleSelector",
					fieldLabel:"",
					text:lang('select'),
					allowBlank: false,
					name:"checkName",
					dataUrl: _this.baseUrl+"&task=getAllUserListsInPermitDeptTree",
					width:70,
					style:'margin: 0 0 0 65px',
					listeners:{
						"selected":function(th, data){
							var names = new Array();
							var uids = new Array();
							
							if (data.length>0){
								for (var i=0;i <= data.length - 1; i++){
									names.push(data[i].uname);
									uids.push(data[i].uid);
								}
							}
							var sNames	= names.join(",");
							var sUids	= uids.join(",");
							
							frm.getForm().findField("recvUids").setValue(sUids);
							frm.getForm().findField("recvMan").setValue(sNames);
						}
					}
				}
			]
		})
		
		submit = function(){
			var f = frm.getForm();
			if (f.isValid()) {
				f.submit({
					url: _this.baseUrl + '&task=submitIssue',
					method: 'POST',
					params: {id:slid},
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						_this.store.reload();
						win.close();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg);
					}
				});
			}else{
				CNOA.msg.alert(lang('formValid'));
			}
		};
		
		var win = new Ext.Window({
			title: '分发',
			width: 430,
			height: 330,
			layout: 'fit',
			modal: true,
			resizable: false,
			maximizable: false,
			items: [frm],
			buttons:[
				{
					text: '确定分发',
					handler: function(){
						submit();
					}
				},{
					text: lang('close'),
					handler: function (){						
						win.close();
					}
				}
			]
		}).show();
		
		return win;
	}
}

//CNOA_odoc_receive_apply = new CNOA_odoc_receive_applyClass();


