/**
 * 全局变量
 */

var CNOA_odoc_files_dananmgr, CNOA_odoc_files_dananmgrClass;

CNOA_odoc_files_dananmgrClass = CNOA.Class.create();
CNOA_odoc_files_dananmgrClass.prototype = {	
	init : function(){
		var _this = this;
		
		var ID_SEARCH_TITLE		= Ext.id();
		var ID_SEARCH_NUMBER	= Ext.id();
		var ID_SEARCH_SORT		= Ext.id();
		var ID_SEARCH_TYPE		= Ext.id();
		var ID_SEARCH_LEVEL		= Ext.id();
		var ID_SEARCH_STIME		= Ext.id();
		var ID_SEARCH_ETIME		= Ext.id();
		var ID_BTN_SPLIT		= Ext.id();
		this.ID_BTN_SAVE		= Ext.id();
		
		this.baseUrl = "index.php?app=odoc&func=files&action=dananmgr";
		
		this.storeBar = {
			storeType : "all",
			title : "",
			number : "",
			sort : "",
			type : "",
			level : "",
			stime : "",
			etime : ""
		};
		
		this.fields = [
			{name : "id"},
			{name : "title"},
			{name : "number"},
			{name : "type"},
			{name : "level"},
			{name : "hurry"},
			{name : "from"},
			{name : "senddate"},
			{name : "danganshi"},
			{name : "anjuan"},
			{name : "fileid"}
		];
		
		this.roomStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=roomList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.roomStore.load();
		
		this.anjuanStore = new Ext.data.Store({
			proxy: new Ext.data.HttpProxy({
				url: _this.baseUrl+"&task=anjuanList"
			}),
			reader: new Ext.data.JsonReader({
				root:'data',
				fields: [
					{name : "id"},
					{name : "title"}
				]
			})
		});
		
		this.store = new Ext.data.Store({
			autoLoad : true,
			proxy:new Ext.data.HttpProxy({url: this.baseUrl+"&task=getJsonData", disableCaching: true}),   
			reader:new Ext.data.JsonReader({totalProperty:"total",root:"data", fields: this.fields}),
			listeners:{
				exception : function(th, type, action, options, response, arg){
					var result = Ext.decode(response.responseText);
					if(result.failure){
						CNOA.msg.alert(result.msg);
					}
				},
				"load" : function(th, rd, op){
					
				}
			}
		});
		
		this.sm = new Ext.grid.CheckboxSelectionModel({
			singleSelect: false
		});
		
		this.pagingBar = new Ext.PagingToolbar({
			displayInfo:true,emptyMsg:"没有数据显示",displayMsg:"显示第{0}--{1}条数据，共{2}条",   
			store: this.store,
			pageSize:15,
			listeners:{
				"beforechange" : function(th, params){
					Ext.apply(params, _this.storeBar);
				}
			}
		});
		
		this.colModel = new Ext.grid.ColumnModel([
			new Ext.grid.RowNumberer(),
			this.sm,
			{header: "id", dataIndex: 'id', hidden: true},
			//{header: '档案编号', dataIndex: 'type', width: 100, sortable: true, menuDisabled :true},
			{header: '文件类型', dataIndex: 'from', width: 80, sortable: true, menuDisabled :true},
			//{header: '类别', dataIndex: 'type', width: 100, sortable: true, menuDisabled :true},
			{header: '标题', dataIndex: 'title', width: 150, sortable: true, menuDisabled :true},
			{header: '文件字号', dataIndex: 'number', width: 100, sortable: true, menuDisabled :true},
			{header: '成文日期', dataIndex: 'senddate', width: 80, sortable: true, menuDisabled :true},
			//{header: '文种', dataIndex: 'w', width: 80, sortable: true, menuDisabled :true},
			{header: '所在档案室', dataIndex: 'danganshi', width: 80, sortable: true, menuDisabled :true},
			{header: '所在案卷', dataIndex: 'anjuan', width: 80, sortable: true, menuDisabled :true},
			{header: '操作', dataIndex: 'fileid', width: 120, sortable: true, menuDisabled :true, renderer : this.operate.createDelegate(this)},
			{header: "", dataIndex: 'noIndex', width: 1, menuDisabled: true,resizable: false}
		]);
		
		this.grid = new Ext.grid.GridPanel({
			stripeRows : true,
			region : "center",
			border:false,
			store:this.store,
			loadMask : {msg: lang('loading')},
			cm: this.colModel,
			sm: this.sm,
			hideBorders: true,
			listeners:{
				"rowdblclick":function(button, event){
					/*
					var rows = _this.grid.getSelectionModel().getSelections();
					_this.type = "edit";
					_this.edit_id = rows[0].get("id");
					var CNOA_odoc_files_clean = new CNOA_odoc_files_cleanClass();
					CNOA_odoc_files_clean.add(_this.type, _this.edit_id);
					*/
				}
			},
			tbar:[
				{
					text:lang('refresh'),
					iconCls:'icon-system-refresh',
					handler:function(button, event){
						_this.store.reload();
					}
				},"-",
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "all";
						_this.store.load({params: _this.storeBar});
						Ext.getCmp(ID_BTN_SPLIT).show();
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					pressed: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示所有档案列表",
					text : '所有档案'
				},'-',
				{
					handler : function(button, event) {
						_this.storeBar.storeType = "history";
						_this.store.load({params: _this.storeBar});
						Ext.getCmp(ID_BTN_SPLIT).hide();
					}.createDelegate(this),
					iconCls: 'icon-roduction',
					enableToggle: true,
					allowDepress: false,
					toggleGroup: "meeting_room_check",
					tooltip: "显示分发历史记录列表",
					text : '分发历史记录'
				},"-",
				{
					handler : function(button, event) {
						var rows = _this.grid.getSelectionModel().getSelections();

						if(rows.length <= 0){
							CNOA.msg.alert('您好，请至少选择一个档案进行操作.');
							return;
						}
						var slid = rows[0].json.id;
						
						_this.issueSend(slid);
					}.createDelegate(this),
					id : ID_BTN_SPLIT,
					iconCls: 'icon-applications-stack',
					tooltip: "分发文件",
					text : '分发'
				},"-","<span>双击可修改档案信息，按住ctrl或shift键可选择多个</span>",
				"->",{xtype: 'cnoa_helpBtn', helpid: 4002}
			],
			bbar: this.pagingBar
		});
		
		this.mainPanel = new Ext.Panel({
			collapsible: false,
			hideBorders: true,
			border: false,
			layout: 'border',
			autoScroll: false,
			items : [this.grid],
			tbar : [
				"标题: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_TITLE
				},
				"文号: ",
				{
					xtype : "textfield",
					width : 100,
					id : ID_SEARCH_NUMBER
				},"类型: ",
				new Ext.form.ComboBox({
					name: 'sort',
					store: new Ext.data.SimpleStore({
						fields: ['value', 'title'],
						data: [['1', "发文"], ['2', "收文"]]
					}),
					width: 60,
					hiddenName: 'sort',
					id : ID_SEARCH_SORT,
					valueField: 'value',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false,
					listeners : {

					}
				}),
				"档案室: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.roomStore,
					width: 100,
					id : ID_SEARCH_TYPE,
					hiddenName: 'id',
					valueField: 'id',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false,
					listeners : {
						select : function(th, record, index){
							Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
							//cdump(record);
							_this.anjuanStore.load({params : {id : record.id}});
						}
					}
				}),
				"案卷: ",
				new Ext.form.ComboBox({
					name: 'title',
					store: _this.anjuanStore,
					width: 100,
					id : ID_SEARCH_LEVEL,
					hiddenName: 'id',
					valueField: 'id',
					displayField: 'title',
					mode: 'local',
					triggerAction: 'all',
					forceSelection: true,
					editable: false
				}),
				"起始日期",
				{
					xtype : "datefield",
					format : "Y-m-d",
					id : ID_SEARCH_STIME,
					width : 100
				},
				"终止日期",
				{
					xtype : "datefield",
					format : "Y-m-d",
					id : ID_SEARCH_ETIME,
					width : 100
				},
				{
					xtype: "button",
					text: "查询",
					style: "margin-left:5px",
					cls: "x-btn-over",
					listeners: {
						"mouseout" : function(btn){
							btn.addClass("x-btn-over");
						}
					},
					handler: function(){
						_this.storeBar.title 		= Ext.getCmp(ID_SEARCH_TITLE).getValue();
						_this.storeBar.number 		= Ext.getCmp(ID_SEARCH_NUMBER).getValue();
						_this.storeBar.sort 		= Ext.getCmp(ID_SEARCH_SORT).getValue();
						_this.storeBar.type 		= Ext.getCmp(ID_SEARCH_TYPE).getValue();
						_this.storeBar.level 		= Ext.getCmp(ID_SEARCH_LEVEL).getValue();
						_this.storeBar.stime 		= Ext.getCmp(ID_SEARCH_STIME).getRawValue();
						_this.storeBar.etime 		= Ext.getCmp(ID_SEARCH_ETIME).getRawValue();
						
						_this.store.load({params:_this.storeBar});
					}
				},
				{
					xtype:"button",
					text:"清空",
					handler:function(){
						Ext.getCmp(ID_SEARCH_TITLE).setValue("");
						Ext.getCmp(ID_SEARCH_NUMBER).setValue("");
						Ext.getCmp(ID_SEARCH_SORT).setValue("");
						Ext.getCmp(ID_SEARCH_TYPE).setValue("");
						Ext.getCmp(ID_SEARCH_LEVEL).setValue("");
						Ext.getCmp(ID_SEARCH_STIME).setValue("");
						Ext.getCmp(ID_SEARCH_ETIME).setValue("");
						
						_this.storeBar.title 		= "";
						_this.storeBar.number 		= "";
						_this.storeBar.sort 		= "";
						_this.storeBar.type 		= "";
						_this.storeBar.level 		= "";
						_this.storeBar.stime 		= "";
						_this.storeBar.etime 		= "";
						
						_this.store.load({params:_this.storeBar});
					}
				}
			]
		});
	},
	
	operate : function(value, cellmeta, record, rowIndex, columnIndex, color_store){
		var _this = this;
		if(_this.storeBar.storeType == "history"){
			return "<a href='javascript:void(0)' onclick='CNOA_odoc_files_dananmgr.newSplit("+value+", \"view\")'>查看分发</a>";
		}else{
			var id = record.data.id;
			/*
			var _this	= this; //cdump(record);
			
			var sUrl	= _this.baseUrl;
			
			var x = 0;
			var y = 0;
			var sWin	= 'window.open("' + sUrl + '&task=view&act=getHtml&id=' + id + '", "", "width='+(screen.availWidth)+',height='+(screen.availHeight)+',left=' + x +',top=' + y + ',scrollbars=yes,resizable=yes,status=no");';
			
			return "<a href='javascript:void(0)' onclick='" + sWin + "'>查看档案</a>";
			*/
			return "<a href='javascript:void(0)' onclick='CNOA_odoc_files_dananmgr.viewOdocFiles("+id+");'>查看档案</a>";
		}
	},

	viewOdocFiles : function(id){
		CNOA_odoc_viewFiles = new CNOA_odoc_viewFilesClass(id, this.baseUrl);
	},
	
	issueSend:function(id){
		var _this = this;
		
		var rows = _this.grid.getSelectionModel().getSelections();
		
		if(rows.length <= 0){
			CNOA.msg.alert('您好，请至少选择一个发文进行操作.');
			return;
		}
		var slid = rows[0].json.id;

		var frm = new Ext.form.FormPanel({
			border: false,
			labelWidth: 50,
			labelAlign: 'right',
			bodyStyle:'padding: 10px 0 0 15px',
			defaults:{
				style: 'margin-bottom: 10px'
			},
			items: [
				{
					xtype:'textarea',
					fieldLabel:'收文人',
					name:'recvMan',
					width:300,
					height:150,
					readOnly:true,
					allowBlank:false
				},
				{
					xtype:"hidden",
					name:"recvUids",
					id:_this.ID_recvUids
				},
				{
					xtype:"panel",
					hidden:false,
					layout:"form",
					border:false,
					items:[
						{
							xtype:"btnForPoepleSelector",
							fieldLabel:"",
							text:'选择',
							allowBlank: false,
							name:"checkName",
							dataUrl: _this.baseUrl+"&task=getAllUserListsInPermitDeptTree",
							width:70,
							style:'margin: 0 0 0 55px',
							listeners:{
								"selected":function(th, data){
									var names = new Array();
									var uids = new Array();
									
									if (data.length>0){
										for (var i=0;i <= data.length - 1; i++){
											names.push(data[i].uname);
											uids.push(data[i].uid);
										}
									}
									var sNames	= names.join(",");
									var sUids	= uids.join(",");
									
									frm.getForm().findField("recvUids").setValue(sUids);
									frm.getForm().findField("recvMan").setValue(sNames);
								}
							}
						}
					]
				}
			]
		})
		
		submit = function(){
			var f = frm.getForm();
			if (f.isValid()) {
				f.submit({
					url: _this.baseUrl + '&task=submitIssue',
					method: 'POST',
					params: {id:slid},
					success: function(form, action) {
						CNOA.msg.notice(action.result.msg, "公文管理");
						_this.store.reload();
						win.close();
					},
					failure: function(form, action) {
						CNOA.msg.alert(action.result.msg);
					}
				});
			}else{
				CNOA.msg.alert("部分表单未完成,请检查");
			}
		};
		
		var win = new Ext.Window({
			title: '分发',
			width: 400,
			height: 300,
			layout: 'fit',
			modal: true,
			resizable: false,
			maximizable: false,
			items: [frm],
			buttons:[
				{
					text: '确定分发',
					handler: function(){
						submit();
					}
				},{
					text: '关闭',
					handler: function (){						
						win.close();
					}
				}
			]
		}).show();
		
		return win;
	}
}

