<?php 
class odocSettingWord extends model{
	private $t_type_list	= "odoc_setting_word_type";
	private $t_level_list	= "odoc_setting_word_level";
	private $t_hurry_list	= "odoc_setting_word_hurry";
	private $t_secret_list	= "odoc_setting_word_secret";
	
	private $t_type_permit	= "odoc_setting_word_type_permit";
	
	private $rows			= 15;
									
	/**
	 * 构造函数
	 */
	public function __construct() {
		//callConstructFunction();
	}
	/**
	 * 析构函数
	 */
	public function __destruct(){
		//callDestructFunction();
	}

	public function run(){
		$task = getPar($_GET, "task", "loadpage");
		switch ($task){
			case "loadpage" :
				$this->_loadpage();
				break;
			case "getJsonData" :
				$this->_getJsonData();
				break;
			case "deleteData" :
				$this->_deleteData();
				break;
			case "add" :
				$this->_add();
				break;
			case "getAllUserListsInPermitDeptTree" :
				$GLOBALS['user']['permitArea']['area'] = "all";
				$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
				echo json_encode($userList);
				exit;
			case "loadFormData" :
				$this->_loadFormData();
				break;
			case "submitTypePermit" :
				$this->_submitTypePermit();
				break;
		}
	}
	
	private function _loadpage(){
		
	}
	
	private function _getJsonData(){
		global $CNOA_DB;
		$from = getPar($_POST, "from", "type");
		$start = getPar($_POST, "start", 0);
		switch ($from){
			case "type" :
				$table = $this->t_type_list;
				break;
			case "level" :
				$table = $this->t_level_list;
				break;
			case "hurry" :
				$table = $this->t_hurry_list;
				break;
			case "secret" :
				$table = $this->t_secret_list;
				break;
		}
		$dblist = $CNOA_DB->db_select("*", $table, "ORDER BY `order` ASC LIMIT {$start}, {$this->rows}");
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v) {
			$uidArr[] = $v['postuid'];
		}
		$uids = app::loadApp("main", "user")->api_getUserNamesByUids($uidArr);
		foreach ($dblist as $k=>$v) {
			$dblist[$k]['postname'] = $uids[$v['postuid']]['truename'];
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		$dataStore->total = $CNOA_DB->db_getcount($table, "WHERE 1");
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _add(){
		global $CNOA_DB, $CNOA_SESSION;
		$tid = getPar($_POST, "tid", 0);
		$data['title'] 	= getPar($_POST, "title", "");
		$data['order'] 	= getPar($_POST, "order", 0);
		$data['postuid']= $CNOA_SESSION->get("UID");
		$from = getPar($_POST, "from", "type");
		switch ($from){
			case "type" :
				$table = $this->t_type_list;
				$content = '公文类型';
				break;
			case "level" :
				$table = $this->t_level_list;
				$content = '秘密等级';
				break;
			case "hurry" :
				$table = $this->t_hurry_list;
				$content = '缓急情况';
				break;
			case "secret" :
				$table = $this->t_secret_list;
				$content = '保密期限';
				break;
		}
		
		$num = $CNOA_DB->db_getcount($table, "WHERE `tid` != '{$tid}' AND `title` = '{$data['title']}'");
		if($num > 0){
			msg::callBack(false, "已存在该名称");
		}
		
		if(!empty($tid)){
			$CNOA_DB->db_update($data, $table, "WHERE `tid` = '{$tid}'");
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('update', 3302, $data['title'], $content);
		}else{
			$CNOA_DB->db_insert($data, $table);
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('add', 3302, $data['title'], $content);
		}
		msg::callBack(true, lang('successopt'));
	}
	
	private function _deleteData(){
		global $CNOA_DB;
		$ids = getPar($_POST, "ids", 0);
		$ids = substr($ids, 0, -1);
		$idArr = explode(",", $ids);
		$from = getPar($_POST, "from", "type");
		switch ($from){
			case "type" :
				$table = $this->t_type_list;
				$content = '公文等级';
				break;
			case "level" :
				$table = $this->t_level_list;
				$content = '秘密等级';
				break;
			case "hurry" :
				$table = $this->t_hurry_list;
				$content = '缓急情况';
				break;
			case "secret" :
				$table = $this->t_secret_list;
				$content = '保密期限';
				break;
		}
		$DB = $CNOA_DB->db_select(array('title', 'tid'), $table, "WHERE `tid` IN ({$ids})");
		foreach($DB as $v){
		    $title[$v['tid']] = $v['title'];
		}
		foreach ($idArr as $v) {
			$CNOA_DB->db_delete($table, "WHERE `tid` = '{$v}' ");
			//系统操作日志
			app::loadApp('main','systemLogs')->api_addLogs('del', 3302, $title[$v], $content);
		}
		msg::callBack(true, lang('successopt'));
	}
	
	/*
	private function _loadFormData(){
		global $CNOA_DB;
		$id = getPar($_POST, "tid", 0);
		$dblist = $CNOA_DB->db_select("*",$this->t_type_permit, "WHERE `tid` = '{$id}'");
		!is_array($dblist) && $dblist = array();
		$temp	= array();
		$data	= array();
		$uidArr = array();
		foreach ($dblist as $k=>$v) {
			$uidArr[] = $v['uid'];
 		}
 		$truenameArr	= app::loadApp("main", "user")->api_getUserNamesByUids($uidArr);
		foreach ($dblist as $k=>$v) {
			if($v['status'] == 1){
				$data['viewuid']	.= $v['uid'] . ",";
				$data['view']		.= $truenameArr[$v['uid']]['truename'] . ", ";
			}else{
				$data['deleteuid']	.= $v['uid'] . ",";
				$data['delete']		.= $truenameArr[$v['uid']]['truename'] . ", ";
			}
		}
		$dataStore = new dataStore();
		$dataStore->data = $data;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	private function _submitTypePermit(){
		global $CNOA_DB;
		$id = getPar($_POST, "tid", 0);
		$CNOA_DB->db_delete($this->t_type_permit, "WHERE `tid` = '{$id}'");
		
		$viewuid	= getPar($_POST, "viewuid", 0);
		$deleteuid	= getPar($_POST, "deleteuid", 0);
		
		//$viewuid	= substr($viewuid, 0, -1);
		$viewArr	= explode(",", $viewuid);
		$view = array();
		$view['tid'] = $id;
		$view['status']	= 1;
		foreach ($viewArr as $k=>$v) {
			$view['uid'] = $v;
			$CNOA_DB->db_insert($view, $this->t_type_permit);
		}
		
		//$deleteuid	= substr($deleteuid, 0, -1);
		$deleteArr	= explode(",", $deleteuid);
		$delete = array();
		$delete['tid'] = $id;
		$delete['status']	= 2;
		foreach ($deleteArr as $k=>$v) {
			$delete['uid'] = $v;
			$CNOA_DB->db_insert($delete, $this->t_type_permit);
		}
		msg::callBack(true, lang('successopt'));
	}
	*/
	
	public function api_getTypeList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("tid", "title"), $this->t_type_list, "ORDER BY `order` ASC ");
		!is_array($dblist) && $dblist = array();
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_getLevelList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("tid", "title"), $this->t_level_list, "ORDER BY `order` ASC ");
		!is_array($dblist) && $dblist = array();
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_getHurryList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("tid", "title"), $this->t_hurry_list, "ORDER BY `order` ASC ");
		!is_array($dblist) && $dblist = array();
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_getSecretList(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("tid", "title", "order"), $this->t_secret_list, "ORDER BY `order` ASC ");
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v){
			$dblist[$k]['title'] = $v['title'];
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_getTypeAllArr(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("tid", "title"), $this->t_type_list, "ORDER BY `order` ASC ");
		!is_array($dblist) && $dblist = array();
		$data = array(0=>array("title"=>""));
		foreach ($dblist as $k=>$v) {
			$data[$v['tid']] = $v;
		}
		return $data;
	}
	
	public function api_getLevelAllArr(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("tid", "title"), $this->t_level_list, "ORDER BY `order` ASC ");
		!is_array($dblist) && $dblist = array();
		$data = array(0=>array("title"=>""));
		foreach ($dblist as $k=>$v) {
			$data[$v['tid']] = $v;
		}
		return $data;
	}
	
	public function api_getHurryAllArr(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("tid", "title"), $this->t_hurry_list, "ORDER BY `order` ASC ");
		!is_array($dblist) && $dblist = array();
		$data = array(0=>array("title"=>""));
		foreach ($dblist as $k=>$v) {
			$data[$v['tid']] = $v;
		}
		return $data;
	}
	
	public function api_getSecretAllArr(){
		global $CNOA_DB;
		$dblist = $CNOA_DB->db_select(array("tid", "title"), $this->t_secret_list, "ORDER BY `order` ASC ");
		!is_array($dblist) && $dblist = array();
		$data = array(0=>array("title"=>""));
		foreach ($dblist as $k=>$v) {
			$data[$v['tid']] = $v;
		}
		return $data;
	}
}
?>