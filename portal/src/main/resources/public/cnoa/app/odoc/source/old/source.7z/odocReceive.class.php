<?php 
class odocReceive extends model{
	public function actionWaiting(){
		app::loadApp("odoc", "receiveWaiting")->run();
	}
	
	public function actionApply(){
		app::loadApp("odoc", "receiveApply")->run();
	}
	
	public function actionHandler(){
		app::loadApp("odoc", "receiveHandler")->run();
	}
	
	public function actionCheck(){
		app::loadApp("odoc", "receiveCheck")->run();
	}
	
	public function actionPart(){
		app::loadApp("odoc", "receivePart")->run();
	}
	
	public function actionUndertake(){
		app::loadApp("odoc", "receiveUndertake")->run();
	}
	
	public function actionList(){
		app::loadApp("odoc", "receiveList")->run();
	}
}
?>