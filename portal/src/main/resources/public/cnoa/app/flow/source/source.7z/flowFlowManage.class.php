<?php
/**
 * cnoa framework
 *
 * @package		cnoa
 * @author		cnoa Dev Team & Linxiaoqing
 * @email		linxiaoqing@live.com
 * @copyright	Copyright (c) 2011, cnoa, Inc.
 * @license		http://cnoa.com/user_guide/license.html
 * @since		Version 1.4.0
 * @filesource
 */
/**
 * 内部调用专用模块
 * 供 flowFlow.class.php -> actionUser() 调用
 * @author Administrator
TRUNCATE TABLE `cnoa_flow_flow_u_event`;
TRUNCATE TABLE `cnoa_flow_flow_u_formdata`;
TRUNCATE TABLE `cnoa_flow_flow_u_list`;
TRUNCATE TABLE `cnoa_flow_flow_u_node`;
 *
 */ 
class flowFlowManage extends model{
	//流程分类表
	private $table_sort			= "flow_flow_sort";
	//流程表
	private $table_list			= "flow_flow_list";
	//流程节点表
	private $table_list_node	= "flow_flow_list_node";
	//流程表单表
	private $table_form			= "flow_flow_form";
	//流程表单表单列表表
	private $table_form_item	= "flow_flow_form_item";
	
	//流程列表
	private $table_u_list		= "flow_flow_u_list";
	//流程节点表
	private $table_u_node		= "flow_flow_u_node";
	//工作表单数据表
	private $table_u_formdata	= "flow_flow_u_formdata";
	//事件表
	private $table_u_event		= "flow_flow_u_event";
	//委托表
	private $table_u_entrust	= "flow_flow_u_entrust";
	
	//事件类型(不可修改)
	//1:开始 2:已处理 3:撤销 4:召回 5:退回 6:退回上一步 7:结束
	private $eventType			= array(1=>"开始",2=>"已办理",3=>"撤销",4=>"召回",5=>"退件",6=>"退回上一步",7=>"结束");
	
	//状态说明
	private $statusType			= array(1=>"办理中", 2=>"已办理", 3=>"退件");
	
	//委托人状态说明
	private $entrustType		= array(0=>"禁用", 1=>"启用", 2=>"未设置");
	
	public function run(){
		global $CNOA_SESSION;
		
		$task = getPar($_GET, 'task', getPar($_POST, 'task'));
		
		if($task == "loadPage"){
			//载入页面
			$this->_loadPage();
		}
	}
	
	/************************* ∨总程序∨ **********************/
	private function _loadPage(){
		global $CNOA_SESSION, $CNOA_CONTROLLER;
		
		$from = getPar($_GET, "from", "");
		
		if($from == "flowlist"){
			//载入流程列表页
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/manage_flowlist.htm';
		}
		
		$CNOA_CONTROLLER->loadExtraTpl($tplPath);
		exit;
	}
	/************************* ∧总程序∧ **********************/
}

















?>