<?php
/**
 * cnoa framework
 *
 * @package		cnoa
 * @author		cnoa Dev Team & Linxiaoqing
 * @email		linxiaoqing@live.com
 * @copyright	Copyright (c) 2011, cnoa, Inc.
 * @license		http://cnoa.com/user_guide/license.html
 * @since		Version 1.4.0
 * @filesource
 */
/**
 * 内部调用专用模块
 * 供 flowFlow.class.php -> actionSetting() 调用
 * @author Administrator
 *
 */ 
class flowFlowSetting extends model{
	//流程分类表
	private $table_sort			= "flow_flow_sort";
	//流程分类查看对照表
	private $table_dept_sort	= "flow_flow_dept_sort";
	//流程分类删除对照表
	private $table_user_sort	= "flow_flow_user_sort";
	//流程表
	private $table_list			= "flow_flow_list";
	//流程节点表
	private $table_list_node	= "flow_flow_list_node";
	//流程表单表
	private $table_form			= "flow_flow_form";
	//流程表单表单列表表
	private $table_form_item	= "flow_flow_form_item";
	
	//流程列表
	private $table_u_list		= "flow_flow_u_list";
	//流程节点表
	private $table_u_node		= "flow_flow_u_node";
	//工作表单数据表
	private $table_u_formdata	= "flow_flow_u_formdata";
	//事件表
	private $table_u_event		= "flow_flow_u_event";
	//委托表
	private $table_u_entrust	= "flow_flow_u_entrust";
	
	private $table_sort_permit	= "news_news_sort_permit";
	
	private $table_huiqian		= "flow_flow_u_huiqian";
	
	private $table_dispense		= "flow_flow_u_dispense";
	
	//缓存路径
	private $cachePath			= "";
	
	public function __construct(){
		$this->cachePath = CNOA_PATH_FILE . "/cache";
	}
	
	public function run(){
		global $CNOA_SESSION;
		
		$task = getPar($_GET, 'task', getPar($_POST, 'task'));
		
		/* 总 */
		if($task == "loadPage"){
			//载入页面
			$this->_loadPage();
		}
		
		/* 分类相关 */
		elseif($task == "sortGetJsonData"){
			//读取分类列表数据
			$this->_sortGetJsonData();
		}elseif($task == "sortAdd"){
			//添加分类
			$this->_sortAdd();
		}elseif($task == "sortEdit"){
			//修改分类
			$this->_sortEdit();
		}elseif($task == "sortDelete"){
			//删除分类
			$this->_sortDelete();
		}elseif($task == "sortLoadFormData"){
			//修改前载入数据
			$this->_sortLoadFormData();
		}
		
		/* 流程相关 */
		elseif($task == "getFlowJsonData"){
			//获取流程列表数据
			$this->_getFlowJsonData();
		}elseif($task == "flowadd"){
			$this->_flowadd();
		}elseif($task == "flowedit"){
			$this->_flowedit();
		}elseif($task == "floweditLoadForm"){
			$this->_floweditLoadForm();
		}elseif($task == "flowdelete"){
			$this->_flowdelete();
		}elseif($task == "flowdesignLoadData"){
			//获取流程设计数据，提供给前台设计用
			$this->_flowdesignLoadData();
		}elseif($task == "flowdesignSubmitData"){
			//提交流程设计数据
			$this->_flowdesignSubmitData();
		}elseif($task == "setFlowPublish"){
			//设置流程为可用/禁用
			$this->_setFlowPublish();
		}elseif($task == "getAllFlowJsonData"){
			//获取所有流程列表，以供删除
			$this->_getAllFlowJsonData();
		}elseif($task == "deleteflow"){
			//删除流程 - 任何状态的
			$this->_deleteflow();
		}elseif($task == "exportExcel"){
			$this->_exportExcel();
		}elseif ($task == "getFlowFrom"){
			$this->_getFlowFrom();
		}
		
		/* 表单相关 */
		elseif($task == "getFormJsonData"){
			//获取流程列表数据
			$this->_getFormJsonData();
		}elseif($task == "formAdd"){
			$this->_formAdd();
		}elseif($task == "formEdit"){
			$this->_fromEdit();
		}elseif($task == "formeditLoadForm"){
			$this->_formeditLoadForm();
		}elseif($task == "formdelete"){
			$this->_formdelete();
		}elseif($task == "formdesign"){
			$this->_formdesign();
		}elseif($task == "saveFormDesignData"){
			$this->_saveFormDesignData();
		}
		
		/* 综合类 */
		elseif($task == "getSortList"){
			//获取分类列表(tree)
			$this->_getSortList();
		}
		elseif($task == "getFormList"){
			//获取表单列表
			$this->_getFormList();
		}
		elseif($task == "getAllUserListsInPermitDeptTree"){
			//获取人员选择树
			$this->_getAllUserListsInPermitDeptTree();
		}elseif ($task == "getStructTree"){
			$this->_getStructTree();
		}
	}
	
	/************************* ∨总程序∨ **********************/
	private function _loadPage(){
		global $CNOA_SESSION, $CNOA_CONTROLLER;
		
		$from = getPar($_GET, "from", "");
		
		if ($from == "flow"){
			//载入流程设计汇总页面
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/setting_flow.htm';
		}elseif ($from == "form"){
			//载入表单设计汇总页面
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/setting_form.htm';
		}elseif ($from == "sort"){
			//载入流程分类汇总页面
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/setting_sort.htm';
		}elseif ($from == "mgr"){
			//载入流程分类汇总页面
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/setting_mgr.htm';
		}
		
		$CNOA_CONTROLLER->loadExtraTpl($tplPath);
		exit;
	}
	/************************* ∧总程序∧ **********************/
	
	/************************* ∨分类相关程序∨ **********************/
	private function _sortGetJsonData(){
		global $CNOA_DB;
		
		$dataStore = new dataStore();
		
		$dblist = $CNOA_DB->db_select("*", $this->table_sort, "WHERE 1 ORDER BY `order` ASC");
			
		$dataStore->total = 0;
		$dataStore->data = $dblist;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _sortAdd(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid = $CNOA_SESSION->get("UID");
		
		//检查权限(未做)
		
		$data['name']	= getPar($_POST, "name", "");
		$data['about']	= getPar($_POST, "about", "", 1);
		$data['order']	= 999;
		
		if(empty($data['name'])){
			msg::callBack(false, "分类名称不能为空");
		}
		
		$sid = $CNOA_DB->db_insert($data, $this->table_sort);
		
		$deptId = explode(",", getPar($_POST, "deptIds"));
		
		foreach ($deptId as $k=>$v){
			$info = array();
			$info['sid'] = $sid;
			$info['deptId'] = $v;
			$CNOA_DB->db_insert($info,$this->table_dept_sort);
		}
		
		$allUids = explode(",", getPar($_POST, "allUids"));
		
		foreach ($allUids as $k=>$v){
			$userinfo = array();
			$userinfo['sid'] = $sid;
			$userinfo['allUid'] = $v;
			$CNOA_DB->db_insert($userinfo,$this->table_user_sort);
		}
		
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('add', 78, $data['name'], "流程分类");
		msg::callBack(true, "操作成功");
	}
	
	private function _sortEdit(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid		= $CNOA_SESSION->get("UID");
		$sid		= getPar($_POST, "sid", 0);
		$deptIds	= getPar($_POST, "deptIds");
		$allUids	= getPar($_POST, "allUids");
		//检查权限(未做)
		
		$data['name']	= getPar($_POST, "name", "");
		$data['about']	= getPar($_POST, "about", "", 1);
		
		if(empty($data['name'])){
			msg::callBack(false, "分类名称不能为空");
		}
		
		$info = $CNOA_DB->db_getone("*", $this->table_sort, "WHERE `sid`='{$sid}'");
		if($info['type'] == "sys"){
			//msg::callBack(false, "系统内置分类不可修改");
			unset($data['name']);
		}
		
		//修改之前删除
		//if(!empty($deptIds)){
			$CNOA_DB->db_delete($this->table_dept_sort, "WHERE `sid`='{$sid}'");
			$deptIdsArray = explode(",", $deptIds);
			if (is_array($deptIdsArray)){
				foreach ($deptIdsArray AS $v){
					$CNOA_DB->db_insert(array("sid"=>$sid,"deptId"=>$v), $this->table_dept_sort);
				}
			}
		//}
		
		//if(!empty($allUids)){
			$CNOA_DB->db_delete($this->table_user_sort, "WHERE `sid`='{$sid}'");
			$allUidsArray = explode(",", $allUids);
			if (is_array($allUidsArray)){
				foreach ($allUidsArray AS $v){
					$CNOA_DB->db_insert(array("sid"=>$sid,"allUid"=>$v), $this->table_user_sort);
				}
			}
		//}
		
		$CNOA_DB->db_update($data, $this->table_sort, "WHERE `sid`='{$sid}'");
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('update', 78, $data['name'], "流程分类");
		
		msg::callBack(true, "操作成功");
	}
	
	private function _sortDelete(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$sid 	= getPar($_POST, "sid", 0);
		$uid  	= $CNOA_SESSION->get("UID");
		
		if($sid == 112){
			msg::callBack(false, "受保护的分类不可删除");
		}
		
		//检查权限(未做)
		
		$info = $CNOA_DB->db_getone("*", $this->table_sort, "WHERE `sid`='{$sid}'");
		if($info['type'] == "sys"){
			msg::callBack(false, "系统内置分类不可删除");
		}
		
		//从列表中删除
		$CNOA_DB->db_delete($this->table_sort, "WHERE `sid`='{$sid}'");
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('del', 78, $info['name'], "流程分类");
		msg::callBack(true, "操作成功");
	}
	
	private function _getFlowFrom(){
		$_GET['type']	= 'combo';
		app::loadApp("flow", "flow")->api_getSortList();
	}
	
	private function _sortLoadFormData(){
		global $CNOA_DB, $CNOA_SESSION, $CNOA_CONTROLLER;
		
		$uid 	= $CNOA_SESSION->get("UID");
		$sid 	= getPar($_POST, "sid", 0);
		$info	= $CNOA_DB->db_getone("*", $this->table_sort, "WHERE `sid`='{$sid}'");
		if(!$info){
			msg::callBack(false, "没有这条数据");
		}
		
		$dataStore = new dataStore();
		
		//选择部门
		$dlist = $CNOA_DB->db_select("*", $this->table_dept_sort, "WHERE `sid`='{$info['sid']}'");
		$ulist = $CNOA_DB->db_select("*", $this->table_user_sort, "WHERE `sid`='{$info['sid']}'");
		if($dlist){
			$deptIds = array();
			foreach ($dlist AS $v){
				$deptIds[] = $v['deptId'];
			}
			$deptNames = app::loadApp("main", "struct")->api_getNamesByIds($deptIds);
			
			
			$info['deptIds']	= is_array($deptIds) ? implode(",", $deptIds) : "";
			$info['deptNames']	= is_array($deptNames) ? implode(",", $deptNames) : "";
		}else {
			$info['sid']	=	$info['sid'];
			$info['name']	=	$info['name'];
		}
		
		if($ulist){
			$uids = array();
			foreach ($ulist AS $v){
				$uids[] = $v['allUid'];
			}
			$userNames = app::loadApp("main", "user")->api_getUserNamesByUids($uids);
			!is_array($userNames) && $userNames=array();
						
			$tmp = array();
			foreach($userNames as $v){
				$tmp[] = $v['truename'];
			}
			$userNames = $tmp;
			
			$info['allUids']		= is_array($uids) ? implode(",", $uids) : "";
			$info['allUserNames']	= is_array($userNames) ? implode(",", $userNames) : "";
		}else {
			$info['sid']	=	$info['sid'];
			$info['name']	=	$info['name'];
		}
		
		$dataStore->total = 0;
		$dataStore->data = $info;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	/************************* ∧分类相关程序∧ **********************/
	
	/************************* ∨流程相关程序∨ **********************/
	private function _getFlowJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$start 	= getPar($_POST, 'start', 0);
		$rows  	= 15;
		$sort	= intval(getPar($_POST, 'sort', 0));
		
		$name	= getPar($_POST, "name","");
		$flowFrom	= getPar($_POST, "flowFrom","");
		

		if($sort == 0){
			$where = "WHERE 1 ";
		}else{
			$where = "WHERE `sort`='{$sort}' ";
		}
		
		if(!empty($name)){
			$where .=" AND `l`.`name` LIKE '%{$name}%'";
		}
		if(!empty($flowFrom)){
			$where .=" AND `l`.`sort` = '$flowFrom'";
		}
		
		$sql = 'SELECT  `l`.`name`, `l`.`lid`, `l`.`publish`, `s`.`name` AS `sname` ' .
			   'FROM '. tname($this->table_list) . " AS `l` " .
			   'LEFT JOIN ' . tname($this->table_sort) . " AS `s` ON `l`.`sort`=`s`.`sid` " .
			   $where . 
			   'ORDER BY `posttime` DESC '.
			   "LIMIT {$start}, {$rows}";

		$dblist = array();
		$queryList = $CNOA_DB->query($sql);
		while ($list = $CNOA_DB->get_array($queryList)) {
			$list['posttime'] 	= date("Y-m-d H:i", $list['posttime']);
			$dblist[] = $list;
		}
		
		$sql = 'SELECT  count(*) AS `count` ' .
			   'FROM '. tname($this->table_list) . " AS `l` " .$where;
		
		$total = $CNOA_DB->get_one($sql);
		$dataStore = new dataStore();
		$dataStore->total = $total['count'];
		//$dataStore->total = $CNOA_DB->db_getcount($this->table_list, $where);
		$dataStore->data = $dblist;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _flowadd(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$data['name']		= getPar($_POST, "name", "");
		$data['sort']		= getPar($_POST, "sid", 0);
		$data['formid']		= getPar($_POST, "formid", 0);
		$data['number']		= getPar($_POST, "number", "");
		$data['about']		= getPar($_POST, "about", "", 1);
		$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['uid']		= $uid;
		
		$CNOA_DB->db_insert($data, $this->table_list);
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('add', 80, $data['name'], "流程设计");
		msg::callBack(true, "操作成功");
	}
	
	private function _flowedit(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$lid = getPar($_POST, "lid", 0);
		
		$data['name']		= getPar($_POST, "name", "");
		$data['sort']		= getPar($_POST, "sid", 0);
		$data['formid']		= getPar($_POST, "formid", 0);
		$data['number']		= getPar($_POST, "number", "");
		$data['about']		= getPar($_POST, "about", "", 1);
		$data['uid']		= $uid;
		//$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
		
		$CNOA_DB->db_update($data, $this->table_list, "WHERE `lid`='{$lid}'");
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('update', 80, $data['name'], "流程设计");
		msg::callBack(true, "操作成功");
	}
	
	private function _flowdelete(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$lid = getPar($_POST, "lid", 0);
		
		$protect_fids = array(193,185,188,191);
		if(in_array($lid, $protect_fids)){
			msg::callBack(false, "受保护的工作流程不允许删除");
		}
		//删除待办和提醒
		$DB = $CNOA_DB->db_select("*", $this->table_u_list, "WHERE `lid`='{$lid}' ");
		!is_array($DB) && $DB = array();
		$ulidArr = array();
		foreach ($DB as $k=>$v){
			$ulidArr[] = $v['ulid'];
		}
		$DB1 = $CNOA_DB->db_select(array("noticeid_c", "todoid_c"), $this->table_u_node, "WHERE `ulid` IN (".implode(",", $ulidArr).") ");
		$DB2 = $CNOA_DB->db_select(array("noticeid_c", "todoid_c"), $this->table_huiqian, "WHERE `ulid` IN (".implode(",", $ulidArr).") ");
		$DB3 = $CNOA_DB->db_select(array("noticeid_c", "todoid_c"), $this->table_dispense, "WHERE `ulid` IN (".implode(",", $ulidArr).") ");
		!is_array($DB1) && $DB1 = array();!is_array($DB2) && $DB2 = array();!is_array($DB3) && $DB3 = array();
		$notice = array();$todo = array();
		foreach ($DB1 as $k=>$v){
			$notice[]	= $v['noticeid_c'];
			$todo[]		= $v['todoid_c'];
		}
		foreach ($DB2 as $k=>$v){
			$notice[]	= $v['noticeid_c'];
			$todo[]		= $v['todoid_c'];
		}
		foreach ($DB3 as $k=>$v){
			$notice[]	= $v['noticeid_c'];
			$todo[]		= $v['todoid_c'];
		}
		notice::deleteNotice($notice, $todo);
		
		$flowname = $CNOA_DB->db_getfield('name', $this->table_list, "WHERE `lid`='{$lid}'");
		
		$CNOA_DB->db_delete($this->table_list, "WHERE `lid`='{$lid}'");
		
		$CNOA_DB->db_delete($this->table_list_node, "WHERE `lid`='{$lid}'");
		
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('del', 80, $flowname, "流程设计");
		
		msg::callBack(true, "操作成功");
	}
	
	private function _floweditLoadForm(){
		global $CNOA_DB, $CNOA_SESSION, $CNOA_CONTROLLER;
		
		$uid 	= $CNOA_SESSION->get("UID");
		$lid 	= getPar($_POST, "lid", 0);
		
		$info	= $CNOA_DB->db_getone("*", $this->table_list, "WHERE `lid`='{$lid}'");
		if(!$info){
			msg::callBack(false, "没有这条数据");
		}
		
		//获取所绑定的工作表单
		if($info['formid'] == 0){
			unset($info['formid']);
		}else{
			$info['formname'] = $CNOA_DB->db_getfield("name", $this->table_form, "WHERE `fid`='{$info['formid']}'");
			if($info['formname'] == false){
				unset($info['formid']);
				unset($info['formname']);
			}
		}
		
		$info['sid'] = $info['sort'];
		unset($info['sort']);
		
		$dataStore = new dataStore();
		$dataStore->total = 0;
		$dataStore->data = $info;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	public function _flowdesignLoadData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid 	= $CNOA_SESSION->get("UID");
		$lid	= getPar($_POST, "lid", 0);
		
		$data = $CNOA_DB->db_select(array("lid", "stepid", "name", "allowup", "allowdown", "type", "operatorperson", "operatortype", "operator", "formitems", "smsdeal"), $this->table_list_node, "WHERE `lid`='{$lid}' ORDER BY `stepid` ASC");
		
		!is_array($data) && $data=array();
		
		foreach ($data AS $k=>$v){
			$data[$k]['id']			= $v['stepid'];
			$data[$k]['upAttach']	= $v['allowup'];
			$data[$k]['downAttach']	= $v['allowdown'];
			$data[$k]['smsdeal']	= $v['smsdeal'];
			$data[$k]['operatorperson']	= $v['operatorperson'];
			$data[$k]['operatortype']	= $v['operatortype'];
			$data[$k]['operator']	= json_decode($v['operator'], true);
			$data[$k]['formitems']	= json_decode($v['formitems'], true);
			unset($data[$k]['allowup']);
			unset($data[$k]['allowdown']);
		}
		
		//获取表单字段数据提供给前台做列表用
		$formid = $CNOA_DB->db_getfield("formid", $this->table_list, "WHERE `lid`='{$lid}'");
		$cacheFormItems	= $this->cachePath . "/flow/flow/formItems/".$formid.".php";
		@include $cacheFormItems;
		
		$GLOBALS['flowFormItems2'] = $GLOBALS['flowFormItems'];
		
		$GLOBALS['flowFormItems2'] = array();
		foreach($GLOBALS['flowFormItems2'] AS $v){
			//工作流编号/工作流名称
			if(!in_array($v['type'], array("SYS_FLOWTITLE", "SYS_FLOWNAME"))){
				$GLOBALS['flowFormItems'][] = $v;
			}
		}

		$dataStore = new dataStore();
		$dataStore->flowFormItems = $GLOBALS['flowFormItems'];
		$dataStore->data = $data;
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _flowdesignSubmitData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid 	= $CNOA_SESSION->get("UID");
		$lid	= getPar($_POST, "lid", 0);
		$data	= json_decode($_POST['data'], true);
		!is_array($data) && $data=array();

		$CNOA_DB->db_delete($this->table_list_node, "WHERE `lid`='{$lid}'");
		foreach ($data AS $k=>$v){
			$nodeData = array();
			$nodeData['name'] 		= getPar($v, "name", "");
			$nodeData['lid'] 		= $lid;
			$nodeData['stepid'] 	= getPar($v, "id", 0);
			$nodeData['type'] 		= getPar($v, "type", "node");
			$nodeData['smsdeal'] 	= getPar($v, "smsdeal", 0);
			$nodeData['allowup'] 	= getPar($v, "upAttach", 0);
			$nodeData['allowdown']	= getPar($v, "downAttach", 0);
			$nodeData['operatorperson'] = getPar($v, "operatorperson", 1);
			$nodeData['operatortype'] = getPar($v, "operatortype", 2);
			
			$nodeData['operator'] 	= json_encode($v["operator"]);
			$nodeData['operator']	= getPar($nodeData, "operator", "", 1);
			
			$nodeData['formitems'] 	= json_encode($v["formitems"]);
			$nodeData['formitems']	= getPar($nodeData, "formitems", "", 1);
			
			if($nodeData['stepid']==0){
				$nodeData['type'] 	= "start";
			}
			
			$CNOA_DB->db_insert($nodeData, $this->table_list_node);
		}
		//系统操作日志
		$flowname = $CNOA_DB->db_getfield('name', $this->table_list, "WHERE `lid`='{$lid}'");
		app::loadApp('main', 'systemLogs')->api_addLogs('', 80, $flowname, "设计流程");
		msg::callBack(true, "操作成功");
	}
	
	private function _setFlowPublish(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid 	= $CNOA_SESSION->get("UID");
		$lid	= getPar($_POST, "lid", 0);
		
		$flowInfo	= $CNOA_DB->db_getone("*", $this->table_list, "WHERE `lid`='{$lid}'");
		if(!$flowInfo){
			msg::callBack(false, "没有这条数据");
		}
		
		if($flowInfo['publish'] == 1){
			$CNOA_DB->db_update(array("publish"=>0), $this->table_list, "WHERE `lid`='{$lid}'");
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('', 80, $flowInfo['name'], "禁用流程设计");
		}else{
			//检测流程是否已经绑定表单
			if(intval($flowInfo['formid']) == 0){
				msg::callBack(false, "该流程没有绑定表单，不能启用");
			}
			
			//检测流程节点是否完整
			$nodeInfo = $CNOA_DB->db_select("*", $this->table_list_node, "WHERE `lid`='{$lid}'");
			!is_array($nodeInfo) && $nodeInfo=array();
			$haveStart	= false;
			$haveEnd	= false;
			foreach ($nodeInfo AS $v){
				if($v['type'] == "start"){	$haveStart = true;}
				if($v['type'] == "end"){	$haveEnd = true;}
			}
			if(!$haveStart){msg::callBack(false, "该流程没有开始节点，不能启用");}
			if(!$haveEnd){msg::callBack(false, "该流程没有结束节点，不能启用");}
			
			$CNOA_DB->db_update(array("publish"=>1), $this->table_list, "WHERE `lid`='{$lid}'");
			//系统操作日志
			app::loadApp('main', 'systemLogs')->api_addLogs('', 80, $flowInfo['name'], "启用流程设计");
		}
		
		msg::callBack(true, "操作成功");
	}
	
	private function _getFormJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$start 	= getPar($_POST, 'start', 0);
		$rows  	= 15;
		$sortAll	= intval(getPar($_POST, 'sort', 0));
		
		$sort 	= getPar($_POST, "flowFrom","");
		$name	= getPar($_POST, "name","");
		
		
		if($sortAll == 0){
			//////////////////这里有问题，需要过滤掉不允许看的栏目
			$where = "WHERE 1 ";
		}else{
			$where = "WHERE `sort`='{$sortAll}' ";
		}
		
		if(!empty($sort)){
			$where .= "AND `l`.`sort` = '$sort' ";
		}
		if(!empty($name)){
			$where .= " AND `l`.`name` LIKE '%{$name}%'";
		}
		
		$sql = 'SELECT  `l`.`name`, `l`.`fid`, `l`.`about`, `s`.`name` AS `sname` ' .
			   'FROM '. tname($this->table_form) . " AS `l` " .
			   'LEFT JOIN ' . tname($this->table_sort) . " AS `s` ON `l`.`sort`=`s`.`sid` " .
			   $where . 
			   'ORDER BY `posttime` DESC '.
			   "LIMIT {$start}, {$rows}";
		
		
		$dblist = array();
		$queryList = $CNOA_DB->query($sql);
		while ($list = $CNOA_DB->get_array($queryList)) {
			$list['posttime'] 	= date("Y-m-d H:i", $list['posttime']);
			$dblist[] = $list;
		}
		
		$sql = 'SELECT  count(*) AS `count` ' .
			   'FROM '. tname($this->table_form) . " AS `l` " .$where;
		
		$dataStore = new dataStore();
		$total=$CNOA_DB->get_one($sql);
		$dataStore->total = $total['count'];
		//$dataStore->total = $CNOA_DB->db_getcount($this->table_form, $where);
		$dataStore->data = $dblist;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _formAdd(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$data = array();
		
		/*
		if(file_exists($_FILES['fileup']['tmp_name'])){
			$fs = new fs();
			$data['attach'] 	= $fs->uploadFile();
		}
		*/

		$data['name']		= getPar($_POST, "name", "");
		$data['sort']		= getPar($_POST, "sid", 0);
		$data['about']		= getPar($_POST, "about", "", 1);
		$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['uid']		= $uid;
		
		$CNOA_DB->db_insert($data, $this->table_form);
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('add', 79, $data['name'], "流程表单");
		msg::callBack(true, "操作成功");
	}
	
	private function _fromEdit(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$fid = getPar($_POST, "fid", 0);
		$data = array();
		
		/*
		$info = $CNOA_DB->db_getone("*", $this->table_form, "WHERE `fid`='{$fid}'");
		if(file_exists($_FILES['fileup']['tmp_name'])){
			$fs = new fs();
			//删除原来附件
			$fs->deleteFile($info['attach']);
			$data['attach'] 	= $fs->uploadFile();
		}
		*/
		
		$data['name']		= getPar($_POST, "name", "");
		$data['sort']		= getPar($_POST, "sid", 0);
		$data['about']		= getPar($_POST, "about", "", 1);
		//$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['uid']		= $uid;
		
		$CNOA_DB->db_update($data, $this->table_form, "WHERE `fid`='{$fid}'");
		header('Content-type: text/html');
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('update', 79, $data['name'], "流程表单");
		msg::callBack(true, "操作成功");
	}
	
	private function _formdelete(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$fid = getPar($_POST, "fid", 0);
		
		$protect_fids = array(170,174,175,176);
		if(in_array($fid, $protect_fids)){
			msg::callBack(false, "受保护的表单不允许删除");
		}
		
		$info = $CNOA_DB->db_getone("*", $this->table_form, "WHERE `fid`='{$fid}'");
		
		//删除表单文件
		//$fs = new fs();
		//$fs->deleteFile($info['attach']);
		
		//从表单表删除
		$CNOA_DB->db_delete($this->table_form, "WHERE `fid`='{$fid}'");
		
		//处理相关流程绑定的表单
		$CNOA_DB->db_update(array("publish"=>0, "formid"=>"", "formitems"=>""), $this->table_list, "WHERE `formid`='{$fid}'");
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('del', 79, $info['name'], "流程表单");
		msg::callBack(true, "操作成功");
	}
	
	private function _formdesign(){
		global $CNOA_DB, $CNOA_CONTROLLER;
		
		$fid	= getPar($_GET, "fid", 0);
		
		$job = getPar($_GET, "job", "");
		if($job == "getMaxNum"){
			$num = $CNOA_DB->db_getfield("item_max", $this->table_form, "WHERE `fid`='{$fid}'");
			$CNOA_DB->db_updateNum("item_max", "+1", $this->table_form, "WHERE `fid`='{$fid}'");
			echo $num;
			exit;
		}
		
		$GLOBALS['content'] = $CNOA_DB->db_getfield("content", $this->table_form, "WHERE `fid`='{$fid}'");
		
		if(!$GLOBALS['content']){
			//msg::callBack(false, "无此数据");
		}
		
		$GLOBALS['content'] = htmlspecialchars($GLOBALS['content']);
		
		$CNOA_CONTROLLER->tplHeaderType = "extjs";
		$GLOBALS['formid'] = $fid;
		$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/setting_form_design.htm';
		
		$CNOA_CONTROLLER->loadViewCustom($tplPath, true, true);
	}
	
	/*
	private function _saveFormDesignDataBackUp(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$data = array();
		
		$fid	 = getPar($_POST, "fid", 0);
		$content = $_POST['content'];

		//分析网页
		$object	 = $this->__getHtmlElement($content);
		
		//处理网页
		$data['content'] = str_replace("'", "\"", $object['html']);
		$data['content'] = getPar($data, "content", "", 1, 0);
		
		//写入缓存
		$cacheForm		= $this->cachePath . "/flow/flow/form/";
		$cacheFormItems	= $this->cachePath . "/flow/flow/formItems/";
		@mkdirs($cacheForm);
		@mkdirs($cacheFormItems);
		@file_put_contents($cacheForm . "{$fid}.php", "<?php\r\n\$GLOBALS['flowFormHtml']='".str_replace("'", "\"", $object['html'])."'; ?>");
		@file_put_contents($cacheFormItems . "{$fid}.php", "<?php\r\n\$GLOBALS['flowFormItems']=".var_export($object['element'], true).";\r\n?>");
		
		//写入主表
		$CNOA_DB->db_update($data, $this->table_form, "WHERE `fid`='{$fid}'");
		
		//写入节点表
		$CNOA_DB->db_delete($this->table_form_item, "WHERE `fid`='{$fid}'");
		!is_array($object['element']) && $object['element']=array();
		foreach($object['element'] AS $v){
			$data = array();
			$data['fid']		= $fid;
			$data['itemid']		= $v['itemid'];
			$data['name']		= $v['name'];
			$data['htmltag']	= $v['htmltag'];
			$CNOA_DB->db_insert($data, $this->table_form_item);
		} 
	
		msg::callBack(true, "操作成功");
	}
	*/
	
	private function _saveFormDesignData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$data = array();
		
		$fid	 = getPar($_POST, "fid", 0);
		$content = $_POST['content'];
		
		//修正IE的BUG，IE表单设计器不能插入控件的name属性
		$content = str_replace("iename", "name", $content);

		//分析表单数据
		$object	 = $this->__getHtmlElement($content);
		
		//处理网页 - 替换掉所有的单引号
		$data['content'] = str_replace("'", "\"", $object['html']);
		$data['content'] = getPar($data, "content", "", 1, 0);
		
		//写入缓存
		$cacheForm		= $this->cachePath . "/flow/flow/form/";
		$cacheFormItems	= $this->cachePath . "/flow/flow/formItems/";
		@mkdirs($cacheForm);
		@mkdirs($cacheFormItems);
		@file_put_contents($cacheForm . "{$fid}.php", "<?php\r\n\$GLOBALS['flowFormHtml']='".str_replace("'", "\"", $object['html'])."'; ?>");
		@file_put_contents($cacheFormItems . "{$fid}.php", "<?php\r\n\$GLOBALS['flowFormItems']=".var_export($object['element'], true).";\r\n?>");
		
		//写入主表
		$CNOA_DB->db_update($data, $this->table_form, "WHERE `fid`='{$fid}'");
		
		//写入节点表
		$CNOA_DB->db_delete($this->table_form_item, "WHERE `fid`='{$fid}'");
		!is_array($object['element']) && $object['element']=array();
		foreach($object['element'] AS $v){
			$data = array();
			$data['fid']		= $fid;
			$data['itemid']		= $v['itemid'];
			$data['type']		= $v['type'];
			$data['title']		= $v['title'];
			$data['name']		= $v['name'];
			$data['htmltag']	= $v['htmltag'];
			$CNOA_DB->db_insert($data, $this->table_form_item);
		} 
		//系统操作日志
		$name = $CNOA_DB->db_getfield('name', $this->table_form, "WHERE `fid`='{$fid}'");
		app::loadApp('main', 'systemLogs')->api_addLogs('', 79, $name, "设计流程表单");
		msg::callBack(true, "操作成功");
	}
	
	/**
	 * 分析出所有表单元素及其相关属性
	 * Enter description here ...
	 * @param unknown_type $html
	 */
	private function __getHtmlElement($html){
		global $CNOA_DB;
		
		$elementList = array();
		//preg_match_all('/<((input|textarea|select))[^>]*>/is', $html, $arr);
		
		/*preg_match_all('/((<((input|textarea))[^>]*>)|(<select[\s\S]+?>[\s\S]+?<\/select>))/i', $html, $arr);*/
		preg_match_all('/((<((input))[^>]*>)|(<textarea[\s\S]+?><\/textarea>)|(<select[\s\S]+?>[\s\S]+?<\/select>))/i', $html, $arr);

		foreach ($arr[0] AS $v){
			$tmp = array ();
			$tmp ['itemid']  = preg_replace ( "/(.*)flowitemid=\"([^\"]*)\"\s?(.*)/is", "\\2", $v );
			$tmp ['type']    = preg_replace ( "/(.*)flowitemtp=\"([^\"]*)\"\s?(.*)/is", "\\2", $v );
			$tmp ['name']	 = preg_replace ( "/(.*)name=\"([^\"]*)\"\s?(.*)/is", "\\2", $v );
			$tmp ['title']	 = preg_replace ( "/(.*)title=\"([^\"]*)\"\s?(.*)/is", "\\2", $v );
			$tmp ['htmltag'] = strtolower ( substr ( $v, 1, strpos ( $v, " " ) - 1 ) );
			$tmp ['html']	 = $v;
			$elementList []  = $tmp;
		}
		
		//处理重复的itemid(来自复制的表单元素)
		$nums = array();
		$repeats = array();
		foreach($elementList AS $v){
			$nums[] = $v['itemid'];
			$repeats[$v['itemid']][] = $v;
		}
		rsort($nums, SORT_NUMERIC);
		$maxnum2 = $maxnum = $nums[0];
		unset($v, $elementList);
		
		$elementList = array();
		foreach($repeats AS $v){
			if(count($v)>1){
				foreach($v AS $v2){
					$maxnum ++;
					$itemhtml = $v2['html'];
					$v2['itemid'] = $maxnum;
					$v2['name'] = "FLOWDATA[{$maxnum}]";
					$v2['html'] = preg_replace ( "/(.*)name=\"FLOWDATA([^\"]*)(\"\s?(.*))/is", "\\1name=\"FLOWDATA[{$maxnum}]\\3", $v2['html'] );
					$v2['html'] = preg_replace ( "/(.*)flowitemid=\"([^\"]*)(\"\s?(.*))/is", "\\1flowitemid=\"{$maxnum}\\3", $v2['html'] );
					$elementList[] = $v2;
					$html = str_replace_once($itemhtml, $v2['html'], $html);
				}
			}else{
				$itemhtml = $v[0]['html'];
				#$v[0]['itemid'] = $maxnum;
				$v[0]['name'] = "FLOWDATA[{$v[0]['itemid']}]";
				$v[0]['html'] = preg_replace ( "/(.*)name=\"FLOWDATA([^\"]*)(\"\s?(.*))/is", "\\1name=\"FLOWDATA[{$v[0]['itemid']}]\\3", $v[0]['html'] );
				$v[0]['html'] = preg_replace ( "/(.*)flowitemid=\"([^\"]*)(\"\s?(.*))/is", "\\1flowitemid=\"{$v[0]['itemid']}\\3", $v[0]['html'] );
				$elementList[] = $v[0];
				$html = str_replace_once($itemhtml, $v[0]['html'], $html);
			}
		}

		$html = str_replace(array("\t", "\n"), "", $html);
		
		//更新最大数
		$fid = getPar($_POST, "fid", '0');
		if($maxnum > $maxnum2){
			$CNOA_DB->db_update(array("item_max"=>++$maxnum), "flow_flow_form", "WHERE `fid`='{$fid}'");
		}
		
		return array("element"=>$elementList, "html"=>$html);
	}
	
	/*
	private function __getHtmlElementBackUp($html){
		$elementList = array();
		preg_match_all('/<((input|textarea|select))[^>]*>/is', $html, $arr);
		//preg_match_all('/(<input([^>]*)>)|(<textarea([^>]*)>(.*)<\/textarea>)|(<select([^>]*)>(.*)<\/select>)/is', $html, $arr);
		
		$itemId = 0;
		foreach ($arr[0] AS $v){
			$itemId ++;
			$tmp = array ();
			$tmp ['itemid'] = $itemId;
			$tmp ['name'] = preg_replace ( "/(.*)title=\"([^\"]*)\"\s?(.*)/is", "\\2", $v );
			$tmp ['htmltag'] = strtolower ( substr ( $v, 1, strpos ( $v, " " ) - 1 ) );
			$elementList [] = $tmp;
			
			$newElement = str_replace("name=\"DATA_", "itemId=\"{$itemId}\" name=\"DATA_" . $itemId, str_replace ( preg_replace ( "/(.*)name=\"([^\"]*)\"\s?(.*)/is", "\\2", $v ), "DATA_", $v ) );
			$html = str_replace_once ( $v, $newElement, $html );
		}
		
		return array("element"=>$elementList, "html"=>$html);
	}
	*/
	
	public function _formeditLoadForm(){
		global $CNOA_DB, $CNOA_SESSION, $CNOA_CONTROLLER;
		
		$uid 	= $CNOA_SESSION->get("UID");
		$fid 	= getPar($_POST, "fid", 0);
		
		$info	= $CNOA_DB->db_getone("*", $this->table_form, "WHERE `fid`='{$fid}'");
		if(!$info){
			msg::callBack(false, "没有这条数据");
		}
		
		/*
		//获取附件信息
		$fs = new fs();
		$attach = $fs->getFileInfoById($info['attach']);
		$info['fileInfo'] = $attach['attachInfo'];
		$info['file'] = $attach['oldname'];
		*/
		
		$info['sid'] = $info['sort'];
		unset($info['sort']);
		
		//$info['content'] = nl2br($info['content']);
		
		$dataStore = new dataStore();
		$dataStore->total = 0;
		$dataStore->data = $info;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	/************************* ∧表单相关程序∧ **********************/
	
	/************************* ∨综合类∨ **********************/
	public function _getSortList(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  	= $CNOA_SESSION->get("UID");
		
		$type	= getPar($_GET, "type", "combo");
		$myJobType = $CNOA_SESSION->get("JOBTYPE");
		
		if($myJobType == "superAdmin"){
			$dblist = $CNOA_DB->db_select("*", $this->table_sort, "WHERE 1 ORDER BY `order` ASC");
		}else{
			$deptId	= $CNOA_DB->db_getone("*","main_user","WHERE `uid` = '{$uid}'");
		
			$ssid	= $CNOA_DB->db_select("*",$this->table_dept_sort,"WHERE `deptId` = '{$deptId['deptId']}'");
			!is_array($ssid) && $ssid=array();
			
			$sids = array(0);
			foreach ($ssid as $v){
				$sids[] = $v['sid'];
				
			}
			$dblist = $CNOA_DB->db_select("*", $this->table_sort, "WHERE `sid` IN (".implode(",", $sids).") ORDER BY `order` ASC");
			
		}
		
		
		!is_array($dblist) && $dblist = array();
		
		if($type == "tree"){
			$list = array();
			foreach ($dblist as $v) {
				$r = array();
				$r['text']	= $v['name'];
				$r['sid']	= $v['sid'];
				$r['iconCls']	= "icon-style-page-key";
				$r['leaf']	= true;
				$r['href']	= "javascript:void(0);";
				//if($this->_private_sortAllow($r['sid'])){
				$list[]	= $r;
				//}
			}
			echo json_encode($list);
			exit;
		}elseif($type == 'combo'){
			$dataStore = new dataStore();
			$dataStore->total = count($dblist);
			$dataStore->data = $dblist;
			
			echo $dataStore->makeJsonData();
			exit;
		}
	}
	
	private function _getFormList(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  	= $CNOA_SESSION->get("UID");
		$type	= getPar($_GET, "type", "");
		$sort	= getPar($_GET, "sort", 0);
		
		$flist = $CNOA_DB->db_select(array("name", "fid", "sort"), $this->table_form, "WHERE `sort`='{$sort}'");
		!is_array($flist) && $flist = array();
		
		$list = array();
		foreach($flist AS $vv){
			$rr = array();
			$rr['text']	= $vv['name'];
			$rr['fid']	= $vv['fid'];
			$rr['iconCls']	= "icon-style-page-key";
			$rr['leaf']	= true;
			$rr['href']	= "javascript:void(0);";
			$list[]	= $rr;
		}
		echo json_encode($list);
		exit;
			
		/*
		//获取分类列表
		$slist = $CNOA_DB->db_select(array("name", "sid"), $this->table_sort, "WHERE 1 ORDER BY `order` ASC");
		!is_array($slist) && $slist = array();
		
		
		$flist = $CNOA_DB->db_select(array("name", "fid", "sort"), $this->table_form, "WHERE 1");
		!is_array($flist) && $flist = array();
		
		if($type == "tree"){
			$list = array();
			foreach ($slist as $v) {
				$r = array();
				$r['text']	= $v['name'];
				$r['sid']	= $v['sid'];
				$r['cls']	= "package";
				//$r['iconCls']	= "icon-style-page-key";
				$r['singleClickExpand']	= true;
				$r['href']	= "javascript:void(0);";
				$r['children'] = array();
				foreach($flist AS $vv){
					if($vv['sort'] == $v['sid']){
						$rr = array();
						$rr['text']	= $vv['name'];
						$rr['fid']	= $vv['fid'];
						$rr['iconCls']	= "icon-style-page-key";
						$rr['leaf']	= true;
						$rr['href']	= "javascript:void(0);";
						$r['children'][] = $rr;
					}
				}
				$list[]	= $r;
			}
			echo json_encode($list);
			exit;
		}elseif($type == 'combo'){
			
		}
		*/
	}

	private function _getAllUserListsInPermitDeptTree(){
		$GLOBALS['user']['permitArea']['area'] = "all";

		$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
			
		echo json_encode($userList);
		exit;
	}
	
	private function _getStructTree(){
		$GLOBALS['GLOBALS']['user']['permitArea']['area'] = "all";
		echo app::loadapp( "main", "struct" )->api_getStructTree( 0 );
		exit();
	}
	/************************* ∧综合类∧ **********************/
	
	
	/**
	 * 
	 * 查询工作流相关信息
	 * 标题、发起开始/结束时间
	 * 
	 */
	private function __findFlowInfo(){
		$name		= getPar($_POST, 'name');
		$title		= getPar($_POST, 'title');
		$document	= getPar($_POST, 'document');
		//$stime	= getPar($_POST, 'startTime', "0000-00-00");
		//$etime	= getPar($_POST, 'endTime', "0000-00-00");
		$stime	= getPar($_POST, 'beginTime');
		$etime	= getPar($_POST, 'endTime');
		$status	= getPar($_POST, 'status');
		$uid	= getPar($_POST, 'buildUser');
		
		$s = '';
		
		//unode可以查询ulist数据 
		
	//cnoa_flow_flow_u_list表下数据 
		if(!empty($uid)){
			$s .= " AND `uid`={$uid}";
		}
		if(!empty($status) && strval($status) != '-99'){ //当前状态
			$s .= " AND `status` = {$status}";
		}
		if(!empty($name)){ //编号
			$s .= " AND `name` LIKE '%{$name}%'";
		}
		if(!empty($title)){ //标题
			$s .= " AND `title` LIKE '%{$title}%'";
		}
		if(!empty($document)){ //公文文号
			$s .= " AND `document` LIKE '%{$document}%'";
		}
		if(!empty($stime) && empty($etime)){
			$stime = strtotime($stime . " 00:00:00");
			$s .= " AND `posttime` >= {$stime}"; 
		}
		if(!empty($etime) && empty($stime)){
			$etime = strtotime($etime . " 23:59:59");
			$s .= " AND `posttime` <= {$etime}";
		}		
		if(!empty($stime) && !empty($etime)){
			//在开始与结束时间之间的信息
			$stime = strtotime($stime . " 00:00:00");
			$etime = strtotime($etime . " 23:59:59");
			
			if($stime > $etime){
				msg::callBack(false, "查询开始时间不能大于结束时间");
			}else{
				$s .= " AND `posttime` > {$stime} AND `posttime` < {$etime}";
			}
			
		}
		return " $s ";
	}
	
}


?>