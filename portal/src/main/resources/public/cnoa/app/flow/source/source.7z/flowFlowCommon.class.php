<?php
/**
 * cnoa framework
 *
 * @package		cnoa
 * @author		cnoa Dev Team & Linxiaoqing
 * @email		linxiaoqing@live.com
 * @copyright	Copyright (c) 2011, cnoa, Inc.
 * @license		http://cnoa.com/user_guide/license.html
 * @since		Version 1.4.0
 * @filesource
 */

class flowFlowCommon extends model{
	/**
	 * 
	 * Enter 查看流程表单时处理数据
	 * @param 表单 $html
	 * @param 本步骤的各个表单属性 $nowItems
	 * @param 已提交过的数据 $data
	 * @param 是否显示未自理的表单提示框
	 */
	public function api_parseFormForView($html, $data, $formItems, $flowInfo, $showIng=true){
		!is_array($nowItems) && $nowItems=array();
		!is_array($data) && $data=array();
		!is_array($formItems) && $formItems=array();

		#debug::xprint($data);

		$elementList = $this->__getHtmlElement($html);

		$nowItems2 = array();
		foreach($nowItems AS $v){
			$nowItems2[$v['itemid']] = $v;
		}
		unset($nowItems, $v);

		//给已有表单赋值
		$formItems2 = array();
		foreach($formItems AS $v){
			$formItems2[$v['itemid']] = $v;
		}
		unset($formItems, $v);
		#debug::xprint($html);
		#debug::xprint($data);
		foreach($data AS $v){
			if($v['step'] <= $flowInfo['step']){
				#debug::xprint($v['data']."||".$formItems2[$v['itemid']]['html']);
				$html = str_replace($formItems2[$v['itemid']]['html'], nl2br($v['data']), $html);
				#debug::xprint("<br>" . htmlentities($formItems2[$v['itemid']]['html']) . "<br>" . $v['itemid'] . "|------------|{$v['data']}<br>" .$html);
			}
		}
		unset($data, $v);

		#debug::xprint($html);
		foreach($elementList AS $v){
			//取消掉所有不是本步骤的表单
			if($showIng){
				$html = str_replace($v['html'], "<span style='color:#FFF;background-color:#660000;padding:2px;'>{$formItems2[$v['itemid']]['title']}</span>", $html);
			}else{
				$html = str_replace($v['html'], "", $html);
			}
		}

		return $html;
	}
	
	public function api_parseFormForNextFlowStep($html, $nowItems, $data, $formItems, $stepInfo){
		global $CNOA_SESSION;
		
		$uid = $CNOA_SESSION->get("UID");
		
		!is_array($nowItems) && $nowItems=array();
		!is_array($data) && $data=array();
		!is_array($formItems) && $formItems=array();
		!is_array($stepInfo) && $stepInfo=array();
		
		//处理$formItems，把itemid交换给key
		$tmpFormItems = $formItems; $formItems = array();
		foreach ($tmpFormItems AS $v){
			if(($v['type'] == 'textarea') && !eregi("<\/textarea>", $v['html'])){
				$v['html'] .= "</textarea>";
			}
			$formItems[$v['itemid']] = $v;
		}
		unset($tmpFormItems, $v);
		
		//处理$nowItems，把itemid交换给key
		$tmpNowItems = $nowItems; $nowItems = array();
		foreach ($tmpNowItems AS $v){
			$nowItems[$v['itemid']] = $v;
		}
		unset($tmpNowItems, $v);
		
		//当前步骤数：
		$nowStep = $stepInfo['stepid'];
		
		//处理数据(把数据分成两块：已经办理的表单内容，当前步骤的表单内容[抛弃掉非当前步骤之后的数据])
		$dataList = array();
		$dataList['ddata'] = array(); #已经输的表单内容
		$dataList['ndata'] = array(); #当前步骤的表单内容
		foreach ($data AS $v){
			if($v['step'] < $nowStep){
				$dataList['ddata'][$v['itemid']] = $v;
			}
			if($v['step'] == $nowStep){
				$dataList['ndata'][$v['itemid']] = $v;
			}
		}
		unset($data, $v);
		
		//处理已经办理的表单内容
		foreach($dataList['ddata'] AS $v){
			//替换控件
			$html = str_replace($formItems[$v['itemid']]['html'], $v['data'], $html);
		}
		unset($dataList['ddata'], $v);
		
		//处理当前步骤及之后的所有步骤
		foreach($nowItems AS $v){
			//当前步骤
			if($v['used'] === true || $v['need'] == true || $v['must'] == true){
				//替换掉宏控件
				$this->__parseMacroInputs($html, $formItems[$v['itemid']]);
				//debug::xprint($html);
				//给非宏控件设置值
				//去掉当前步骤的一些未办理表单，用于多人办理方式时
				if(($stepInfo['operatortype'] == 2) && ($stepInfo['operatorperson'] == 2)){
					if($dataList['ndata'][$v['itemid']]['uid'] == $uid){
						$this->__setValue($html, $formItems[$v['itemid']], $dataList['ndata'][$v['itemid']]['data']);
					}else{
						if(!empty($dataList['ndata'][$v['itemid']]['data'])){
							$html = str_replace($formItems[$v['itemid']]['html'], $dataList['ndata'][$v['itemid']]['data'], $html);
						}
					}
				}else{
					//debug::xprint($dataList['ndata'][$v['itemid']]['data']);
					$this->__setValue($html, $formItems[$v['itemid']], $dataList['ndata'][$v['itemid']]['data']);
				}
				
				//给必填和选填的表单附加上样式
				if($nowItems[$v['itemid']]['need'] == '1'){
					$itemReplace = "name=\"FLOWDATA[{$v['itemid']}]\"";
					if($nowItems[$v['itemid']]['must'] == '1'){
						$html = str_replace($itemReplace, " class=\"flow_form_must_color\" {$itemReplace}", $html);
					}else{
						$html = str_replace($itemReplace, " class=\"flow_form_need_color\" {$itemReplace}", $html);
					}
				}
			}
			//之后步骤
			else{
				$html = str_replace(
					$formItems[$v['itemid']]['html'],
					"<span style='color:#FFF;background-color:#660000;padding:2px;' title='未办理'>{$formItems[$v['itemid']]['title']}</span>",
					$html
				);
			}
		}
		unset($v);
		
		return $html;
	}
	
	
	/**
	 * !!暂时没在用，已经被上面所替换掉了
	 * Enter 办理下一级流程时的表单处理
	 * @param 表单 $html
	 * @param 本步骤的各个表单属性 $nowItems
	 * @param 已提交过的数据 $data
	 * @param 本次节点的流程信息
	 */
	public function api_parseFormForNextFlowStep__($html, $nowItems, $data, $formItems, $stepInfo){
		!is_array($nowItems) && $nowItems=array();
		!is_array($data) && $data=array();
		!is_array($formItems) && $formItems=array();
		!is_array($stepInfo) && $stepInfo=array();
		
		$data2 = $data;
		$data  = array();
		
		foreach($data2 AS $k=>$v){
			$data[$v['itemid']] = $v;
		}
		unset($k, $v);

		$elementList = $this->__getHtmlElement($html);

		$nowItems2 = array();
		foreach($nowItems AS $v){
			$nowItems2[$v['itemid']] = $v;
		}
		unset($nowItems, $v);
		
		//给已有表单赋值
		$formItems2 = array();
		foreach($formItems AS $k=>$v){
			if(($formItems[$k]['type'] == 'textarea') && !eregi("<\/textarea>", $formItems[$k]['html'])){
				$formItems[$k]['html'] .= "</textarea>";
				$v['html'] .= "</textarea>";
			}
			$formItems2[$v['itemid']] = $v;
		}
		unset($formItems, $k, $v);
		
		//去掉当前步骤的一些未办理表单，用于多人办理方式时
		if(($stepInfo['operatortype'] == 2) && ($stepInfo['operatorperson'] == 2)){
			$stepInfo['formitems'] = json_decode($stepInfo['formitems'], TRUE);
			!is_array($stepInfo['formitems']) && $stepInfo['formitems']=array();
			foreach($stepInfo['formitems'] AS $v){
				if(empty($data[$v['itemid']]['data'])){
					unset($data[$v['itemid']]);
				}
			}
		}

		foreach($data AS $v){
			$html = str_replace($formItems2[$v['itemid']]['html'], $v['data'], $html);
		}
		unset($data, $v);
		
		foreach($elementList AS $v){
			//替换掉宏控件
			if($nowItems2[$v['itemid']]['used'] == '1'){
				$this->__parseMacroInputs($html, $v);
			}
			
			//给必填和选填的表单附加上样式
			if($nowItems2[$v['itemid']]['need'] == '1'){
				$itemReplace = "name=\"FLOWDATA[{$v['itemid']}]\"";
				if($nowItems2[$v['itemid']]['must'] == '1'){
					$html = str_replace($itemReplace, " class=\"flow_form_must_color\" {$itemReplace}", $html);
				}else{
					$html = str_replace($itemReplace, " class=\"flow_form_need_color\" {$itemReplace}", $html);
				}
			}
			
			//取消掉所有不是本步骤的表单
			else{
				//$html = str_replace($v['html'], "", $html);
				$html = str_replace($v['html'], "<span style='color:#FFF;background-color:#660000;border:1px solid red'>{$formItems2[$v['itemid']]['title']}(未办理)</span>", $html);
			}
		}
		
		return $html;
	}
	
	public function api_parseFormForNewFlow($html, $firstItems, $flowFormItems){
		!is_array($itemsInfo) && $itemsInfo=array();
		
		$elementList = $this->__getHtmlElement($html);
		
		//重新组成数据
		$firstItems2 = array();
		foreach($firstItems AS $v){
			$firstItems2[$v['itemid']] = $v;
		}
		unset($firstItems, $v);
		
		//重新生成数据
		$flowFormItems2 = array();
		!is_array($flowFormItems) && $flowFormItems = array();
		foreach($flowFormItems AS $v){
			$flowFormItems2[$v['itemid']] = $v;
		}
		unset($flowFormItems, $v);
		
		//替换掉流程编号和流程名称
		foreach($elementList AS $v){
			if($flowFormItems2[$v['itemid']]['type'] == "SYS_FLOWTITLE"){
				$html = str_replace($v['html'], "<span style='color:yellow;background-color:#660000'>流程名称</span>", $html);
			}
			if($flowFormItems2[$v['itemid']]['type'] == "SYS_FLOWNAME"){
				$html = str_replace($v['html'], "<span style='color:yellow;background-color:#660000'>流程编号</span>", $html);
			}
		}
		unset($v);
		
		foreach($elementList AS $v){
			//替换掉宏控件
			if($firstItems2[$v['itemid']]['used'] == '1'){
				$this->__parseMacroInputs($html, $v);
			}
			
			//给必填和选填的表单附加上样式
			if($firstItems2[$v['itemid']]['need'] == '1'){
				$itemReplace = "name=\"FLOWDATA[{$v['itemid']}]\"";
				if($firstItems2[$v['itemid']]['must'] == '1'){
					$html = str_replace($itemReplace, " class=\"flow_form_must_color\" {$itemReplace}", $html);
				}else{
					$html = str_replace($itemReplace, " class=\"flow_form_need_color\" {$itemReplace}", $html);
				}
			}
			
			//取消掉所有不是本步骤的表单
			else{
				$html = str_replace($v['html'], "<span style='color:#FFF;background-color:#660000;padding:2px;'>{$flowFormItems2[$v['itemid']]['title']}</span>", $html);
			}
		}
		return $html;
	}
	
	private function __getHtmlElement($html){
		$elementList = array();

		/*
		preg_match_all('/((<((input|textarea))[^>]*>)|(<select[\s\S]+?>[\s\S]+?<\/select>))/i', $html, $arr);
		*/
		preg_match_all('/((<((input))[^>]*>)|(<textarea[\s\S]+?><\/textarea>)|(<select[\s\S]+?>[\s\S]+?<\/select>))/i', $html, $arr);
		
		foreach ($arr[0] AS $v){
			$tmp = array ();
			$tmp ['itemid']  = preg_replace ( "/(.*)flowitemid=\"([^\"]*)\"\s?(.*)/is", "\\2", $v );
			$tmp ['type']  = preg_replace ( "/(.*)flowitemtp=\"([^\"]*)\"\s?(.*)/is", "\\2", $v );
			$tmp ['name']	 = preg_replace ( "/(.*)name=\"([^\"]*)\"\s?(.*)/is", "\\2", $v );
			$tmp ['title']	 = preg_replace ( "/(.*)title=\"([^\"]*)\"\s?(.*)/is", "\\2", $v );
			$tmp ['htmltag'] = strtolower ( substr ( $v, 1, strpos ( $v, " " ) - 1 ) );
			$tmp ['html']	 = $v;
			$elementList []  = $tmp;
		}
		
		return $elementList;
	}
	
	/**
	 * 给非宏控件设置值
	 */
	public function __setValue(&$html, $item, $value){
		$value = trim($value);
		if($item['htmltag'] == "input"){
			$item['html2'] = str_replace("<input", "<input value='".$value."'", $item['html']);
		}
		if($item['htmltag'] == "textarea"){
			$item['html2'] = str_replace("</textarea>", $value."</textarea>", $item['html']);
		}
		if($item['htmltag'] == "select"){
			$item['html2'] = str_replace("<option value=\"".$value."\">", "<option value=\"".$value."\" selected=\"selected\">", $item['html']);
		}
		$html = str_replace($item['html'], $item['html2'], $html);
	}
	
	/**
	 * 解析宏控件
	 * 
	 */
	private function __parseMacroInputs(&$html, $item){
		$value = "";
		switch ($item['type']){
			#[ "当前日期, 形如: 2011-01-01", 'SYS_DATE' ],
			case "SYS_DATE":
				$value = $this->__SYS_DATE();
				break;
			#[ "当前日期, 形如: 2011年1月1日", 'SYS_DATE_CN' ],
			case "SYS_DATE_CN":
				$value = $this->__SYS_DATE_CN();
				break;
			#[ "当前日期, 形如: 2011年", 'SYS_DATE_CN_SHORT3' ],
			case "SYS_DATE_CN_SHORT3":
				$value = $this->__SYS_DATE_CN_SHORT3();
				break;
			#[ "当前年份, 形如: 2011", 'SYS_DATE_CN_SHORT4' ],
			case "SYS_DATE_CN_SHORT4":
				$value = $this->__SYS_DATE_CN_SHORT4();
				break;
			#[ "当前日期, 形如: 2011年1月", 'SYS_DATE_CN_SHORT1' ],
			case "SYS_DATE_CN_SHORT1":
				$value = $this->__SYS_DATE_CN_SHORT1();
				break;
			#[ "当前日期, 形如: 1月1日", 'SYS_DATE_CN_SHORT2' ],
			case "SYS_DATE_CN_SHORT2":
				$value = $this->__SYS_DATE_CN_SHORT2();
				break;
			#[ "当前时间, 形如: 12时12分", 'SYS_TIME' ],
			case "SYS_TIME":
				$value = $this->__SYS_TIME();
				break;
			#[ "当前日期+时间, 形如2011年12月11日 12时21分", 'SYS_DATETIME' ],
			case "SYS_DATETIME":
				$value = $this->__SYS_DATETIME();
				break;
			#[ "星期几, 形如: 星期一", 'SYS_WEEK' ],
			case "SYS_WEEK":
				$value = $this->__SYS_WEEK();
				break;
			#[ "当前用户ID", 'SYS_UID' ],
			case "SYS_UID":
				$value = $this->__SYS_UID();
				break;
			#[ "当前用户姓名", 'SYS_TRUENAME' ],
			case "SYS_TRUENAME":
				$value = $this->__SYS_TRUENAME();
				break;
			#[ "当前用户帐号", 'SYS_USERNAME' ],
			case "SYS_USERNAME":
				$value = $this->__SYS_USERNAME();
				break;
			#[ "当前用户所在部门", 'SYS_DEPTNAME' ],
			case "SYS_DEPTNAME":
				$value = $this->__SYS_DEPTNAME();
				break;
			#[ "当前用户职位", 'SYS_JOBNAME' ],
			case "SYS_JOBNAME":
				$value = $this->__SYS_JOBNAME();
				break;
			#[ "当前用户岗位", 'SYS_STATIONNAME' ],
			case "SYS_STATIONNAME":
				$value = $this->__SYS_STATIONNAME();
				break;
			#[ "当前用户姓名+日期", 'SYS_TRUENAME_DATE' ],
			case "SYS_TRUENAME_DATE":
				$value = $this->__SYS_TRUENAME_DATE();
				break;
			#[ "当前用户姓名+日期+时间", 'SYS_TRUENAME_DATETIME' ],
			case "SYS_TRUENAME_DATETIME":
				$value = $this->__SYS_TRUENAME_DATETIME();
				break;
			#[ "表单名称", 'SYS_FORMNAME' ],
			case "SYS_FORMNAME":
				$value = $this->__SYS_FORMNAME();
				break;
			#[ "工作流名称", 'SYS_FLOWTITLE' ],
			case "SYS_FLOWTITLE":
				$value = $this->__SYS_FLOWTITLE();
				break;
			#[ "工作流编号", 'SYS_FLOWNAME' ],
			case "SYS_FLOWNAME":
				$value = $this->__SYS_FLOWNAME();
				break;
			#[ "流程开始日期", 'SYS_SDATE' ],
			case "SYS_SDATE":
				$value = $this->__SYS_SDATE();
				break;
			#[ "流程开始日期+时间", 'SYS_SDATETIME' ],
			case "SYS_SDATETIME":
				$value = $this->__SYS_SDATETIME();
				break;
			#[ "经办人IP地址", 'SYS_IP' ],
			case "SYS_IP":
				$value = $this->__SYS_IP();
				break;
				/*
			#[ "部门主管(本部门)", 'SYS_MANAGER' ]
			case "SYS_IP":
				$value = $this->__SYS_IP();
				break;*/
			default:
				return ;
				break;
		}
		
		$value .= "<input type='hidden' name='{$item['name']}' value='{$value}'>";
		
		$html = str_replace($item['html'], $value, $html);
	}
	
	private function __SYS_DATE(){
		return date("Y-m-d", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_DATE_CN(){
		return date("Y年m月d日", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_DATE_CN_SHORT3(){
		return date("Y年", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_DATE_CN_SHORT4(){
		return date("Y", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_DATE_CN_SHORT1(){
		return date("Y年m月", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_DATE_CN_SHORT2(){
		return date("m月d日", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_TIME(){
		return date("H时i分", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_DATETIME(){
		return date("Y年m月d日 H时i分", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_WEEK(){
		return getWeek($GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_UID(){
		global $CNOA_SESSION;
		return $CNOA_SESSION->get("UID");
	}
	
	private function __SYS_TRUENAME(){
		global $CNOA_SESSION;
		return $CNOA_SESSION->get("TRUENAME");
	}
	
	private function __SYS_USERNAME(){
		global $CNOA_SESSION;
		return $CNOA_SESSION->get("TRUENAME");
	}
	
	private function __SYS_DEPTNAME(){
		global $CNOA_SESSION;
		return app::loadApp("main", "struct")->api_getNameById($CNOA_SESSION->get("DID"));
	}
	
	private function __SYS_JOBNAME(){
		global $CNOA_SESSION;
		return app::loadApp("main", "job")->api_getNameById($CNOA_SESSION->get("JID"));
	}
	
	private function __SYS_STATIONNAME(){
		global $CNOA_SESSION;
		return app::loadApp("main", "station")->api_getNameById($CNOA_SESSION->get("SID"));
	}
	
	private function __SYS_TRUENAME_DATE(){
		global $CNOA_SESSION;
		return $CNOA_SESSION->get("TRUENAME") . " " . date("Y年m月d日", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_TRUENAME_DATETIME(){
		global $CNOA_SESSION;
		return $CNOA_SESSION->get("TRUENAME") . " " . date("Y年m月d日 H时i分", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_FORMNAME(){
		global $CNOA_DB;
		
		$fid = getPar($_POST, "fid", 0);
		
		return $CNOA_DB->db_getfield("name", "flow_flow_form", "WHERE `fid`='{$fie}'");
	}
	
	private function __SYS_FLOWTITLE(){
		global $CNOA_DB;
		
		$lid = getPar($_POST, "lid", 0);
		
		return $CNOA_DB->db_getfield("name", "flow_flow_list", "WHERE `lid`='{$fie}'");
	}
	
	private function __SYS_FLOWNAME(){
		global $CNOA_DB;
		$lid = getPar($_POST, "lid", 0);
		
		return $CNOA_DB->db_getfield("number", "flow_flow_list", "WHERE `lid`='{$fie}'");
	}
	
	private function __SYS_SDATE(){
		return date("Y年m月d日", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_SDATETIME(){
		return date("Y年m月d日 H时2i1分", $GLOBALS['CNOA_TIMESTAMP']);
	}
	
	private function __SYS_IP(){
		
		return getip();
	}
	
	public function api_SYS_FLOWTITLE(){
		$this->__SYS_FLOWTITLE();
	}
	
	public function api_SYS_FORMNAME(){
		$this->__SYS_FORMNAME();
	}
}

