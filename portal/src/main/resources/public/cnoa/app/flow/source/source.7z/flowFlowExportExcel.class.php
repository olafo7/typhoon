<?php
/**
 * cnoa framework
 *
 * @package		cnoa
 * @author		cnoa Dev Team & Linxiaoqing
 * @email		linxiaoqing@live.com
 * @copyright	Copyright (c) 2011, cnoa, Inc.
 * @license		http://cnoa.com/user_guide/license.html
 * @since		Version 1.4.0
 * @filesource
 */
class flowFlowExportExcel extends model{
	
	
	public function __construct(){
		
	}
	
	public function init($source, $truename, $stime, $etime){
		$this->objPHPExcel = new PHPExcel();
		$this->setProperties($truename, $stime, $etime);
		$this->addData($source);
	}
	
	private function setProperties($truename, $stime, $etime){
		//设置文档属性
		$this->objPHPExcel->getProperties()
			 ->setCreator("协众软件")
			 ->setLastModifiedBy("协众软件")
			 ->setTitle("协众软件XLS文档")
			 ->setSubject("协众软件XLS标题")
			 ->setDescription("协众软件XLS描述")
			 ->setKeywords("关键词")
			 ->setCategory("Category");
		
		//激活第一页
		$this->objPHPExcel->setActiveSheetIndex(0);
			
		//设置页名
		$this->objPHPExcel->getActiveSheet()->setTitle('第一页');
		
		//合并第一行
		$this->objPHPExcel->getActiveSheet()->mergeCells('A1:G1');
		
		//设置第一行高度
		$this->objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(30);
		
		//设置列宽
		$this->objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(30);
		$this->objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(13);
		$this->objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(13);
		$this->objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(12);
		$this->objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
		$this->objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(12);
		$this->objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
		
		//设置表头样式
		$styleTitle = array ('font' => array ('bold' => true, 'color' => array ('argb' => '000000' ) ), 'borders' => array ('allborders' => array ('style' => PHPExcel_Style_Border::BORDER_THIN ) ) );
		$this->objPHPExcel->getActiveSheet()->getStyle('A2:G2')->applyFromArray($styleTitle);
		$this->objPHPExcel->getActiveSheet()->getStyle('A2:G2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('DFDFDFDF');
		
		//设置单元格初始内容
		$this->objPHPExcel->getActiveSheet()
			 ->setCellValue('A1', '工作流程列表 - [发起人:'.$truename.' / 时间段:'.date("Y年m月d日", $stime).'-'.date("Y年m月d日", $etime).']')
			 ->setCellValue('A2', '流程编号')
			 ->setCellValue('B2', '所属流程')
			 ->setCellValue('C2', '标题')
			 ->setCellValue('D2', '重要等级')
			 ->setCellValue('E2', '当前步骤')
			 ->setCellValue('F2', '状态')
			 ->setCellValue('G2', '发起日期');
	}
	
	private function addData($source){
		!is_array($source) && $source = array();
		$i = 3;
		foreach($source AS $sv){
			$this->objPHPExcel->getActiveSheet()
			 ->setCellValue('A'.$i, $sv['name'])
			 ->setCellValue('B'.$i, $sv['flowname'])
			 ->setCellValue('C'.$i, $sv['title'])
			 ->setCellValue('D'.$i, $sv['level'])
			 ->setCellValue('E'.$i, $sv['step'])
			 ->setCellValue('F'.$i, $sv['statusText'])
			 ->setCellValue('G'.$i, $sv['posttime']);
			//$this->objPHPExcel->getActiveSheet()->getRowDimension($i)->setRowHeight(30);
			$i++;
		}
		
		//设置表单元格样式
		$styleBody = array('borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN,)));
		$this->objPHPExcel->getActiveSheet()->getStyle('A2:G'.(--$i))->applyFromArray($styleBody);
	}
	
	public function save($filename){		
		$this->objPHPExcel = PHPExcel_IOFactory::createWriter($this->objPHPExcel, 'Excel5');
		$this->objPHPExcel->save($filename);
	}
	
	public function export(){
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="01simple.xls"');
		header('Cache-Control: max-age=0');
		
		$this->objPHPExcel = PHPExcel_IOFactory::createWriter($this->objPHPExcel, 'Excel5');
		$this->objPHPExcel->save('php://output');
		exit;
	}
}