<?php
/**
 * cnoa framework
 *
 * @package		cnoa
 * @author		cnoa Dev Team & Linxiaoqing
 * @email		linxiaoqing@live.com
 * @copyright	Copyright (c) 2011, cnoa, Inc.
 * @license		http://cnoa.com/user_guide/license.html
 * @since		Version 1.4.0
 * @filesource
 */
/**
 * 内部调用专用模块
 * 供 flowFlow.class.php -> actionUser() 调用
 * @author Administrator
TRUNCATE TABLE `cnoa_flow_flow_u_event`;
TRUNCATE TABLE `cnoa_flow_flow_u_formdata`;
TRUNCATE TABLE `cnoa_flow_flow_u_list`;
TRUNCATE TABLE `cnoa_flow_flow_u_node`;
 *
 */ 
class flowFlowUserCommonFlow extends model{
	//流程分类表
	private $table_sort			= "flow_flow_sort";
	//流程表
	private $table_list			= "flow_flow_list";
	//流程节点表
	private $table_list_node	= "flow_flow_list_node";
	//流程表单表
	private $table_form			= "flow_flow_form";
	//流程表单表单列表表
	private $table_form_item	= "flow_flow_form_item";
	
	//流程列表
	private $table_u_list		= "flow_flow_u_list";
	//流程节点表
	private $table_u_node		= "flow_flow_u_node";
	//工作表单数据表
	private $table_u_formdata	= "flow_flow_u_formdata";
	//事件表
	private $table_u_event		= "flow_flow_u_event";
	//委托表
	private $table_u_entrust	= "flow_flow_u_entrust";
	
	//事件类型(不可修改)
	//1:开始 2:已处理 3:撤销 4:召回 5:退回 6:退回上一步 7:结束
	private $eventType			= array(1=>"开始",2=>"已办理",3=>"撤销",4=>"召回",5=>"退件",6=>"退回上一步",7=>"结束");
	
	//状态说明
	private $statusType			= array(1=>"办理中", 2=>"已办理", 3=>"退件");
	
	//委托人状态说明
	private $entrustType		= array(0=>"禁用", 1=>"启用", 2=>"未设置");
	
	private $viewUrlCommonFlow	= 'index.php?app=flow&func=flow&action=user&module=commonFlow&task=loadPage&from=viewflow&ulid=';
	
	//缓存路径
	private $cachePath			= "";
	
	public function __construct(){
		$this->cachePath = CNOA_PATH_FILE . "/cache";
	}
	
	public function run(){
		global $CNOA_SESSION;
		
		$task = getPar($_GET, 'task', getPar($_POST, 'task'));

		switch ($task){
			case "loadPage":
				$this->_loadPage();
				exit;break;
			case "getAllUserListsInPermitDeptTree":
				$this->_getAllUserListsInPermitDeptTree();
				exit;break;
			case "sendFlow":
				$this->_sendFlow();
				exit;break;
			case "editLoadFormDataInfo":
				$this->_editLoadFormDataInfo();
				exit;break;
		}
	}
	
	/************************* ∨总程序∨ **********************/
	private function _loadPage(){
		global $CNOA_SESSION, $CNOA_CONTROLLER;
		
		$from = getPar($_GET, "from", "");
		
		if ($from == "newflow"){
			//载入新建通用工作流程页面
			$GLOBALS['ac']		= getPar($_GET, 'ac', 'add');
			$GLOBALS['ulid']	= getPar($_GET, 'ulid', '0');
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_newcommonflow.htm';
		}elseif($from == "showflow"){
			//载入查看通用工作流程页面
			$GLOBALS['ulid'] = getPar($_GET, "ulid", 0);
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_showcommonflow.htm';
		}elseif($from == "viewflow"){
			//载入办理通用工作流程页面
			$GLOBALS['ulid'] = getPar($_GET, "ulid", 0);
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_viewcommonflow.htm';
		}elseif ($from == "showdispenseflow"){
			//载入分发流程列表页
			$GLOBALS['ulid'] = getPar($_GET, "ulid", 0);
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/dispense_view_commonflow.htm';
		}
		
		$CNOA_CONTROLLER->loadExtraTpl($tplPath);
		exit;
	}

	
	private function _getAllUserListsInPermitDeptTree(){
		$GLOBALS['user']['permitArea']['area'] = "all";
		
		$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
			
		echo json_encode($userList);
		exit;
	}
	
	private function _sendFlow(){
		global $CNOA_DB, $CNOA_SESSION;

		/*
		 * 获取数据 ==========================================================
		 */
		$uid				= $CNOA_SESSION->get("UID");
		$uname				= $CNOA_SESSION->get("TRUENAME");
		
		$stepInfo			= $_POST['step'];
		//$data	= json_decode($_POST['data'], true);
		$nextOperatorUid 	= 0;
		
		$ac					= getPar($_POST, "ac", "add");
		$ulid				= getPar($_POST, "ulid", 0);
		
		/*
		 * 处理数据，进数据库=================================================
		 */
		#处理附件
		

		#生成表单
		if($ac == "edit"){
			$ds = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}'");
			$CNOA_DB->db_delete($this->table_u_list, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}'");
			
			//处理附件
			$fs = new fs();
			$attach = $fs->edit(getPar($_POST, "filesUpload", array()), json_decode($ds['attach'], false), 7);
			$ds['attach'] = json_encode($attach);
		}else{
			$ds = array();
			$ds['lid']			= 0;
			$ds['flowmax']		= $CNOA_DB->db_getmax("flowmax", $this->table_u_list, "WHERE `flowtype`=1")+1;
			$ds['name']			= "通用流程".str_pad($ds['flowmax'], 10, "0", STR_PAD_LEFT);
			
			//处理附件
			$fs = new fs();
			$filesUpload = getPar($_POST, "filesUpload", array());
			$attach = $fs->add($filesUpload, 7);
			$ds['attach'] = json_encode($attach);
		}
		$ds['flowtype']		= 1;
		$ds['flowname']		= "通用流程";
		$ds['title']		= getPar($_POST, "title", "");
		$ds['uid']			= $uid;
		$ds['level']		= getPar($_POST, "level", "");
		$ds['reason']		= getPar($_POST, "reason", "", 1, 0);
		$ds['about']		= '';
		$ds['posttime']		= $GLOBALS['CNOA_TIMESTAMP'];
		$ds['file']			= '';
		$ds['status']		= 1;
		#$ds['nodecache']	= '';
		#$ds['sort']		= 0;
		$ds['step']			= 1;
		$ds['commonflowdata'] = addslashes($stepInfo);
		
		$ulid = $CNOA_DB->db_insert($ds, $this->table_u_list);
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('add', 73, $ds['title'], '通用流程');
		
		/*
		 * 生成步骤节点缓存信息================================================
		 */
		$flowStepInfos		= array();
		#开始节点->
		$flowStepItem		= array();
		$flowStepItem['stepid']		= 0;
		$flowStepItem['name']		= "开始";
		$flowStepItem['about']		= "";
		$flowStepItem['allowup']	= "1";
		$flowStepItem['allowdown']	= "1";
		$flowStepItem['type']		= "start";
		$flowStepItem['operatorperson']	= "1";
		$flowStepItem['operatortype']	= "1";
		$flowStepItem['operator']	= json_encode(array("user"=>array(
			array("uid"=>$uid, "name"=>$uname)
		)));
		$flowStepInfos[] = $flowStepItem;
		#开始节点<-
		$stepInfo = json_decode($stepInfo, true);
		if(is_array($stepInfo)){
			foreach ($stepInfo AS $k=>$v){
				#中间节点->
				$flowStepItem				= array();
				$flowStepItem['stepid']		= $k+1;
				$flowStepItem['name']		= $v['stepName'];
				$flowStepItem['about']		= "";
				$flowStepItem['allowup']	= "1";
				$flowStepItem['allowdown']	= "1";
				$flowStepItem['type']		= "node";
				$flowStepItem['operatorperson']	= "1";
				$flowStepItem['operatortype']	= "1";
				$flowStepItem['operator']	= json_encode(array("user"=>array(
					array("uid"=>$v['uid'], "name"=>$v['uname'])
				)));
				$flowStepInfos[] = $flowStepItem;
				#中间节点<-
				if($k == 0){
					$nextOperatorUid = $v['uid'];
				}
			}
		}
		#结束节点->
		$flowStepItem				= array();
		$flowStepItem['stepid']		= $k+1;
		$flowStepItem['name']		= "结束";
		$flowStepItem['about']		= "";
		$flowStepItem['allowup']	= "1";
		$flowStepItem['allowdown']	= "1";
		$flowStepItem['type']		= "end";
		$flowStepItem['operatorperson']	= "1";
		$flowStepItem['operatortype']	= "1";
		$flowStepItem['operator']	= json_encode(array("user"=>array(array())));
		$flowStepInfos[] = $flowStepItem;
		#结束节点<-
		
		#写入缓存
		$cachePath = $this->cachePath . "/flow/user/{$ulid}/" . "flow_node.php";
		@mkdirs(dirname($cachePath));
		file_put_contents($cachePath, "<?php\r\nreturn ".var_export($flowStepInfos, true).";");
		
		/**
		 * 生成已经办理节点信息列表============================================
		 */
		//添加事件
		app::loadApp("flow", "flowUser")->api_eventAdd($ulid, 1, 0, "开始", $ds['reason']);
		
		#生成本节点(提供给流程进度查询用)
		unset($data);$data = array();
		$data['ulid']			= $ulid;
		$data['stepid']			= 0;
		$data['say']			= $ds['reason'];
		$data['status']			= 2;
		$data['nodename']		= $flowStepInfos[0]['name'];
		$data['stime']			= $GLOBALS['CNOA_TIMESTAMP'];
		$data['uid']			= $uid;
		$data['operatortype']	= 1;
		$data['attachdown']		= 1;
		$data['attachup']		= 1;
		$data['sponsor']		= 1;
		$CNOA_DB->db_insert($data, $this->table_u_node);
		
		//生成下一步节点信息
		unset($data);$data = array();
		$nextUids = explode(",", getPar($_POST, "nextUids", ""));
		$data['ulid']			= $ulid;
		$data['stepid']			= 1;
		$data['status']			= 1;
		$data['nodename']		= $flowStepInfos[1]['name'];
		$data['stime']			= $GLOBALS['CNOA_TIMESTAMP'];
		$data['operatortype']	= 1;
		$data['attachdown']		= 1;
		$data['attachup']		= 1;
		$data['sponsor']		= 1;
		$data['uid']			= $nextOperatorUid;

		#添加一个提醒
		$noticeT = "工作流管理";
		$noticeC = "你有一个工作需要审批{$ds['name']}[{$ds['title']}]";
		$noticeH = $this->viewUrlCommonFlow . $ulid;
		$data['noticeid_c'] = notice::add($nextOperatorUid, $noticeT, $noticeC, $noticeH, 0, 5);
		
		$notice['touid']	= $nextOperatorUid;
		$notice['from']		= 5;
		$notice['fromid']	= 0;
		$notice['href']		= $noticeH;
		$notice['title']	= $noticeC;
		$notice['funname']	= "工作流管理";
		$notice['move']		= "审批";
		$data['todoid_c']	= notice::add2($notice);
		
		$CNOA_DB->db_insert($data, $this->table_u_node);
		
		msg::callBack(true, "操作成功");
	}
	
	public function _editLoadFormDataInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		/*
		 * 获取数据 ==========================================================
		 */
		$uid	= $CNOA_SESSION->get("UID");
		$uname	= $CNOA_SESSION->get("TRUENAME");
		$ulid	= intval(getPar($_POST, "ulid", 0));
		if($ulid != 0){
			$formInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}'");
			$formInfo['commonflowdata'] = json_decode($formInfo['commonflowdata'], true);
			
			//获取附件信息
			$fs = new fs();
			$formInfo['attach'] = $fs->getEditList(json_decode($formInfo['attach'], true));
			
			$ds = new dataStore();
			$ds->data = $formInfo;
			$ds->step = $formInfo['commonflowdata'];
			
			echo $ds->makeJsonData();
			exit;
		}else{
			msg::callBack(false, "参数错误");
		}
	}
	
	public function api_getStepInfo($flowInfo){
		global $CNOA_DB, $CNOA_SESSION;
		
		$stepInfo = "开始[".app::loadApp("main", "user")->api_getUserTruenameByUid($flowInfo['uid'])."]";
		
		$flowInfo['commonflowdata'] = json_decode($flowInfo['commonflowdata'], true);
		!is_array($flowInfo['commonflowdata']) && $flowInfo['commonflowdata']=array();
		
		foreach ($flowInfo['commonflowdata'] AS $v){
			$stepInfo .= " <img src='resources/images/icons/arrow-right.png' align='absmiddle'> {$v['stepName']}[{$v['uname']}]";
		}
		
		return $stepInfo;
	}
}


































