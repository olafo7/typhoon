<?php
/**
 * cnoa framework
 *
 * @package		cnoa
 * @author		cnoa Dev Team & Linxiaoqing
 * @email		linxiaoqing@live.com
 * @copyright	Copyright (c) 2011, cnoa, Inc.
 * @license		http://cnoa.com/user_guide/license.html
 * @since		Version 1.4.0
 * @filesource
 */
class flowFlow extends model {
	private $table_sort	= "flow_flow_sort";
	
	function __construct(){
		
	}
	
	function __destruct(){
		
	}
	
	function actionDefault(){
		
	}

	function actionSetting(){
		app::loadApp("flow", "flowSetting")->run();
	}

	function actionfmanger(){
		app::loadApp("flow", "flowFmanger")->run();
	}
	
	function actionUser(){
		$module = getPar($_GET, "module", "");
		if($module == "commonFlow"){
			app::loadApp("flow", "flowUserCommonFlow")->run();
		}else{
			app::loadApp("flow", "flowUser")->run();
		}
	}
	
	function actionManage(){
		app::loadApp("flow", "flowManage")->run();
	}
	
	
	public function api_getSortList(){
		app::loadApp("flow", "flowSetting")->_getSortList();
	}
	
	public function api_flowpreviewLoadData(){
		app::loadApp("flow", "flowSetting")->_flowdesignLoadData();
	}
	
	public function api_loadFormData(){
		app::loadApp("flow", "flowSetting")->_formeditLoadForm();
	}
}
?>