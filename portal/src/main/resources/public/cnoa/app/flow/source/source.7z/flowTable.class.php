<?php
/**
 * cnoa framework
 *
 * @package		cnoa
 * @author		cnoa Dev Team & Linxiaoqing
 * @email		linxiaoqing@live.com
 * @copyright	Copyright (c) 2011, cnoa, Inc.
 * @license		http://cnoa.com/user_guide/license.html
 * @since		Version 1.4.0
 * @filesource
 */
class flowTable extends model {//流程分类表
	private $table_sort			= "flow_flow_sort";
	//流程表
	private $table_list			= "flow_flow_list";
	//流程节点表
	private $table_list_node	= "flow_flow_list_node";
	//流程表单表
	private $table_form			= "flow_flow_form";
	//流程表单表单列表表
	private $table_form_item	= "flow_flow_form_item";
	
	//流程列表
	private $table_u_list		= "flow_flow_u_list";
	//流程节点表
	private $table_u_node		= "flow_flow_u_node";
	//工作表单数据表
	private $table_u_formdata	= "flow_flow_u_formdata";
	//事件表
	private $table_u_event		= "flow_flow_u_event";
	//委托表
	private $table_u_entrust	= "flow_flow_u_entrust";
	
	function __construct(){
		
	}
	
	function __destruct(){
		
	}
	
	function actionList(){
		global $CNOA_SESSION;
		
		$task = getPar($_GET, 'task', getPar($_POST, 'task'));

		if($task == "loadPage"){
			//载入页面
			$this->_loadPage();
		}elseif($task == "getMyFlowJsonData"){
			//获取我的流程列表(所有我发起的流程)
			$this->_getMyFlowJsonData();
		}elseif($task == "show_loadFlowInfo"){
			$this->_show_loadFlowInfo();
		}
	}
	
	private function _loadPage(){
		global $CNOA_SESSION, $CNOA_CONTROLLER;
		
		$from = getPar($_GET, "from", "");
		
		if($from == "list"){
			$GLOBALS['lid'] = getPar($_GET, "lid", 0);
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/table/list.htm';
		}elseif ($from == "view"){
			$GLOBALS['ulid'] = getPar($_GET, "ulid", 0);
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/table/view.htm';
		}

		$CNOA_CONTROLLER->loadExtraTpl($tplPath);
		exit;
	}
	
	private function _getMyFlowJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$start 	= getPar($_POST, 'start', 0);
		$rows  	= 15;
		$lid	= intval(getPar($_GET, 'lid', 0));

		$where = "WHERE `lid`='{$lid}' AND 1";

		
		//查询相关工作流信息
		$where .= $this->__findFlowInfo();
		
		$order = "ORDER BY `posttime` DESC LIMIT {$start}, {$rows} ";
		
		$dbList = $CNOA_DB->db_select("*", $this->table_u_list, $where . $order);
		!is_array($dbList) && $dbList=array();
		
		foreach ($dbList AS $k=>$v){
			//发布时间
			$dbList[$k]['posttime'] = date("Y-m-d H:i", $v['posttime']);
		}
		
		$dataStore = new dataStore();
		$dataStore->total = $CNOA_DB->db_getcount($this->table_u_list, $where);
		$dataStore->data = $dbList;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function __findFlowInfo(){
		$name	= getPar($_POST, 'name');
		$title	= getPar($_POST, 'title');
		$stime	= getPar($_POST, 'beginTime');
		$etime	= getPar($_POST, 'endTime');
		$uid	= getPar($_POST, 'buildUser');
		
		$s = '';
		
		//unode可以查询ulist数据 
		
	//cnoa_flow_flow_u_list表下数据 
		if(!empty($uid)){
			$s .= " AND `uid`={$uid}";
		}
		if(!empty($name)){ //编号
			$s .= " AND `name` LIKE '%{$name}%'";
		}
		if(!empty($title)){ //标题
			$s .= " AND `title` LIKE '%{$title}%'";
		}
		if(!empty($stime) && empty($etime)){
			$stime = strtotime($stime . " 00:00:00");
			$s .= " AND `posttime` >= {$stime}";
		}		
		if(!empty($etime) && empty($stime)){
			$etime = strtotime($etime . " 23:59:59");
			$s .= " AND `posttime` <= {$etime}";
		}
		if(!empty($stime) && !empty($etime)){
			//在开始与结束时间之间的信息
			$stime = strtotime($stime . " 00:00:00");
			$etime = strtotime($etime . " 23:59:59");
			
			if($stime > $etime){
				msg::callBack(false, "查询开始时间不能大于结束时间");
			}else{
				$s .= " AND `posttime` > {$stime} AND `posttime` < {$etime}";
			}
		}
		
		return " $s ";
	}
	
	private function _show_loadFlowInfo(){
		app::loadApp("flow", "flowUser")->api_show_loadFlowInfo();
	}
}
?>