<?php
/**
 * cnoa framework
 *
 * @package		cnoa
 * @author		cnoa Dev Team & Linxiaoqing
 * @email		linxiaoqing@live.com
 * @copyright	Copyright (c) 2011, cnoa, Inc.
 * @license		http://cnoa.com/user_guide/license.html
 * @since		Version 1.4.0
 * @filesource
 */
/**
 * 内部调用专用模块
 * 供 flowFlow.class.php -> actionUser() 调用
 * @author Administrator
TRUNCATE TABLE `cnoa_flow_flow_u_event`;
TRUNCATE TABLE `cnoa_flow_flow_u_formdata`;
TRUNCATE TABLE `cnoa_flow_flow_u_list`;
TRUNCATE TABLE `cnoa_flow_flow_u_node`;
 *
 */ 

class flowFlowUser extends flowCommon{
	//流程分类表
	private $table_sort			= "flow_flow_sort";
	
	//流程分类查看对照表
	private $table_dept_sort	= "flow_flow_dept_sort";
	//流程表
	private $table_list			= "flow_flow_list";
	//流程节点表
	private $table_list_node	= "flow_flow_list_node";
	//流程表单表
	private $table_form			= "flow_flow_form";
	//流程表单表单列表表
	private $table_form_item	= "flow_flow_form_item";
	//流程列表
	private $table_u_list		= "flow_flow_u_list";
	//流程节点表
	private $table_u_node		= "flow_flow_u_node";
	//工作表单数据表
	private $table_u_formdata	= "flow_flow_u_formdata";
	//事件表
	private $table_u_event		= "flow_flow_u_event";
	//委托表
	private $table_u_entrust	= "flow_flow_u_entrust";
	//会签表
	private $table_u_huiqian	= "flow_flow_u_huiqian";
	
	//事件类型(不可修改)
	//1:开始 2:已处理 3:撤销 4:召回 5:退回 6:退回上一步 7:结束
	private $eventType			= array(1=>"开始",2=>"已办理",3=>"撤销",4=>"召回",5=>"退件",6=>"退回上一步",7=>"结束");
	
	//状态说明
	private $statusType			= array(1=>"办理中", 2=>"已办理", 3=>"退件");
	
	//委托人状态说明
	private $entrustType		= array(0=>"禁用", 1=>"启用", 2=>"未设置");
	
	private $viewUrl			= 'index.php?app=flow&func=flow&action=user&task=loadPage&from=viewflow&ulid=';
	private $viewUrlCommonFlow	= 'index.php?app=flow&func=flow&action=user&module=commonFlow&task=loadPage&from=viewflow&ulid=';
	
	//缓存路径
	private $cachePath			= "";
	
	public function __construct(){
		$this->cachePath = CNOA_PATH_FILE . "/cache";
	}
	
	public function run(){
		global $CNOA_SESSION;
		
		$task = getPar($_GET, 'task', getPar($_POST, 'task'));
		
		/* 总: 杂 + 发起申请 */
		if($task == "loadPage"){
			//载入页面
			$this->_loadPage();
		}elseif($task == "getSortList"){
			//获取分类列表(tree)
			$this->_getSortList();
		}elseif($task == "getFlowJsonData"){
			//
			$this->_getFlowJsonData();
		}elseif($task == "getFlowJsonDataForout"){
			//
			$this->_getFlowJsonDataForout();
		}elseif($task == "flowpreviewLoadData"){
			//
			$this->_flowpreviewLoadData();
		}elseif($task == "loadFormData"){
			//根据表单ID载入表单(空白)
			$this->_loadFormData();
		}elseif($task == "loadFormData2"){
			//新建设流程时载入表单数据
			//根据表单ID载入表单(包含了表单各种状态)
			$this->_loadFormData2();
		}elseif($task == "loadNextStepInfo"){
			//获取下一步数据
			$this->_loadNextStepInfo();
		}elseif($task == "sendFlow"){
			//发送流程
			$this->_sendFlow();
		}elseif($task == "saveFlow_add"){
			$this->_saveFlow_add();
		}elseif($task == "saveFlow_edit"){
			$this->_saveFlow_edit();
		}elseif($task == "deleteflow"){
			$this->_deleteflow();
		}
		
		/* 我的流程 */
		elseif($task == "getMyFlowJsonData"){
			//获取我的流程列表(所有我发起的流程)
			$this->_getMyFlowJsonData();
		}elseif($task == "recall"){
			//召回流程
			$this->_recall();
		}elseif($task == "repeal"){
			//撤销流程
			$this->_repeal();
		}
		
		/* 审批流程 */
		elseif($task == "getdealflowJsonData"){
			//获取审批流程列表(所有和我相关的流程)
			$this->_getdealflowJsonData();
		}elseif($task == "deal_loadNextStepInfo"){
			//获取下一步数据
			$this->_deal_loadNextStepInfo();
		}elseif($task == "deal_sendFlow"){
			//提交给下一步
			$this->_deal_sendFlow();
		}elseif($task == "disagree"){
			//不同意(退件)
			$this->_disagree();
		}elseif($task == "gotoPrevstep"){
			//退回上一步
			$this->_gotoPrevstep();
		}elseif($task == "show_loadFlowInfo"){
			//办理流程时载入数据
			$this->_show_loadFlowInfo();
		}
		
		/* 委托流程 */
		elseif($task == "getEntrustJsonData"){
			//获取委托人列表
			$this->_getEntrustJsonData();
		}elseif($task == "getAllUserListsInPermitDeptTree"){
			//设置委托人时的人员选择
			$this->_getAllUserListsInPermitDeptTree();
		}elseif($task == "setEntrust"){
			//设置委托人时的人员选择
			$this->_setEntrust();
		}elseif($task == "editEntrustLoadForm"){
			//设置委托人时form载入数据
			$this->_editEntrustLoadForm();
		}
		
		/* 查看流程 */
		elseif($task == "view_loadFlowInfo"){
			//获取流程信息: 基本信息/表单内容/表单数据/流程进度/事件日志
			$this->_view_loadFlowInfo();
		}elseif($task == "getEventList"){
			$this->_getEventList();
		}elseif($task == "getProgressList"){
			$this->_getProgressList();
		}
		
		/* 导出流程列表 */
		elseif($task == "exportExcel"){
			$this->_exportExcel();
		}
		
		/* 导出流程内容 */
		elseif($task == "exportFlow"){
			app::loadApp("flow", "flowExportHtml")->init();
		}
		
		/* 分发流程 */
		elseif($task == "dispenseFlow"){
			$this->_dispenseFlow();
		}/* 分发流程 */
		elseif($task == "getDispenseJsonData"){
			$this->_getDispenseJsonData();
		}
		/* 查看分发流程 */
		elseif($task == "show_loadDispenseFlowInfo"){
			$this->_show_loadDispenseFlowInfo();
		}
		
		/* 查看已阅流程记录 */
		elseif($task == "getReaderList"){
			$this->_getReaderList();
		}
		
		/* 发布评阅记录 */
		elseif($task == "addDispenseSay"){
			$this->_addDispenseSay();
		}
		
		/* 会签 */
		#载入会签列表
		elseif($task == "getHuiQianInfo"){
			$this->_getHuiQianInfo();
		}
		#设置会签列表
		elseif($task == "setHuiQianInfo"){
			$this->_setHuiQianInfo();
		}
		#载入会签意见以供编辑
		elseif($task == "loadHuiQianInfo"){
			$this->_loadHuiQianInfo();
		}
		#提交会签意见
		elseif($task == "submitHuiQianInfo"){
			$this->_submitHuiQianInfo();
		}
		
		/*转办*/
		#设置转办
		elseif($task == "setZhuangbanInfo"){
			$this->_setZhuangbanInfo();
		}
		
		/*表单自动保存*/
		elseif ($task == "getAutoSaveFormData"){
			$this->_getAutoSaveFormData();
		}
		elseif ($task == "setAutoSaveFormData"){
			$this->_setAutoSaveFormData();
		}
		
		elseif($task == "getFlowFrom"){
			$this->_getFlowFrom();
		}
		
		elseif ($task == "sendNewFlowList"){
			$this->_sendNewFlowList();
		}
	}
	
	
	/**
	 * 流程所属
	 * Enter description here ...
	 */
	private function _getFlowFrom(){
		$_GET['type']	= 'combo';
		app::loadApp("flow", "flow")->api_getSortList();
	}
	
	
	
	/************************* ∨总程序∨ **********************/
	private function _loadPage(){
		global $CNOA_SESSION, $CNOA_CONTROLLER;
		
		$from = getPar($_GET, "from", "");
		
		if($from == "flowlist"){
			//载入流程列表页
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_flowlist.htm';
		}elseif ($from == "flowlistOut"){
			$GLOBALS['sort'] = getPar($_GET, "sort", 0);
			//载入流程列表页[从外部点击进来的(人事申请等)]
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_flowlistOut.htm';
		}elseif ($from == "newflow"){
			//载入新建工作流程页面
			$this->_loadNewFlowPage();
		}elseif ($from == "newcommonflow"){
			//载入新建通用工作流程页面
			$this->_loadNewCommonFlowPage();
		}elseif ($from == "myflow"){
			//载入表单设计汇总页面
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_myflow.htm';
		}elseif ($from == "entrust"){
			//载入表单设计汇总页面
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_entrust.htm';
		}elseif ($from == "dealflow"){
			//载入流程分类汇总页面
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_dealflow.htm';
		}elseif ($from == "viewflow"){
			//载入流程查看页面(看+操作)
			$GLOBALS['ulid'] = getPar($_GET, "ulid", 0);
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_viewflow.htm';
		}elseif ($from == "showflow"){
			//载入流程查看页面(只看)
			$GLOBALS['ulid'] = getPar($_GET, "ulid", 0);
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_showflow.htm';
		}elseif ($from == "dispense"){
			//载入分发流程列表页
			$GLOBALS['isread'] = getPar($_GET, "isread", 0);
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/dispense_list.htm';
		}elseif ($from == "showdispenseflow"){
			//载入分发流程列表页
			$GLOBALS['ulid'] = getPar($_GET, "ulid", 0);
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/dispense_view.htm';
		}
		
		$CNOA_CONTROLLER->loadExtraTpl($tplPath);
		exit;
	}
	
	private function _getSortList(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  	= $CNOA_SESSION->get("UID");
		
		$type	= getPar($_GET, "type", "combo");
		$myJobType = $CNOA_SESSION->get("JOBTYPE");
		
		$dblist = $CNOA_DB->db_select("*", $this->table_sort, "WHERE 1 ORDER BY `order` ASC");
		
		!is_array($dblist) && $dblist = array();
		
		if($type == "tree"){
			$list = array();
			foreach ($dblist as $v) {
				$r = array();
				$r['text']	= $v['name'];
				$r['sid']	= $v['sid'];
				$r['iconCls']	= "icon-style-page-key";
				$r['leaf']	= true;
				$r['href']	= "javascript:void(0);";
				//if($this->_private_sortAllow($r['sid'])){
				$list[]	= $r;
				//}
			}
			echo json_encode($list);
			exit;
		}elseif($type == 'combo'){
			$dataStore = new dataStore();
			$dataStore->total = count($dblist);
			$dataStore->data = $dblist;
			
			echo $dataStore->makeJsonData();
			exit;
		}
	}
	
	private function _getFlowJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$start 	= getPar($_POST, 'start', 0);
		$rows  	= 15;
		$sort	= intval(getPar($_POST, 'sort', 0));
		$myJobType = $CNOA_SESSION->get("JOBTYPE");
		
		if($sort == 0){
			$where = "WHERE `publish`=1 ";
		}else{
			$where = "WHERE `publish`=1 AND `sort`='{$sort}' ";
		}
		/*
		if($myJobType == "superAdmin"){
			if($sort == 0){
				$where = "WHERE `publish`=1 ";
			}else{
				$where = "WHERE `publish`=1 AND `sort`='{$sort}' ";
			}
		}else{
			if($sort == 0){
				$deptId	= $CNOA_DB->db_getone("*","main_user","WHERE `uid` = '{$uid}'");
			
				$ssid	= $CNOA_DB->db_select("*",$this->table_dept_sort,"WHERE `deptId` = '{$deptId['deptId']}'");
				
				$sids = array(0);
				foreach ($ssid as $v){
					$sids[] = $v['sid'];
					
				}
				$where = "WHERE `sort` IN (".implode(",", $sids).") ";
				//$dblist = $CNOA_DB->db_select("*", $this->table_sort, "WHERE `sid` IN (".implode(",", $sids).") ORDER BY `order` ASC");
				//$where = "WHERE `publish`=1 ";
			}else{
				$where = "WHERE `publish`=1 AND `sort`='{$sort}' ";
			}
		}
		*/
		$sql = 'SELECT  `l`.`name`, `l`.`lid`, `l`.`formid`, `s`.`name` AS `sname` ' .
			   'FROM '. tname($this->table_list) . " AS `l` " .
			   'LEFT JOIN ' . tname($this->table_sort) . " AS `s` ON `l`.`sort`=`s`.`sid` " .
			   $where . 
			   'ORDER BY `posttime` DESC '.
			   "LIMIT {$start}, {$rows}";

		$dblist = array();
		$formids = array();
		$queryList = $CNOA_DB->query($sql);
		while ($list = $CNOA_DB->get_array($queryList)) {
			$list['posttime'] 	= date("Y-m-d H:i", $list['posttime']);
			$formids[$list['lid']] = $list['formid'];
			$dblist[] = $list;
		}
		
		$dataStore = new dataStore();
		$dataStore->total = $CNOA_DB->db_getcount($this->table_list, $where);
		$dataStore->data = $dblist;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _getFlowJsonDataForout(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$sort	= intval(getPar($_GET, 'sort', 0));

		$where = "WHERE `publish`=1 AND `sort`='{$sort}' ";
		
		$sql = 'SELECT  `l`.`name`, `l`.`lid`, `l`.`formid`, `s`.`name` AS `sname` ' .
			   'FROM '. tname($this->table_list) . " AS `l` " .
			   'LEFT JOIN ' . tname($this->table_sort) . " AS `s` ON `l`.`sort`=`s`.`sid` " .
			   $where . 
			   'ORDER BY `posttime` DESC ';

		$dblist = array();
		$formids = array();
		$queryList = $CNOA_DB->query($sql);
		while ($list = $CNOA_DB->get_array($queryList)) {
			$list['posttime'] 	= date("Y-m-d H:i", $list['posttime']);
			$formids[$list['lid']] = $list['formid'];
			$dblist[] = $list;
		}
		
		$dataStore = new dataStore();
		$dataStore->total = $CNOA_DB->db_getcount($this->table_list, $where);
		$dataStore->data = $dblist;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _flowpreviewLoadData(){
		app::loadApp("flow", "flow")->api_flowpreviewLoadData();
	}
	
	private function _loadFormData(){
		app::loadApp("flow", "flow")->api_loadFormData();
	}
	
	private function _loadFormData2(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$fid = getPar($_POST, "fid", 0);
		$lid = getPar($_POST, "lid", 0);
		
		//获取表单内容数据提供给前台用
		$cacheForm		= $this->cachePath . "/flow/flow/form/".$fid.".php";
		@include $cacheForm;
		
		$cacheFormItems	= $this->cachePath . "/flow/flow/formItems/".$fid.".php";
		@include $cacheFormItems;
		
		//获取表单可用不可用数据
		$itemsInfo = $CNOA_DB->db_getfield("formitems", $this->table_list_node, "WHERE `lid`='{$lid}' AND `stepid`=0");
		$itemsInfo = json_decode($itemsInfo, true);
		
		$content = app::loadApp("flow", "flowCommon")->api_parseFormForNewFlow($GLOBALS['flowFormHtml'], $itemsInfo, $GLOBALS['flowFormItems']);
		
		$array = array();
		$array['content'] = $content;
		$dataStore = new dataStore();
		$dataStore->data = $array;

		echo $dataStore->makeJsonData();
		exit;
	}
	/************************* ∧总程序∧ **********************/
	
	/************************* ∨总程序∨ **********************/
	private function _loadNewFlowPage(){
		global $CNOA_DB, $CNOA_SESSION, $CNOA_CONTROLLER;
		
		$uid  	= $CNOA_SESSION->get("UID");
		$sid  	= $CNOA_SESSION->get("SID");
		$lid	= getPar($_GET, "lid", 0);
		$ulid	= getPar($_GET, "ulid", 0);
		$GLOBALS['ac']			= getPar($_GET, "ac", "add");
		
		if($GLOBALS['ac'] == "edit"){
			$uflowInfo 	= $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `uid`='{$uid}' AND `ulid`='{$ulid}'");
			$lid		= $uflowInfo['lid']; 
		}
		
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_list, "WHERE `lid`='{$lid}'");
		
		//检查流程所在的表单完整性
		$GLOBALS['formready'] = "yes";
		if(!$this->__checkForm($flowInfo['formid'])){
			$GLOBALS['formready'] = "no";
		}

		$GLOBALS['havePermit']	= $this->__isUidInStep($uid, $lid, 0);

		$GLOBALS['lid']			= $lid;
		$GLOBALS['ulid']		= $ulid;
		$GLOBALS['fid']			= $flowInfo['formid'];
		$GLOBALS['havePermit']  = $GLOBALS['havePermit'] ? 1 : 0;
		
		//获取附件上传权限
		$GLOBALS['allowup']		= $CNOA_DB->db_getfield("allowup", $this->table_list_node, "WHERE `lid`='{$lid}' AND `stepid`='0'");
		
		if($GLOBALS['ac'] == "edit"){
			$GLOBALS['flowName']	= $uflowInfo['flowname'];
			$GLOBALS['flowNumber']	= $uflowInfo['name'];
			$GLOBALS['title']		= $uflowInfo['title'];
			$GLOBALS['level']		= $uflowInfo['level'];
			$GLOBALS['reason']		= substr(json_encode(str_replace("'", "\"", $uflowInfo['reason'])), 1, -1);
			$GLOBALS['about']		= str_replace("'", "\"", $uflowInfo['about']);
			
			//获取表单数据
			$formData = $CNOA_DB->db_select("*", $this->table_u_formdata, "WHERE `ulid`='{$ulid}'");
			$GLOBALS['formData'] = json_encode($formData);
			
			//获取附件信息
			$fs = new fs();
			$GLOBALS['attach'] = json_encode($fs->getEditList(json_decode($uflowInfo['attach'], true)));
			//系统操作日志
			$name = $CNOA_DB->db_getfield('name', $this->table_u_list, "WHERE `ulid`='{$ulid}'");
			app::loadApp('main', 'systemLogs')->api_addLogs('update', 73, "流程（{$name}）");
		}else{
			$GLOBALS['level']		= 1;
			$GLOBALS['flowName']	= $flowInfo['name'];
			$GLOBALS['flowNumber']	= $flowInfo['number'];
			$GLOBALS['formData'] = "null";
			$GLOBALS['attach'] = json_encode(array());
			//系统操作日志
			$name = $CNOA_DB->db_getfield('name', $this->table_u_list, "WHERE `ulid`='{$ulid}'");
			app::loadApp('main', 'systemLogs')->api_addLogs('add', 73, "流程（{$name}）");
		}
		
		$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_newflow.htm';
		$CNOA_CONTROLLER->loadExtraTpl($tplPath);
		exit;
	}
	
	private function _loadNewCommonFlowPage(){
		global $CNOA_DB, $CNOA_SESSION, $CNOA_CONTROLLER;
		$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/user_newcommonflow.htm';
		$CNOA_CONTROLLER->loadExtraTpl($tplPath);
		exit;
	}
	
	private function _saveFlow_add(){
		global $CNOA_DB, $CNOA_SESSION;

		$uid	= $CNOA_SESSION->get("UID");
		$lid	= getPar($_POST, "lid", 0);
		$data	= array();
		$data['lid']		= $lid;
		$data['title']		= getPar($_POST, "title", "");
		$data['level']		= getPar($_POST, "level", 1);
		$data['reason']		= getPar($_POST, "reason", "", 1);
		$data['about']		= getPar($_POST, "about", "", 1);
		$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['uid']		= $uid;
		//status : -1:已删除  0:未发布  1:办理中  2:已办理  3:已退件  4:已撤销
		$data['status']		= 0;
		
		//取得流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_list, "WHERE `lid`='{$lid}'");
		$data['flowname']	= $flowInfo['name'];
		$data['name']		= str_replace("{F}", $flowInfo['name'], $flowInfo['number']);
		$data['sort']		= $flowInfo['sort'];

		//处理附件
		$fs = new fs();
		$filesUpload = getPar($_POST, "filesUpload", array());
		$attch = $fs->add($filesUpload, 7);
		$data['attach'] = json_encode($attch);
		
		$ulid = $CNOA_DB->db_insert($data, $this->table_u_list);
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('add', 73, $data['title'], '流程');
		//保存表单数据
		foreach ($_POST['FLOWDATA'] AS $k=>$v){
			$item = array();
			$item['ulid']	= $ulid;
			$item['itemid']	= $k;
			$item['uid']	= $uid;
			$item['step']	= 0;
			$item['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
			$item['data']	= getPar($_POST['FLOWDATA'], $k, "", 1);
			$CNOA_DB->db_insert($item, $this->table_u_formdata);
		}
		
		header('Content-type: text/html');
		
		
		msg::callBack(true, "操作成功");
	}
	
	private function _saveFlow_edit(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		$lid	= getPar($_POST, "lid", 0);
		$ulid	= getPar($_POST, "ulid", 0);
		$data	= array();
		$data['lid']		= $lid;
		$data['title']		= getPar($_POST, "title", "");
		$data['level']		= getPar($_POST, "level", 1);
		$data['reason']		= getPar($_POST, "reason", "", 1);
		$data['about']		= getPar($_POST, "about", "", 1);
		$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['uid']		= $uid;
		//status : -1:已删除  0:未发布  1:办理中  2:已办理  3:已退件  4:已撤销
		$data['status']		= 0;
		
		//取得流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_list, "WHERE `lid`='{$lid}'");
		$data['flowname']	= $flowInfo['name'];
		$data['name']		= str_replace("{F}", $flowInfo['name'], $flowInfo['number']);
		$data['sort']		= $flowInfo['sort'];
		
		//处理附件
		$fs = new fs();
		$attach = $CNOA_DB->db_getfield("attach", $this->table_u_list, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}'");
		$attch = $fs->edit(getPar($_POST, "filesUpload", array()), json_decode($attach, false), 7);
		$data['attach'] = json_encode($attch);

		$CNOA_DB->db_update($data, $this->table_u_list, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}'");
		
		//保存表单数据
		$CNOA_DB->db_delete($this->table_u_formdata, "WHERE `ulid`='{$ulid}'");
		
		//保存表单数据
		foreach ($_POST['FLOWDATA'] AS $k=>$v){
			$item = array();
			$item['ulid']	= $ulid;
			$item['itemid']	= $k;
			$item['data']	= getPar($_POST['FLOWDATA'], $k, "", 1);
			$item['uid']	= $uid;
			$item['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
			$item['step']	= 0;
			$CNOA_DB->db_insert($item, $this->table_u_formdata);
		}
		
		header('Content-type: text/html');
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('update', 73, $data['title'], '流程');
		msg::callBack(true, "操作成功");
	}
	
	/**
	 * 获取下一步骤信息(新建/编辑时)
	 */
	private function _loadNextStepInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$flowid = getPar($_POST, "flowid", 0);
		$stepid = intval(getPar($_POST, "stepid", 0));
		$nextstep = $stepid+1;

		$nextInfo = $CNOA_DB->db_getone(array("name", "operatorperson", "operatortype", "operator", "type"), $this->table_list_node, "WHERE `lid`='{$flowid}' AND `stepid`='{$nextstep}'");
		
		//下一步骤所有人UID
		$nextMans = $this->__getAllUidsInStep($flowid, $nextstep);
		$nextUids = $nextMans['uid'];
		
		$userList = app::loadApp("main", "user")->api_getUserInfoByUids($nextUids);
		$stationList = app::loadApp("main", "station")->api_getStationList();
		!is_array($userList) && $userList=array();
		!is_array($stationList) && $stationList=array();
		
		if($nextInfo['type'] == "end"){
			$nextInfo['nextStepType'] = "end";
		}
		
		$users = array();
		foreach ($userList AS $v){
			$station = $stationList[intval($v['stationid'])]['name'] == NULL ? "" : " (" . $stationList[intval($v['stationid'])]['name'] . ")";
			
			$u = array();
			$u['uid']	= $v['uid'];
			$u['name']	= $v['truename'] . $station;
			$users[] = $u;
		}
		
		$nextInfo['operator'] = $users;
		
		$dataStore = new dataStore();
		$dataStore->data = $nextInfo;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	
	//新建流程之发送流程(转一下步)
	private function _sendFlow(){
		global $CNOA_DB, $CNOA_SESSION;
		
		//dbug::xprint($_POST);msg::callBack(false, 33);
		
		$flowName = "";
		$uid	= $CNOA_SESSION->get("UID");
		$lid	= getPar($_POST, "lid", 0);
		$ulid	= intval(getPar($_POST, "ulid", 0));
		$data	= array();
		
		$data['lid']		= $lid;
		$data['title']		= getPar($_POST, "title", "");
		$data['level']		= getPar($_POST, "level", 1);
		$data['reason']		= getPar($_POST, "reason", "", 1);
		$data['about']		= getPar($_POST, "about", "", 1);
		$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['uid']		= $uid;
		$data['step']		= 1;
		//status : -1:已删除  0:未发布  1:办理中  2:已办理  3:已退件  4:已撤销
		$data['status']		= 1;
		$reason				= $data['reason'];
		
		//这里加入流程扫描功能，扫描流程是否能完整执行下去(每一个节点都确保至少有一个经办人)
		$this->__checkFlow($lid);
		
		//判断ulid是否已经存在(如果存在，则是通过编辑发送;如果不存在，则是通过新建发送)
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_list, "WHERE `lid`='{$lid}'");
		
		$data['flowname']	= $flowInfo['name'];
		$data['name']		= $flowName = $this->__getNumber($lid);
		$data['sort']		= $flowInfo['sort'];
		
		//获取表单可用不可用数据
		$itemsInfo = $CNOA_DB->db_getfield("formitems", $this->table_list_node, "WHERE `lid`='{$lid}' AND `stepid`=0");
		$itemsInfo = json_decode($itemsInfo, true);
		!is_array($itemsInfo) && $itemsInfo=array();
		$itemsInfoData = array();
		foreach($itemsInfo AS $itemsInfok=>$itemsInfov){
			$itemsInfoData[$itemsInfov['itemid']] = $itemsInfov;
		}
		
		//获取下一步骤节点信息
		$nextItemsInfo = $CNOA_DB->db_getone("*", $this->table_list_node, "WHERE `lid`='{$lid}' AND `stepid`=1");

		if($nextItemsInfo['type'] == 'end'){
			$data['status']		= 2;
		}
		
		if($ulid == 0){
			//处理附件
			$fs = new fs();	
			$filesUpload = getPar($_POST, "filesUpload", array());
			$attch = $fs->add($filesUpload, 7);
			$data['attach'] = json_encode($attch);
			
			$ulid = $CNOA_DB->db_insert($data, $this->table_u_list);
			
			//保存表单数据
			!is_array($_POST['FLOWDATA']) && $_POST['FLOWDATA']=array();
			foreach ($_POST['FLOWDATA'] AS $k=>$v){
				$item = array();
				$item['ulid']	= $ulid;
				$item['itemid']	= $k;
				$item['data']	= getPar($_POST['FLOWDATA'], $k, "", 1);
				$item['uid']	= $uid;
				$item['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
				$item['step']	= 0;
				if(($itemsInfoData[$item['itemid']]['need'] == 1) || ($itemsInfoData[$item['itemid']]['used'] == 1)){
					$CNOA_DB->db_insert($item, $this->table_u_formdata);
				}
			}
		}else{
			//处理附件
			$fs = new fs();
			$attach = $CNOA_DB->db_getfield("attach", $this->table_u_list, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}'");
			$attch = $fs->edit(getPar($_POST, "filesUpload", array()), json_decode($attach, false), 7);
			$data['attach'] = json_encode($attch);
			
			$CNOA_DB->db_update($data, $this->table_u_list, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}'");
			
			//保存表单数据
			$CNOA_DB->db_delete($this->table_u_formdata, "WHERE `ulid`='{$ulid}'");
			!is_array($_POST['FLOWDATA']) && $_POST['FLOWDATA'] = array();
			foreach ($_POST['FLOWDATA'] AS $k=>$v){
				$item = array();
				$item['ulid']	= $ulid;
				$item['itemid']	= $k;
				$item['data']	= getPar($_POST['FLOWDATA'], $k, "", 1);
				$item['uid']	= $uid;
				$item['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
				$item['step']	= 0;
				if(($itemsInfoData[$item['itemid']]['need'] == 1) || ($itemsInfoData[$item['itemid']]['used'] == 1)){
					$CNOA_DB->db_insert($item, $this->table_u_formdata);
				}
			}
		}
		
		$cachePath	= $this->cachePath . "/flow/user/{$ulid}/";
		@mkdirs($cachePath);
		$cacheFile = array();
		
		//缓存 - 复制主流程
		$cacheFile['flow']		= $cachePath . "flow.php";
		$cacheData['flow']		= $flowInfo;
		file_put_contents($cacheFile['flow'], "\r\nreturn ".var_export($cacheData['flow'], true).";");
		
		//缓存 - 复制主流程节点数据
		$cacheFile['flow_node']	= $cachePath . "flow_node.php";
		$cacheData['flow_node']	= $CNOA_DB->db_select("*", $this->table_list_node, "WHERE `lid`='{$lid}' ORDER BY `stepid` ASC");
		file_put_contents($cacheFile['flow_node'], "<?php\r\nreturn ".var_export($cacheData['flow_node'], true).";");
		
		//缓存 - 复制表单
		$cacheFile['form']		= $cachePath . "form.php";
		@include $this->cachePath . "/flow/flow/form/".$flowInfo['formid'].".php";
		$cacheData['form']		= $GLOBALS['flowFormHtml'];
		file_put_contents($cacheFile['form'], "<?php\r\nreturn ".var_export($cacheData['form'], true).";");
		
		//缓存 - 复制表单数据
		$cacheFile['form_item']	= $cachePath . "form_item.php";
		@include $this->cachePath . "/flow/flow/formItems/".$flowInfo['formid'].".php";
		$cacheData['form_item']	= $GLOBALS['flowFormItems'];
		file_put_contents($cacheFile['form_item'], "<?php\r\nreturn ".var_export($cacheData['form_item'], true).";");
		
		//处理系统宏控件
		!is_array($GLOBALS['flowFormItems']) && $GLOBALS['flowFormItems']=array();
		foreach($GLOBALS['flowFormItems'] AS $itv){
			$item = array();
			$item['ulid']	= $ulid;
			$item['itemid']	= $itv['itemid'];
			$item['uid']	= $uid;
			$item['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
			$item['step']	= 0;
			if($itv['type'] == 'SYS_FLOWTITLE'){
				$item['data']	= $data['title'];
				$CNOA_DB->db_insert($item, $this->table_u_formdata);
			}
			if($itv['type'] == 'SYS_FLOWNAME'){
				$item['data']	= $data['name'];
				$CNOA_DB->db_insert($item, $this->table_u_formdata);
			}
		}
		
		//添加事件
		$this->__eventAdd($ulid, 1, 0, $cacheData['flow_node'][0]['name'], $reason);
		
		//生成本节点(提供给流程进度查询用)
		unset($data);$data = array();
		$data['ulid']			= $ulid;
		$data['stepid']			= 0;
		$data['say']			= $reason;
		$data['status']			= 2;
		$data['nodename']		= $cacheData['flow_node'][0]['name'];
		$data['stime']			= $GLOBALS['CNOA_TIMESTAMP'];
		$data['uid']			= $uid;
		$data['operatortype']	= 1;
		$data['attachdown']		= $cacheData['flow_node'][0]['allowdown'];
		$data['attachup']		= $cacheData['flow_node'][0]['allowup'];
		$data['sponsor']		= 1;
		$CNOA_DB->db_insert($data, $this->table_u_node);
		
		if($nextItemsInfo['type'] != 'end'){
			//生成下一步节点信息
			/*
			ulid			流程ID
			stepid			步骤ID
			uid				当前步骤经办人UID
			status			状态
			nodename		节点名称
			stime			开始时间
			etime			结束时间
			operatortype	办理类型
			attachdown		是否允许下载附件
			attachup		是否允许上传附件
			say				
			sponsor			是否是主办人
			*/
			unset($data);$data = array();
			$nextUids = explode(",", getPar($_POST, "nextUids", ""));
			$data['ulid']			= $ulid;
			$data['stepid']			= 1;
			$data['status']			= 1;
			$data['nodename']		= $cacheData['flow_node'][$data['stepid']]['name'];
			$data['stime']			= $GLOBALS['CNOA_TIMESTAMP'];
			//$data['etime']			= $ulid;
			$data['operatortype']	= $cacheData['flow_node'][$data['stepid']]['operatortype'];
			$data['attachdown']		= $cacheData['flow_node'][$data['stepid']]['allowdown'];
			$data['attachup']		= $cacheData['flow_node'][$data['stepid']]['allowup'];
			$data['sponsor']		= 1;
			foreach($nextUids AS $v){
				$data['uid']		= $v;
				
				$noticeT = "工作流管理";
				$noticeC = "你有一个工作需要审批, [" . $flowName. "]";
				$noticeH = $this->viewUrl . $ulid;
				$data['noticeid_c'] = notice::add($v, $noticeT, $noticeC, $noticeH, 0, 5);
				
				$notice['touid']	= $v;
				$notice['from']		= 5;
				$notice['fromid']	= 0;
				$notice['href']		= $noticeH;
				$notice['title']	= $noticeC;
				$notice['content']	= "";
				$notice['funname']	= "工作流管理";
				$notice['move']		= "审批";
				
				$data['todoid_c'] = notice::add2($notice);
				$CNOA_DB->db_insert($data, $this->table_u_node);
				$data['sponsor']	= 0;
				
				//使用手机短信审批
				if($cacheData['flow_node'][$data['stepid']]['smsdeal'] == '1'){
					$this->sendSmsDeal($ulid, $flowName, $v, $reason);
				}
			}
		}
		//清空自动保存的数据
		$this->__clearAutoSaveFormData($lid);
		msg::callBack(true, "操作成功");
	}
	
	private function _deleteflow(){
		
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$ulid = getPar($_POST, "ulid", 0);
		
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}'");
		if($flowInfo == false){
			msg::callBack(false, "没有这条数据");
		}
		
		//从主表删除
		$CNOA_DB->db_delete($this->table_u_list, "WHERE `ulid`='{$ulid}'");
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('del', 74, $flowInfo['name'], "删除流程");
		
		//从节点表删除
		$CNOA_DB->db_delete($this->table_u_node, "WHERE `ulid`='{$ulid}'");
		
		//从表单表删除
		$CNOA_DB->db_delete($this->table_u_formdata, "WHERE `ulid`='{$ulid}'");
		
		//从日志表删除
		$CNOA_DB->db_delete($this->table_u_event, "WHERE `ulid`='{$ulid}'");
		
		//从缓存删除
		$cachePath	= $this->cachePath . "/flow/user/{$ulid}/";
		$cacheFile  = array();
		$cacheFile['flow']		= $cachePath . "flow.php";
		$cacheFile['flow_node']	= $cachePath . "flow_node.php";
		$cacheFile['form']		= $cachePath . "form.php";
		$cacheFile['form_item']	= $cachePath . "form_item.php";
		foreach ($cacheFile AS $v){
			@unlink($v);
		}
		@rmdir($cachePath);
		
		//从附件表删除
		$fs = new fs();
		$fs->deleteFile(json_decode($flowInfo['attach'], true));
		
		msg::callBack(true, "操作成功");
	}
	
	
	/************************* ∧总程序∧ **********************/
	
	
	
	
	
	
	
	/************************* ∨我的流程∨ **********************/
	private function _getMyFlowJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$start 	= getPar($_POST, 'start', 0);
		$rows  	= 15;
		$sort	= intval(getPar($_POST, 'sort', 0));

		if($sort == 0){
			$where = "WHERE `uid`='{$uid}' ";
		}else{
			$where = "WHERE `sort`='{$sort}' AND `uid`='{$uid}'";
		}
		
		
		//查询相关工作流信息
		$where .= $this->__findFlowInfo();
		
		
		$order = "ORDER BY `posttime` DESC LIMIT {$start}, {$rows} ";
		
		$dbList = $CNOA_DB->db_select("*", $this->table_u_list, $where . $order);
		!is_array($dbList) && $dbList=array();
		
		foreach ($dbList AS $k=>$v){
			//发布时间
			$dbList[$k]['posttime'] = date("Y-m-d H:i", $v['posttime']);
			//重要等级
				if($v['level'] == 2){$dbList[$k]['level'] = "<span class='cnoa_color_orange'>重要</span>";}
			elseif($v['level'] == 3){$dbList[$k]['level'] = "<span class='cnoa_color_red'>非常重要</span>";}
			else{$dbList[$k]['level'] = "普通";}
			//当前步骤
			if($v['flowtype'] == '0'){
				if($v['status'] == 0){
					$dbList[$k]['step'] = $CNOA_DB->db_getfield("name", $this->table_list_node, "WHERE `lid`='{$v['lid']}' AND `stepid`='0'");
				}else{
					$cacheFile	= @include $this->cachePath . "/flow/user/{$v['ulid']}/" . "flow_node.php";
					$dbList[$k]['step'] = $cacheFile[$v['step']]['name'];
				}
				//状态 -1已删除 0:未发布 1:办理中 2已办理 3已退件 4已撤销
			}else if($v['flowtype'] == '1'){
				$cacheFile	= @include $this->cachePath . "/flow/user/{$v['ulid']}/" . "flow_node.php";
				$dbList[$k]['step'] = $cacheFile[$v['step']]['name'];
			}
		}
	
		$dataStore = new dataStore();
		$dataStore->total = $CNOA_DB->db_getcount($this->table_u_list, $where);
		$dataStore->data = $dbList;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _recall(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$ulid = getPar($_POST, 'ulid', 0);
		
		//获取流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}'");
		if(!$flowInfo){
			msg::callBack(false, "无此流程");
		}
		
		if($flowInfo['status'] != 1){
			msg::callBack(false, "当前流程状态不是\"处理中\"，无法召回");
		}

		//删除待办及提醒
		$stepInfo = $CNOA_DB->db_select("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}'");
		!is_array($stepInfo) && $stepInfo=array();
		foreach($stepInfo AS $stv){
			notice::deleteNotice($stv['noticeid_c'], $stv['todoid_c']);
		}

		//删除节点(表cnoa_flow_flow_u_node)
		$CNOA_DB->db_delete($this->table_u_node, "WHERE `ulid`='{$ulid}'");
		
		//获取缓存文件
		$cachePath	= $this->cachePath . "/flow/user/{$ulid}/";
		$cacheFile  = array();
		$cacheFile['flow']		= $cachePath . "flow.php";
		$cacheFile['flow_node']	= $cachePath . "flow_node.php";
		$cacheFile['form']		= $cachePath . "form.php";
		$cacheFile['form_item']	= $cachePath . "form_item.php";
		
		//删除表单数据(表cnoa_flow_flow_u_formdata中的非第一步数据)
		$flowFormDataStepData	= @include $cacheFile['flow_node'];
		$flowFormItems			= json_decode($flowFormDataStepData[0]['formitems'], true);
		!is_array($flowFormItems) && $flowFormItems=array();
		$formItems = array();
		foreach ($flowFormItems AS $v){
			if(($v['need']==1) || ($v['muse']==1)){
				$formItems[] = $v['itemid'];
			}
		}
		if(count($formItems)>0){
			$CNOA_DB->db_delete($this->table_u_formdata, "WHERE `ulid`='{$ulid}' AND `itemid` NOT IN (".implode(",", $formItems).")");
		}
		
		//删除缓存文件
		foreach ($cacheFile AS $v){
			@unlink($v);
		}
		
		//添加事件日志
		$this->__eventAdd($ulid, 4, 0, "----", "召回流程");
		
		//修改本流程状态及所处步骤
		$CNOA_DB->db_update(array("status"=>0, "step"=>0), $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('', 74, $flowInfo['name'], '召回流程');
		msg::callBack(true, "操作成功");
	}
	
	private function _repeal(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$ulid = getPar($_POST, 'ulid', 0);
		
		//获取流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}'");
		if(!$flowInfo){
			msg::callBack(false, "无此流程");
		}
		
		if($flowInfo['status'] != 1){
			msg::callBack(false, "当前流程状态不是\"处理中\"，无法撤销");
		}

		//删除待办及提醒
		$stepInfo = $CNOA_DB->db_select("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}'");
		!is_array($stepInfo) && $stepInfo=array();
		foreach($stepInfo AS $stv){
			notice::deleteNotice($stv['noticeid_c'], $stv['todoid_c']);
		}
		
		//添加事件日志
		$this->__eventAdd($ulid, 3, 0, "----", "撤销流程");
		
		//修改本流程状态及所处步骤
		$CNOA_DB->db_update(array("status"=>4), $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('', 74, $flowInfo['name'], '撤销流程');
		
		msg::callBack(true, "操作成功");
	}
	/************************* ∧我的流程∧ **********************/
	
	/************************* ∨审批流程∨ **********************/
	private function _getdealflowJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$start 	= getPar($_POST, 'start', 0);
		$rows  	= 15;
		
		//获取被委托数据
		$entrustInfo = $CNOA_DB->db_select(array("fromuid"), $this->table_u_entrust, "WHERE `touid`='{$uid}' AND `status`=1 AND `stime`<={$GLOBALS['CNOA_TIMESTAMP']} AND `etime`>={$GLOBALS['CNOA_TIMESTAMP']}");
		if(!$entrustInfo){
			$sqlEntrust = "";
		}else{
			$entUids = array();
			foreach($entrustInfo AS $v){
				$entUids[] = $v['fromuid'];
			}
			$sqlEntrust = " OR `uid` IN (".implode(",", $entUids).") ";
			unset($entUids);
		}
		unset($entrustInfo);
		
		
		//查询相关工作流信息
		$sWhere = $this->__findFlowInfo();
		
		/*优化程序，提高查询速度 */
		$ulidsArray = $CNOA_DB->db_select(array('ulid'), $this->table_u_node, "WHERE `uid`='{$uid}' {$sqlEntrust} ");
		!is_array($ulidsArray) && $ulidsArray=array();
		$ulids = array(0);
		foreach($ulidsArray AS $uldv){
			$ulids[] = $uldv['ulid'];
		}
		$ulids = array_merge(array_unique($ulids));

		$sql  = "`ulid` IN (".implode(",", $ulids).")";
		
		#会签用户也显示此流程
		##### $sql2 = "`ulid` IN (SELECT `ulid` FROM " . tname($this->table_u_huiqian) . " WHERE `to_uid`='{$uid}' )";
		//$where = "WHERE ({$sql}) OR ({$sql2}) {$sWhere} ORDER BY `posttime` DESC LIMIT {$start},{$rows}";

		$where = "WHERE {$sql}{$sWhere} ORDER BY `posttime` DESC LIMIT {$start},{$rows}";
		//debug::xprint($where);
		$dbList = $CNOA_DB->db_select("*", $this->table_u_list, $where);
		!is_array($dbList) && $dbList=array();
		
		$uids = array();
		foreach ($dbList AS $k=>$v){
			//重要等级
				if($v['level'] == 2){$dbList[$k]['level'] = "<span class='cnoa_color_orange'>重要</span>";}
			elseif($v['level'] == 3){$dbList[$k]['level'] = "<span class='cnoa_color_red'>非常重要</span>";}
			else{$dbList[$k]['level'] = "普通";}
			
			//发布时间
			$dbList[$k]['posttime'] = date("Y-m-d H:i", $v['posttime']);
			//$dbList[$k]['uname'] = "2323";
			$uids[] = $v['uid'];
			
			//当前步骤
			if($v['status'] == 0){
				$dbList[$k]['stepText'] = $CNOA_DB->db_getfield("name", $this->table_list_node, "WHERE `lid`='{$v['lid']}' AND `stepid`='0'");
			}else{
				$cacheFile	= @include $this->cachePath . "/flow/user/{$v['ulid']}/" . "flow_node.php";
				$dbList[$k]['stepText'] = $cacheFile[$v['step']]['name'];
				
				$allowOperate = $CNOA_DB->db_getone(array("uid"), $this->table_u_node, "WHERE `ulid`='{$v['ulid']}' AND (`uid`='{$uid}' {$sqlEntrust}) AND `stepid`='{$v['step']}' AND (`status`=1 OR `status`=3)");
				//$dbList[$k]['allowOperate'] = ($allowOperate && ($v['status']==1 || $v['status']==3)) === false ? 0 : 1;
				#会签权限判断
				$allowOperate2 = $CNOA_DB->db_getone(array("to_uid"), $this->table_u_huiqian, " WHERE `to_uid`='{$uid}' AND `stepid`='{$v['step']}' AND `ulid`='{$v['ulid']}' AND `isread`=0");

				if($allowOperate || $allowOperate2){
					if($v['status']==1 || $v['status']==3){
						$dbList[$k]['allowOperate'] = 1;
					}
				}else{
					$dbList[$k]['allowOperate'] = 0;
				}
			}
		}
		
		$usersInfo = app::loadApp("main", "user")->api_getUserNamesByUids($uids);
		foreach ($dbList AS $k=>$v){
			$dbList[$k]['uname'] = $usersInfo[$v['uid']]['truename'];
		}
		
		$dataStore = new dataStore();
		$dataStore->total = $CNOA_DB->db_getcount($this->table_u_list, "WHERE {$sql}{$sWhere} ");
		$dataStore->data = $dbList;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _view_loadFlowInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$sid  = $CNOA_SESSION->get("SID");
		$ulid = getPar($_POST, "ulid", 0);

		//更新已阅记录
		$this->__addDespanseSayDefault($uid, $ulid);
		
		//获取流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		
		if($flowInfo !== false){
			$flowInfo['uname'] = app::loadApp("main", "user")->api_getUserTruenameByUid($flowInfo['uid']);
		}
		
		$flowInfo['posttime'] = date("Y年m月d日 H时i分", $flowInfo['posttime']);
		
		//当前步骤
		$cacheFile	= @include $this->cachePath . "/flow/user/{$flowInfo['ulid']}/" . "flow_node.php";
		$flowInfo['stepText'] = $cacheFile[$flowInfo['step']]['name'];

		
		//判断是会签还是普通办理
		$isHuiQian = $CNOA_DB->db_getone("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}' AND `stepid`='{$flowInfo['step']}'");
		$isHuiQian = $isHuiQian === false ? '1' : '0';

		//是否允许上传/下载附件
		$flowInfo['allowup'] = $cacheFile[$flowInfo['step']]['allowup'];
		$flowInfo['allowdown'] = $cacheFile[$flowInfo['step']]['allowdown'];

		//获取附件信息
		if($cacheFile[$flowInfo['step']]['type'] == "end"){
			//如果是结束节点，则允许查看附件(不完美)
			$flowInfo['allowdown'] = '1';
		}
		if($flowInfo['allowdown'] == '1'){
			$fs = new fs();
			$flowInfo['attach']		 	= json_decode($flowInfo['attach'], true);
			$flowInfo['attachCount']	= !$flowInfo['attach'] ? 0 : count($flowInfo['attach']);
			$flowInfo['attach']			= $fs->getDownLoadItems4normal($flowInfo['attach'], true, true, true);
			//$flowInfo['attach'] = $fs->getXXXXDownLoadFileListByIds(json_decode($flowInfo['attach']));
			//$flowInfo['attachCount'] = count($flowInfo['attach']);
		}else{
			$flowInfo['attachCount'] = 0;
		}
		
		//状态 -1已删除 0:未发布 1:办理中 2已办理 3已退件 4已撤销
			if($flowInfo['status'] == 0){$flowInfo['statusText'] = "未发布";	}
		elseif($flowInfo['status'] == 1){$flowInfo['statusText'] = "办理中";	}
		elseif($flowInfo['status'] == 2){$flowInfo['statusText'] = "已办理";	}
		elseif($flowInfo['status'] == 3){$flowInfo['statusText'] = "已退件";	}
		elseif($flowInfo['status'] == 4){$flowInfo['statusText'] = "已撤销";	}
		
		//如果是普通流程，则处理表单，否则不需要处理
		if($flowInfo['flowtype'] == '0'){
			//获取表单信息
			//表单内容
			$cacheFile_form		 = @include $this->cachePath . "/flow/user/{$ulid}/form.php";
			//表单元素列表
			$cacheFile_form_item = @include $this->cachePath . "/flow/user/{$ulid}/form_item.php";
			//流程步骤列表
			$cacheFile_flow_node = @include $this->cachePath . "/flow/user/{$ulid}/flow_node.php";
			
			$itemsInfo = json_decode($cacheFile_flow_node[$flowInfo['step']]['formitems'], true);
			
			//获取已有表单数据
			$formData = $CNOA_DB->db_select("*", $this->table_u_formdata, "WHERE `ulid`='{$ulid}'");
			
			//如果是退件的流程
			if($flowInfo['step']==0 && $flowInfo['status']==1){
				$content = app::loadApp("flow", "flowCommon")->api_parseFormForNewFlow($cacheFile_form, $itemsInfo, $cacheFile_form_item);
			}else{
				$content = app::loadApp("flow", "flowCommon")->api_parseFormForNextFlowStep($cacheFile_form, $itemsInfo, $formData, $cacheFile_form_item, $cacheFile[$flowInfo['step']]);
			}
		}
		
		//获取被委托数据
		$flowNodeInfo = $CNOA_DB->db_getone("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}'");
		#找出委托人UID$flowInfo['step']
		$isEntrust = $CNOA_DB->db_getone("*", $this->table_u_entrust, "WHERE `fromuid`='{$flowNodeInfo['uid']}' AND `touid`='{$uid}' AND `status`=1 AND `stime`<={$GLOBALS['CNOA_TIMESTAMP']} AND `etime`>={$GLOBALS['CNOA_TIMESTAMP']}");
		$isEntrust = $isEntrust !== false ? '1' : '0';

		$data = array();
		$data['flowInfo'] = $flowInfo;
		$data['formInfo'] = $content;
		$data['formData'] = $formData;
		$data['isHuiQian'] = $isHuiQian;
		$data['isEntrust'] = $isEntrust;
		
		$dataStore = new dataStore();
		$dataStore->total = 0;
		$dataStore->data = $data;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function replaceHTML($html, $data){
		$dataTmp = array();
		
		if(empty($html) || !isset($html) || empty($data) || !isset($data)){
			return "无工作表单";
		}
		
		foreach($data AS $v){
			$dataTmp[$v['itemid']] = $v;
		}
		
		//preg_match_all('/<((input|textarea|select))[^>]*>/is', $html, $arr);
		preg_match_all('/<((input|textarea))[^>]*>/is', $html, $arr);
	
		//替换掉input/textarea
		$str_source = array();
		$str_target = array();
		foreach($arr[0] AS $k=>$v){
			$itemid = preg_replace("/.*itemid\=\"([0-9]{1,})\".*/is", "\\1", $v);
			$str_source[$itemid] = $v;
			if(strtolower($arr[1][$k]) == "input"){
				$v = str_replace("<input", "<input value=\"".$dataTmp[$itemid]['data']."\"", $v);
			}elseif(strtolower($arr[1][$k]) == "textarea"){
				$v = str_replace(">", ">".$dataTmp[$itemid]['data'], $v);
			}
			$str_target[] = $v;
		}
		$html = str_replace($str_source, $str_target, $html);
	
		//替换掉select
		preg_match_all('/<select[^>]*>(.*?)<\/select>/is', $html, $arr);
		$str_source = array();
		$str_target = array();
		foreach($arr[0] AS $k=>$v){
			$itemid = preg_replace("/.*itemid\=\"([0-9]{1,})\".*/is", "\\1", $v);
			$str_source[$itemid] = $v;
			$v = str_replace(array(' selected="selected"', 'value="'.$dataTmp[$itemid]['data'].'"'), array('', 'value="'.$dataTmp[$itemid]['data'].'" selected="selected"'), $v);
			$str_target[] = $v;
		}
		$html = str_replace($str_source, $str_target, $html);
		return $html;
	}
	
	/**
	 * 获取下一步骤信息(办理时)
	 */
	private function _deal_loadNextStepInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		//获取得ulid
		$ulid = getPar($_POST, "ulid", 0);
		
		//获取流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		
		//获取被委托数据
		$entrustInfo = $CNOA_DB->db_select(array("fromuid"), $this->table_u_entrust, "WHERE `touid`='{$uid}' AND `status`=1 AND `stime`<={$GLOBALS['CNOA_TIMESTAMP']} AND `etime`>={$GLOBALS['CNOA_TIMESTAMP']}");
		if(!$entrustInfo){
			$sqlEntrust = "";
		}else{
			$entUids = array();
			foreach($entrustInfo AS $v){
				$entUids[] = $v['fromuid'];
			}
			$sqlEntrust = " OR `uid` IN (".implode(",", $entUids).") ";
			unset($entUids);
		}
		unset($entrustInfo);
		
		//获取当前步骤
		$nowStep = $flowInfo['step'];
		$flowNodeInfo = $CNOA_DB->db_getone("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND (`uid`='{$uid}' {$sqlEntrust})");
		
		//判断当前办理人是否有操作权限(是否正处于自己所在步骤)
		if($flowNodeInfo == false){
			msg::callBack(false, "你不是当前流程该步骤的办理人，不能办理!");
		}
		
		$data = array();
		
		
		//判断当前用户是否是主办人(如果是主办人，则送出下一步用户列表; 如果不是，则标记为不是，不发送下一步用户列表)
		$nextstep = $nowStep+1;
		//$cacheFile_form		 = @include $this->cachePath . "/flow/user/{$ulid}/form.php";
		//$cacheFile_form_item = @include $this->cachePath . "/flow/user/{$ulid}/form_item.php";
		$cacheFile_flow_node = @include $this->cachePath . "/flow/user/{$ulid}/flow_node.php";
		$nextInfo = $cacheFile_flow_node[$nextstep];
		
		//如果是主办人或者经办方式为任意一人办理
		if($nextInfo['type'] == "end"){
			$data['nextStepType'] = "end";
		}else{
			if(($flowNodeInfo['sponsor'] == 1) || ($flowNodeInfo['operatortype'] == 1)){
				//前台是否显示下一步经办人选择框的依据
				$data['sponsor'] = 1;
				
				$nextMans = $this->__getAllUidsInStepByOperator($nextInfo['operator']);
				$nextUids = $nextMans['uid'];
				
				$userList = app::loadApp("main", "user")->api_getUserInfoByUids($nextUids);
				$stationList = app::loadApp("main", "station")->api_getStationList();
				!is_array($userList) && $userList=array();
				!is_array($stationList) && $stationList=array();
				
				$users = array();
				foreach ($userList AS $v){
					$station = $stationList[intval($v['stationid'])]['name'] == NULL ? "" : " (" . $stationList[intval($v['stationid'])]['name'] . ")";
					
					$u = array();
					$u['uid']	= $v['uid'];
					$u['name']	= $v['truename'] . $station;
					$users[] = $u;
				}
				
				$nextInfo['operator'] = $users;
			}else{
				//前台是否显示下一步经办人选择框的依据
				$data['sponsor'] = 0;
			}
			$data['nextStepType'] = "node";
		}
		
		$data['nextData'] = $nextInfo;
		
		$dataStore = new dataStore();
		$dataStore->data = $data;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _deal_sendFlow(){
		global $CNOA_DB, $CNOA_SESSION;

		$uid		= $CNOA_SESSION->get("UID");
		//获取得ulid
		$ulid		= getPar($_POST, "ulid", 0);
		$nextUids	= getPar($_POST, "nextUids", 0);
		$say		= getPar($_POST, "say", "", 1);
		$data			= array();
		
		//读入缓存
		//$cacheFile_flow			= @include $this->cachePath . "/flow/user/{$ulid}/flow.php";
		$cacheFile_flow_node	= @include $this->cachePath . "/flow/user/{$ulid}/flow_node.php";
		//$cacheFile_form		 = @include $this->cachePath . "/flow/user/{$ulid}/form.php";
		//$cacheFile_form_item = @include $this->cachePath . "/flow/user/{$ulid}/form_item.php";
		
		//获取被委托数据
		$entrustInfo = $CNOA_DB->db_select(array("fromuid"), $this->table_u_entrust, "WHERE `touid`='{$uid}' AND `status`=1 AND `stime`<={$GLOBALS['CNOA_TIMESTAMP']} AND `etime`>={$GLOBALS['CNOA_TIMESTAMP']}");
		if(!$entrustInfo){
			$sqlEntrust = "";
		}else{
			$entUids = array();
			foreach($entrustInfo AS $v){
				$entUids[] = $v['fromuid'];
			}
			$sqlEntrust = " OR `uid` IN (".implode(",", $entUids).") ";
			unset($entUids);
		}
		unset($entrustInfo);
		
		//获取本步骤流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		$nowStep = $flowInfo['step'];
		$flowNodeInfo = $CNOA_DB->db_getone("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND (`uid`='{$uid}' {$sqlEntrust})");
		
		//判断当前办理人是否有操作权限(是否正处于自己所在步骤)
		if($flowNodeInfo == false){
			msg::callBack(false, "你不是当前流程该步骤的办理人，不能办理!");
		}
		
		//处理附件
		$fs = new fs();
		$attachOld = json_decode($flowInfo['attach'], true);
		!is_array($attachOld) && $attachOld=array();
		$filesUpload = getPar($_POST, "filesUpload", array());
		$attachNew = $fs->add($filesUpload, 7);
		$attach = json_encode(array_merge($attachOld, $attachNew));
		$CNOA_DB->db_update(array("attach"=>$attach), $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		
		//更新本步骤信息
		$data['say'] = $say;
		$data['status'] = 2;
		$data['etime'] = $GLOBALS['CNOA_TIMESTAMP'];
		$info = $CNOA_DB->db_getone("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND (`uid`='{$uid}' {$sqlEntrust})");
		
		notice::doneN($info['noticeid_c']);
		notice::doneT($info['todoid_c']);
		
		$CNOA_DB->db_update($data, $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND (`uid`='{$uid}' {$sqlEntrust})");
		
		//处理工作表单
		$flowFormitems = json_decode($cacheFile_flow_node[$nowStep]['formitems'], true);
		!is_array($flowFormitems) && $flowFormitems=array();
		foreach ($flowFormitems AS $v){
			if(($v['need'] == 1) || ($v['must'] == 1) || ($v['used'] == 1)){
				$formItemData	= array();
				$formItemData['ulid'] = $ulid;
				$formItemData['itemid'] = $v['itemid'];
				//$formItemData['data'] = getPar($_POST, "DATA_".$v['itemid'], "", 1);
				$formItemData['data'] = getPar($_POST['FLOWDATA'], $v['itemid'], "", 1);
				$formItemData['uid']	= $uid;
				$formItemData['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
				$formItemData['step']	= $nowStep;
				//如果经办方式为多人办理并且是所有人办理后才进入下一步骤的话
				if($cacheFile_flow_node[$nowStep]['operatorperson'] == 2 && $cacheFile_flow_node[$nowStep]['operatortype'] == 2){
					$vinfoo = $CNOA_DB->db_getone("*", $this->table_u_formdata, "WHERE `ulid`='{$ulid}' AND `itemid`='{$v['itemid']}' AND (`uid`='{$uid}' {$sqlEntrust})");
					if(!$vinfoo && !empty($formItemData['data'])){
						$CNOA_DB->db_insert($formItemData, $this->table_u_formdata);
					}
				}else{
					$vinfoo = $CNOA_DB->db_delete($this->table_u_formdata, "WHERE `ulid`='{$ulid}' AND `itemid`='{$v['itemid']}' AND (`uid`='{$uid}' {$sqlEntrust})");
					$CNOA_DB->db_insert($formItemData, $this->table_u_formdata);
				}
			}
		}

		//处理自己所处的整个流程步骤
		$nextStep = $nowStep + 1;
		
		//如果下一步是结束
		if($cacheFile_flow_node[$nextStep]['type'] == "end"){
			//经办方式：任意一人都可以办理
			if($flowNodeInfo['operatortype'] == 1){
				//更新主流程
				$CNOA_DB->db_update(array("step"=>$nextStep, "status"=>2), $this->table_u_list, "WHERE `ulid`='{$ulid}'");
				
				#删除其它人的待办
				$info = $CNOA_DB->db_select("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND `status`=1 ");
				!is_array($info) && $info = array();
				foreach($info AS $v){
					notice::deleteNotice($v['noticeid_c'], $v['todoid_c']);
				}
				
				$CNOA_DB->db_delete($this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND `status`=1 ");
			}
			//经办方式：所有人通过
			else{
				//所有人是否已经完成
				$isStepComplete = $CNOA_DB->db_getcount($this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND `status`=1");
				$isStepComplete = $isStepComplete == 0 ? true : false;
				
				//如果步骤已经完成
				if($isStepComplete){
					$CNOA_DB->db_update(array("step"=>$nextStep, "status"=>2), $this->table_u_list, "WHERE `ulid`='{$ulid}'");
				}
				//如果步骤还没完成，则不处理
				else{}
			}

			$noticeT = "流程已经办理完毕";
			$noticeC = "流程:" . $flowInfo['name'] . " 已办理完毕";
			if($flowInfo['flowtype'] == '0'){
				$noticeH = "index.php?app=flow&func=flow&action=user&task=loadPage&from=showflow&ulid=" . $ulid;
			}else{
				$noticeH = "index.php?app=flow&func=flow&action=user&module=commonFlow&task=loadPage&from=showflow&ulid=" . $ulid;
			}
			$data['noticeid_c'] = notice::add($flowInfo['uid'], $noticeT, $noticeC, $noticeH, 0, 5);
		}
		//如果下一步是普通节点（非结束点）
		else{
			//①经办方式：任意一人都可以办理
			if($flowNodeInfo['operatortype'] == 1){
				$this->__makeNextStepNode($flowInfo, $nextUids, $ulid, $nextStep, $cacheFile_flow_node[$nextStep]);

				#删除其它人的待办
				$info = $CNOA_DB->db_select("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND `status`=1 ");
				!is_array($info) && $info = array();
				foreach($info AS $v){
					notice::deleteNotice($v['noticeid_c'], $v['todoid_c']);
				}

				$CNOA_DB->db_delete($this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND `status`=1 ");
			}
			//②经办方式：所有人通过
			else{
				//⑤所有人是否已经完成
				$isStepComplete = $CNOA_DB->db_getcount($this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND `status`=1");
				$isStepComplete = $isStepComplete == 0 ? true : false;
				
				//③是主办人
				if($flowNodeInfo['sponsor'] == 1){
					//⑤如果步骤已经完成
					if($isStepComplete){
						$this->__makeNextStepNode($flowInfo, $nextUids, $ulid, $nextStep, $cacheFile_flow_node[$nextStep]);
					}
					//⑥如果步骤还没完成
					else{
						$CNOA_DB->db_update(array("nextstepuids"=>$nextUids), $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND (`uid`='{$uid}' {$sqlEntrust})");
					}
				}
				//④不是主办人
				else{
					//⑦如果步骤已经完成
					if($isStepComplete){
						$nextUidsInfo = $CNOA_DB->db_getfield("nextstepuids", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}' AND `sponsor`=1");
						$this->__makeNextStepNode($flowInfo, $nextUidsInfo, $ulid, $nextStep, $cacheFile_flow_node[$nextStep]);
					}
					//⑧如果步骤还没完成(不用处理)
					else{}
				}
			}
		}
		
		//添加事件
		$this->__eventAdd($ulid, 2, $nowStep, $cacheFile_flow_node[$nowStep]['name'], $say);
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('', 75, $flowInfo['name'], "同意流程");
		msg::callBack(true, "操作成功");
	}
	
	private function _disagree(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		$ulid	= getPar($_POST, "ulid", 0);
		$reason = getPar($_POST, "reason", "", 1);
		
		//获取流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		if(!$flowInfo){
			msg::callBack(false, "无此流程");
		}
		
		if($flowInfo['status'] != 1){
			msg::callBack(false, "当前流程状态不是\"办理中\"，无法退件");
		}
		
		//获取被委托数据
		$entrustInfo = $CNOA_DB->db_select(array("fromuid"), $this->table_u_entrust, "WHERE `touid`='{$uid}' AND `status`=1 AND `stime`<={$GLOBALS['CNOA_TIMESTAMP']} AND `etime`>={$GLOBALS['CNOA_TIMESTAMP']}");
		if(!$entrustInfo){
			$sqlEntrust = "";
		}else{
			$entUids = array();
			foreach($entrustInfo AS $v){
				$entUids[] = $v['fromuid'];
			}
			$sqlEntrust = " OR `uid` IN (".implode(",", $entUids).") ";
			unset($entUids);
		}
		unset($entrustInfo);
		
		//获取当前步骤
		$nowStep = $flowInfo['step'];
		$stepInfo = $CNOA_DB->db_getone("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND (`uid`='{$uid}' {$sqlEntrust}) AND `stepid`='{$nowStep}'");
		if(!$stepInfo){
			msg::callBack(false, "你不是当前流程该步骤的办理人，无权退件");
		}

		//修改本流程状态及所处步骤
		$CNOA_DB->db_update(array("status"=>1, "step"=>0), $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		
		//修改当前步骤状态
		$CNOA_DB->db_update(array("status"=>1), $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`=0");

		//删除除第一个步骤之外的步骤
		$CNOA_DB->db_delete($this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`>0");

		//删除表单数据(删除除第一步骤外的所有数据)
		$cacheFile_flow_node = @include $this->cachePath . "/flow/user/{$ulid}/flow_node.php";
		$firstStepItems = json_decode($cacheFile_flow_node[0]['formitems'], true);
		!is_array($firstStepItems) && $firstStepItems=array();
		$firstItemsIds = array();
		foreach($firstStepItems AS $nsiv){
			if($nsiv['need'] || $nsiv['must'] || $nsiv['used']){
				$firstItemsIds[] = $nsiv['itemid'];
			}
		}
		$sqlIn = (is_array($firstItemsIds) && count($firstItemsIds)>0) ? " AND `itemid` NOT IN (".implode(",", $firstItemsIds).")" : "";
		$CNOA_DB->db_delete($this->table_u_formdata, "WHERE `ulid`='{$ulid}' {$sqlIn}");
		
		//添加消息提醒
		$noticeT = "你有一个工作审批被退回";
		$noticeC = $flowInfo['name']."(".$flowInfo['title'].")";
		//$noticeH = $this->viewUrl . $ulid;
		if($flowInfo['flowtype'] == '0'){
			$noticeH = $this->viewUrl . $ulid;
		}else{
			$noticeH = $this->viewUrlCommonFlow . $ulid;
		}
		notice::add($flowInfo['uid'], $noticeT, $noticeC, $noticeH, 0, 5);
		
		//添加事件日志
		$this->__eventAdd($ulid, 5, $nowStep, $stepInfo['nodename'], "[退件]<br />".$reason);
		
		//取消之前的待办及提醒
		notice::doneN($stepInfo['noticeid_c']);
		notice::doneT($stepInfo['todoid_c']);
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('', 75, $flowInfo['name'], "不同意流程");
		msg::callBack(true, "操作成功");
	}
	
	private function _show_loadFlowInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$ulid = getPar($_POST, "ulid", 0);

		//更新已阅记录
		$this->__addDespanseSayDefault($uid, $ulid);
		#$CNOA_DB->db_update(array("isread"=>1,"viewtime"=>$GLOBALS['CNOA_TIMESTAMP'],"say"=>"已阅"), "flow_flow_u_dispense", "WHERE `ulid`='{$ulid}' AND `to_uid`='{$uid}'");
		
		//获取流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		
		if($flowInfo !== false){
			$flowInfo['uname'] = app::loadApp("main", "user")->api_getUserTruenameByUid($flowInfo['uid']);
		}
		
		$flowInfo['posttime'] = date("Y年m月d日 H时i分", $flowInfo['posttime']);
		
		//当前步骤
		$cacheFile	= @include $this->cachePath . "/flow/user/{$flowInfo['ulid']}/" . "flow_node.php";
		$flowInfo['stepText'] = $cacheFile[$flowInfo['step']]['name'];
		
		//是否允许上传/下载附件
		$flowInfo['allowup'] = $cacheFile[$flowInfo['step']]['allowup'];
		$flowInfo['allowdown'] = $cacheFile[$flowInfo['step']]['allowdown'];

		//获取附件信息
		if($cacheFile[$flowInfo['step']]['type'] == "end"){
			//如果是结束节点，则允许查看附件(不完美)
			$flowInfo['allowdown'] = '1';
		}
		if($flowInfo['allowdown'] == '1'){
			$fs = new fs();
			$flowInfo['attach']		 	= json_decode($flowInfo['attach'], true);
			$flowInfo['attachCount']	= !$flowInfo['attach'] ? 0 : count($flowInfo['attach']);
			$flowInfo['attach']			= $fs->getDownLoadItems4normal($flowInfo['attach'], true);
			//$flowInfo['attach'] = $fs->getXXXXDownLoadFileListByIds(json_decode($flowInfo['attach']));
			//$flowInfo['attachCount'] = count($flowInfo['attach']);
		}else{
			$flowInfo['attachCount'] = 0;
		}
		
		//状态 -1已删除 0:未发布 1:办理中 2已办理 3已退件 4已撤销
			if($flowInfo['status'] == 0){$flowInfo['statusText'] = "未发布";	}
		elseif($flowInfo['status'] == 1){$flowInfo['statusText'] = "办理中";	}
		elseif($flowInfo['status'] == 2){$flowInfo['statusText'] = "已办理";	}
		elseif($flowInfo['status'] == 3){$flowInfo['statusText'] = "已退件";	}
		elseif($flowInfo['status'] == 4){$flowInfo['statusText'] = "已撤销";	}
		
		//获取表单信息
		//表单内容
		$cacheFile_form		 = @include $this->cachePath . "/flow/user/{$ulid}/form.php";
		//表单元素列表
		$cacheFile_form_item = @include $this->cachePath . "/flow/user/{$ulid}/form_item.php";
		//流程步骤列表
		$cacheFile_flow_node = @include $this->cachePath . "/flow/user/{$ulid}/flow_node.php";
		
		//$itemsInfo = json_decode($cacheFile_flow_node[$flowInfo['step']]['formitems'], true);
		
		//获取已有表单数据
		$formData = $CNOA_DB->db_select("*", $this->table_u_formdata, "WHERE `ulid`='{$ulid}'");

		$content = app::loadApp("flow", "flowCommon")->api_parseFormForView($cacheFile_form, $formData, $cacheFile_form_item, $flowInfo);
		
		if($flowInfo['flowtype'] == 1){
			$flowInfo['stepInfo'] = app::loadApp("flow", "flowUserCommonFlow")->api_getStepInfo($flowInfo);
		}
		
		$data = array();
		$data['flowInfo'] = $flowInfo;
		$data['formInfo'] = $content;
		$data['formData'] = $formData;
		
		$dataStore = new dataStore();
		$dataStore->total = 0;
		$dataStore->data = $data;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _gotoPrevstep(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		$ulid	= getPar($_POST, "ulid", 0);
		$reason = getPar($_POST, "reason", "", 1);
		
		//获取流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		if(!$flowInfo){
			msg::callBack(false, "无此流程");
		}
		
		if($flowInfo['status'] != 1){
			msg::callBack(false, "当前流程状态不是\"处理中\"，无法退回");
		}
		
		//获取被委托数据
		$entrustInfo = $CNOA_DB->db_select(array("fromuid"), $this->table_u_entrust, "WHERE `touid`='{$uid}' AND `status`=1 AND `stime`<={$GLOBALS['CNOA_TIMESTAMP']} AND `etime`>={$GLOBALS['CNOA_TIMESTAMP']}");
		if(!$entrustInfo){
			$sqlEntrust = "";
		}else{
			$entUids = array();
			foreach($entrustInfo AS $v){
				$entUids[] = $v['fromuid'];
			}
			$sqlEntrust = " OR `uid` IN (".implode(",", $entUids).") ";
			unset($entUids);
		}
		unset($entrustInfo);
		
		//获取当前步骤
		$nowStep = $flowInfo['step'];
		$stepInfo = $CNOA_DB->db_getone("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND (`uid`='{$uid}' {$sqlEntrust}) AND `stepid`='{$nowStep}'");
		if(!$stepInfo){
			msg::callBack(false, "你不是当前流程该步骤的办理人，无权退回");
		}
		if($nowStep == 0){
			msg::callBack(false, "当前流程已是起点步骤，无法再退回上一步");
		}
		
		//删除表单数据（本步骤之后的所有数据）
		$CNOA_DB->db_delete($this->table_u_formdata, "WHERE `ulid`='{$ulid}' AND `step`>='{$nowStep}'");
		
		//删除本步骤
		$CNOA_DB->db_delete($this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$nowStep}'");
		
		//修改上一步骤状态
		$prevStep = $nowStep-1;
		$CNOA_DB->db_update(array("status"=>1), $this->table_u_node, "WHERE `stepid`='{$prevStep}' AND `ulid`='{$ulid}'");
		
		//添加消息提醒
		$prevStepInfo = $CNOA_DB->db_select("*", $this->table_u_node, "WHERE  (`ulid`='{$ulid}' {$sqlEntrust}) AND `stepid`='{$prevStep}'");
		//debug::xprint($prevStepInfo);
		!is_array($prevStepInfo) && $prevStepInfo = array();
		$noticeT = "你有一个工作审批被退回,请重新办理";
		$noticeC = $flowInfo['name']."(".$flowInfo['title'].")";
		//$noticeH = $this->viewUrl . $ulid;
		if($flowInfo['flowtype'] == '0'){
			$noticeH = $this->viewUrl . $ulid;
		}else{
			$noticeH = $this->viewUrlCommonFlow . $ulid;
		}
		foreach($prevStepInfo AS $v){
			notice::add($v['uid'], $noticeT, $noticeC, $noticeH, 0, 5);
		}
		//添加事件日志
		$this->__eventAdd($ulid, 6, $nowStep, $stepInfo['nodename'], "[退回上一步]<br />".$reason);
		
		//修改本流程所处步骤
		$CNOA_DB->db_update(array("step"=>$prevStep), $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		
		notice::doneN($stepInfo['noticeid_c']);
		notice::doneT($stepInfo['todoid_c']);
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('', 75, $flowInfo['name'], "流程退回上一步");
		msg::callBack(true, "操作成功");
	}
	
	/*
	 * 获取被委托人列表
	 */
	private function _getEntrustJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		
		$entrustInfo = $CNOA_DB->db_getone("*", $this->table_u_entrust, "WHERE `fromuid`='{$uid}'");
		
		if(!$entrustInfo){
			$entrustInfo = array();
			$entrustInfo["fromuid"]	= $uid;
			$entrustInfo["touid"]	= 0;
			$entrustInfo["status"]	= 2;
			$entrustInfo["stime"]	= 0;
			$entrustInfo["etime"]	= 0;
			$CNOA_DB->db_insert($entrustInfo, $this->table_u_entrust, "WHERE `fromuid`='{$uid}'");
		}
		
		$entrustInfo["expiresText"] = "";
		
		if($entrustInfo["touid"] == 0){
			$entrustInfo['touname'] = "----";
			$entrustInfo["stime"] = "----";
			$entrustInfo["etime"] = "----";
		}else{
			if($entrustInfo["stime"] > $GLOBALS['CNOA_TIMESTAMP']){
				$entrustInfo["expiresText"] = "<span class='cnoa_color_gray'>[未到时间]</span>";
			}
			if($entrustInfo["etime"] < $GLOBALS['CNOA_TIMESTAMP']){
				$entrustInfo["expiresText"] = "<span class='cnoa_color_red'>[已过期]</span>";
			}
			$entrustInfo['touname'] = app::loadApp("main", "user")->api_getUserTruenameByUid($entrustInfo["touid"]);
			$entrustInfo["stime"] = date("Y年m月d日 H:i", $entrustInfo["stime"]);
			$entrustInfo["etime"] = date("Y年m月d日 H:i", $entrustInfo["etime"]);
		}
		$entrustInfo["statusText"]	= $this->entrustType[$entrustInfo["status"]];
		
		
		$dataStore = new dataStore();
		$dataStore->total = 0;
		$dataStore->data = array($entrustInfo);

		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _getAllUserListsInPermitDeptTree(){
		$GLOBALS['user']['permitArea']['area'] = "all";
		
		$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
			
		echo json_encode($userList);
		exit;
	}
	
	private function _setEntrust(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		$uname	= $CNOA_SESSION->get("TRUENAME");

		$data = array();
		$data['touid']		= getPar($_POST, "touid", 0);
		$data['fromuid']	= $uid;
		$data['stime']		= strtotime(getPar($_POST, "stime", "0000-00-00 00:00"));
		$data['etime']		= strtotime(getPar($_POST, "etime", "0000-00-00 00:00"));
		$data['status']		= getPar($_POST, "status", 0);
		
		if($data['touid'] == $data['fromuid']){
			msg::callBack(false, "被委托人不能是自己");
		}
		
		if($data['stime']>=$data['etime']){
			msg::callBack(false, "开始时间不能晚于结束时间");
		}
		
		//添加消息提醒
		$noticeT = "你被委托成为工作代理人";
		$noticeC = "你被 {$uname} 授权成为他的工作代理人，委托生效时间为".date("Y年m月d日",$data['stime'])."至".date("Y年m月d日",$data['etime'])."。";
		$noticeH = "";
		notice::add($data['touid'], $noticeT, $noticeC, $noticeH, 0, 5);
		
		$CNOA_DB->db_update($data, $this->table_u_entrust, "WHERE `fromuid`='{$uid}'");
		
		//系统操作日志
		$name = app::loadApp('main', 'user')->api_getUserNameByUid($data['touid']);
		app::loadApp('main', 'systemLogs')->api_addLogs('update', 76, $name, "委托人");
		msg::callBack(true, "操作成功");
	}
	
	private function _editEntrustLoadForm(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		
		$entrustInfo = $CNOA_DB->db_getone("*", $this->table_u_entrust, "WHERE `fromuid`='{$uid}'");
		
		if(!$entrustInfo){
			msg::callBack(false, "无此数据");
		}
		
		if($entrustInfo['status'] == 2){
			$entrustInfo['stime'] = "";
			$entrustInfo['etime'] = "";
			$entrustInfo['toName'] = "";
			$entrustInfo["touid"] = "";
			$entrustInfo["status"] = 1;
		}else{
			$entrustInfo['stime'] = date("Y-m-d H:i:s", $entrustInfo['stime']);
			$entrustInfo['etime'] = date("Y-m-d H:i:s", $entrustInfo['etime']);
			$entrustInfo['toName'] = app::loadApp("main", "user")->api_getUserTruenameByUid($entrustInfo["touid"]);
		}
		
		$dataStore = new dataStore();
		$dataStore->total = 0;
		$dataStore->data = $entrustInfo;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _getEventList() {
		global $CNOA_DB, $CNOA_SESSION;
		
		$ulid	= getPar($_GET, "ulid", 0);
		
		//安全限制  - 只允许流程参与人查看
		
		//获取数据
		$dblist = $CNOA_DB->db_select("*", $this->table_u_event, "WHERE `ulid`='{$ulid}' ORDER BY `eid` ASC");
		if ($dblist !== false){
			foreach ($dblist AS $k=>$v){
				$dblist[$k]['typename'] = $this->eventType[$v['type']];
				$dblist[$k]['user'] 	  = $v['truename'] . " ("  . timeFormat($v['posttime']) . ")";
				$dblist[$k]['posttime'] = date("Y年m月d日 H:i", $v['posttime']);
			}
		}
		
		$dataStore = new dataStore();
		$dataStore->total = 0;
		$dataStore->data = $dblist;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _getProgressList(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$ulid	= getPar($_GET, "ulid", 0);
		
		//安全限制  - 只允许流程参与人查看
		
		$dblist = $CNOA_DB->db_select("*", $this->table_u_node, "WHERE `ulid`='{$ulid}' ORDER BY `stepid` ASC");

		if ($dblist !== false){
			$uids = array();
			foreach ($dblist AS $k=>$v){
				$uids[] = $v['uid'];
				$dblist[$k]['statusText'] = $this->statusType[$v['status']];
				$dblist[$k]['stime']	  = date("Y年m月d日 H:i", $v['stime']);
				
				if(($v['status'] == 2) && ($v['stepid']!=0)){
					$dblist[$k]['utime']  = timeFormat2($v['etime'] - $v['stime']);
				}elseif($v['stepid']!=0){
					$dblist[$k]['utime']  = timeFormat2($GLOBALS['CNOA_TIMESTAMP'] - $v['stime']);
				}else{
					$dblist[$k]['utime']  = "----";
				}
			}
			
			$usersInfo = app::loadApp("main", "user")->api_getUserNamesByUids($uids);
			foreach ($dblist AS $k=>$v){
				$dblist[$k]['uname'] = $usersInfo[$v['uid']]['truename'];
			}
			
			$flowStatus = $CNOA_DB->db_getfield("status", $this->table_u_list, "WHERE `ulid`='{$ulid}'");
			if($flowStatus == 2){
				$arr = array();
				$arr['ulid']		= $ulid;
				$arr['stepid']		= 0;
				$arr['status']		= 2;
				$arr['nodename']	= "结束";
				$arr['stime']		= "";
				$arr['statusText']	= "已办理";
				$arr['utime']		= "----";
				$arr['stime']		= "";
				$arr['uname']		= "<span style='color:green;'>流程已结束</span>";
				$arr['nodetype']	= "end";
				$dblist[] = $arr;
			}
			if($flowStatus == 3){
				$arr = array();
				$arr['ulid']		= $ulid;
				$arr['stepid']		= 0;
				$arr['status']		= 2;
				$arr['nodename']	= "结束";
				$arr['stime']		= "";
				$arr['statusText']	= "已退件";
				$arr['utime']		= "----";
				$arr['stime']		= "";
				$arr['uname']		= "<span style='color:green;'>流程已被退回</span>";
				$arr['nodetype']	= "end";
				$dblist[] = $arr;
			}
			if($flowStatus == 4){
				$arr = array();
				$arr['ulid']		= $ulid;
				$arr['stepid']		= 0;
				$arr['status']		= 2;
				$arr['nodename']	= "结束";
				$arr['stime']		= "";
				$arr['statusText']	= "已撤销";
				$arr['utime']		= "----";
				$arr['stime']		= "";
				$arr['uname']		= "<span style='color:green;'>流程已撤销</span>";
				$arr['nodetype']	= "end";
				$dblist[] = $arr;
			}
		}
		
		$dataStore = new dataStore();
		$dataStore->total = 0;
		$dataStore->data = $dblist;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	/**
	 * 导出数据给Excel生成报表用
	 */
	private function _exportExcel(){
		global $CNOA_SESSION;

		$uid  = $CNOA_SESSION->get("UID");
		$stime = strtotime(getPar($_POST, "stime", "0000-00-00")." 00:00:00");
		$etime = strtotime(getPar($_POST, "etime", "0000-00-00")." 23:59:59");
		
		$truename	= $CNOA_SESSION->get("TRUENAME");

		if($stime>=$etime){
			msg::callBack(false, "结束时间不能早于开始时间");
		}


		$fileName = "CNOA.FLOW-".$uid.date("Ymd", $stime)."-".date("Ymd", $etime)."-".string::rands(10, 2).".xls";
		$dataInfo = $this->_getExportExcelData($stime, $etime);
		$excelClass = app::loadApp("flow", "flowExportExcel");
		$excelClass->init($dataInfo, $truename, $stime, $etime);
		$excelClass->save(CNOA_PATH_FILE. "/common/temp/". $fileName);
		
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('', 81, "条件：".date('Y-m-d', $stime)."--".date('Y-m-d', $etime), "导出excel报表");

		msg::callBack(true, makeDownLoadIcon("file/common/temp/". $fileName, $fileName, "img"));
		//msg::callBack(true, "file/common/temp/". $fileName);
	}
	
	/**
	 * 生成数据，导出数据给Excel生成报表用
	 */
	private function _getExportExcelData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$stime = strtotime(getPar($_POST, "stime", "0000-00-00")." 00:00:00");
		$etime = strtotime(getPar($_POST, "etime", "0000-00-00")." 23:59:59");

		$where  = "WHERE `uid`='{$uid}' AND `status`>0 ";
		$where .= "AND `posttime`>='{$stime}' AND `posttime`<='{$etime}' ";
		$where .= "ORDER BY `posttime` ASC ";
		
		$dbList = $CNOA_DB->db_select("*", $this->table_u_list, $where);
		!is_array($dbList) && $dbList=array();
		
		foreach ($dbList AS $k=>$v){
			//发布时间
			$dbList[$k]['posttime'] = date("Y-m-d H:i", $v['posttime']);
			//重要等级
				if($v['level'] == 2){$dbList[$k]['level'] = "重要";}
			elseif($v['level'] == 3){$dbList[$k]['level'] = "非常重要";}
			else{$dbList[$k]['level'] = "普通";}
			//当前步骤
			if($v['status'] == 0){
				$dbList[$k]['step'] = $CNOA_DB->db_getfield("name", $this->table_list_node, "WHERE `lid`='{$v['lid']}' AND `stepid`='0'");
			}else{
				$cacheFile	= @include $this->cachePath . "/flow/user/{$v['ulid']}/" . "flow_node.php";
				$dbList[$k]['step'] = $cacheFile[$v['step']]['name'];
			}
			
			//状态 -1已删除 0:未发布 1:办理中 2已办理 3已退件 4已撤销
			$dbList[$k]['statusText'] = "";
			if($v['status'] == 0){$dbList[$k]['statusText'] = "未发送";}
			else if($v['status'] == 1){$dbList[$k]['statusText'] = "办理中";}
			else if($v['status'] == 2){$dbList[$k]['statusText'] = "已办理";}
			else if($v['status'] == 3){$dbList[$k]['statusText'] = "已退件";}
			else if($v['status'] == 4){$dbList[$k]['statusText'] = "已撤销";}
		}
		
		return $dbList;
		exit;
	}
	
	/**
	 * 生成下一步节点
	 * @param 下一步所有人的UID(1,2,3,8) $nextUids
	 * @param 当前流程ID $ulid
	 * @param 下一步ID $nextStep
	 * @param 下一步数据 $nextFlowNodeData
	 */
	private function __makeNextStepNode($flowInfo, $nextUids, $ulid, $nextStep, $nextFlowNodeData){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		
		//生成下一步节点信息
		/*
		ulid			流程ID
		stepid			步骤ID
		uid				当前步骤经办人UID
		status			状态
		nodename		节点名称
		stime			开始时间
		etime			结束时间
		operatortype	办理类型
		attachdown		是否允许下载附件
		attachup		是否允许上传附件
		say				
		sponsor			是否是主办人
		*/
		$data = array();
		$nextUids = explode(",", $nextUids);
		$data['ulid']			= $ulid;
		$data['stepid']			= $nextStep;
		$data['status']			= 1;
		$data['nodename']		= $nextFlowNodeData['name'];
		$data['stime']			= $GLOBALS['CNOA_TIMESTAMP'];
		$data['operatortype']	= $nextFlowNodeData['operatortype'];
		$data['attachdown']		= $nextFlowNodeData['allowdown'];
		$data['attachup']		= $nextFlowNodeData['allowup'];
		$data['sponsor']		= 1;

		foreach($nextUids AS $v){
			$data['uid']		= $v;
			
			$noticeT = "工作流管理";
			$noticeC = "你有一个工作需要审批" . $flowInfo['name']."(".$flowInfo['title'].")";
			//$noticeH = $this->viewUrl . $ulid;
			if($flowInfo['flowtype'] == '0'){
				$noticeH = $this->viewUrl . $ulid;
			}else{
				$noticeH = $this->viewUrlCommonFlow . $ulid;
			}
			$data['noticeid_c'] = notice::add($v, $noticeT, $noticeC, $noticeH, 0, 5);
			
			$notice['touid']	= $v;
			$notice['from']		= 5;
			$notice['fromid']	= 0;
			$notice['href']		= $noticeH;
			$notice['title']	= $noticeC;
			$notice['funname']	= "工作流管理";
			$notice['move']		= "审批";
			
			$data['todoid_c'] = notice::add2($notice);
			
			$CNOA_DB->db_insert($data, $this->table_u_node);
			$data['sponsor']	= 0;
			
			//使用手机短信审批
			if($nextFlowNodeData['smsdeal'] == '1'){
				$this->sendSmsDeal($ulid, $flowInfo['name'], $v, $flowInfo['reason']);
			}
		}
		
		//更新主流程
		$CNOA_DB->db_update(array("step"=>$nextStep), $this->table_u_list, "WHERE `ulid`='{$ulid}'");
	}
	/************************* ∧审批流程∧ **********************/

	
	/**
	 * 	获取流程(流水号)编号
	{F}	: 此变量表示当前的流程名称。
	{U}	: 此变量表示当前的流程发起者。
	{Y}	: 此变量表示当前时间的四位年份值，如2008。
	{M}	: 此变量表示当前时间的两位月份值，如12。
	{D}	: 此变量表示当前时间的两位日期值，如31。
	{H}	: 此变量表示当前时间的两位小时值，如08。
	{I}	: 此变量表示当前时间的两位分钟值，如59。
	{S}	: 此变量表示当前时间的两位秒钟值，如59。
	{N}	: 此变量表示当天的系统流水号，{N}表示一位流水号，
	{NNNN}	: 表示五位流水号，最多五位，如00001。
	 * @param 流程ID $lid
	 */
	private function __getNumber($lid){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		$uname	= $CNOA_SESSION->get("TRUENAME");
		
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_list, "WHERE `lid`='{$lid}'");
		
		$flowInfo['number'] = str_replace("{F}", $flowInfo['name'], $flowInfo['number']);
		$flowInfo['number'] = str_replace("{U}", $uname, $flowInfo['number']);
		$flowInfo['number'] = str_replace("{Y}", date("Y", $GLOBALS['CNOA_TIMESTAMP']), $flowInfo['number']);
		$flowInfo['number'] = str_replace("{M}", date("m", $GLOBALS['CNOA_TIMESTAMP']), $flowInfo['number']);
		$flowInfo['number'] = str_replace("{D}", date("d", $GLOBALS['CNOA_TIMESTAMP']), $flowInfo['number']);
		$flowInfo['number'] = str_replace("{H}", date("H", $GLOBALS['CNOA_TIMESTAMP']), $flowInfo['number']);
		$flowInfo['number'] = str_replace("{I}", date("i", $GLOBALS['CNOA_TIMESTAMP']), $flowInfo['number']);
		$flowInfo['number'] = str_replace("{S}", date("s", $GLOBALS['CNOA_TIMESTAMP']), $flowInfo['number']);
		
		//获取编号值
		$NNNN				= preg_replace("/(.*)\{([N]{1,})\}(.*)/i", '\\2', $flowInfo['number']);
		if(strlen($NNNN) < strlen($flowInfo['number'])){
			$NUMM				= str_pad(++$flowInfo['counter'], strlen($NNNN), "0", STR_PAD_LEFT);
			$flowInfo['number'] = str_replace("{".$NNNN."}", $NUMM, $flowInfo['number']);
			//更新编号值
			$CNOA_DB->db_updateNum("counter", "+1", $this->table_list, "WHERE `lid`='{$lid}'");
		}

		return $flowInfo['number'];
	}
	
	/**
	 * 获取某一步骤中涉及到的所有经办人UIDS(从数据库)
	 * @param Int 流程ID $lid
	 * @param Int 步骤ID $stepid
	 * 
	 * @return Array
	 */
	private function __getAllUidsInStep($lid, $stepid){
		global $CNOA_DB, $CNOA_SESSION;
		
		$stepInfo = $CNOA_DB->db_getone("*", $this->table_list_node, "WHERE `lid`='{$lid}' AND `stepid`='{$stepid}'");
		$operator = json_decode($stepInfo['operator'], true);
		
		$uids = array();
		$list = array();
		$list['uid'] = array();
		$list['sid'] = array();

		if(is_array($operator)){
			if($operator['user']){
				foreach($operator['user'] AS $v){
					$uids[$v['uid']] = $v['uid'];
				}
			}
			unset($v);
			if($operator['station']){
				foreach($operator['station'] AS $v){
					$uids_tmp = app::loadApp("main", "user")->api_getUidsByStationId($v['sid']);
					$list['sid'][$v['sid']] = $v['sid'];
					foreach ($uids_tmp AS $v2){
						$uids[$v2] = $v2;
					}
				}
			}
		}
		
		$list['uid'] = $uids;
		
		return $list;
	}
	
	/**
	 * 获取某一步骤中涉及到的所有经办人UIDS(从缓存)
	 * @param Int 流程ID $lid
	 * @param Int 步骤ID $stepid
	 * 
	 * @return Array
	 */
	private function __getAllUidsInStepByOperator($operator){
		global $CNOA_DB, $CNOA_SESSION;

		$operator = json_decode($operator, true);

		$uids = array();
		$list = array();
		$list['uid'] = array();
		$list['sid'] = array();

		if(is_array($operator)){
			if($operator['user']){
				foreach($operator['user'] AS $v){
					$uids[$v['uid']] = $v['uid'];
				}
			}
			unset($v);
			if($operator['station']){
				foreach($operator['station'] AS $v){
					$uids_tmp = app::loadApp("main", "user")->api_getUidsByStationId($v['sid']);
					$list['sid'][$v['sid']] = $v['sid'];
					foreach ($uids_tmp AS $v2){
						$uids[$v2] = $v2;
					}
				}
			}
		}
		
		$list['uid'] = $uids;
		
		return $list;
	}
	
	private function __isUidInStep($uid, $lid, $stepid){	
		$list = $this->__getAllUidsInStep($lid, $stepid);
		
		$isUidInStep = false;
		
		$userInfo = app::loadApp("main", "user")->api_getUserInfoByUids($uid);
		
		if($stepid == 0){
			if(in_array($uid, $list['uid']) || in_array($userInfo['stationid'], $list['sid'])){
				$isUidInStep = true;
			}else{
				if((count($list['uid']) < 1) && (count($list['sid']) < 1)){
					$isUidInStep = true;
				}else{
					$isUidInStep = false;
				}
			}
		}else{
			
		}

		return $isUidInStep;
	}
	
	/**
	 * 添加事件
	 * @param 流程ID $ulid
	 * @param 类型 $type 1=>"开始",2=>"已办理",3=>"撤销",4=>"召回",5=>"退回",6=>"退回上一步",7=>"结束"
	 * @param 步骤ID $step
	 * @param 步骤名称 $stepname
	 * @param 理由 $say
	 */
	private function __eventAdd($ulid, $type, $step, $stepname, $say){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		$uname	= $CNOA_SESSION->get("TRUENAME");
		
		$data	= array();
		$data['uid']		= $uid;
		$data['uname']		= $uname;
		$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['ulid']		= $ulid;
		$data['type']		= $type;
		$data['step']		= $step;
		$data['stepname']	= $stepname;
		$data['say']		= $say;
		
		$CNOA_DB->db_insert($data, $this->table_u_event);
	}
	
	/**
	 * 检查流程完整性
	 * @param 流程ID $lid
	 * @return bool
	 */
	private function __checkFlow($lid){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		
		$flowNodeInfo = $CNOA_DB->db_select("*", $this->table_list_node, "WHERE `lid`='{$lid}'");
		if(!$flowNodeInfo){
			msg::callBack(false, "本流程没有子步骤，不能运行！");
		}
		
		foreach ($flowNodeInfo AS $v){
			if(($v['type']!="start") && ($v['type']!="end")){
				$operator = json_decode($v['operator'], true);
				$uids = array();
				if(is_array($operator)){
					if($operator['user']){
						foreach($operator['user'] AS $v1){
							$uids[$v1['uid']] = $v1['uid'];
						}
					}
					if($operator['station']){
						foreach($operator['station'] AS $v2){
							$uids_tmp = app::loadApp("main", "user")->api_getUidsByStationId($v2['sid']);
							foreach ($uids_tmp AS $v3){
								$uids[$v3] = $v3;
							}
						}
					}
				}
				if(count($uids)<1){
					msg::callBack(false, "本流程步骤: \"".$v['name']."\"(第".($v['stepid']+1)."步)<br>经检测没有经办人，流程将不能继续发布，请与管理员联系！");
				}
			}
		}
	}
	
	/**
	 * 检查表单完整性
	 * @param 流程ID $lid
	 * @return bool
	 */
	private function __checkForm($formid){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		
		//获取表单数据
		$formList = $CNOA_DB->db_select("*", $this->table_form_item, "WHERE `fid`='{$formid}'");
		!is_array($formList) && $formList = array();
		
		$ready = true;
		foreach ($formList AS $v){
			if($v['name'] != "FLOWDATA[{$v['itemid']}]"){
				$ready = false;
			}
		}
		return $ready;
	}
	
	
	/**
	 * 
	 * 查询工作流相关信息
	 * 标题、发起开始/结束时间
	 * 
	 */
	private function __findFlowInfo(){
		$name	= getPar($_POST, 'name');
		$title	= getPar($_POST, 'title');
		$stime	= getPar($_POST, 'beginTime');
		$etime	= getPar($_POST, 'endTime');
		$status	= getPar($_POST, 'status');
		$uid	= getPar($_POST, 'buildUser');
		$sort	= getPar($_POST, 'flowFrom');
		
		$s = '';
		
		//unode可以查询ulist数据 
		
	//cnoa_flow_flow_u_list表下数据 
		if(!empty($uid)){
			$s .= " AND `uid`={$uid}";
		}
		if(!empty($sort)){
			$s .= " AND `sort`={$sort}";
		}
		if(!empty($status) && strval($status) != '-99'){ //当前状态
			$s .= " AND `status` = {$status}";
		}
		if(!empty($name)){ //编号
			$s .= " AND `name` LIKE '%{$name}%'";
		}
		if(!empty($title)){ //标题
			$s .= " AND `title` LIKE '%{$title}%'";
		}
		if(!empty($stime) && empty($etime)){
			$stime = strtotime($stime . " 00:00:00");
			$s .= " AND `posttime` >= {$stime}";
		}		
		if(!empty($etime) && empty($stime)){
			$etime = strtotime($etime . " 23:59:59");
			$s .= " AND `posttime` <= {$etime}";
		}
		if(!empty($stime) && !empty($etime)){
			//在开始与结束时间之间的信息
			$stime = strtotime($stime . " 00:00:00");
			$etime = strtotime($etime . " 23:59:59");
			
			if($stime > $etime){
				msg::callBack(false, "查询开始时间不能大于结束时间");
			}else{
				$s .= " AND `posttime` > {$stime} AND `posttime` < {$etime}";
			}
		}
		
		return " $s ";
	}
	
	
	/**
	 * 分发流程
	 * Enter description here ...
	 */
	private function _dispenseFlow(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		$ulid	= getPar($_POST, "ulid", 0);
		$allUids = getPar($_POST, "allUids", "");
		
		if(empty($allUids)){
			msg::callBack(false, "无选择要分发的人员");
		}
		
		$ds = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}' AND `uid`='{$uid}'");
		
		$allUids = explode(",", $allUids);
		
		foreach($allUids AS $v){
			$data = array();
			$data['uid'] = $uid;
			$data['to_uid'] = $v;
			$data['ulid'] = $ulid;
			$data['posttime'] = $GLOBALS['CNOA_TIMESTAMP'];
			
			$noticeT = "工作流管理";
			$noticeC = "新的待阅的分发工作流";
			if($ds['flowtype'] == "0"){
				$noticeH = "index.php?app=flow&func=flow&action=user&task=loadPage&from=showdispenseflow&ulid=" . $ulid;
			}else{
				$noticeH = "index.php?app=flow&func=flow&action=user&module=commonFlow&task=loadPage&from=showdispenseflow&ulid=" . $ulid;
			}
			
			$data['noticeid_c'] = notice::add($v, $noticeT, $noticeC, $noticeH, 0, 5);
			
			$notice['touid']	= $v;
			$notice['from']		= 5;
			$notice['fromid']	= 0;
			$notice['href']		= $noticeH;
			$notice['title']	= $noticeC;
			$notice['funname']	= "工作流管理";
			$notice['move']		= "阅读";
			$data['todoid_c']	= notice::add2($notice);
			
			$CNOA_DB->db_insert($data, "flow_flow_u_dispense");
		}
		
		//系统操作日志
		$temp = app::loadApp('main', 'user')->api_getUserNamesByUids($allUids);
		foreach($temp as $v){
			$argMan .= "{$v['truename']}, ";
		}
		$argMan = substr($argMan, 0, -2);
		app::loadApp('main', 'systemLogs')->api_addLogs('', 81, $argMan, "分发流程（{$ds['name']}）");
		msg::callBack(true, "操作成功");
	}
	
	/**
	 * 查看分发的流程
	 * Enter description here ...
	 * @param unknown_type $html
	 * @param unknown_type $data
	 */
	private function _getDispenseJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$isread = getPar($_GET, 'isread', 0);
		$start 	= getPar($_POST, 'start', 0);
		$rows  	= 15;
		
		#$dispenseList = $CNOA_DB->db_select("*", "flow_flow_u_dispense", "WHERE `to_uid`='{$uid}'");
			
		//查询相关工作流信息
		$where = $this->__findFlowInfo();
	
		$sql = "SELECT * FROM ".tname($this->table_u_list)." WHERE `ulid` IN (SELECT `ulid` FROM ".tname("flow_flow_u_dispense")." WHERE `to_uid`='{$uid}' AND `isread`='{$isread}') {$where} ";

		$order = " ORDER BY `posttime` DESC LIMIT {$start}, {$rows} ";
		
		$dbList = array();
		$queryList = $CNOA_DB->query($sql.$order);
		while ($list = $CNOA_DB->get_array($queryList)) {
			$dbList[] = $list;
		}
		!is_array($dbList) && $dbList=array();
		
		foreach ($dbList AS $k=>$v){
			//发布时间
			$dbList[$k]['posttime'] = date("Y-m-d H:i", $v['posttime']);
			//重要等级
				if($v['level'] == 2){$dbList[$k]['level'] = "<span class='cnoa_color_orange'>重要</span>";}
			elseif($v['level'] == 3){$dbList[$k]['level'] = "<span class='cnoa_color_red'>非常重要</span>";}
			else{$dbList[$k]['level'] = "普通";}
			//当前步骤
			if($v['status'] == 0){
				$dbList[$k]['step'] = $CNOA_DB->db_getfield("name", $this->table_list_node, "WHERE `lid`='{$v['lid']}' AND `stepid`='0'");
			}else{
				$cacheFile	= @include $this->cachePath . "/flow/user/{$v['ulid']}/" . "flow_node.php";
				$dbList[$k]['step'] = $cacheFile[$v['step']]['name'];
			}
			//状态 -1已删除 0:未发布 1:办理中 2已办理 3已退件 4已撤销
		}
		
		$dataStore = new dataStore();
		$dataStore->total = $CNOA_DB->db_getcount($this->table_u_list, $where);
		$dataStore->data = $dbList;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _show_loadDispenseFlowInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$ulid = getPar($_POST, "ulid", 0);
		
		//获取流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		
		if($flowInfo !== false){
			$flowInfo['uname'] = app::loadApp("main", "user")->api_getUserTruenameByUid($flowInfo['uid']);
		}
		
		$flowInfo['posttime'] = date("Y年m月d日 H时i分", $flowInfo['posttime']);
		
		//当前步骤
		$cacheFile	= @include $this->cachePath . "/flow/user/{$flowInfo['ulid']}/" . "flow_node.php";
		$flowInfo['stepText'] = $cacheFile[$flowInfo['step']]['name'];
		
		//是否允许上传/下载附件
		$flowInfo['allowup'] = $cacheFile[$flowInfo['step']]['allowup'];
		$flowInfo['allowdown'] = $cacheFile[$flowInfo['step']]['allowdown'];

		//获取附件信息
		if($cacheFile[$flowInfo['step']]['type'] == "end"){
			//如果是结束节点，则允许查看附件(不完美)
			$flowInfo['allowdown'] = '1';
		}
		if($flowInfo['allowdown'] == '1'){
			$fs = new fs();
			$flowInfo['attach']		 	= json_decode($flowInfo['attach'], true);
			$flowInfo['attachCount']	= !$flowInfo['attach'] ? 0 : count($flowInfo['attach']);
			$flowInfo['attach']			= $fs->getDownLoadItems4normal($flowInfo['attach'], true);
			//$flowInfo['attach'] = $fs->getXXXXDownLoadFileListByIds(json_decode($flowInfo['attach']));
			//$flowInfo['attachCount'] = count($flowInfo['attach']);
		}else{
			$flowInfo['attachCount'] = 0;
		}
		
		//状态 -1已删除 0:未发布 1:办理中 2已办理 3已退件 4已撤销
			if($flowInfo['status'] == 0){$flowInfo['statusText'] = "未发布";	}
		elseif($flowInfo['status'] == 1){$flowInfo['statusText'] = "办理中";	}
		elseif($flowInfo['status'] == 2){$flowInfo['statusText'] = "已办理";	}
		elseif($flowInfo['status'] == 3){$flowInfo['statusText'] = "已退件";	}
		elseif($flowInfo['status'] == 4){$flowInfo['statusText'] = "已撤销";	}
		
		//获取表单信息
		//表单内容
		$cacheFile_form		 = @include $this->cachePath . "/flow/user/{$ulid}/form.php";
		//表单元素列表
		$cacheFile_form_item = @include $this->cachePath . "/flow/user/{$ulid}/form_item.php";
		//流程步骤列表
		$cacheFile_flow_node = @include $this->cachePath . "/flow/user/{$ulid}/flow_node.php";
		
		//$itemsInfo = json_decode($cacheFile_flow_node[$flowInfo['step']]['formitems'], true);
		
		//获取已有表单数据
		$formData = $CNOA_DB->db_select("*", $this->table_u_formdata, "WHERE `ulid`='{$ulid}'");

		$content = app::loadApp("flow", "flowCommon")->api_parseFormForView($cacheFile_form, $formData, $cacheFile_form_item, $flowInfo);

		//更新已阅
		$info = $CNOA_DB->db_getone("*", "flow_flow_u_dispense", "WHERE `ulid`='{$ulid}' AND `to_uid`='{$uid}'");
		notice::doneN($info['noticeid_c']);
		notice::doneT($info['todoid_c']);
		
		$CNOA_DB->db_update(array("isread"=>1,"viewtime"=>$GLOBALS['CNOA_TIMESTAMP']), "flow_flow_u_dispense", "WHERE `ulid`='{$ulid}' AND `to_uid`='{$uid}'");
		
		$data = array();
		$data['flowInfo'] = $flowInfo;
		$data['formInfo'] = $content;
		$data['formData'] = $formData;
		
		$dataStore = new dataStore();
		$dataStore->total = 0;
		$dataStore->data = $data;
		
		echo $dataStore->makeJsonData();
		exit;
	}
	
	
	//提取已阅读流程用户列表
	private function _getReaderList(){
		global $CNOA_DB;
		$ulid = getPar($_GET, "ulid", 0);
		$dbList = $CNOA_DB->db_select(array("uid","viewtime", "to_uid","isread","say"), "flow_flow_u_dispense", "WHERE `ulid`='{$ulid}'");
		//获取已阅读这的uid
		!is_array($dbList) && $dbList = array();
		$listForm = array();
		$uids = array();
		foreach ($dbList as $v){
			$list = array();
			$list['viewtime'] = empty($v['viewtime']) ? "----" : date("Y-m-d G:i:s",$v['viewtime']);
			$list['to_uid'] = $v['to_uid'];
			$list['say']    = $v['say'];
			$list['isread'] = $v['isread'];
			$readerUids[] = $v['to_uid'];
			$listForm[] = $list;
		}
		
		$userList = app::loadApp("main", "user")->api_getUserInfoByUids($readerUids);
		$depList  = app::loadApp("main", "struct")->api_getArrayList();
		
		foreach ($listForm AS $k=>$v){
			if($v['isread'] == 1){
				$listForm[$k]['name'] = "<font color='#FF0000'>".$userList[$v['to_uid']]['truename']."</font>";
			}else{
				$listForm[$k]['name'] = "<font color='#C0C0C0'>".$userList[$v['to_uid']]['truename']."</font>";
			}
			$listForm[$k]['jid'] = $depList[$userList[$v['to_uid']]['deptId']];
		}

		#debug::xprint($listForm);
		$dataStore = new dataStore();
		$dataStore->data = $listForm;
		echo $dataStore->makeJsonData();
		exit;
	}

	private function _addDispenseSay(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$ulid = getPar($_POST, "ulid", 0);
		$say  = getPar($_POST, "say", "", 1, 0);

		$info = $CNOA_DB->db_getone("*", "flow_flow_u_dispense", "WHERE `ulid`='{$ulid}' AND `to_uid`='{$uid}'");

		if(!$info){
			msg::callBack(false, "此流程没有分发给您，不能发表评阅意见");
		}
		
		$CNOA_DB->db_update(array("say"=>$say), "flow_flow_u_dispense", "WHERE `ulid`='{$ulid}' AND `to_uid`='{$uid}'");
		//系统操作日志
		$name = $CNOA_DB->db_getfield('name', $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		app::loadApp('main', 'systemLogs')->api_addLogs('', 81, $say, "评阅流程（{$name}）");
		msg::callBack(true, "操作成功");
	}
	
	#获取会签人员列表信息
	private function _getHuiQianInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$ulid = getPar($_POST, "ulid", 0);
		
		//找出当前步骤ID
		$step = $CNOA_DB->db_getfield("step", $this->table_u_list, "WHERE `ulid`='{$ulid}'");

		$listdb = $CNOA_DB->db_select("*", $this->table_u_huiqian, "WHERE `ulid`='{$ulid}' AND `stepid`='{$step}' AND `uid`='{$uid}'");
		!is_array($listdb) && $listdb = array();

		$data = array();
		$data['allUids'] = array();
		$data['allUserNames'] = array();
		foreach($listdb AS $v){
			$data['allUids'][] = $v['to_uid'];
		}
		
		$usersInfo = app::loadApp("main", "user")->api_getUserNamesByUids($data['allUids']);
		foreach ($data['allUids'] AS $k=>$v){
			$data['allUserNames'][] = $usersInfo[$v]['truename'];
		}

		$data['allUids']		= implode(",", $data['allUids']);
		$data['allUserNames']	= implode(",", $data['allUserNames']);
		
		$dataStore = new dataStore();
		$dataStore->data = $data;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	#设置会签人员列表
	private function _setHuiQianInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid			= $CNOA_SESSION->get("UID");
		$ulid			= getPar($_POST, "ulid", 0);
		$allUserNames	= getPar($_POST, "allUserNames", "");
		$allUids		= getPar($_POST, "allUids", "");

		//找出当前步骤ID
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		
		if(!empty($allUids)){
			$allUids		= explode(",", $allUids);
			if(count($allUids)>0 && is_array($allUids)){
				//删除去除的数据
				$CNOA_DB->db_delete($this->table_u_huiqian, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}' AND `uid`='{$uid}' AND `to_uid` NOT IN (".implode(",", $allUids).")");

				//取出已有的数据
				$to_uid_list = array();
				$listdb = $CNOA_DB->db_select(array("to_uid"), $this->table_u_huiqian, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}' AND `uid`='{$uid}'");
				!is_array($listdb) && $listdb = array();
				foreach($listdb AS $v){
					$to_uid_list[] = $v['to_uid'];
				}

				foreach($allUids AS $v){
					//判断当前数据是否存在
					if(!in_array($v, $to_uid_list)){
						$data = array();
						$data['uid']		= $uid;
						$data['to_uid']		= $v;
						$data['ulid']		= $ulid;
						$data['posttime']	= $GLOBALS['CNOA_TIMESTAMP'];
						$data['isread']		= 0;
						$data['stepid']		= $flowInfo['step'];
						
						$noticeT = "工作流管理";
						$noticeC = "新工作流程会签办理请求[" . $flowInfo['name'] . "]";
						if($flowInfo['flowtype'] == '0'){
							$noticeH = $this->viewUrl . $ulid;
						}else{
							$noticeH = $this->viewUrlCommonFlow . $ulid;
						}
						$data['noticeid_c'] = notice::add($v, $noticeT, $noticeC, $noticeH, 0, 5, $id);
						
						$notice['touid']	= $v;
						$notice['from']		= 5;
						$notice['fromid']	= 0;
						$notice['href']		= $noticeH;
						$notice['title']	= $noticeC;				
						$notice['funname']	= "工作流管理";
						$notice['move']		= "会签";
						$data['todoid_c'] = notice::add2($notice);
						
						$id = $CNOA_DB->db_insert($data, $this->table_u_huiqian, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}' AND `uid`='{$uid}'");

						
					}
				}
			}else{
				
			}
		}else{
			$CNOA_DB->db_delete($this->table_u_huiqian, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}' AND `uid`='{$uid}'");
		}
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('', 75, $allUserNames, "设置流程（{$flowInfo['name']}）会签人员");
		msg::callBack(true, "操作成功");
		
	}

	/**/
	#载入会签办理内容
	private function _loadHuiQianInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid			= $CNOA_SESSION->get("UID");
		$ulid			= getPar($_POST, "ulid", 0);
		$say			= getPar($_POST, "say", "");

		#取出该流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}'");

		$dblist = $CNOA_DB->db_getone("*", $this->table_u_huiqian, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}' AND `to_uid`='{$uid}'");
		!is_array($dblist) && $dblist = array();
		
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	

	#提交会签办理内容
	private function _submitHuiQianInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid			= $CNOA_SESSION->get("UID");
		$ulid			= getPar($_POST, "ulid", 0);
		$say			= getPar($_POST, "say", "");

		#取出该流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}'");

		#获取待办和提醒id，更新待办状态
		$temp = $CNOA_DB->db_getone("*", $this->table_u_huiqian, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}' AND `to_uid`='{$uid}'");
		
		#如果步骤已经过(主办人办理了流程,流程已经进入了下个步骤)
		if(!$temp){
			#结束掉此流程的所有会签意见列表
			$temp = $CNOA_DB->db_select("*", $this->table_u_huiqian, "WHERE `ulid`='{$ulid}' AND `to_uid`='{$uid}' AND `stepid`<'{$flowInfo['step']}'");
			!is_array($temp) && $temp = array();
			foreach($temp AS $v){
				notice::doneN($v['noticeid_c']);
				notice::doneT($v['todoid_c']);
			}
			msg::callBack(false, "会签失败，可能流程已经进入了下一个步骤");
		}

		$data = array();
		$data['uid']		= $flowInfo['uid'];
		$data['to_uid']		= $uid;
		$data['ulid']		= $ulid;
		$data['isread']		= 1;
		$data['viewtime']	= $GLOBALS['CNOA_TIMESTAMP'];
		$data['say']		= $say;

		$CNOA_DB->db_update($data, $this->table_u_huiqian, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}' AND `to_uid`='{$uid}'");
		
		#添加事件日志
		$stepName = $CNOA_DB->db_getfield("nodename", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}'");
		$this->__eventAdd($ulid, 2, $flowInfo['step'], "{$stepName}", "[会签] ".$data['say']);
		
		
		$noticeT = "会签通知";
		$noticeC = $CNOA_SESSION->get("TRUENAME") . " 已会签，办理意见：<br>" . $say;
		$noticeH = $this->viewUrl . $ulid;
		if($flowInfo['flowtype'] == '0'){
			$noticeH = $this->viewUrl . $ulid;
		}else{
			$noticeH = $this->viewUrlCommonFlow . $ulid;
		}
		$data['noticeid_c'] = notice::add($temp['uid'], $noticeT, $noticeC, $noticeH, 0, 5);
		
		notice::doneN($temp['noticeid_c']);
		notice::doneT($temp['todoid_c']);
		
		msg::callBack(true, "操作成功");
	}
	
	#设置转办
	private function _setZhuangbanInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid	= $CNOA_SESSION->get("UID");
		$uname	= $CNOA_SESSION->get("TRUENAME");
		$ulid	= getPar($_POST, "ulid", 0);
		$tuid	= getPar($_POST, "uid", 0);
		$say  	= getPar($_POST, "say", "", 1, 0);
		
		$tuname = app::loadApp("main", "user")->api_getUserTruenameByUid($tuid);

		//找出当前步骤ID
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$ulid}'");
		
		//修正步骤表数据
		$CNOA_DB->db_update(array("uid"=>$tuid), $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}'");
		
		#添加事件日志
		$stepName = $CNOA_DB->db_getfield("nodename", $this->table_u_node, "WHERE `ulid`='{$ulid}' AND `stepid`='{$flowInfo['step']}'");
		$this->__eventAdd($ulid, 2, $flowInfo['step'], "{$stepName}", "[转办] 转办给 {$tuname}办理, 转办内容：<br>".addslashes($say));
		
		$noticeT = "{$uname} 把工作流转给你办理";
		$noticeC = $flowInfo['name'];
		if($flowInfo['flowtype'] == '0'){
			$noticeH = $this->viewUrl . $ulid;
		}else{
			$noticeH = $this->viewUrlCommonFlow . $ulid;
		}
		notice::add($tuid, $noticeT, $noticeC, $noticeH, 0, 5, 0);
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('', 75, $tuname, "转办工作流（{$flowInfo['name']}）");
		msg::callBack(true, "操作成功");
	}

	private function __addDespanseSayDefault($uid, $ulid){
		global $CNOA_DB;

		$info = $CNOA_DB->db_getone("*", "flow_flow_u_dispense", "WHERE `ulid`='{$ulid}' AND `to_uid`='{$uid}'");
		
		if($info['say'] == ""){
			notice::doneN($info['noticeid_c']);
			notice::doneT($info['todoid_c']);
			$CNOA_DB->db_update(array("isread"=>1,"viewtime"=>$GLOBALS['CNOA_TIMESTAMP'],"say"=>"已阅"), "flow_flow_u_dispense", "WHERE `ulid`='{$ulid}' AND `to_uid`='{$uid}'");
		}
	}

	private function _getAutoSaveFormData(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid  = $CNOA_SESSION->get("UID");
		$lid = getPar($_POST, "lid", 0);

		$info = $CNOA_DB->db_getone("*", "flow_flow_form_auto_save", "WHERE `lid`='{$lid}' AND `uid`='{$uid}'");
		$dataStore = new dataStore();
		
		$dataStore->data = $info['data'];
		echo $dataStore->makeJsonData();
		exit;
	}
	
	private function _setAutoSaveFormData(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid  = $CNOA_SESSION->get("UID");
		$lid  = getPar($_POST, "lid", "");
		$data = addslashes($_POST['data']);
		
		$info = $CNOA_DB->db_getone("*", "flow_flow_form_auto_save", "WHERE `lid`='{$lid}' AND `uid`='{$uid}'");
		if($info ===false){
			$CNOA_DB->db_insert(array("lid" => $lid,"uid"=>$uid,"data"=>$data), "flow_flow_form_auto_save");
		}else{
			$CNOA_DB->db_update(array("data"=>$data), "flow_flow_form_auto_save","WHERE `lid`='{$lid}' AND `uid`='{$uid}'");
		}
		
		msg::callBack(true,"操作成功");
	}
	
	public function api_replaceHTML($html, $data){
		$this->replaceHTML($html, $data);
	}
	
	/**
	 * 获取工作流进度接口
	 */
	public function api_getProgressList($ulid){
		$_GET['ulid'] = $ulid;
		$this->_getProgressList();
	}
	
	public function api_takeViewFlowList(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid = $CNOA_SESSION->get("UID");
		$dblist = $CNOA_DB->db_select(array("ulid","title", "name"), $this->table_u_list, "WHERE `uid`={$uid}");
		!is_array($dblist) && $dblist = array();
		foreach ($dblist as $k=>$v) {
			if(!empty($v['title'])){
				$add = "( " . $v['title'] . " )";
			}
			$dblist[$k]['title'] = $v['name'] . $add; 
			unset($add);
		}
		$dataStore = new dataStore();
		$dataStore->data = $dblist;
		echo $dataStore->makeJsonData();
		exit();
	}
	
	public function api_show_loadFlowInfo(){
		$this->_show_loadFlowInfo();
	}
	
	public function api_GetFlowName($ulid){
		global $CNOA_DB;
		return $CNOA_DB->db_getfield("name", $this->table_u_list, "WHERE `ulid`={$ulid}");
	}
	
	public function api_getMyFlowJsonData(){
		$this->_getMyFlowJsonData();
	}
	public function api_getMyFlowJsonDataByulid($ulid){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$start 	= getPar($_POST, 'start', 0);
		$rows  	= 15;
		$sort	= intval(getPar($_POST, 'sort', 0));

		if($sort == 0){
			$where = "WHERE `uid`='{$uid}' ";
		}else{
			$where = "WHERE `sort`='{$sort}' AND `uid`='{$uid}'";
		}
		
		
		//查询相关工作流信息
		$where .= $this->__findFlowInfo();
		
		if(!is_array($ulid)){
			$where .= "AND `ulid` = '{$ulid}' ";
		}else{
			if(!empty($ulid)){
				$where .= "AND `ulid` IN (" . implode(",", $ulid) . ") ";
			}else{
				return array();
			}
		}
		
		$order = "ORDER BY `posttime` DESC LIMIT {$start}, {$rows} ";
		
		$dbList = $CNOA_DB->db_select("*", $this->table_u_list, $where . $order);
		!is_array($dbList) && $dbList=array();
		
		foreach ($dbList AS $k=>$v){
			//发布时间
			$dbList[$k]['posttime'] = date("Y-m-d H:i", $v['posttime']);
			//重要等级
				if($v['level'] == 2){$dbList[$k]['level'] = "<span class='cnoa_color_orange'>重要</span>";}
			elseif($v['level'] == 3){$dbList[$k]['level'] = "<span class='cnoa_color_red'>非常重要</span>";}
			else{$dbList[$k]['level'] = "普通";}
			//当前步骤
			if($v['status'] == 0){
				$dbList[$k]['step'] = $CNOA_DB->db_getfield("name", $this->table_list_node, "WHERE `lid`='{$v['lid']}' AND `stepid`='0'");
			}else{
				$cacheFile	= @include $this->cachePath . "/flow/user/{$v['ulid']}/" . "flow_node.php";
				$dbList[$k]['step'] = $cacheFile[$v['step']]['name'];
			}
			//状态 -1已删除 0:未发布 1:办理中 2已办理 3已退件 4已撤销
		}
		
		return $dbList;
	}
	
	public function api_eventAdd($ulid, $type, $step, $stepName, $say){
		$this->__eventAdd($ulid, $type, $step, $stepName, $say);
	}

	public function __clearAutoSaveFormData($lid){
		global $CNOA_DB, $CNOA_SESSION;
		$uid  = $CNOA_SESSION->get("UID");

		$CNOA_DB->db_delete("flow_flow_form_auto_save", "WHERE `lid`='{$lid}' AND `uid`='{$uid}'");
	}
}



