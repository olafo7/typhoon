<?php
/**
 * cnoa framework
 *
 * @package		cnoa
 * @author		cnoa Dev Team & Linxiaoqing
 * @email		linxiaoqing@live.com
 * @copyright	Copyright (c) 2011, cnoa, Inc.
 * @license		http://cnoa.com/user_guide/license.html
 * @since		Version 1.4.0
 * @filesource
 */
/**
 * 内部调用专用模块
 * 供 flowFlow.class.php -> actionSetting() 调用
 * @author Administrator
 *
 */ 
class flowFlowFmanger extends model{
	//流程分类表
	private $table_sort			= "flow_flow_sort";
	//流程分类查看对照表
	private $table_dept_sort	= "flow_flow_dept_sort";
	//流程分类删除对照表
	private $table_user_sort	= "flow_flow_user_sort";
	//流程表
	private $table_list			= "flow_flow_list";
	//流程节点表
	private $table_list_node	= "flow_flow_list_node";
	//流程表单表
	private $table_form			= "flow_flow_form";
	//流程表单表单列表表
	private $table_form_item	= "flow_flow_form_item";
	
	//流程列表
	private $table_u_list		= "flow_flow_u_list";
	//流程节点表
	private $table_u_node		= "flow_flow_u_node";
	//工作表单数据表
	private $table_u_formdata	= "flow_flow_u_formdata";
	//事件表
	private $table_u_event		= "flow_flow_u_event";
	//委托表
	private $table_u_entrust	= "flow_flow_u_entrust";
	
	private $table_sort_permit	= "news_news_sort_permit";
	
	//缓存路径
	private $cachePath			= "";
	
	public function __construct(){
		$this->cachePath = CNOA_PATH_FILE . "/cache";
	}
	
	public function run(){
		global $CNOA_SESSION;
		
		$task = getPar($_GET, 'task', getPar($_POST, 'task'));
		
		/* 总 */
		if($task == "loadPage"){
			//载入页面
			$this->_loadPage();
		}
		
		/* 分类相关 */
		elseif($task == "sortGetJsonData"){
			//读取分类列表数据
			$this->_sortGetJsonData();
		}elseif($task == "sortAdd"){
			//添加分类
			$this->_sortAdd();
		}elseif($task == "sortEdit"){
			//修改分类
			$this->_sortEdit();
		}elseif($task == "sortDelete"){
			//删除分类
			$this->_sortDelete();
		}elseif($task == "sortLoadFormData"){
			//修改前载入数据
			$this->_sortLoadFormData();
		}
		
		/* 流程相关 */
		elseif($task == "getFlowJsonData"){
			//获取流程列表数据
			$this->_getFlowJsonData();
		}elseif($task == "flowadd"){
			$this->_flowadd();
		}elseif($task == "flowedit"){
			$this->_flowedit();
		}elseif($task == "floweditLoadForm"){
			$this->_floweditLoadForm();
		}elseif($task == "flowdelete"){
			$this->_flowdelete();
		}elseif($task == "flowdesignLoadData"){
			//获取流程设计数据，提供给前台设计用
			$this->_flowdesignLoadData();
		}elseif($task == "flowdesignSubmitData"){
			//提交流程设计数据
			$this->_flowdesignSubmitData();
		}elseif($task == "setFlowPublish"){
			//设置流程为可用/禁用
			$this->_setFlowPublish();
		}elseif($task == "getAllFlowJsonData"){
			//获取所有流程列表，以供删除
			$this->_getAllFlowJsonData();
		}elseif($task == "deleteflow"){
			//删除流程 - 任何状态的
			$this->_deleteflow();
		}elseif($task == "exportExcel"){
			$this->_exportExcel();
		}
		
		/* 表单相关 */
		elseif($task == "getFormJsonData"){
			//获取流程列表数据
			$this->_getFormJsonData();
		}elseif($task == "formAdd"){
			$this->_formAdd();
		}elseif($task == "formEdit"){
			$this->_fromEdit();
		}elseif($task == "formeditLoadForm"){
			$this->_formeditLoadForm();
		}elseif($task == "formdelete"){
			$this->_formdelete();
		}elseif($task == "formdesign"){
			$this->_formdesign();
		}elseif($task == "saveFormDesignData"){
			$this->_saveFormDesignData();
		}
		
		/* 综合类 */
		elseif($task == "getSortList"){
			//获取分类列表(tree)
			$this->_getSortList();
		}
		elseif($task == "getFormList"){
			//获取表单列表
			$this->_getFormList();
		}
		elseif($task == "getAllUserListsInPermitDeptTree"){
			//获取人员选择树
			$this->_getAllUserListsInPermitDeptTree();
		}elseif ($task == "getStructTree"){
			$this->_getStructTree();
		}
	}
	
	/************************* ∨总程序∨ **********************/
	private function _loadPage(){
		global $CNOA_SESSION, $CNOA_CONTROLLER;
		
		$from = getPar($_GET, "from", "");
		
		if ($from == "flow"){
			//载入流程设计汇总页面
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/setting_flow.htm';
		}elseif ($from == "form"){
			//载入表单设计汇总页面
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/setting_form.htm';
		}elseif ($from == "sort"){
			//载入流程分类汇总页面
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/setting_sort.htm';
		}elseif ($from == "mgr"){
			//载入流程分类汇总页面
			$tplPath = $CNOA_CONTROLLER->appPath . '/tpl/default/flow/fmanger_mgr.htm';
		}
		
		$CNOA_CONTROLLER->loadExtraTpl($tplPath);
		exit;
	}
	

	/************************* ∧表单相关程序∧ **********************/
	
	/************************* ∨综合类∨ **********************/
	public function _getSortList(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  	= $CNOA_SESSION->get("UID");
		
		$type	= getPar($_GET, "type", "combo");
		$myJobType = $CNOA_SESSION->get("JOBTYPE");
		
		if($myJobType == "superAdmin"){
			$dblist = $CNOA_DB->db_select("*", $this->table_sort, "WHERE 1 ORDER BY `order` ASC");
		}else{
			$deptId	= $CNOA_DB->db_getone("*","main_user","WHERE `uid` = '{$uid}'");
		
			$ssid	= $CNOA_DB->db_select("*",$this->table_dept_sort,"WHERE `deptId` = '{$deptId['deptId']}'");
			
			$sids = array(0);
			foreach ($ssid as $v){
				$sids[] = $v['sid'];
				
			}
			$dblist = $CNOA_DB->db_select("*", $this->table_sort, "WHERE `sid` IN (".implode(",", $sids).") ORDER BY `order` ASC");
			
		}
		
		
		!is_array($dblist) && $dblist = array();
		
		if($type == "tree"){
			$list = array();
			foreach ($dblist as $v) {
				$r = array();
				$r['text']	= $v['name'];
				$r['sid']	= $v['sid'];
				$r['iconCls']	= "icon-style-page-key";
				$r['leaf']	= true;
				$r['href']	= "javascript:void(0);";
				//if($this->_private_sortAllow($r['sid'])){
				$list[]	= $r;
				//}
			}
			echo json_encode($list);
			exit;
		}elseif($type == 'combo'){
			$dataStore = new dataStore();
			$dataStore->total = count($dblist);
			$dataStore->data = $dblist;
			
			echo $dataStore->makeJsonData();
			exit;
		}
	}

	/**
	 * 管理流程 - 查看所有流程
	 * Enter description here ...
	 */
	private function _getAllFlowJsonData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		$start 	= getPar($_POST, 'start', 0);
		$rows  	= 15;
		$sort	= intval(getPar($_POST, 'sort', 0));
		
		$myJobType = $CNOA_SESSION->get("JOBTYPE");
		
		if($myJobType == "superAdmin"){
			if($sort == 0){
				$where = "WHERE 1";
			}else{
				$where = "WHERE `sort`='{$sort}' ";
			}
		}else {
			if($sort == 0){
				
				$deptId	= $CNOA_DB->db_getone("*","main_user","WHERE `uid` = '{$uid}'");
			
				$ssid	= $CNOA_DB->db_select("*",$this->table_dept_sort,"WHERE `deptId` = '{$deptId['deptId']}'");
				
				$sids = array(0);
				foreach ($ssid as $v){
					$sids[] = $v['sid'];
				}
				$where = "WHERE `sort` IN (".implode(",", $sids).") ";
			}else{
				$where = "WHERE `sort`='{$sort}' ";
			}
		}
		
		//查询相关工作流信息
		$where .= $this->__findFlowInfo();
		
		
		
		$order = "ORDER BY `posttime` DESC LIMIT {$start}, {$rows} ";
		
		$dbList = $CNOA_DB->db_select("*", $this->table_u_list, $where . $order);
		!is_array($dbList) && $dbList=array();
		
		$uids = array();
		foreach ($dbList AS $k=>$v){
			//发布时间
			$dbList[$k]['posttime'] = date("Y-m-d H:i", $v['posttime']);
			//重要等级
				if($v['level'] == 2){$dbList[$k]['level'] = "<span class='cnoa_color_orange'>重要</span>";}
			elseif($v['level'] == 3){$dbList[$k]['level'] = "<span class='cnoa_color_red'>非常重要</span>";}
			else{$dbList[$k]['level'] = "普通";}
			//当前步骤
			if($v['status'] == 0){
				$dbList[$k]['step'] = $CNOA_DB->db_getfield("name", $this->table_list_node, "WHERE `lid`='{$v['lid']}' AND `stepid`='0'");
			}else{
				$cacheFile	= @include $this->cachePath . "/flow/user/{$v['ulid']}/" . "flow_node.php";
				$dbList[$k]['step'] = $cacheFile[$v['step']]['name'];
			}
			//状态 -1已删除 0:未发布 1:办理中 2已办理 3已退件 4已撤销

			//获取已阅待阅情况 despanseStatus
			//$CNOA_DB->db_update(array("isread"=>1,"viewtime"=>$GLOBALS['CNOA_TIMESTAMP'],"say"=>"已阅"), "flow_flow_u_dispense", "WHERE `ulid`='{$ulid}' AND `to_uid`='{$uid}'");
			$dbList[$k]['despanseStatus'] = $CNOA_DB->db_getfield("isread", "flow_flow_u_dispense", "WHERE `ulid`='{$v['ulid']}' AND `to_uid`='{$uid}'");
			
			if(!$dbList[$k]['despanseStatus'] || $dbList[$k]['despanseStatus']==0){
				$dbList[$k]['despanseStatus'] = "未阅";
			}else{
				$dbList[$k]['despanseStatus'] = "已阅";
			}
			
			$uids[$v['uid']] = $v['uid'];
		}
		
		$userNames = app::loadApp("main", "user")->api_getUserNamesByUids($uids);
		foreach ($dbList AS $key=>$value){
			$dbList[$key]['uname'] = $userNames[$value['uid']]['truename'];
		}
		
		$delbtn	= $this->_flowDelBtn();
		
		$dataStore = new dataStore();
		$dataStore->total = $CNOA_DB->db_getcount($this->table_u_list, $where);
		$dataStore->data = $dbList;
		$dataStore->hasDel = $delbtn;
		echo $dataStore->makeJsonData();
		exit;
	}
	
	//处理流程删除按钮
	private function _flowDelBtn(){
		global $CNOA_DB ,$CNOA_SESSION;
		
		$myJobType = $CNOA_SESSION->get("JOBTYPE");
		$uid  = $CNOA_SESSION->get("UID");
		$sort = intval(getPar($_POST, "sort",""));
		
		if($myJobType == "superAdmin"){
			return true;
		}
		
		if($sort == 0){
			return false;
		}
		
		$info = $CNOA_DB->db_getone("*",$this->table_user_sort,"WHERE `sid` = '{$sort}' AND `allUid` = '{$uid}' ");
		if($info === false){
			return false;
		}else{
			return true;
		}
	}
	
	/**
	 * 导出数据给Excel生成报表用
	 */
	private function _exportExcel(){
		global $CNOA_SESSION;

		$uid   = intval(getPar($_POST, "uid", ""));
		$stime = strtotime(getPar($_POST, "stime", "0000-00-00")." 00:00:00");
		$etime = strtotime(getPar($_POST, "etime", "0000-00-00")." 23:59:59");
		
		$truename	= app::loadApp("main", "user")->api_getUserTruenameByUid($uid);

		if($stime>=$etime){
			msg::callBack(false, "结束时间不能早于开始时间");
		}

		$fileName = "CNOA.FLOW-".$uid.date("Ymd", $stime)."-".date("Ymd", $etime)."-".string::rands(10, 2).".xls";
		$dataInfo = $this->_getExportExcelData($stime, $etime);
		$excelClass = app::loadApp("flow", "flowExportExcel");
		$excelClass->init($dataInfo, $truename, $stime, $etime);
		$excelClass->save(CNOA_PATH_FILE. "/common/temp/". $fileName);
		//系统操作日志
		$truename = app::loadApp('main', 'user')->api_getUserTruenameByUid($uid);
		app::loadApp('main', 'systemLogs')->api_addLogs('', 81, "条件：{$truename}, ".date('Y-m-d', $stime)."--".date('Y-m-d', $etime), "导出excel报表");
		
		msg::callBack(true, makeDownLoadIcon("file/common/temp/". $fileName, $fileName, "img"));
		//msg::callBack(true, "file/common/temp/". $fileName);
	}
	
	/**
	 * 生成数据，导出数据给Excel生成报表用
	 */
	private function _getExportExcelData(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = intval(getPar($_POST, "uid", ""));
		$stime = strtotime(getPar($_POST, "stime", "0000-00-00")." 00:00:00");
		$etime = strtotime(getPar($_POST, "etime", "0000-00-00")." 23:59:59");

		$where  = "WHERE `uid`='{$uid}' AND `status`>0 ";
		$where .= "AND `posttime`>='{$stime}' AND `posttime`<='{$etime}' ";
		$where .= "ORDER BY `posttime` ASC ";
		
		$dbList = $CNOA_DB->db_select("*", $this->table_u_list, $where);
		!is_array($dbList) && $dbList=array();
		
		foreach ($dbList AS $k=>$v){
			//发布时间
			$dbList[$k]['posttime'] = date("Y-m-d H:i", $v['posttime']);
			//重要等级
				if($v['level'] == 2){$dbList[$k]['level'] = "重要";}
			elseif($v['level'] == 3){$dbList[$k]['level'] = "非常重要";}
			else{$dbList[$k]['level'] = "普通";}
			//当前步骤
			if($v['status'] == 0){
				$dbList[$k]['step'] = $CNOA_DB->db_getfield("name", $this->table_list_node, "WHERE `lid`='{$v['lid']}' AND `stepid`='0'");
			}else{
				$cacheFile	= @include $this->cachePath . "/flow/user/{$v['ulid']}/" . "flow_node.php";
				$dbList[$k]['step'] = $cacheFile[$v['step']]['name'];
			}
			
			//状态 -1已删除 0:未发布 1:办理中 2已办理 3已退件 4已撤销
			$dbList[$k]['statusText'] = "";
			if($v['status'] == 0){$dbList[$k]['statusText'] = "未发送";}
			else if($v['status'] == 1){$dbList[$k]['statusText'] = "办理中";}
			else if($v['status'] == 2){$dbList[$k]['statusText'] = "已办理";}
			else if($v['status'] == 3){$dbList[$k]['statusText'] = "已退件";}
			else if($v['status'] == 4){$dbList[$k]['statusText'] = "已撤销";}
		}
		
		return $dbList;
		exit;
	}
	
	private function _deleteflow(){
		
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		$ulids = getPar($_POST, "ulids", 0);
		$ulids = substr($ulids, 0, -1);
		$ulidArr = explode(",", $ulids);
		//系统操作日志
		$DB = $CNOA_DB->db_select(array('name'), $this->table_u_list, "WHERE `ulid` IN ({$ulids})");
		$names = '';
		foreach($DB as $v){
		    $names .= "{$v['name']}, ";
		} 
		$names = substr($names, 0, -2);
		
		foreach ($ulidArr as $v){
			//从主表删除
			$CNOA_DB->db_delete($this->table_u_list, "WHERE `ulid`='{$v}'");
			
			//从节点表删除
			$CNOA_DB->db_delete($this->table_u_node, "WHERE `ulid`='{$v}'");
			
			//从表单表删除
			$CNOA_DB->db_delete($this->table_u_formdata, "WHERE `ulid`='{$v}'");
			
			//从日志表删除
			$CNOA_DB->db_delete($this->table_u_event, "WHERE `ulid`='{$v}'");
			
			//从缓存删除
			$cachePath	= $this->cachePath . "/flow/user/{$v}/";
		}
		
		$cacheFile  = array();
		$cacheFile['flow']		= $cachePath . "flow.php";
		$cacheFile['flow_node']	= $cachePath . "flow_node.php";
		$cacheFile['form']		= $cachePath . "form.php";
		$cacheFile['form_item']	= $cachePath . "form_item.php";
		foreach ($cacheFile AS $v1){
			@unlink($v1);
		}
		@rmdir($cachePath);
		
		//从附件表删除
		$fs = new fs();
		$fs->deleteFile(json_decode($flowInfo['attach'], true));
		
		//系统操作日志
		app::loadApp('main', 'systemLogs')->api_addLogs('del', 81, $names, '流程');
		msg::callBack(true, "操作成功");
	}
	
	private function _getAllUserListsInPermitDeptTree(){
		$GLOBALS['user']['permitArea']['area'] = "all";

		$userList = app::loadApp("main", "user")->api_getAllUserListsInPermitDeptTree();
			
		echo json_encode($userList);
		exit;
	}
	
	/**
	 * 
	 * 查询工作流相关信息
	 * 标题、发起开始/结束时间
	 * 
	 */
	private function __findFlowInfo(){
		$name		= getPar($_POST, 'name');
		$title		= getPar($_POST, 'title');
		$document	= getPar($_POST, 'document');
		//$stime	= getPar($_POST, 'startTime', "0000-00-00");
		//$etime	= getPar($_POST, 'endTime', "0000-00-00");
		$stime	= getPar($_POST, 'beginTime');
		$etime	= getPar($_POST, 'endTime');
		$status	= getPar($_POST, 'status');
		$uid	= getPar($_POST, 'buildUser');
		
		$s = '';
		
		//unode可以查询ulist数据 
		
	//cnoa_flow_flow_u_list表下数据 
		if(!empty($uid)){
			$s .= " AND `uid`={$uid}";
		}
		if(!empty($status) && strval($status) != '-99'){ //当前状态
			$s .= " AND `status` = {$status}";
		}
		if(!empty($name)){ //编号
			$s .= " AND `name` LIKE '%{$name}%'";
		}
		if(!empty($title)){ //标题
			$s .= " AND `title` LIKE '%{$title}%'";
		}
		if(!empty($document)){ //公文文号
			$s .= " AND `document` LIKE '%{$document}%'";
		}
		if(!empty($stime) && empty($etime)){
			$stime = strtotime($stime . " 00:00:00");
			$s .= " AND `posttime` >= {$stime}"; 
		}
		if(!empty($etime) && empty($stime)){
			$etime = strtotime($etime . " 23:59:59");
			$s .= " AND `posttime` <= {$etime}";
		}		
		if(!empty($stime) && !empty($etime)){
			//在开始与结束时间之间的信息
			$stime = strtotime($stime . " 00:00:00");
			$etime = strtotime($etime . " 23:59:59");
			
			if($stime > $etime){
				msg::callBack(false, "查询开始时间不能大于结束时间");
			}else{
				$s .= " AND `posttime` > {$stime} AND `posttime` < {$etime}";
			}
			
		}
		return " $s ";
	}
	
}

?>