<?php
/**
 * cnoa framework
 *
 * @package		cnoa
 * @author		cnoa Dev Team & Linxiaoqing
 * @email		linxiaoqing@live.com
 * @copyright	Copyright (c) 2011, cnoa, Inc.
 * @license		http://cnoa.com/user_guide/license.html
 * @since		Version 1.4.0
 * @filesource
 */
class flowFlowExportHtml extends model{
	//流程分类表
	private $table_sort			= "flow_flow_sort";
	//流程表
	private $table_list			= "flow_flow_list";
	//流程节点表
	private $table_list_node	= "flow_flow_list_node";
	//流程表单表
	private $table_form			= "flow_flow_form";
	//流程表单表单列表表
	private $table_form_item	= "flow_flow_form_item";
	
	//流程列表
	private $table_u_list		= "flow_flow_u_list";
	//流程节点表
	private $table_u_node		= "flow_flow_u_node";
	//工作表单数据表
	private $table_u_formdata	= "flow_flow_u_formdata";
	//事件表
	private $table_u_event		= "flow_flow_u_event";
	//委托表
	private $table_u_entrust	= "flow_flow_u_entrust";
	//分发表
	private $table_u_dispense	= "flow_flow_u_dispense";
	
	private $eventType			= array(1=>"开始",2=>"已办理",3=>"撤销",4=>"召回",5=>"退件",6=>"退回上一步",7=>"结束");
	
	//状态说明
	private $statusType			= array(1=>"办理中", 2=>"已办理", 3=>"退件");
	
	//委托人状态说明
	private $entrustType		= array(0=>"禁用", 1=>"启用", 2=>"未设置");
	
	private $ulid, $target;
	
	public function __construct(){
		$this->ulid = getPar($_POST, "ulid", getPar($_GET, "ulid", 0));
		$this->cachePath = CNOA_PATH_FILE . "/cache";
		$this->flowInfo = array();
	}
	
	public function init(){
		global $CNOA_DB, $CNOA_SESSION;
		$uid		 = $CNOA_SESSION->get("UID");
		$exportArray = $_SERVER['REQUEST_METHOD']=='POST' ? $_POST['exportArray'] : $_GET['exportArray'];
		$exportArray = json_decode($exportArray, true);
		$this->target= getPar($_GET, "target", "html");
	
		$data = array();
		
		//获取流程基本信息
		//if($exportArray['i'] == 1){
		$data['FlowInfo'] = $this->_getFlowInfo();
		$this->flowInfo = $data['FlowInfo'];
		//}
		
		//获取流程工作表单
		if($exportArray['f'] == 1){
			$data['FlowForm'] = $this->_getFlowForm();
		}
		
		
		//获取流程进度列表
		if($exportArray['p'] == 1){
			$data['FlowProgress'] = $this->_getFlowProgress();
		}
		
		//获取事件列表
		if($exportArray['e'] == 1){
			$data['FlowEvent'] = $this->_getFlowEvent();
		}
		
		//获取分发评阅列表
		if($exportArray['r'] == 1){
			$data['FlowReader'] = $this->_getFlowReader();
		}
		
		$GLOBALS['FLOWDATA'] = $data;
		$GLOBALS['EXPORTCFG'] = $exportArray;
		$this->_makeTempDownFile($data['FlowInfo']['name']);
		
		exit;
	}
	
	private function _getFlowInfo(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		
		//获取流程信息
		$flowInfo = $CNOA_DB->db_getone("*", $this->table_u_list, "WHERE `ulid`='{$this->ulid}'");
		
		if($flowInfo !== false){
			$flowInfo['uname'] = app::loadApp("main", "user")->api_getUserTruenameByUid($flowInfo['uid']);
		}
		
		$flowInfo['posttime'] = date("Y年m月d日 H时i分", $flowInfo['posttime']);
		$flowInfo['flowname'] = $flowInfo['flowname'];
		//当前步骤
		$cacheFile	= @include $this->cachePath . "/flow/user/{$flowInfo['ulid']}/" . "flow_node.php";
		
		$flowInfo['stepText'] = $cacheFile[$flowInfo['step']]['name'];
		
		//状态 -1已删除 0:未发布 1:办理中 2已办理 3已退件 4已撤销
			if($flowInfo['status'] == 0){$flowInfo['statusText'] = "未发布";	}
		elseif($flowInfo['status'] == 1){$flowInfo['statusText'] = "办理中";	}
		elseif($flowInfo['status'] == 2){$flowInfo['statusText'] = "已办理";	}
		elseif($flowInfo['status'] == 3){$flowInfo['statusText'] = "已退件";	}
		elseif($flowInfo['status'] == 4){$flowInfo['statusText'] = "已撤销";	}
		
		return $flowInfo;
	}
	
	private function _getFlowForm(){
		global $CNOA_DB, $CNOA_SESSION;
		
		$uid  = $CNOA_SESSION->get("UID");
		
		//获取表单
		$cacheFile_form		 = @include $this->cachePath . "/flow/user/{$this->ulid}/form.php";
		
		//获取表单数据
		$formData = $CNOA_DB->db_select("*", $this->table_u_formdata, "WHERE `ulid`='{$this->ulid}' ORDER BY `itemid` ASC");
		
		//表单元素列表
		$cacheFile_form_item = @include $this->cachePath . "/flow/user/{$this->ulid}/form_item.php";
		
		$content = app::loadApp("flow", "flowCommon")->api_parseFormForView($cacheFile_form, $formData, $cacheFile_form_item, $this->flowInfo, false);
		
		return $content;
	}
	
	private function _getFlowProgress(){
		global $CNOA_DB, $CNOA_SESSION;
		//安全限制  - 只允许流程参与人查看
		
		$dblist = $CNOA_DB->db_select("*", $this->table_u_node, "WHERE `ulid`='{$this->ulid}' ORDER BY `stepid` ASC");

		if ($dblist !== false){
			$uids = array();
			foreach ($dblist AS $k=>$v){
				$uids[] = $v['uid'];
				$dblist[$k]['statusText'] = $this->statusType[$v['status']];
				$dblist[$k]['stime']	  = date("Y年m月d日 H:i", $v['stime']);
				
				if(($v['status'] == 2) && ($v['stepid']!=0)){
					$dblist[$k]['utime']  = timeFormat2($v['etime'] - $v['stime']);
				}elseif($v['stepid']!=0){
					$dblist[$k]['utime']  = timeFormat2($GLOBALS['CNOA_TIMESTAMP'] - $v['stime']);
				}else{
					$dblist[$k]['utime']  = "----";
				}
			}
			
			$usersInfo = app::loadApp("main", "user")->api_getUserNamesByUids($uids);
			foreach ($dblist AS $k=>$v){
				$dblist[$k]['uname'] = $usersInfo[$v['uid']]['truename'];
			}
			
			$flowStatus = $CNOA_DB->db_getfield("status", $this->table_u_list, "WHERE `ulid`='{$this->ulid}'");
			if($flowStatus == 2){
				$arr = array();
				$arr['ulid']		= $this->ulid;
				$arr['stepid']		= 0;
				$arr['status']		= 2;
				$arr['nodename']	= "结束";
				$arr['stime']		= "";
				$arr['statusText']	= "已办理";
				$arr['utime']		= "----";
				$arr['stime']		= "";
				$arr['uname']		= "<span style='color:green;'>流程已结束</span>";
				$arr['nodetype']	= "end";
				$dblist[] = $arr;
			}
			if($flowStatus == 3){
				$arr = array();
				$arr['ulid']		= $this->ulid;
				$arr['stepid']		= 0;
				$arr['status']		= 2;
				$arr['nodename']	= "结束";
				$arr['stime']		= "";
				$arr['statusText']	= "已退件";
				$arr['utime']		= "----";
				$arr['stime']		= "";
				$arr['uname']		= "<span style='color:green;'>流程已被退回</span>";
				$arr['nodetype']	= "end";
				$dblist[] = $arr;
			}
			if($flowStatus == 4){
				$arr = array();
				$arr['ulid']		= $this->ulid;
				$arr['stepid']		= 0;
				$arr['status']		= 2;
				$arr['nodename']	= "结束";
				$arr['stime']		= "";
				$arr['statusText']	= "已撤销";
				$arr['utime']		= "----";
				$arr['stime']		= "";
				$arr['uname']		= "<span style='color:green;'>流程已撤销</span>";
				$arr['nodetype']	= "end";
				$dblist[] = $arr;
			}
		}

		return $dblist;
	}
	
	private function _getFlowEvent(){
		global $CNOA_DB, $CNOA_SESSION;
		
		//安全限制  - 只允许流程参与人查看
		
		//获取数据
		$dblist = $CNOA_DB->db_select("*", $this->table_u_event, "WHERE `ulid`='{$this->ulid}' ORDER BY `eid` ASC");
		!is_array($dblist) && $dblist = array();
		
		if ($dblist !== false){
			foreach ($dblist AS $k=>$v){
				$dblist[$k]['typename'] = $this->eventType[$v['type']];
				$dblist[$k]['user'] 	  = $v['truename'] . " ("  . timeFormat($v['posttime']) . ")";
				$dblist[$k]['posttime'] = date("Y年m月d日 H:i", $v['posttime']);
			}
		}

		return $dblist;
	}
	
	private function _getFlowReader(){
		global $CNOA_DB, $CNOA_SESSION;
		
		//安全限制  - 只允许流程参与人查看
		
		//获取数据
		$dblist = $CNOA_DB->db_select("*", $this->table_u_dispense, "WHERE `ulid`='{$this->ulid}' ORDER BY `id` ASC");
		!is_array($dblist) && $dblist = array();
		
		$uids = array();
		foreach ($dblist AS $k=>$v){
			$dblist[$k]['posttime'] = date("Y年m月d日 H:i", $v['posttime']);
			$dblist[$k]['say'] = nl2br($v['say']);
			$uids[] = $v['to_uid'];
		}
		
		$userList = app::loadApp("main", "user")->api_getUserNamesByUids($uids);
		$depList  = app::loadApp("main", "struct")->api_getArrayList();
		
		foreach ($dblist AS $k=>$v){
			$dblist[$k]['name'] = $userList[$v['to_uid']]['truename'];
			$dblist[$k]['jid']  = $depList[$userList[$v['to_uid']]['deptId']];
		}
		
		return $dblist;
	}
	
	private function _makeTempDownFile($name){
		global $CNOA_CONTROLLER, $CNOA_DB;
		
		if($this->target == 'printer'){
			include $CNOA_CONTROLLER->appPath . "/tpl/default/flow/export.tpl.html";
			//系统操作日志
			$name =  $CNOA_DB->db_getfield("name", $this->table_u_list, "WHERE `ulid`='{$this->ulid}'");
			app::loadApp('main', 'systemLogs')->api_addLogs('', 1201, $name, "打印流程");
			exit;
		}elseif($this->target == 'word'){
			$tempFile = "file/common/temp/flowInfoExport." . string::rands(40) . ".download";
			
			ob_start();
			include $CNOA_CONTROLLER->appPath . "/tpl/default/flow/export.tpl.html";
			$msdoc = new msdoc(ob_get_contents());
			$msdoc->save($tempFile);
			ob_end_clean();

			//$dataStore = new dataStore();
			//$dataStore->data = array('url'=>$tempFile, 'flowname'=>$name.".doc");
			//echo $dataStore->makeJsonData();
			//exit;
			//系统操作日志
			$name =  $CNOA_DB->db_getfield("name", $this->table_u_list, "WHERE `ulid`='{$this->ulid}'");
			app::loadApp('main', 'systemLogs')->api_addLogs('', 1201, $name, "以word格式导出流程");
			
			msg::callBack(true, makeDownLoadIcon($tempFile, $name.".doc", "img"));
		}elseif($this->target == 'html'){
			$tempFile = "file/common/temp/flowInfoExport." . string::rands(40) . ".download";
			
			ob_start();
			include $CNOA_CONTROLLER->appPath . "/tpl/default/flow/export.tpl.html";

			file_put_contents($tempFile, ob_get_contents());
			ob_end_clean();
			
			//$dataStore = new dataStore();
			//$dataStore->data = array('url'=>$tempFile, 'name'=>$name.".html");
			
			//echo $dataStore->makeJsonData();
			//exit;
			
			//系统操作日志
			$name =  $CNOA_DB->db_getfield("name", $this->table_u_list, "WHERE `ulid`='{$this->ulid}'");
			app::loadApp('main', 'systemLogs')->api_addLogs('', 1201, $name, "以html格式导出流程");
			
			msg::callBack(true, makeDownLoadIcon($tempFile, $name.".html", "img"));
		}elseif($this->target == 'page'){
			//显示我的流程的详细内容模板，因为在其他app中调用，所以写成绝对路径
			include CNOA_PATH . "/app/flow/tpl/default/flow/export.tpl.html";
			exit;
		}
	}
}
?>